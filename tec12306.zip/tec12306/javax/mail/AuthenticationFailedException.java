// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public class AuthenticationFailedException extends MessagingException
{
    private static final long serialVersionUID = 492080754054436511L;
    
    public AuthenticationFailedException() {
    }
    
    public AuthenticationFailedException(final String s) {
        super(s);
    }
    
    public AuthenticationFailedException(final String s, final Exception ex) {
        super(s, ex);
    }
}
