// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import java.util.Enumeration;
import java.io.OutputStream;
import javax.activation.DataHandler;
import java.io.InputStream;

public interface Part
{
    public static final String ATTACHMENT = "attachment";
    public static final String INLINE = "inline";
    
    int getSize();
    
    int getLineCount();
    
    String getContentType();
    
    boolean isMimeType(final String p0);
    
    String getDisposition();
    
    void setDisposition(final String p0);
    
    String getDescription();
    
    void setDescription(final String p0);
    
    String getFileName();
    
    void setFileName(final String p0);
    
    InputStream getInputStream();
    
    DataHandler getDataHandler();
    
    Object getContent();
    
    void setDataHandler(final DataHandler p0);
    
    void setContent(final Object p0, final String p1);
    
    void setText(final String p0);
    
    void setContent(final Multipart p0);
    
    void writeTo(final OutputStream p0);
    
    String[] getHeader(final String p0);
    
    void setHeader(final String p0, final String p1);
    
    void addHeader(final String p0, final String p1);
    
    void removeHeader(final String p0);
    
    Enumeration getAllHeaders();
    
    Enumeration getMatchingHeaders(final String[] p0);
    
    Enumeration getNonMatchingHeaders(final String[] p0);
}
