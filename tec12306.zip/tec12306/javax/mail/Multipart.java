// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import java.io.OutputStream;
import java.util.Vector;

public abstract class Multipart
{
    protected Vector parts;
    protected String contentType;
    protected Part parent;
    
    protected Multipart() {
        this.parts = new Vector();
        this.contentType = "multipart/mixed";
    }
    
    protected synchronized void setMultipartDataSource(final MultipartDataSource multipartDataSource) {
        this.contentType = multipartDataSource.getContentType();
        for (int count = multipartDataSource.getCount(), i = 0; i < count; ++i) {
            this.addBodyPart(multipartDataSource.getBodyPart(i));
        }
    }
    
    public synchronized String getContentType() {
        return this.contentType;
    }
    
    public synchronized int getCount() {
        if (this.parts == null) {
            return 0;
        }
        return this.parts.size();
    }
    
    public synchronized BodyPart getBodyPart(final int n) {
        if (this.parts == null) {
            throw new IndexOutOfBoundsException("No such BodyPart");
        }
        return this.parts.elementAt(n);
    }
    
    public synchronized boolean removeBodyPart(final BodyPart bodyPart) {
        if (this.parts == null) {
            throw new MessagingException("No such body part");
        }
        final boolean removeElement = this.parts.removeElement(bodyPart);
        bodyPart.setParent(null);
        return removeElement;
    }
    
    public synchronized void removeBodyPart(final int n) {
        if (this.parts == null) {
            throw new IndexOutOfBoundsException("No such BodyPart");
        }
        final BodyPart bodyPart = this.parts.elementAt(n);
        this.parts.removeElementAt(n);
        bodyPart.setParent(null);
    }
    
    public synchronized void addBodyPart(final BodyPart bodyPart) {
        if (this.parts == null) {
            this.parts = new Vector();
        }
        this.parts.addElement(bodyPart);
        bodyPart.setParent(this);
    }
    
    public synchronized void addBodyPart(final BodyPart bodyPart, final int n) {
        if (this.parts == null) {
            this.parts = new Vector();
        }
        this.parts.insertElementAt(bodyPart, n);
        bodyPart.setParent(this);
    }
    
    public abstract void writeTo(final OutputStream p0);
    
    public synchronized Part getParent() {
        return this.parent;
    }
    
    public synchronized void setParent(final Part parent) {
        this.parent = parent;
    }
}
