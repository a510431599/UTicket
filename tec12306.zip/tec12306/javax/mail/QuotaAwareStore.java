// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public interface QuotaAwareStore
{
    Quota[] getQuota(final String p0);
    
    void setQuota(final Quota p0);
}
