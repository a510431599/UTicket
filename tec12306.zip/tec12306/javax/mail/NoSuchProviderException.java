// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public class NoSuchProviderException extends MessagingException
{
    private static final long serialVersionUID = 8058319293154708827L;
    
    public NoSuchProviderException() {
    }
    
    public NoSuchProviderException(final String s) {
        super(s);
    }
    
    public NoSuchProviderException(final String s, final Exception ex) {
        super(s, ex);
    }
}
