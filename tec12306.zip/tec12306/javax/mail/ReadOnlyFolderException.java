// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public class ReadOnlyFolderException extends MessagingException
{
    private transient Folder folder;
    private static final long serialVersionUID = 5711829372799039325L;
    
    public ReadOnlyFolderException(final Folder folder) {
        this(folder, null);
    }
    
    public ReadOnlyFolderException(final Folder folder, final String s) {
        super(s);
        this.folder = folder;
    }
    
    public ReadOnlyFolderException(final Folder folder, final String s, final Exception ex) {
        super(s, ex);
        this.folder = folder;
    }
    
    public Folder getFolder() {
        return this.folder;
    }
}
