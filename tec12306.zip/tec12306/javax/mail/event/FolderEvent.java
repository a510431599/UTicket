// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.event;

import javax.mail.Folder;

public class FolderEvent extends MailEvent
{
    public static final int CREATED = 1;
    public static final int DELETED = 2;
    public static final int RENAMED = 3;
    protected int type;
    protected transient Folder folder;
    protected transient Folder newFolder;
    private static final long serialVersionUID = 5278131310563694307L;
    
    public FolderEvent(final Object o, final Folder folder, final int n) {
        this(o, folder, folder, n);
    }
    
    public FolderEvent(final Object o, final Folder folder, final Folder newFolder, final int type) {
        super(o);
        this.folder = folder;
        this.newFolder = newFolder;
        this.type = type;
    }
    
    public int getType() {
        return this.type;
    }
    
    public Folder getFolder() {
        return this.folder;
    }
    
    public Folder getNewFolder() {
        return this.newFolder;
    }
    
    @Override
    public void dispatch(final Object o) {
        if (this.type == 1) {
            ((FolderListener)o).folderCreated(this);
        }
        else if (this.type == 2) {
            ((FolderListener)o).folderDeleted(this);
        }
        else if (this.type == 3) {
            ((FolderListener)o).folderRenamed(this);
        }
    }
}
