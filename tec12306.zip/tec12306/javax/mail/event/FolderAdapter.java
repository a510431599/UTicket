// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.event;

public abstract class FolderAdapter implements FolderListener
{
    @Override
    public void folderCreated(final FolderEvent folderEvent) {
    }
    
    @Override
    public void folderRenamed(final FolderEvent folderEvent) {
    }
    
    @Override
    public void folderDeleted(final FolderEvent folderEvent) {
    }
}
