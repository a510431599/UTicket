// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import java.io.InvalidObjectException;
import java.io.Serializable;
import javax.mail.search.SearchTerm;
import java.util.Date;

public abstract class Message implements Part
{
    protected int msgnum;
    protected boolean expunged;
    protected Folder folder;
    protected Session session;
    
    protected Message() {
        this.msgnum = 0;
        this.expunged = false;
        this.folder = null;
        this.session = null;
    }
    
    protected Message(final Folder folder, final int msgnum) {
        this.msgnum = 0;
        this.expunged = false;
        this.folder = null;
        this.session = null;
        this.folder = folder;
        this.msgnum = msgnum;
        this.session = folder.store.session;
    }
    
    protected Message(final Session session) {
        this.msgnum = 0;
        this.expunged = false;
        this.folder = null;
        this.session = null;
        this.session = session;
    }
    
    public Session getSession() {
        return this.session;
    }
    
    public abstract Address[] getFrom();
    
    public abstract void setFrom();
    
    public abstract void setFrom(final Address p0);
    
    public abstract void addFrom(final Address[] p0);
    
    public abstract Address[] getRecipients(final RecipientType p0);
    
    public Address[] getAllRecipients() {
        final Address[] recipients = this.getRecipients(RecipientType.TO);
        final Address[] recipients2 = this.getRecipients(RecipientType.CC);
        final Address[] recipients3 = this.getRecipients(RecipientType.BCC);
        if (recipients2 == null && recipients3 == null) {
            return recipients;
        }
        final Address[] array = new Address[((recipients != null) ? recipients.length : 0) + ((recipients2 != null) ? recipients2.length : 0) + ((recipients3 != null) ? recipients3.length : 0)];
        int n = 0;
        if (recipients != null) {
            System.arraycopy(recipients, 0, array, n, recipients.length);
            n += recipients.length;
        }
        if (recipients2 != null) {
            System.arraycopy(recipients2, 0, array, n, recipients2.length);
            n += recipients2.length;
        }
        if (recipients3 != null) {
            System.arraycopy(recipients3, 0, array, n, recipients3.length);
            final int n2 = n + recipients3.length;
        }
        return array;
    }
    
    public abstract void setRecipients(final RecipientType p0, final Address[] p1);
    
    public void setRecipient(final RecipientType recipientType, final Address address) {
        this.setRecipients(recipientType, new Address[] { address });
    }
    
    public abstract void addRecipients(final RecipientType p0, final Address[] p1);
    
    public void addRecipient(final RecipientType recipientType, final Address address) {
        this.addRecipients(recipientType, new Address[] { address });
    }
    
    public Address[] getReplyTo() {
        return this.getFrom();
    }
    
    public void setReplyTo(final Address[] array) {
        throw new MethodNotSupportedException("setReplyTo not supported");
    }
    
    public abstract String getSubject();
    
    public abstract void setSubject(final String p0);
    
    public abstract Date getSentDate();
    
    public abstract void setSentDate(final Date p0);
    
    public abstract Date getReceivedDate();
    
    public abstract Flags getFlags();
    
    public boolean isSet(final Flags.Flag flag) {
        return this.getFlags().contains(flag);
    }
    
    public abstract void setFlags(final Flags p0, final boolean p1);
    
    public void setFlag(final Flags.Flag flag, final boolean b) {
        this.setFlags(new Flags(flag), b);
    }
    
    public int getMessageNumber() {
        return this.msgnum;
    }
    
    protected void setMessageNumber(final int msgnum) {
        this.msgnum = msgnum;
    }
    
    public Folder getFolder() {
        return this.folder;
    }
    
    public boolean isExpunged() {
        return this.expunged;
    }
    
    protected void setExpunged(final boolean expunged) {
        this.expunged = expunged;
    }
    
    public abstract Message reply(final boolean p0);
    
    public abstract void saveChanges();
    
    public boolean match(final SearchTerm searchTerm) {
        return searchTerm.match(this);
    }
    
    public static class RecipientType implements Serializable
    {
        public static final RecipientType TO;
        public static final RecipientType CC;
        public static final RecipientType BCC;
        protected String type;
        private static final long serialVersionUID = -7479791750606340008L;
        
        protected RecipientType(final String type) {
            this.type = type;
        }
        
        protected Object readResolve() {
            if (this.type.equals("To")) {
                return RecipientType.TO;
            }
            if (this.type.equals("Cc")) {
                return RecipientType.CC;
            }
            if (this.type.equals("Bcc")) {
                return RecipientType.BCC;
            }
            throw new InvalidObjectException("Attempt to resolve unknown RecipientType: " + this.type);
        }
        
        @Override
        public String toString() {
            return this.type;
        }
        
        static {
            TO = new RecipientType("To");
            CC = new RecipientType("Cc");
            BCC = new RecipientType("Bcc");
        }
    }
}
