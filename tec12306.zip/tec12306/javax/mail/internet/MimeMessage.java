// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.util.Enumeration;
import com.sun.mail.util.LineOutputStream;
import java.util.Vector;
import javax.mail.Part;
import javax.mail.Multipart;
import com.sun.mail.util.MessageRemovedIOException;
import javax.mail.MessageRemovedException;
import com.sun.mail.util.FolderClosedIOException;
import javax.mail.FolderClosedException;
import javax.activation.DataSource;
import com.sun.mail.util.MimeUtil;
import java.text.ParseException;
import java.util.Date;
import java.io.UnsupportedEncodingException;
import javax.mail.Address;
import com.sun.mail.util.ASCIIUtility;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import com.sun.mail.util.PropUtil;
import javax.mail.Folder;
import java.io.IOException;
import javax.mail.MessagingException;
import javax.mail.util.SharedByteArrayInputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import javax.mail.Session;
import javax.mail.Flags;
import java.io.InputStream;
import javax.activation.DataHandler;
import javax.mail.Message;

public class MimeMessage extends Message implements MimePart
{
    protected DataHandler dh;
    protected byte[] content;
    protected InputStream contentStream;
    protected InternetHeaders headers;
    protected Flags flags;
    protected boolean modified;
    protected boolean saved;
    protected Object cachedContent;
    private static final MailDateFormat mailDateFormat;
    private boolean strict;
    private static final Flags answeredFlag;
    
    public MimeMessage(final Session session) {
        super(session);
        this.modified = false;
        this.saved = false;
        this.strict = true;
        this.modified = true;
        this.headers = new InternetHeaders();
        this.flags = new Flags();
        this.initStrict();
    }
    
    public MimeMessage(final Session session, final InputStream inputStream) {
        super(session);
        this.modified = false;
        this.saved = false;
        this.strict = true;
        this.flags = new Flags();
        this.initStrict();
        this.parse(inputStream);
        this.saved = true;
    }
    
    public MimeMessage(final MimeMessage mimeMessage) {
        super(mimeMessage.session);
        this.modified = false;
        this.saved = false;
        this.strict = true;
        this.flags = mimeMessage.getFlags();
        if (this.flags == null) {
            this.flags = new Flags();
        }
        final int size = mimeMessage.getSize();
        ByteArrayOutputStream byteArrayOutputStream;
        if (size > 0) {
            byteArrayOutputStream = new ByteArrayOutputStream(size);
        }
        else {
            byteArrayOutputStream = new ByteArrayOutputStream();
        }
        try {
            this.strict = mimeMessage.strict;
            mimeMessage.writeTo(byteArrayOutputStream);
            byteArrayOutputStream.close();
            final SharedByteArrayInputStream sharedByteArrayInputStream = new SharedByteArrayInputStream(byteArrayOutputStream.toByteArray());
            this.parse(sharedByteArrayInputStream);
            sharedByteArrayInputStream.close();
            this.saved = true;
        }
        catch (IOException ex) {
            throw new MessagingException("IOException while copying message", ex);
        }
    }
    
    protected MimeMessage(final Folder folder, final int n) {
        super(folder, n);
        this.modified = false;
        this.saved = false;
        this.strict = true;
        this.flags = new Flags();
        this.saved = true;
        this.initStrict();
    }
    
    protected MimeMessage(final Folder folder, final InputStream inputStream, final int n) {
        this(folder, n);
        this.initStrict();
        this.parse(inputStream);
    }
    
    protected MimeMessage(final Folder folder, final InternetHeaders headers, final byte[] content, final int n) {
        this(folder, n);
        this.headers = headers;
        this.content = content;
        this.initStrict();
    }
    
    private void initStrict() {
        if (this.session != null) {
            this.strict = PropUtil.getBooleanSessionProperty(this.session, "mail.mime.address.strict", true);
        }
    }
    
    protected void parse(InputStream inputStream) {
        if (!(inputStream instanceof ByteArrayInputStream) && !(inputStream instanceof BufferedInputStream) && !(inputStream instanceof SharedInputStream)) {
            inputStream = new BufferedInputStream(inputStream);
        }
        this.headers = this.createInternetHeaders(inputStream);
        if (inputStream instanceof SharedInputStream) {
            final SharedInputStream sharedInputStream = (SharedInputStream)inputStream;
            this.contentStream = sharedInputStream.newStream(sharedInputStream.getPosition(), -1L);
        }
        else {
            try {
                this.content = ASCIIUtility.getBytes(inputStream);
            }
            catch (IOException ex) {
                throw new MessagingException("IOException", ex);
            }
        }
        this.modified = false;
    }
    
    @Override
    public Address[] getFrom() {
        Address[] array = this.getAddressHeader("From");
        if (array == null) {
            array = this.getAddressHeader("Sender");
        }
        return array;
    }
    
    @Override
    public void setFrom(final Address address) {
        if (address == null) {
            this.removeHeader("From");
        }
        else {
            this.setHeader("From", address.toString());
        }
    }
    
    public void setFrom(final String s) {
        if (s == null) {
            this.removeHeader("From");
        }
        else {
            this.setAddressHeader("From", InternetAddress.parse(s));
        }
    }
    
    @Override
    public void setFrom() {
        InternetAddress getLocalAddress;
        try {
            getLocalAddress = InternetAddress._getLocalAddress(this.session);
        }
        catch (Exception ex) {
            throw new MessagingException("No From address", ex);
        }
        if (getLocalAddress != null) {
            this.setFrom(getLocalAddress);
            return;
        }
        throw new MessagingException("No From address");
    }
    
    @Override
    public void addFrom(final Address[] array) {
        this.addAddressHeader("From", array);
    }
    
    public Address getSender() {
        final Address[] addressHeader = this.getAddressHeader("Sender");
        if (addressHeader == null || addressHeader.length == 0) {
            return null;
        }
        return addressHeader[0];
    }
    
    public void setSender(final Address address) {
        if (address == null) {
            this.removeHeader("Sender");
        }
        else {
            this.setHeader("Sender", address.toString());
        }
    }
    
    @Override
    public Address[] getRecipients(final Message.RecipientType recipientType) {
        if (recipientType == RecipientType.NEWSGROUPS) {
            final String header = this.getHeader("Newsgroups", ",");
            return (Address[])((header == null) ? null : NewsAddress.parse(header));
        }
        return this.getAddressHeader(this.getHeaderName(recipientType));
    }
    
    @Override
    public Address[] getAllRecipients() {
        final Address[] allRecipients = super.getAllRecipients();
        final Address[] recipients = this.getRecipients(RecipientType.NEWSGROUPS);
        if (recipients == null) {
            return allRecipients;
        }
        if (allRecipients == null) {
            return recipients;
        }
        final Address[] array = new Address[allRecipients.length + recipients.length];
        System.arraycopy(allRecipients, 0, array, 0, allRecipients.length);
        System.arraycopy(recipients, 0, array, allRecipients.length, recipients.length);
        return array;
    }
    
    @Override
    public void setRecipients(final Message.RecipientType recipientType, final Address[] array) {
        if (recipientType == RecipientType.NEWSGROUPS) {
            if (array == null || array.length == 0) {
                this.removeHeader("Newsgroups");
            }
            else {
                this.setHeader("Newsgroups", NewsAddress.toString(array));
            }
        }
        else {
            this.setAddressHeader(this.getHeaderName(recipientType), array);
        }
    }
    
    public void setRecipients(final Message.RecipientType recipientType, final String s) {
        if (recipientType == RecipientType.NEWSGROUPS) {
            if (s == null || s.length() == 0) {
                this.removeHeader("Newsgroups");
            }
            else {
                this.setHeader("Newsgroups", s);
            }
        }
        else {
            this.setAddressHeader(this.getHeaderName(recipientType), (Address[])((s == null) ? null : InternetAddress.parse(s)));
        }
    }
    
    @Override
    public void addRecipients(final Message.RecipientType recipientType, final Address[] array) {
        if (recipientType == RecipientType.NEWSGROUPS) {
            final String string = NewsAddress.toString(array);
            if (string != null) {
                this.addHeader("Newsgroups", string);
            }
        }
        else {
            this.addAddressHeader(this.getHeaderName(recipientType), array);
        }
    }
    
    public void addRecipients(final Message.RecipientType recipientType, final String s) {
        if (recipientType == RecipientType.NEWSGROUPS) {
            if (s != null && s.length() != 0) {
                this.addHeader("Newsgroups", s);
            }
        }
        else {
            this.addAddressHeader(this.getHeaderName(recipientType), InternetAddress.parse(s));
        }
    }
    
    @Override
    public Address[] getReplyTo() {
        Address[] array = this.getAddressHeader("Reply-To");
        if (array == null || array.length == 0) {
            array = this.getFrom();
        }
        return array;
    }
    
    @Override
    public void setReplyTo(final Address[] array) {
        this.setAddressHeader("Reply-To", array);
    }
    
    private Address[] getAddressHeader(final String s) {
        final String header = this.getHeader(s, ",");
        return (Address[])((header == null) ? null : InternetAddress.parseHeader(header, this.strict));
    }
    
    private void setAddressHeader(final String s, final Address[] array) {
        final String string = InternetAddress.toString(array);
        if (string == null) {
            this.removeHeader(s);
        }
        else {
            this.setHeader(s, string);
        }
    }
    
    private void addAddressHeader(final String s, final Address[] array) {
        if (array == null || array.length == 0) {
            return;
        }
        final Address[] addressHeader = this.getAddressHeader(s);
        Address[] array2;
        if (addressHeader == null || addressHeader.length == 0) {
            array2 = array;
        }
        else {
            array2 = new Address[addressHeader.length + array.length];
            System.arraycopy(addressHeader, 0, array2, 0, addressHeader.length);
            System.arraycopy(array, 0, array2, addressHeader.length, array.length);
        }
        final String string = InternetAddress.toString(array2);
        if (string == null) {
            return;
        }
        this.setHeader(s, string);
    }
    
    @Override
    public String getSubject() {
        final String header = this.getHeader("Subject", null);
        if (header == null) {
            return null;
        }
        try {
            return MimeUtility.decodeText(MimeUtility.unfold(header));
        }
        catch (UnsupportedEncodingException ex) {
            return header;
        }
    }
    
    @Override
    public void setSubject(final String s) {
        this.setSubject(s, null);
    }
    
    public void setSubject(final String s, final String s2) {
        if (s == null) {
            this.removeHeader("Subject");
        }
        else {
            try {
                this.setHeader("Subject", MimeUtility.fold(9, MimeUtility.encodeText(s, s2, null)));
            }
            catch (UnsupportedEncodingException ex) {
                throw new MessagingException("Encoding error", ex);
            }
        }
    }
    
    @Override
    public Date getSentDate() {
        final String header = this.getHeader("Date", null);
        if (header != null) {
            try {
                synchronized (MimeMessage.mailDateFormat) {
                    return MimeMessage.mailDateFormat.parse(header);
                }
            }
            catch (ParseException ex) {
                return null;
            }
        }
        return null;
    }
    
    @Override
    public void setSentDate(final Date date) {
        if (date == null) {
            this.removeHeader("Date");
        }
        else {
            synchronized (MimeMessage.mailDateFormat) {
                this.setHeader("Date", MimeMessage.mailDateFormat.format(date));
            }
        }
    }
    
    @Override
    public Date getReceivedDate() {
        return null;
    }
    
    @Override
    public int getSize() {
        if (this.content != null) {
            return this.content.length;
        }
        if (this.contentStream != null) {
            try {
                final int available = this.contentStream.available();
                if (available > 0) {
                    return available;
                }
            }
            catch (IOException ex) {}
        }
        return -1;
    }
    
    @Override
    public int getLineCount() {
        return -1;
    }
    
    @Override
    public String getContentType() {
        final String cleanContentType = MimeUtil.cleanContentType((MimePart)this, this.getHeader("Content-Type", null));
        if (cleanContentType == null) {
            return "text/plain";
        }
        return cleanContentType;
    }
    
    @Override
    public boolean isMimeType(final String s) {
        return MimeBodyPart.isMimeType(this, s);
    }
    
    @Override
    public String getDisposition() {
        return MimeBodyPart.getDisposition(this);
    }
    
    @Override
    public void setDisposition(final String s) {
        MimeBodyPart.setDisposition(this, s);
    }
    
    @Override
    public String getEncoding() {
        return MimeBodyPart.getEncoding(this);
    }
    
    @Override
    public String getContentID() {
        return this.getHeader("Content-Id", null);
    }
    
    public void setContentID(final String s) {
        if (s == null) {
            this.removeHeader("Content-ID");
        }
        else {
            this.setHeader("Content-ID", s);
        }
    }
    
    @Override
    public String getContentMD5() {
        return this.getHeader("Content-MD5", null);
    }
    
    @Override
    public void setContentMD5(final String s) {
        this.setHeader("Content-MD5", s);
    }
    
    @Override
    public String getDescription() {
        return MimeBodyPart.getDescription(this);
    }
    
    @Override
    public void setDescription(final String s) {
        this.setDescription(s, null);
    }
    
    public void setDescription(final String s, final String s2) {
        MimeBodyPart.setDescription(this, s, s2);
    }
    
    @Override
    public String[] getContentLanguage() {
        return MimeBodyPart.getContentLanguage(this);
    }
    
    @Override
    public void setContentLanguage(final String[] array) {
        MimeBodyPart.setContentLanguage(this, array);
    }
    
    public String getMessageID() {
        return this.getHeader("Message-ID", null);
    }
    
    @Override
    public String getFileName() {
        return MimeBodyPart.getFileName(this);
    }
    
    @Override
    public void setFileName(final String s) {
        MimeBodyPart.setFileName(this, s);
    }
    
    private String getHeaderName(final Message.RecipientType recipientType) {
        String s;
        if (recipientType == Message.RecipientType.TO) {
            s = "To";
        }
        else if (recipientType == Message.RecipientType.CC) {
            s = "Cc";
        }
        else if (recipientType == Message.RecipientType.BCC) {
            s = "Bcc";
        }
        else {
            if (recipientType != RecipientType.NEWSGROUPS) {
                throw new MessagingException("Invalid Recipient Type");
            }
            s = "Newsgroups";
        }
        return s;
    }
    
    @Override
    public InputStream getInputStream() {
        return this.getDataHandler().getInputStream();
    }
    
    protected InputStream getContentStream() {
        if (this.contentStream != null) {
            return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
        }
        if (this.content != null) {
            return new SharedByteArrayInputStream(this.content);
        }
        throw new MessagingException("No MimeMessage content");
    }
    
    public InputStream getRawInputStream() {
        return this.getContentStream();
    }
    
    @Override
    public synchronized DataHandler getDataHandler() {
        if (this.dh == null) {
            this.dh = new MimeBodyPart.MimePartDataHandler(new MimePartDataSource(this));
        }
        return this.dh;
    }
    
    @Override
    public Object getContent() {
        if (this.cachedContent != null) {
            return this.cachedContent;
        }
        Object content;
        try {
            content = this.getDataHandler().getContent();
        }
        catch (FolderClosedIOException ex) {
            throw new FolderClosedException(ex.getFolder(), ex.getMessage());
        }
        catch (MessageRemovedIOException ex2) {
            throw new MessageRemovedException(ex2.getMessage());
        }
        if (MimeBodyPart.cacheMultipart && (content instanceof Multipart || content instanceof Message) && (this.content != null || this.contentStream != null)) {
            this.cachedContent = content;
            if (content instanceof MimeMultipart) {
                ((MimeMultipart)content).parse();
            }
        }
        return content;
    }
    
    @Override
    public synchronized void setDataHandler(final DataHandler dh) {
        this.dh = dh;
        this.cachedContent = null;
        MimeBodyPart.invalidateContentHeaders(this);
    }
    
    @Override
    public void setContent(final Object o, final String s) {
        if (o instanceof Multipart) {
            this.setContent((Multipart)o);
        }
        else {
            this.setDataHandler(new DataHandler(o, s));
        }
    }
    
    @Override
    public void setText(final String s) {
        this.setText(s, null);
    }
    
    @Override
    public void setText(final String s, final String s2) {
        MimeBodyPart.setText(this, s, s2, "plain");
    }
    
    @Override
    public void setText(final String s, final String s2, final String s3) {
        MimeBodyPart.setText(this, s, s2, s3);
    }
    
    @Override
    public void setContent(final Multipart multipart) {
        this.setDataHandler(new DataHandler(multipart, multipart.getContentType()));
        multipart.setParent(this);
    }
    
    @Override
    public Message reply(final boolean b) {
        return this.reply(b, true);
    }
    
    public Message reply(final boolean b, final boolean b2) {
        final MimeMessage mimeMessage = this.createMimeMessage(this.session);
        String s = this.getHeader("Subject", null);
        if (s != null) {
            if (!s.regionMatches(true, 0, "Re: ", 0, 4)) {
                s = "Re: " + s;
            }
            mimeMessage.setHeader("Subject", s);
        }
        final Address[] replyTo = this.getReplyTo();
        mimeMessage.setRecipients(Message.RecipientType.TO, replyTo);
        if (b) {
            final Vector<InternetAddress> vector = new Vector<InternetAddress>();
            final InternetAddress localAddress = InternetAddress.getLocalAddress(this.session);
            if (localAddress != null) {
                vector.addElement(localAddress);
            }
            String property = null;
            if (this.session != null) {
                property = this.session.getProperty("mail.alternates");
            }
            if (property != null) {
                this.eliminateDuplicates(vector, InternetAddress.parse(property, false));
            }
            boolean booleanSessionProperty = false;
            if (this.session != null) {
                booleanSessionProperty = PropUtil.getBooleanSessionProperty(this.session, "mail.replyallcc", false);
            }
            this.eliminateDuplicates(vector, replyTo);
            final Address[] eliminateDuplicates = this.eliminateDuplicates(vector, this.getRecipients(Message.RecipientType.TO));
            if (eliminateDuplicates != null && eliminateDuplicates.length > 0) {
                if (booleanSessionProperty) {
                    mimeMessage.addRecipients(Message.RecipientType.CC, eliminateDuplicates);
                }
                else {
                    mimeMessage.addRecipients(Message.RecipientType.TO, eliminateDuplicates);
                }
            }
            final Address[] eliminateDuplicates2 = this.eliminateDuplicates(vector, this.getRecipients(Message.RecipientType.CC));
            if (eliminateDuplicates2 != null && eliminateDuplicates2.length > 0) {
                mimeMessage.addRecipients(Message.RecipientType.CC, eliminateDuplicates2);
            }
            final Address[] recipients = this.getRecipients(RecipientType.NEWSGROUPS);
            if (recipients != null && recipients.length > 0) {
                mimeMessage.setRecipients(RecipientType.NEWSGROUPS, recipients);
            }
        }
        final String header = this.getHeader("Message-Id", null);
        if (header != null) {
            mimeMessage.setHeader("In-Reply-To", header);
        }
        String s2 = this.getHeader("References", " ");
        if (s2 == null) {
            s2 = this.getHeader("In-Reply-To", " ");
        }
        if (header != null) {
            if (s2 != null) {
                s2 = MimeUtility.unfold(s2) + " " + header;
            }
            else {
                s2 = header;
            }
        }
        if (s2 != null) {
            mimeMessage.setHeader("References", MimeUtility.fold(12, s2));
        }
        if (b2) {
            try {
                this.setFlags(MimeMessage.answeredFlag, true);
            }
            catch (MessagingException ex) {}
        }
        return mimeMessage;
    }
    
    private Address[] eliminateDuplicates(final Vector vector, Address[] array) {
        if (array == null) {
            return null;
        }
        int n = 0;
        for (int i = 0; i < array.length; ++i) {
            boolean b = false;
            for (int j = 0; j < vector.size(); ++j) {
                if (vector.elementAt(j).equals(array[i])) {
                    b = true;
                    ++n;
                    array[i] = null;
                    break;
                }
            }
            if (!b) {
                vector.addElement(array[i]);
            }
        }
        if (n != 0) {
            Address[] array2;
            if (array instanceof InternetAddress[]) {
                array2 = new InternetAddress[array.length - n];
            }
            else {
                array2 = new Address[array.length - n];
            }
            int k = 0;
            int n2 = 0;
            while (k < array.length) {
                if (array[k] != null) {
                    array2[n2++] = array[k];
                }
                ++k;
            }
            array = array2;
        }
        return array;
    }
    
    @Override
    public void writeTo(final OutputStream outputStream) {
        this.writeTo(outputStream, null);
    }
    
    public void writeTo(final OutputStream outputStream, final String[] array) {
        if (!this.saved) {
            this.saveChanges();
        }
        if (this.modified) {
            MimeBodyPart.writeTo(this, outputStream, array);
            return;
        }
        final Enumeration nonMatchingHeaderLines = this.getNonMatchingHeaderLines(array);
        final LineOutputStream lineOutputStream = new LineOutputStream(outputStream);
        while (nonMatchingHeaderLines.hasMoreElements()) {
            lineOutputStream.writeln((String)nonMatchingHeaderLines.nextElement());
        }
        lineOutputStream.writeln();
        if (this.content == null) {
            InputStream contentStream = null;
            final byte[] array2 = new byte[8192];
            try {
                contentStream = this.getContentStream();
                int read;
                while ((read = contentStream.read(array2)) > 0) {
                    outputStream.write(array2, 0, read);
                }
            }
            finally {
                if (contentStream != null) {
                    contentStream.close();
                }
            }
        }
        else {
            outputStream.write(this.content);
        }
        outputStream.flush();
    }
    
    @Override
    public String[] getHeader(final String s) {
        return this.headers.getHeader(s);
    }
    
    @Override
    public String getHeader(final String s, final String s2) {
        return this.headers.getHeader(s, s2);
    }
    
    @Override
    public void setHeader(final String s, final String s2) {
        this.headers.setHeader(s, s2);
    }
    
    @Override
    public void addHeader(final String s, final String s2) {
        this.headers.addHeader(s, s2);
    }
    
    @Override
    public void removeHeader(final String s) {
        this.headers.removeHeader(s);
    }
    
    @Override
    public Enumeration getAllHeaders() {
        return this.headers.getAllHeaders();
    }
    
    @Override
    public Enumeration getMatchingHeaders(final String[] array) {
        return this.headers.getMatchingHeaders(array);
    }
    
    @Override
    public Enumeration getNonMatchingHeaders(final String[] array) {
        return this.headers.getNonMatchingHeaders(array);
    }
    
    @Override
    public void addHeaderLine(final String s) {
        this.headers.addHeaderLine(s);
    }
    
    @Override
    public Enumeration getAllHeaderLines() {
        return this.headers.getAllHeaderLines();
    }
    
    @Override
    public Enumeration getMatchingHeaderLines(final String[] array) {
        return this.headers.getMatchingHeaderLines(array);
    }
    
    @Override
    public Enumeration getNonMatchingHeaderLines(final String[] array) {
        return this.headers.getNonMatchingHeaderLines(array);
    }
    
    @Override
    public synchronized Flags getFlags() {
        return (Flags)this.flags.clone();
    }
    
    @Override
    public synchronized boolean isSet(final Flags.Flag flag) {
        return this.flags.contains(flag);
    }
    
    @Override
    public synchronized void setFlags(final Flags flags, final boolean b) {
        if (b) {
            this.flags.add(flags);
        }
        else {
            this.flags.remove(flags);
        }
    }
    
    @Override
    public void saveChanges() {
        this.modified = true;
        this.saved = true;
        this.updateHeaders();
    }
    
    protected void updateMessageID() {
        this.setHeader("Message-ID", "<" + UniqueValue.getUniqueMessageIDValue(this.session) + ">");
    }
    
    protected synchronized void updateHeaders() {
        MimeBodyPart.updateHeaders(this);
        this.setHeader("MIME-Version", "1.0");
        this.updateMessageID();
        if (this.cachedContent != null) {
            this.dh = new DataHandler(this.cachedContent, this.getContentType());
            this.cachedContent = null;
            this.content = null;
            if (this.contentStream != null) {
                try {
                    this.contentStream.close();
                }
                catch (IOException ex) {}
            }
            this.contentStream = null;
        }
    }
    
    protected InternetHeaders createInternetHeaders(final InputStream inputStream) {
        return new InternetHeaders(inputStream);
    }
    
    protected MimeMessage createMimeMessage(final Session session) {
        return new MimeMessage(session);
    }
    
    static {
        mailDateFormat = new MailDateFormat();
        answeredFlag = new Flags(Flags.Flag.ANSWERED);
    }
    
    public static class RecipientType extends Message.RecipientType
    {
        private static final long serialVersionUID = -5468290701714395543L;
        public static final RecipientType NEWSGROUPS;
        
        protected RecipientType(final String s) {
            super(s);
        }
        
        @Override
        protected Object readResolve() {
            if (this.type.equals("Newsgroups")) {
                return RecipientType.NEWSGROUPS;
            }
            return super.readResolve();
        }
        
        static {
            NEWSGROUPS = new RecipientType("Newsgroups");
        }
    }
}
