// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.logging.Level;
import java.text.ParsePosition;
import java.text.FieldPosition;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;
import com.sun.mail.util.MailLogger;
import java.text.SimpleDateFormat;

public class MailDateFormat extends SimpleDateFormat
{
    private static final long serialVersionUID = -8148227605210628779L;
    static boolean debug;
    private static MailLogger logger;
    private static final Calendar cal;
    
    public MailDateFormat() {
        super("EEE, d MMM yyyy HH:mm:ss 'XXXXX' (z)", Locale.US);
    }
    
    @Override
    public StringBuffer format(final Date time, final StringBuffer sb, final FieldPosition fieldPosition) {
        final int length = sb.length();
        super.format(time, sb, fieldPosition);
        int n;
        for (n = length + 25; sb.charAt(n) != 'X'; ++n) {}
        this.calendar.clear();
        this.calendar.setTime(time);
        int n2 = this.calendar.get(15) + this.calendar.get(16);
        if (n2 < 0) {
            sb.setCharAt(n++, '-');
            n2 = -n2;
        }
        else {
            sb.setCharAt(n++, '+');
        }
        final int n3 = n2 / 60 / 1000;
        final int n4 = n3 / 60;
        final int n5 = n3 % 60;
        sb.setCharAt(n++, Character.forDigit(n4 / 10, 10));
        sb.setCharAt(n++, Character.forDigit(n4 % 10, 10));
        sb.setCharAt(n++, Character.forDigit(n5 / 10, 10));
        sb.setCharAt(n++, Character.forDigit(n5 % 10, 10));
        return sb;
    }
    
    @Override
    public Date parse(final String s, final ParsePosition parsePosition) {
        return parseDate(s.toCharArray(), parsePosition, this.isLenient());
    }
    
    private static Date parseDate(final char[] array, final ParsePosition parsePosition, final boolean b) {
        try {
            int number = 0;
            int timeZone = 0;
            final MailDateParser mailDateParser = new MailDateParser(array, parsePosition.getIndex());
            mailDateParser.skipUntilNumber();
            final int number2 = mailDateParser.parseNumber();
            if (!mailDateParser.skipIfChar('-')) {
                mailDateParser.skipWhiteSpace();
            }
            final int month = mailDateParser.parseMonth();
            if (!mailDateParser.skipIfChar('-')) {
                mailDateParser.skipWhiteSpace();
            }
            int number3 = mailDateParser.parseNumber();
            if (number3 < 50) {
                number3 += 2000;
            }
            else if (number3 < 100) {
                number3 += 1900;
            }
            mailDateParser.skipWhiteSpace();
            final int number4 = mailDateParser.parseNumber();
            mailDateParser.skipChar(':');
            final int number5 = mailDateParser.parseNumber();
            if (mailDateParser.skipIfChar(':')) {
                number = mailDateParser.parseNumber();
            }
            try {
                mailDateParser.skipWhiteSpace();
                timeZone = mailDateParser.parseTimeZone();
            }
            catch (ParseException ex) {
                if (MailDateFormat.logger.isLoggable(Level.FINE)) {
                    MailDateFormat.logger.log(Level.FINE, "No timezone? : '" + new String(array) + "'", (Throwable)ex);
                }
            }
            parsePosition.setIndex(mailDateParser.getIndex());
            return ourUTC(number3, month, number2, number4, number5, number, timeZone, b);
        }
        catch (Exception ex2) {
            if (MailDateFormat.logger.isLoggable(Level.FINE)) {
                MailDateFormat.logger.log(Level.FINE, "Bad date: '" + new String(array) + "'", (Throwable)ex2);
            }
            parsePosition.setIndex(1);
            return null;
        }
    }
    
    private static synchronized Date ourUTC(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final boolean lenient) {
        MailDateFormat.cal.clear();
        MailDateFormat.cal.setLenient(lenient);
        MailDateFormat.cal.set(1, n);
        MailDateFormat.cal.set(2, n2);
        MailDateFormat.cal.set(5, n3);
        MailDateFormat.cal.set(11, n4);
        MailDateFormat.cal.set(12, n5);
        MailDateFormat.cal.add(12, n7);
        MailDateFormat.cal.set(13, n6);
        return MailDateFormat.cal.getTime();
    }
    
    @Override
    public void setCalendar(final Calendar calendar) {
        throw new RuntimeException("Method setCalendar() shouldn't be called");
    }
    
    @Override
    public void setNumberFormat(final NumberFormat numberFormat) {
        throw new RuntimeException("Method setNumberFormat() shouldn't be called");
    }
    
    static {
        MailDateFormat.debug = false;
        MailDateFormat.logger = new MailLogger((Class)MailDateFormat.class, "DEBUG", MailDateFormat.debug, System.out);
        cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    }
}
