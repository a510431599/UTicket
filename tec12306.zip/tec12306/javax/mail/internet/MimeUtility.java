// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import com.sun.mail.util.PropUtil;
import java.util.HashMap;
import java.util.NoSuchElementException;
import com.sun.mail.util.LineInputStream;
import java.io.InputStreamReader;
import com.sun.mail.util.QDecoderStream;
import java.io.ByteArrayInputStream;
import com.sun.mail.util.ASCIIUtility;
import java.io.ByteArrayOutputStream;
import com.sun.mail.util.QEncoderStream;
import com.sun.mail.util.BEncoderStream;
import java.util.StringTokenizer;
import com.sun.mail.util.UUEncoderStream;
import com.sun.mail.util.QPEncoderStream;
import com.sun.mail.util.BASE64EncoderStream;
import javax.mail.MessagingException;
import com.sun.mail.util.UUDecoderStream;
import com.sun.mail.util.QPDecoderStream;
import com.sun.mail.util.BASE64DecoderStream;
import java.io.OutputStream;
import javax.activation.DataHandler;
import java.io.UnsupportedEncodingException;
import java.util.Locale;
import java.io.InputStream;
import java.io.IOException;
import javax.mail.EncodingAware;
import javax.activation.DataSource;
import java.util.Hashtable;
import java.util.Map;

public class MimeUtility
{
    public static final int ALL = -1;
    private static final Map nonAsciiCharsetMap;
    private static final boolean decodeStrict;
    private static final boolean encodeEolStrict;
    private static final boolean ignoreUnknownEncoding;
    private static final boolean foldEncodedWords;
    private static final boolean foldText;
    private static String defaultJavaCharset;
    private static String defaultMIMECharset;
    private static Hashtable mime2java;
    private static Hashtable java2mime;
    static final int ALL_ASCII = 1;
    static final int MOSTLY_ASCII = 2;
    static final int MOSTLY_NONASCII = 3;
    
    public static String getEncoding(final DataSource dataSource) {
        InputStream inputStream = null;
        String encoding = null;
        if (dataSource instanceof EncodingAware) {
            encoding = ((EncodingAware)dataSource).getEncoding();
            if (encoding != null) {
                return encoding;
            }
        }
        try {
            final ContentType contentType = new ContentType(dataSource.getContentType());
            inputStream = dataSource.getInputStream();
            final boolean match = contentType.match("text/*");
            switch (checkAscii(inputStream, -1, !match)) {
                case 1: {
                    encoding = "7bit";
                    break;
                }
                case 2: {
                    if (match && nonAsciiCharset(contentType)) {
                        encoding = "base64";
                        break;
                    }
                    encoding = "quoted-printable";
                    break;
                }
                default: {
                    encoding = "base64";
                    break;
                }
            }
        }
        catch (Exception ex) {
            return "base64";
        }
        finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            catch (IOException ex2) {}
        }
        return encoding;
    }
    
    private static boolean nonAsciiCharset(final ContentType contentType) {
        final String parameter = contentType.getParameter("charset");
        if (parameter == null) {
            return false;
        }
        final String lowerCase = parameter.toLowerCase(Locale.ENGLISH);
        Boolean b;
        synchronized (MimeUtility.nonAsciiCharsetMap) {
            b = MimeUtility.nonAsciiCharsetMap.get(lowerCase);
        }
        if (b == null) {
            try {
                final byte[] bytes = "\r\n".getBytes(lowerCase);
                b = (bytes.length != 2 || bytes[0] != 13 || bytes[1] != 10);
            }
            catch (UnsupportedEncodingException ex) {
                b = Boolean.FALSE;
            }
            catch (RuntimeException ex2) {
                b = Boolean.TRUE;
            }
            synchronized (MimeUtility.nonAsciiCharsetMap) {
                MimeUtility.nonAsciiCharsetMap.put(lowerCase, b);
            }
        }
        return b;
    }
    
    public static String getEncoding(final DataHandler dataHandler) {
        if (dataHandler.getName() != null) {
            return getEncoding(dataHandler.getDataSource());
        }
        ContentType contentType;
        try {
            contentType = new ContentType(dataHandler.getContentType());
        }
        catch (Exception ex) {
            return "base64";
        }
        String s = null;
        if (contentType.match("text/*")) {
            final AsciiOutputStream asciiOutputStream = new AsciiOutputStream(false, false);
            try {
                dataHandler.writeTo(asciiOutputStream);
            }
            catch (IOException ex2) {}
            switch (asciiOutputStream.getAscii()) {
                case 1: {
                    s = "7bit";
                    break;
                }
                case 2: {
                    s = "quoted-printable";
                    break;
                }
                default: {
                    s = "base64";
                    break;
                }
            }
        }
        else {
            final AsciiOutputStream asciiOutputStream2 = new AsciiOutputStream(true, MimeUtility.encodeEolStrict);
            try {
                dataHandler.writeTo(asciiOutputStream2);
            }
            catch (IOException ex3) {}
            if (asciiOutputStream2.getAscii() == 1) {
                s = "7bit";
            }
            else {
                s = "base64";
            }
        }
        return s;
    }
    
    public static InputStream decode(final InputStream inputStream, final String s) {
        if (s.equalsIgnoreCase("base64")) {
            return (InputStream)new BASE64DecoderStream(inputStream);
        }
        if (s.equalsIgnoreCase("quoted-printable")) {
            return (InputStream)new QPDecoderStream(inputStream);
        }
        if (s.equalsIgnoreCase("uuencode") || s.equalsIgnoreCase("x-uuencode") || s.equalsIgnoreCase("x-uue")) {
            return (InputStream)new UUDecoderStream(inputStream);
        }
        if (s.equalsIgnoreCase("binary") || s.equalsIgnoreCase("7bit") || s.equalsIgnoreCase("8bit")) {
            return inputStream;
        }
        if (!MimeUtility.ignoreUnknownEncoding) {
            throw new MessagingException("Unknown encoding: " + s);
        }
        return inputStream;
    }
    
    public static OutputStream encode(final OutputStream outputStream, final String s) {
        if (s == null) {
            return outputStream;
        }
        if (s.equalsIgnoreCase("base64")) {
            return (OutputStream)new BASE64EncoderStream(outputStream);
        }
        if (s.equalsIgnoreCase("quoted-printable")) {
            return (OutputStream)new QPEncoderStream(outputStream);
        }
        if (s.equalsIgnoreCase("uuencode") || s.equalsIgnoreCase("x-uuencode") || s.equalsIgnoreCase("x-uue")) {
            return (OutputStream)new UUEncoderStream(outputStream);
        }
        if (s.equalsIgnoreCase("binary") || s.equalsIgnoreCase("7bit") || s.equalsIgnoreCase("8bit")) {
            return outputStream;
        }
        throw new MessagingException("Unknown encoding: " + s);
    }
    
    public static OutputStream encode(final OutputStream outputStream, final String s, final String s2) {
        if (s == null) {
            return outputStream;
        }
        if (s.equalsIgnoreCase("base64")) {
            return (OutputStream)new BASE64EncoderStream(outputStream);
        }
        if (s.equalsIgnoreCase("quoted-printable")) {
            return (OutputStream)new QPEncoderStream(outputStream);
        }
        if (s.equalsIgnoreCase("uuencode") || s.equalsIgnoreCase("x-uuencode") || s.equalsIgnoreCase("x-uue")) {
            return (OutputStream)new UUEncoderStream(outputStream, s2);
        }
        if (s.equalsIgnoreCase("binary") || s.equalsIgnoreCase("7bit") || s.equalsIgnoreCase("8bit")) {
            return outputStream;
        }
        throw new MessagingException("Unknown encoding: " + s);
    }
    
    public static String encodeText(final String s) {
        return encodeText(s, null, null);
    }
    
    public static String encodeText(final String s, final String s2, final String s3) {
        return encodeWord(s, s2, s3, false);
    }
    
    public static String decodeText(final String s) {
        final String s2 = " \t\n\r";
        if (s.indexOf("=?") == -1) {
            return s;
        }
        final StringTokenizer stringTokenizer = new StringTokenizer(s, s2, true);
        final StringBuffer sb = new StringBuffer();
        final StringBuffer sb2 = new StringBuffer();
        int endsWith = 0;
        while (stringTokenizer.hasMoreTokens()) {
            final String nextToken = stringTokenizer.nextToken();
            final char char1;
            if ((char1 = nextToken.charAt(0)) == ' ' || char1 == '\t' || char1 == '\r' || char1 == '\n') {
                sb2.append(char1);
            }
            else {
                String decodeWord;
                try {
                    decodeWord = decodeWord(nextToken);
                    if (endsWith == 0 && sb2.length() > 0) {
                        sb.append(sb2);
                    }
                    endsWith = 1;
                }
                catch (ParseException ex) {
                    decodeWord = nextToken;
                    if (!MimeUtility.decodeStrict) {
                        final String decodeInnerWords = decodeInnerWords(decodeWord);
                        if (decodeInnerWords != decodeWord) {
                            if (endsWith == 0 || !decodeWord.startsWith("=?")) {
                                if (sb2.length() > 0) {
                                    sb.append(sb2);
                                }
                            }
                            endsWith = (decodeWord.endsWith("?=") ? 1 : 0);
                            decodeWord = decodeInnerWords;
                        }
                        else {
                            if (sb2.length() > 0) {
                                sb.append(sb2);
                            }
                            endsWith = 0;
                        }
                    }
                    else {
                        if (sb2.length() > 0) {
                            sb.append(sb2);
                        }
                        endsWith = 0;
                    }
                }
                sb.append(decodeWord);
                sb2.setLength(0);
            }
        }
        sb.append(sb2);
        return sb.toString();
    }
    
    public static String encodeWord(final String s) {
        return encodeWord(s, null, null);
    }
    
    public static String encodeWord(final String s, final String s2, final String s3) {
        return encodeWord(s, s2, s3, true);
    }
    
    private static String encodeWord(final String s, String defaultMIMECharset, String s2, final boolean b) {
        final int checkAscii = checkAscii(s);
        if (checkAscii == 1) {
            return s;
        }
        String s3;
        if (defaultMIMECharset == null) {
            s3 = getDefaultJavaCharset();
            defaultMIMECharset = getDefaultMIMECharset();
        }
        else {
            s3 = javaCharset(defaultMIMECharset);
        }
        if (s2 == null) {
            if (checkAscii != 3) {
                s2 = "Q";
            }
            else {
                s2 = "B";
            }
        }
        boolean b2;
        if (s2.equalsIgnoreCase("B")) {
            b2 = true;
        }
        else {
            if (!s2.equalsIgnoreCase("Q")) {
                throw new UnsupportedEncodingException("Unknown transfer encoding: " + s2);
            }
            b2 = false;
        }
        final StringBuffer sb = new StringBuffer();
        doEncode(s, b2, s3, 68 - defaultMIMECharset.length(), "=?" + defaultMIMECharset + "?" + s2 + "?", true, b, sb);
        return sb.toString();
    }
    
    private static void doEncode(final String s, final boolean b, final String s2, final int n, final String s3, final boolean b2, final boolean b3, final StringBuffer sb) {
        final byte[] bytes = s.getBytes(s2);
        int n2;
        if (b) {
            n2 = BEncoderStream.encodedLength(bytes);
        }
        else {
            n2 = QEncoderStream.encodedLength(bytes, b3);
        }
        final int length;
        if (n2 > n && (length = s.length()) > 1) {
            doEncode(s.substring(0, length / 2), b, s2, n, s3, b2, b3, sb);
            doEncode(s.substring(length / 2, length), b, s2, n, s3, false, b3, sb);
        }
        else {
            final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            Object o;
            if (b) {
                o = new BEncoderStream((OutputStream)byteArrayOutputStream);
            }
            else {
                o = new QEncoderStream((OutputStream)byteArrayOutputStream, b3);
            }
            try {
                ((OutputStream)o).write(bytes);
                ((OutputStream)o).close();
            }
            catch (IOException ex) {}
            final byte[] byteArray = byteArrayOutputStream.toByteArray();
            if (!b2) {
                if (MimeUtility.foldEncodedWords) {
                    sb.append("\r\n ");
                }
                else {
                    sb.append(" ");
                }
            }
            sb.append(s3);
            for (int i = 0; i < byteArray.length; ++i) {
                sb.append((char)byteArray[i]);
            }
            sb.append("?=");
        }
    }
    
    public static String decodeWord(final String s) {
        if (!s.startsWith("=?")) {
            throw new ParseException("encoded word does not start with \"=?\": " + s);
        }
        final int n = 2;
        final int index;
        if ((index = s.indexOf(63, n)) == -1) {
            throw new ParseException("encoded word does not include charset: " + s);
        }
        String s2 = s.substring(n, index);
        final int index2 = s2.indexOf(42);
        if (index2 >= 0) {
            s2 = s2.substring(0, index2);
        }
        final String javaCharset = javaCharset(s2);
        final int n2 = index + 1;
        final int index3;
        if ((index3 = s.indexOf(63, n2)) == -1) {
            throw new ParseException("encoded word does not include encoding: " + s);
        }
        final String substring = s.substring(n2, index3);
        final int n3 = index3 + 1;
        final int index4;
        if ((index4 = s.indexOf("?=", n3)) == -1) {
            throw new ParseException("encoded word does not end with \"?=\": " + s);
        }
        final String substring2 = s.substring(n3, index4);
        try {
            String string;
            if (substring2.length() > 0) {
                final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(ASCIIUtility.getBytes(substring2));
                Object o;
                if (substring.equalsIgnoreCase("B")) {
                    o = new BASE64DecoderStream((InputStream)byteArrayInputStream);
                }
                else {
                    if (!substring.equalsIgnoreCase("Q")) {
                        throw new UnsupportedEncodingException("unknown encoding: " + substring);
                    }
                    o = new QDecoderStream((InputStream)byteArrayInputStream);
                }
                final int available = byteArrayInputStream.available();
                final byte[] array = new byte[available];
                final int read = ((InputStream)o).read(array, 0, available);
                string = ((read <= 0) ? "" : new String(array, 0, read, javaCharset));
            }
            else {
                string = "";
            }
            if (index4 + 2 < s.length()) {
                String s3 = s.substring(index4 + 2);
                if (!MimeUtility.decodeStrict) {
                    s3 = decodeInnerWords(s3);
                }
                string += s3;
            }
            return string;
        }
        catch (UnsupportedEncodingException ex) {
            throw ex;
        }
        catch (IOException ex2) {
            throw new ParseException(ex2.toString());
        }
        catch (IllegalArgumentException ex3) {
            throw new UnsupportedEncodingException(javaCharset);
        }
    }
    
    private static String decodeInnerWords(final String s) {
        int n = 0;
        final StringBuffer sb = new StringBuffer();
        int index;
        while ((index = s.indexOf("=?", n)) >= 0) {
            sb.append(s.substring(n, index));
            final int index2 = s.indexOf(63, index + 2);
            if (index2 < 0) {
                break;
            }
            final int index3 = s.indexOf(63, index2 + 1);
            if (index3 < 0) {
                break;
            }
            final int index4 = s.indexOf("?=", index3 + 1);
            if (index4 < 0) {
                break;
            }
            String s2 = s.substring(index, index4 + 2);
            try {
                s2 = decodeWord(s2);
            }
            catch (ParseException ex) {}
            sb.append(s2);
            n = index4 + 2;
        }
        if (n == 0) {
            return s;
        }
        if (n < s.length()) {
            sb.append(s.substring(n));
        }
        return sb.toString();
    }
    
    public static String quote(final String s, final String s2) {
        final int length = s.length();
        if (length == 0) {
            return "\"\"";
        }
        boolean b = false;
        for (int i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (char1 == '\"' || char1 == '\\' || char1 == '\r' || char1 == '\n') {
                final StringBuffer sb = new StringBuffer(length + 3);
                sb.append('\"');
                sb.append(s.substring(0, i));
                int n = 0;
                for (int j = i; j < length; ++j) {
                    final char char2 = s.charAt(j);
                    if (char2 == '\"' || char2 == '\\' || char2 == '\r' || char2 == '\n') {
                        if (char2 != '\n' || n != 13) {
                            sb.append('\\');
                        }
                    }
                    sb.append(char2);
                    n = char2;
                }
                sb.append('\"');
                return sb.toString();
            }
            if (char1 < ' ' || char1 >= '\u007f' || s2.indexOf(char1) >= 0) {
                b = true;
            }
        }
        if (b) {
            final StringBuffer sb2 = new StringBuffer(length + 2);
            sb2.append('\"').append(s).append('\"');
            return sb2.toString();
        }
        return s;
    }
    
    public static String fold(int n, String s) {
        if (!MimeUtility.foldText) {
            return s;
        }
        int i;
        for (i = s.length() - 1; i >= 0; --i) {
            final char char1 = s.charAt(i);
            if (char1 != ' ' && char1 != '\t' && char1 != '\r' && char1 != '\n') {
                break;
            }
        }
        if (i != s.length() - 1) {
            s = s.substring(0, i + 1);
        }
        if (n + s.length() <= 76) {
            return s;
        }
        final StringBuffer sb = new StringBuffer(s.length() + 4);
        char char2 = '\0';
        while (n + s.length() > 76) {
            int n2 = -1;
            for (int n3 = 0; n3 < s.length() && (n2 == -1 || n + n3 <= 76); ++n3) {
                final char char3 = s.charAt(n3);
                if ((char3 == ' ' || char3 == '\t') && char2 != ' ' && char2 != '\t') {
                    n2 = n3;
                }
                char2 = char3;
            }
            if (n2 == -1) {
                sb.append(s);
                s = "";
                n = 0;
                break;
            }
            sb.append(s.substring(0, n2));
            sb.append("\r\n");
            char2 = s.charAt(n2);
            sb.append(char2);
            s = s.substring(n2 + 1);
            n = 1;
        }
        sb.append(s);
        return sb.toString();
    }
    
    public static String unfold(String s) {
        if (!MimeUtility.foldText) {
            return s;
        }
        StringBuffer sb = null;
        int indexOfAny;
        while ((indexOfAny = indexOfAny(s, "\r\n")) >= 0) {
            final int n = indexOfAny;
            final int length = s.length();
            if (++indexOfAny < length && s.charAt(indexOfAny - 1) == '\r' && s.charAt(indexOfAny) == '\n') {
                ++indexOfAny;
            }
            if (n == 0 || s.charAt(n - 1) != '\\') {
                final char char1;
                if (indexOfAny < length && ((char1 = s.charAt(indexOfAny)) == ' ' || char1 == '\t')) {
                    ++indexOfAny;
                    char char2;
                    while (indexOfAny < length && ((char2 = s.charAt(indexOfAny)) == ' ' || char2 == '\t')) {
                        ++indexOfAny;
                    }
                    if (sb == null) {
                        sb = new StringBuffer(s.length());
                    }
                    if (n != 0) {
                        sb.append(s.substring(0, n));
                        sb.append(' ');
                    }
                    s = s.substring(indexOfAny);
                }
                else {
                    if (sb == null) {
                        sb = new StringBuffer(s.length());
                    }
                    sb.append(s.substring(0, indexOfAny));
                    s = s.substring(indexOfAny);
                }
            }
            else {
                if (sb == null) {
                    sb = new StringBuffer(s.length());
                }
                sb.append(s.substring(0, n - 1));
                sb.append(s.substring(n, indexOfAny));
                s = s.substring(indexOfAny);
            }
        }
        if (sb != null) {
            sb.append(s);
            return sb.toString();
        }
        return s;
    }
    
    private static int indexOfAny(final String s, final String s2) {
        return indexOfAny(s, s2, 0);
    }
    
    private static int indexOfAny(final String s, final String s2, final int n) {
        try {
            for (int length = s.length(), i = n; i < length; ++i) {
                if (s2.indexOf(s.charAt(i)) >= 0) {
                    return i;
                }
            }
            return -1;
        }
        catch (StringIndexOutOfBoundsException ex) {
            return -1;
        }
    }
    
    public static String javaCharset(final String s) {
        if (MimeUtility.mime2java == null || s == null) {
            return s;
        }
        final String s2 = MimeUtility.mime2java.get(s.toLowerCase(Locale.ENGLISH));
        return (s2 == null) ? s : s2;
    }
    
    public static String mimeCharset(final String s) {
        if (MimeUtility.java2mime == null || s == null) {
            return s;
        }
        final String s2 = MimeUtility.java2mime.get(s.toLowerCase(Locale.ENGLISH));
        return (s2 == null) ? s : s2;
    }
    
    public static String getDefaultJavaCharset() {
        if (MimeUtility.defaultJavaCharset == null) {
            String property = null;
            try {
                property = System.getProperty("mail.mime.charset");
            }
            catch (SecurityException ex) {}
            if (property != null && property.length() > 0) {
                return MimeUtility.defaultJavaCharset = javaCharset(property);
            }
            try {
                MimeUtility.defaultJavaCharset = System.getProperty("file.encoding", "8859_1");
            }
            catch (SecurityException ex2) {
                MimeUtility.defaultJavaCharset = new InputStreamReader(new 1NullInputStream()).getEncoding();
                if (MimeUtility.defaultJavaCharset == null) {
                    MimeUtility.defaultJavaCharset = "8859_1";
                }
            }
        }
        return MimeUtility.defaultJavaCharset;
    }
    
    static String getDefaultMIMECharset() {
        if (MimeUtility.defaultMIMECharset == null) {
            try {
                MimeUtility.defaultMIMECharset = System.getProperty("mail.mime.charset");
            }
            catch (SecurityException ex) {}
        }
        if (MimeUtility.defaultMIMECharset == null) {
            MimeUtility.defaultMIMECharset = mimeCharset(getDefaultJavaCharset());
        }
        return MimeUtility.defaultMIMECharset;
    }
    
    private static void loadMappings(final LineInputStream lineInputStream, final Hashtable hashtable) {
        while (true) {
            String line;
            try {
                line = lineInputStream.readLine();
            }
            catch (IOException ex) {
                break;
            }
            if (line == null) {
                break;
            }
            if (line.startsWith("--") && line.endsWith("--")) {
                break;
            }
            if (line.trim().length() == 0) {
                continue;
            }
            if (line.startsWith("#")) {
                continue;
            }
            final StringTokenizer stringTokenizer = new StringTokenizer(line, " \t");
            try {
                hashtable.put(stringTokenizer.nextToken().toLowerCase(Locale.ENGLISH), stringTokenizer.nextToken());
            }
            catch (NoSuchElementException ex2) {}
        }
    }
    
    static int checkAscii(final String s) {
        int n = 0;
        int n2 = 0;
        for (int length = s.length(), i = 0; i < length; ++i) {
            if (nonascii(s.charAt(i))) {
                ++n2;
            }
            else {
                ++n;
            }
        }
        if (n2 == 0) {
            return 1;
        }
        if (n > n2) {
            return 2;
        }
        return 3;
    }
    
    static int checkAscii(final byte[] array) {
        int n = 0;
        int n2 = 0;
        for (int i = 0; i < array.length; ++i) {
            if (nonascii(array[i] & 0xFF)) {
                ++n2;
            }
            else {
                ++n;
            }
        }
        if (n2 == 0) {
            return 1;
        }
        if (n > n2) {
            return 2;
        }
        return 3;
    }
    
    static int checkAscii(final InputStream inputStream, int i, final boolean b) {
        int n = 0;
        int n2 = 0;
        int n3 = 4096;
        int n4 = 0;
        boolean b2 = false;
        boolean b3 = false;
        final boolean b4 = MimeUtility.encodeEolStrict && b;
        byte[] array = null;
        if (i != 0) {
            n3 = ((i == -1) ? 4096 : Math.min(i, 4096));
            array = new byte[n3];
        }
        while (i != 0) {
            int read;
            try {
                if ((read = inputStream.read(array, 0, n3)) == -1) {
                    break;
                }
                int n5 = 0;
                for (int j = 0; j < read; ++j) {
                    final int n6 = array[j] & 0xFF;
                    if (b4 && ((n5 == 13 && n6 != 10) || (n5 != 13 && n6 == 10))) {
                        b3 = true;
                    }
                    if (n6 == 13 || n6 == 10) {
                        n4 = 0;
                    }
                    else if (++n4 > 998) {
                        b2 = true;
                    }
                    if (nonascii(n6)) {
                        if (b) {
                            return 3;
                        }
                        ++n2;
                    }
                    else {
                        ++n;
                    }
                    n5 = n6;
                }
            }
            catch (IOException ex) {
                break;
            }
            if (i != -1) {
                i -= read;
            }
        }
        if (i == 0 && b) {
            return 3;
        }
        if (n2 == 0) {
            if (b3) {
                return 3;
            }
            if (b2) {
                return 2;
            }
            return 1;
        }
        else {
            if (n > n2) {
                return 2;
            }
            return 3;
        }
    }
    
    static final boolean nonascii(final int n) {
        return n >= 127 || (n < 32 && n != 13 && n != 10 && n != 9);
    }
    
    static {
        nonAsciiCharsetMap = new HashMap();
        decodeStrict = PropUtil.getBooleanSystemProperty("mail.mime.decodetext.strict", true);
        encodeEolStrict = PropUtil.getBooleanSystemProperty("mail.mime.encodeeol.strict", false);
        ignoreUnknownEncoding = PropUtil.getBooleanSystemProperty("mail.mime.ignoreunknownencoding", false);
        foldEncodedWords = PropUtil.getBooleanSystemProperty("mail.mime.foldencodedwords", false);
        foldText = PropUtil.getBooleanSystemProperty("mail.mime.foldtext", true);
        MimeUtility.java2mime = new Hashtable(40);
        MimeUtility.mime2java = new Hashtable(10);
        try {
            Object resourceAsStream = MimeUtility.class.getResourceAsStream("/META-INF/javamail.charset.map");
            if (resourceAsStream != null) {
                try {
                    resourceAsStream = new LineInputStream((InputStream)resourceAsStream);
                    loadMappings((LineInputStream)resourceAsStream, MimeUtility.java2mime);
                    loadMappings((LineInputStream)resourceAsStream, MimeUtility.mime2java);
                }
                finally {
                    try {
                        ((InputStream)resourceAsStream).close();
                    }
                    catch (Exception ex) {}
                }
            }
        }
        catch (Exception ex2) {}
        if (MimeUtility.java2mime.isEmpty()) {
            MimeUtility.java2mime.put("8859_1", "ISO-8859-1");
            MimeUtility.java2mime.put("iso8859_1", "ISO-8859-1");
            MimeUtility.java2mime.put("iso8859-1", "ISO-8859-1");
            MimeUtility.java2mime.put("8859_2", "ISO-8859-2");
            MimeUtility.java2mime.put("iso8859_2", "ISO-8859-2");
            MimeUtility.java2mime.put("iso8859-2", "ISO-8859-2");
            MimeUtility.java2mime.put("8859_3", "ISO-8859-3");
            MimeUtility.java2mime.put("iso8859_3", "ISO-8859-3");
            MimeUtility.java2mime.put("iso8859-3", "ISO-8859-3");
            MimeUtility.java2mime.put("8859_4", "ISO-8859-4");
            MimeUtility.java2mime.put("iso8859_4", "ISO-8859-4");
            MimeUtility.java2mime.put("iso8859-4", "ISO-8859-4");
            MimeUtility.java2mime.put("8859_5", "ISO-8859-5");
            MimeUtility.java2mime.put("iso8859_5", "ISO-8859-5");
            MimeUtility.java2mime.put("iso8859-5", "ISO-8859-5");
            MimeUtility.java2mime.put("8859_6", "ISO-8859-6");
            MimeUtility.java2mime.put("iso8859_6", "ISO-8859-6");
            MimeUtility.java2mime.put("iso8859-6", "ISO-8859-6");
            MimeUtility.java2mime.put("8859_7", "ISO-8859-7");
            MimeUtility.java2mime.put("iso8859_7", "ISO-8859-7");
            MimeUtility.java2mime.put("iso8859-7", "ISO-8859-7");
            MimeUtility.java2mime.put("8859_8", "ISO-8859-8");
            MimeUtility.java2mime.put("iso8859_8", "ISO-8859-8");
            MimeUtility.java2mime.put("iso8859-8", "ISO-8859-8");
            MimeUtility.java2mime.put("8859_9", "ISO-8859-9");
            MimeUtility.java2mime.put("iso8859_9", "ISO-8859-9");
            MimeUtility.java2mime.put("iso8859-9", "ISO-8859-9");
            MimeUtility.java2mime.put("sjis", "Shift_JIS");
            MimeUtility.java2mime.put("jis", "ISO-2022-JP");
            MimeUtility.java2mime.put("iso2022jp", "ISO-2022-JP");
            MimeUtility.java2mime.put("euc_jp", "euc-jp");
            MimeUtility.java2mime.put("koi8_r", "koi8-r");
            MimeUtility.java2mime.put("euc_cn", "euc-cn");
            MimeUtility.java2mime.put("euc_tw", "euc-tw");
            MimeUtility.java2mime.put("euc_kr", "euc-kr");
        }
        if (MimeUtility.mime2java.isEmpty()) {
            MimeUtility.mime2java.put("iso-2022-cn", "ISO2022CN");
            MimeUtility.mime2java.put("iso-2022-kr", "ISO2022KR");
            MimeUtility.mime2java.put("utf-8", "UTF8");
            MimeUtility.mime2java.put("utf8", "UTF8");
            MimeUtility.mime2java.put("ja_jp.iso2022-7", "ISO2022JP");
            MimeUtility.mime2java.put("ja_jp.eucjp", "EUCJIS");
            MimeUtility.mime2java.put("euc-kr", "KSC5601");
            MimeUtility.mime2java.put("euckr", "KSC5601");
            MimeUtility.mime2java.put("us-ascii", "ISO-8859-1");
            MimeUtility.mime2java.put("x-us-ascii", "ISO-8859-1");
        }
    }
    
    class 1NullInputStream extends InputStream
    {
        @Override
        public int read() {
            return 0;
        }
    }
}
