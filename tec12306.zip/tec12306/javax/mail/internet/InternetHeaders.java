// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import javax.mail.Header;
import com.sun.mail.util.PropUtil;
import java.util.NoSuchElementException;
import java.util.Enumeration;
import java.util.Iterator;
import java.io.IOException;
import javax.mail.MessagingException;
import com.sun.mail.util.LineInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class InternetHeaders
{
    private static final boolean ignoreWhitespaceLines;
    protected List headers;
    
    public InternetHeaders() {
        (this.headers = new ArrayList(40)).add(new InternetHeader("Return-Path", null));
        this.headers.add(new InternetHeader("Received", null));
        this.headers.add(new InternetHeader("Resent-Date", null));
        this.headers.add(new InternetHeader("Resent-From", null));
        this.headers.add(new InternetHeader("Resent-Sender", null));
        this.headers.add(new InternetHeader("Resent-To", null));
        this.headers.add(new InternetHeader("Resent-Cc", null));
        this.headers.add(new InternetHeader("Resent-Bcc", null));
        this.headers.add(new InternetHeader("Resent-Message-Id", null));
        this.headers.add(new InternetHeader("Date", null));
        this.headers.add(new InternetHeader("From", null));
        this.headers.add(new InternetHeader("Sender", null));
        this.headers.add(new InternetHeader("Reply-To", null));
        this.headers.add(new InternetHeader("To", null));
        this.headers.add(new InternetHeader("Cc", null));
        this.headers.add(new InternetHeader("Bcc", null));
        this.headers.add(new InternetHeader("Message-Id", null));
        this.headers.add(new InternetHeader("In-Reply-To", null));
        this.headers.add(new InternetHeader("References", null));
        this.headers.add(new InternetHeader("Subject", null));
        this.headers.add(new InternetHeader("Comments", null));
        this.headers.add(new InternetHeader("Keywords", null));
        this.headers.add(new InternetHeader("Errors-To", null));
        this.headers.add(new InternetHeader("MIME-Version", null));
        this.headers.add(new InternetHeader("Content-Type", null));
        this.headers.add(new InternetHeader("Content-Transfer-Encoding", null));
        this.headers.add(new InternetHeader("Content-MD5", null));
        this.headers.add(new InternetHeader(":", null));
        this.headers.add(new InternetHeader("Content-Length", null));
        this.headers.add(new InternetHeader("Status", null));
    }
    
    public InternetHeaders(final InputStream inputStream) {
        this.headers = new ArrayList(40);
        this.load(inputStream);
    }
    
    public void load(final InputStream inputStream) {
        final LineInputStream lineInputStream = new LineInputStream(inputStream);
        String s = null;
        final StringBuffer sb = new StringBuffer();
        try {
            String line;
            do {
                line = lineInputStream.readLine();
                if (line != null && (line.startsWith(" ") || line.startsWith("\t"))) {
                    if (s != null) {
                        sb.append(s);
                        s = null;
                    }
                    sb.append("\r\n");
                    sb.append(line);
                }
                else {
                    if (s != null) {
                        this.addHeaderLine(s);
                    }
                    else if (sb.length() > 0) {
                        this.addHeaderLine(sb.toString());
                        sb.setLength(0);
                    }
                    s = line;
                }
            } while (line != null && !isEmpty(line));
        }
        catch (IOException ex) {
            throw new MessagingException("Error in input stream", ex);
        }
    }
    
    private static final boolean isEmpty(final String s) {
        return s.length() == 0 || (InternetHeaders.ignoreWhitespaceLines && s.trim().length() == 0);
    }
    
    public String[] getHeader(final String s) {
        final Iterator<InternetHeader> iterator = this.headers.iterator();
        final ArrayList<String> list = new ArrayList<String>();
        while (iterator.hasNext()) {
            final InternetHeader internetHeader = iterator.next();
            if (s.equalsIgnoreCase(internetHeader.getName()) && internetHeader.line != null) {
                list.add(internetHeader.getValue());
            }
        }
        if (list.size() == 0) {
            return null;
        }
        return list.toArray(new String[list.size()]);
    }
    
    public String getHeader(final String s, final String s2) {
        final String[] header = this.getHeader(s);
        if (header == null) {
            return null;
        }
        if (header.length == 1 || s2 == null) {
            return header[0];
        }
        final StringBuffer sb = new StringBuffer(header[0]);
        for (int i = 1; i < header.length; ++i) {
            sb.append(s2);
            sb.append(header[i]);
        }
        return sb.toString();
    }
    
    public void setHeader(final String s, final String s2) {
        int n = 0;
        for (int i = 0; i < this.headers.size(); ++i) {
            final InternetHeader internetHeader = this.headers.get(i);
            if (s.equalsIgnoreCase(internetHeader.getName())) {
                if (n == 0) {
                    final int index;
                    if (internetHeader.line != null && (index = internetHeader.line.indexOf(58)) >= 0) {
                        internetHeader.line = internetHeader.line.substring(0, index + 1) + " " + s2;
                    }
                    else {
                        internetHeader.line = s + ": " + s2;
                    }
                    n = 1;
                }
                else {
                    this.headers.remove(i);
                    --i;
                }
            }
        }
        if (n == 0) {
            this.addHeader(s, s2);
        }
    }
    
    public void addHeader(final String s, final String s2) {
        int size = this.headers.size();
        final boolean b = s.equalsIgnoreCase("Received") || s.equalsIgnoreCase("Return-Path");
        if (b) {
            size = 0;
        }
        for (int i = this.headers.size() - 1; i >= 0; --i) {
            final InternetHeader internetHeader = this.headers.get(i);
            if (s.equalsIgnoreCase(internetHeader.getName())) {
                if (!b) {
                    this.headers.add(i + 1, new InternetHeader(s, s2));
                    return;
                }
                size = i;
            }
            if (!b && internetHeader.getName().equals(":")) {
                size = i;
            }
        }
        this.headers.add(size, new InternetHeader(s, s2));
    }
    
    public void removeHeader(final String s) {
        for (int i = 0; i < this.headers.size(); ++i) {
            final InternetHeader internetHeader = this.headers.get(i);
            if (s.equalsIgnoreCase(internetHeader.getName())) {
                internetHeader.line = null;
            }
        }
    }
    
    public Enumeration getAllHeaders() {
        return new matchEnum(this.headers, null, false, false);
    }
    
    public Enumeration getMatchingHeaders(final String[] array) {
        return new matchEnum(this.headers, array, true, false);
    }
    
    public Enumeration getNonMatchingHeaders(final String[] array) {
        return new matchEnum(this.headers, array, false, false);
    }
    
    public void addHeaderLine(final String s) {
        try {
            final char char1 = s.charAt(0);
            if (char1 == ' ' || char1 == '\t') {
                final InternetHeader internetHeader = this.headers.get(this.headers.size() - 1);
                final StringBuilder sb = new StringBuilder();
                final InternetHeader internetHeader2 = internetHeader;
                internetHeader2.line = sb.append(internetHeader2.line).append("\r\n").append(s).toString();
            }
            else {
                this.headers.add(new InternetHeader(s));
            }
        }
        catch (StringIndexOutOfBoundsException ex) {}
        catch (NoSuchElementException ex2) {}
    }
    
    public Enumeration getAllHeaderLines() {
        return this.getNonMatchingHeaderLines(null);
    }
    
    public Enumeration getMatchingHeaderLines(final String[] array) {
        return new matchEnum(this.headers, array, true, true);
    }
    
    public Enumeration getNonMatchingHeaderLines(final String[] array) {
        return new matchEnum(this.headers, array, false, true);
    }
    
    static {
        ignoreWhitespaceLines = PropUtil.getBooleanSystemProperty("mail.mime.ignorewhitespacelines", false);
    }
    
    static class matchEnum implements Enumeration
    {
        private Iterator e;
        private String[] names;
        private boolean match;
        private boolean want_line;
        private InternetHeader next_header;
        
        matchEnum(final List list, final String[] names, final boolean match, final boolean want_line) {
            this.e = list.iterator();
            this.names = names;
            this.match = match;
            this.want_line = want_line;
            this.next_header = null;
        }
        
        @Override
        public boolean hasMoreElements() {
            if (this.next_header == null) {
                this.next_header = this.nextMatch();
            }
            return this.next_header != null;
        }
        
        @Override
        public Object nextElement() {
            if (this.next_header == null) {
                this.next_header = this.nextMatch();
            }
            if (this.next_header == null) {
                throw new NoSuchElementException("No more headers");
            }
            final InternetHeader next_header = this.next_header;
            this.next_header = null;
            if (this.want_line) {
                return next_header.line;
            }
            return new Header(next_header.getName(), next_header.getValue());
        }
        
        private InternetHeader nextMatch() {
        Label_0000:
            while (this.e.hasNext()) {
                final InternetHeader internetHeader = this.e.next();
                if (internetHeader.line == null) {
                    continue;
                }
                if (this.names == null) {
                    return this.match ? null : internetHeader;
                }
                int i = 0;
                while (i < this.names.length) {
                    if (this.names[i].equalsIgnoreCase(internetHeader.getName())) {
                        if (this.match) {
                            return internetHeader;
                        }
                        continue Label_0000;
                    }
                    else {
                        ++i;
                    }
                }
                if (!this.match) {
                    return internetHeader;
                }
            }
            return null;
        }
    }
    
    protected static final class InternetHeader extends Header
    {
        String line;
        
        public InternetHeader(final String line) {
            super("", "");
            final int index = line.indexOf(58);
            if (index < 0) {
                this.name = line.trim();
            }
            else {
                this.name = line.substring(0, index).trim();
            }
            this.line = line;
        }
        
        public InternetHeader(final String s, final String s2) {
            super(s, "");
            if (s2 != null) {
                this.line = s + ": " + s2;
            }
            else {
                this.line = null;
            }
        }
        
        @Override
        public String getValue() {
            final int index = this.line.indexOf(58);
            if (index < 0) {
                return this.line;
            }
            int i;
            for (i = index + 1; i < this.line.length(); ++i) {
                final char char1 = this.line.charAt(i);
                if (char1 != ' ' && char1 != '\t' && char1 != '\r' && char1 != '\n') {
                    break;
                }
            }
            return this.line.substring(i);
        }
    }
}
