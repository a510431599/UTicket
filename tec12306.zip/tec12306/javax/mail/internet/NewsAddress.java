// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.util.Vector;
import java.util.StringTokenizer;
import java.util.Locale;
import javax.mail.Address;

public class NewsAddress extends Address
{
    protected String newsgroup;
    protected String host;
    private static final long serialVersionUID = -4203797299824684143L;
    
    public NewsAddress() {
    }
    
    public NewsAddress(final String s) {
        this(s, null);
    }
    
    public NewsAddress(final String newsgroup, final String host) {
        this.newsgroup = newsgroup;
        this.host = host;
    }
    
    @Override
    public String getType() {
        return "news";
    }
    
    public void setNewsgroup(final String newsgroup) {
        this.newsgroup = newsgroup;
    }
    
    public String getNewsgroup() {
        return this.newsgroup;
    }
    
    public void setHost(final String host) {
        this.host = host;
    }
    
    public String getHost() {
        return this.host;
    }
    
    @Override
    public String toString() {
        return this.newsgroup;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof NewsAddress)) {
            return false;
        }
        final NewsAddress newsAddress = (NewsAddress)o;
        return this.newsgroup.equals(newsAddress.newsgroup) && ((this.host == null && newsAddress.host == null) || (this.host != null && newsAddress.host != null && this.host.equalsIgnoreCase(newsAddress.host)));
    }
    
    @Override
    public int hashCode() {
        int n = 0;
        if (this.newsgroup != null) {
            n += this.newsgroup.hashCode();
        }
        if (this.host != null) {
            n += this.host.toLowerCase(Locale.ENGLISH).hashCode();
        }
        return n;
    }
    
    public static String toString(final Address[] array) {
        if (array == null || array.length == 0) {
            return null;
        }
        final StringBuffer sb = new StringBuffer(((NewsAddress)array[0]).toString());
        for (int i = 1; i < array.length; ++i) {
            sb.append(",").append(((NewsAddress)array[i]).toString());
        }
        return sb.toString();
    }
    
    public static NewsAddress[] parse(final String s) {
        final StringTokenizer stringTokenizer = new StringTokenizer(s, ",");
        final Vector<NewsAddress> vector = new Vector<NewsAddress>();
        while (stringTokenizer.hasMoreTokens()) {
            vector.addElement(new NewsAddress(stringTokenizer.nextToken()));
        }
        final int size = vector.size();
        final NewsAddress[] array = new NewsAddress[size];
        if (size > 0) {
            vector.copyInto(array);
        }
        return array;
    }
}
