// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.text.ParseException;

class MailDateParser
{
    int index;
    char[] orig;
    
    public MailDateParser(final char[] orig, final int index) {
        this.index = 0;
        this.orig = null;
        this.orig = orig;
        this.index = index;
    }
    
    public void skipUntilNumber() {
        try {
        Label_0064:
            while (true) {
                switch (this.orig[this.index]) {
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9': {
                        break Label_0064;
                    }
                    default: {
                        ++this.index;
                        continue;
                    }
                }
            }
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            throw new ParseException("No Number Found", this.index);
        }
    }
    
    public void skipWhiteSpace() {
        while (this.index < this.orig.length) {
            switch (this.orig[this.index]) {
                case '\t':
                case '\n':
                case '\r':
                case ' ': {
                    ++this.index;
                    continue;
                }
                default: {}
            }
        }
    }
    
    public int peekChar() {
        if (this.index < this.orig.length) {
            return this.orig[this.index];
        }
        throw new ParseException("No more characters", this.index);
    }
    
    public void skipChar(final char c) {
        if (this.index >= this.orig.length) {
            throw new ParseException("No more characters", this.index);
        }
        if (this.orig[this.index] == c) {
            ++this.index;
            return;
        }
        throw new ParseException("Wrong char", this.index);
    }
    
    public boolean skipIfChar(final char c) {
        if (this.index >= this.orig.length) {
            throw new ParseException("No more characters", this.index);
        }
        if (this.orig[this.index] == c) {
            ++this.index;
            return true;
        }
        return false;
    }
    
    public int parseNumber() {
        final int length = this.orig.length;
        boolean b = false;
        int n = 0;
        while (this.index < length) {
            switch (this.orig[this.index]) {
                case '0': {
                    n *= 10;
                    b = true;
                    break;
                }
                case '1': {
                    n = n * 10 + 1;
                    b = true;
                    break;
                }
                case '2': {
                    n = n * 10 + 2;
                    b = true;
                    break;
                }
                case '3': {
                    n = n * 10 + 3;
                    b = true;
                    break;
                }
                case '4': {
                    n = n * 10 + 4;
                    b = true;
                    break;
                }
                case '5': {
                    n = n * 10 + 5;
                    b = true;
                    break;
                }
                case '6': {
                    n = n * 10 + 6;
                    b = true;
                    break;
                }
                case '7': {
                    n = n * 10 + 7;
                    b = true;
                    break;
                }
                case '8': {
                    n = n * 10 + 8;
                    b = true;
                    break;
                }
                case '9': {
                    n = n * 10 + 9;
                    b = true;
                    break;
                }
                default: {
                    if (b) {
                        return n;
                    }
                    throw new ParseException("No Number found", this.index);
                }
            }
            ++this.index;
        }
        if (b) {
            return n;
        }
        throw new ParseException("No Number found", this.index);
    }
    
    public int parseMonth() {
        try {
            switch (this.orig[this.index++]) {
                case 'J':
                case 'j': {
                    switch (this.orig[this.index++]) {
                        case 'A':
                        case 'a': {
                            final char c = this.orig[this.index++];
                            if (c == 'N' || c == 'n') {
                                return 0;
                            }
                            break;
                        }
                        case 'U':
                        case 'u': {
                            final char c2 = this.orig[this.index++];
                            if (c2 == 'N' || c2 == 'n') {
                                return 5;
                            }
                            if (c2 == 'L' || c2 == 'l') {
                                return 6;
                            }
                            break;
                        }
                    }
                    break;
                }
                case 'F':
                case 'f': {
                    final char c3 = this.orig[this.index++];
                    if (c3 != 'E' && c3 != 'e') {
                        break;
                    }
                    final char c4 = this.orig[this.index++];
                    if (c4 == 'B' || c4 == 'b') {
                        return 1;
                    }
                    break;
                }
                case 'M':
                case 'm': {
                    final char c5 = this.orig[this.index++];
                    if (c5 != 'A' && c5 != 'a') {
                        break;
                    }
                    final char c6 = this.orig[this.index++];
                    if (c6 == 'R' || c6 == 'r') {
                        return 2;
                    }
                    if (c6 == 'Y' || c6 == 'y') {
                        return 4;
                    }
                    break;
                }
                case 'A':
                case 'a': {
                    final char c7 = this.orig[this.index++];
                    if (c7 == 'P' || c7 == 'p') {
                        final char c8 = this.orig[this.index++];
                        if (c8 == 'R' || c8 == 'r') {
                            return 3;
                        }
                        break;
                    }
                    else {
                        if (c7 != 'U' && c7 != 'u') {
                            break;
                        }
                        final char c9 = this.orig[this.index++];
                        if (c9 == 'G' || c9 == 'g') {
                            return 7;
                        }
                        break;
                    }
                    break;
                }
                case 'S':
                case 's': {
                    final char c10 = this.orig[this.index++];
                    if (c10 != 'E' && c10 != 'e') {
                        break;
                    }
                    final char c11 = this.orig[this.index++];
                    if (c11 == 'P' || c11 == 'p') {
                        return 8;
                    }
                    break;
                }
                case 'O':
                case 'o': {
                    final char c12 = this.orig[this.index++];
                    if (c12 != 'C' && c12 != 'c') {
                        break;
                    }
                    final char c13 = this.orig[this.index++];
                    if (c13 == 'T' || c13 == 't') {
                        return 9;
                    }
                    break;
                }
                case 'N':
                case 'n': {
                    final char c14 = this.orig[this.index++];
                    if (c14 != 'O' && c14 != 'o') {
                        break;
                    }
                    final char c15 = this.orig[this.index++];
                    if (c15 == 'V' || c15 == 'v') {
                        return 10;
                    }
                    break;
                }
                case 'D':
                case 'd': {
                    final char c16 = this.orig[this.index++];
                    if (c16 != 'E' && c16 != 'e') {
                        break;
                    }
                    final char c17 = this.orig[this.index++];
                    if (c17 == 'C' || c17 == 'c') {
                        return 11;
                    }
                    break;
                }
            }
        }
        catch (ArrayIndexOutOfBoundsException ex) {}
        throw new ParseException("Bad Month", this.index);
    }
    
    public int parseTimeZone() {
        if (this.index >= this.orig.length) {
            throw new ParseException("No more characters", this.index);
        }
        final char c = this.orig[this.index];
        if (c == '+' || c == '-') {
            return this.parseNumericTimeZone();
        }
        return this.parseAlphaTimeZone();
    }
    
    public int parseNumericTimeZone() {
        boolean b = false;
        final char c = this.orig[this.index++];
        if (c == '+') {
            b = true;
        }
        else if (c != '-') {
            throw new ParseException("Bad Numeric TimeZone", this.index);
        }
        final int index = this.index;
        final int number = this.parseNumber();
        if (number >= 2400) {
            throw new ParseException("Numeric TimeZone out of range", index);
        }
        final int n = number / 100 * 60 + number % 100;
        if (b) {
            return -n;
        }
        return n;
    }
    
    public int parseAlphaTimeZone() {
        boolean b = false;
        int n = 0;
        try {
            switch (this.orig[this.index++]) {
                case 'U':
                case 'u': {
                    final char c = this.orig[this.index++];
                    if (c == 'T' || c == 't') {
                        n = 0;
                        break;
                    }
                    throw new ParseException("Bad Alpha TimeZone", this.index);
                }
                case 'G':
                case 'g': {
                    final char c2 = this.orig[this.index++];
                    if (c2 == 'M' || c2 == 'm') {
                        final char c3 = this.orig[this.index++];
                        if (c3 == 'T' || c3 == 't') {
                            n = 0;
                            break;
                        }
                    }
                    throw new ParseException("Bad Alpha TimeZone", this.index);
                }
                case 'E':
                case 'e': {
                    n = 300;
                    b = true;
                    break;
                }
                case 'C':
                case 'c': {
                    n = 360;
                    b = true;
                    break;
                }
                case 'M':
                case 'm': {
                    n = 420;
                    b = true;
                    break;
                }
                case 'P':
                case 'p': {
                    n = 480;
                    b = true;
                    break;
                }
                default: {
                    throw new ParseException("Bad Alpha TimeZone", this.index);
                }
            }
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            throw new ParseException("Bad Alpha TimeZone", this.index);
        }
        if (b) {
            final char c4 = this.orig[this.index++];
            if (c4 == 'S' || c4 == 's') {
                final char c5 = this.orig[this.index++];
                if (c5 != 'T' && c5 != 't') {
                    throw new ParseException("Bad Alpha TimeZone", this.index);
                }
            }
            else if (c4 == 'D' || c4 == 'd') {
                final char c6 = this.orig[this.index++];
                if (c6 != 'T' && c6 == 't') {
                    throw new ParseException("Bad Alpha TimeZone", this.index);
                }
                n -= 60;
            }
        }
        return n;
    }
    
    int getIndex() {
        return this.index;
    }
}
