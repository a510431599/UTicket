// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

public class AddressException extends ParseException
{
    protected String ref;
    protected int pos;
    private static final long serialVersionUID = 9134583443539323120L;
    
    public AddressException() {
        this.ref = null;
        this.pos = -1;
    }
    
    public AddressException(final String s) {
        super(s);
        this.ref = null;
        this.pos = -1;
    }
    
    public AddressException(final String s, final String ref) {
        super(s);
        this.ref = null;
        this.pos = -1;
        this.ref = ref;
    }
    
    public AddressException(final String s, final String ref, final int pos) {
        super(s);
        this.ref = null;
        this.pos = -1;
        this.ref = ref;
        this.pos = pos;
    }
    
    public String getRef() {
        return this.ref;
    }
    
    public int getPos() {
        return this.pos;
    }
    
    @Override
    public String toString() {
        final String string = super.toString();
        if (this.ref == null) {
            return string;
        }
        final String string2 = string + " in string ``" + this.ref + "''";
        if (this.pos < 0) {
            return string2;
        }
        return string2 + " at position " + this.pos;
    }
}
