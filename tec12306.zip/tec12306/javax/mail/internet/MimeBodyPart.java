// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import javax.mail.EncodingAware;
import com.sun.mail.util.LineOutputStream;
import com.sun.mail.util.PropUtil;
import java.util.Vector;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import javax.activation.FileDataSource;
import java.io.File;
import javax.mail.Part;
import javax.mail.Message;
import javax.mail.Multipart;
import com.sun.mail.util.MessageRemovedIOException;
import javax.mail.MessageRemovedException;
import com.sun.mail.util.FolderClosedIOException;
import javax.mail.FolderClosedException;
import javax.activation.DataSource;
import com.sun.mail.util.MimeUtil;
import java.io.IOException;
import javax.mail.MessagingException;
import com.sun.mail.util.ASCIIUtility;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.activation.DataHandler;
import javax.mail.BodyPart;

public class MimeBodyPart extends BodyPart implements MimePart
{
    private static final boolean setDefaultTextCharset;
    private static final boolean setContentTypeFileName;
    private static final boolean encodeFileName;
    private static final boolean decodeFileName;
    private static final boolean ignoreMultipartEncoding;
    static final boolean cacheMultipart;
    protected DataHandler dh;
    protected byte[] content;
    protected InputStream contentStream;
    protected InternetHeaders headers;
    protected Object cachedContent;
    
    public MimeBodyPart() {
        this.headers = new InternetHeaders();
    }
    
    public MimeBodyPart(InputStream inputStream) {
        if (!(inputStream instanceof ByteArrayInputStream) && !(inputStream instanceof BufferedInputStream) && !(inputStream instanceof SharedInputStream)) {
            inputStream = new BufferedInputStream(inputStream);
        }
        this.headers = new InternetHeaders(inputStream);
        if (inputStream instanceof SharedInputStream) {
            final SharedInputStream sharedInputStream = (SharedInputStream)inputStream;
            this.contentStream = sharedInputStream.newStream(sharedInputStream.getPosition(), -1L);
        }
        else {
            try {
                this.content = ASCIIUtility.getBytes(inputStream);
            }
            catch (IOException ex) {
                throw new MessagingException("Error reading input stream", ex);
            }
        }
    }
    
    public MimeBodyPart(final InternetHeaders headers, final byte[] content) {
        this.headers = headers;
        this.content = content;
    }
    
    @Override
    public int getSize() {
        if (this.content != null) {
            return this.content.length;
        }
        if (this.contentStream != null) {
            try {
                final int available = this.contentStream.available();
                if (available > 0) {
                    return available;
                }
            }
            catch (IOException ex) {}
        }
        return -1;
    }
    
    @Override
    public int getLineCount() {
        return -1;
    }
    
    @Override
    public String getContentType() {
        String cleanContentType = MimeUtil.cleanContentType((MimePart)this, this.getHeader("Content-Type", null));
        if (cleanContentType == null) {
            cleanContentType = "text/plain";
        }
        return cleanContentType;
    }
    
    @Override
    public boolean isMimeType(final String s) {
        return isMimeType(this, s);
    }
    
    @Override
    public String getDisposition() {
        return getDisposition(this);
    }
    
    @Override
    public void setDisposition(final String s) {
        setDisposition(this, s);
    }
    
    @Override
    public String getEncoding() {
        return getEncoding(this);
    }
    
    @Override
    public String getContentID() {
        return this.getHeader("Content-Id", null);
    }
    
    public void setContentID(final String s) {
        if (s == null) {
            this.removeHeader("Content-ID");
        }
        else {
            this.setHeader("Content-ID", s);
        }
    }
    
    @Override
    public String getContentMD5() {
        return this.getHeader("Content-MD5", null);
    }
    
    @Override
    public void setContentMD5(final String s) {
        this.setHeader("Content-MD5", s);
    }
    
    @Override
    public String[] getContentLanguage() {
        return getContentLanguage(this);
    }
    
    @Override
    public void setContentLanguage(final String[] array) {
        setContentLanguage(this, array);
    }
    
    @Override
    public String getDescription() {
        return getDescription(this);
    }
    
    @Override
    public void setDescription(final String s) {
        this.setDescription(s, null);
    }
    
    public void setDescription(final String s, final String s2) {
        setDescription(this, s, s2);
    }
    
    @Override
    public String getFileName() {
        return getFileName(this);
    }
    
    @Override
    public void setFileName(final String s) {
        setFileName(this, s);
    }
    
    @Override
    public InputStream getInputStream() {
        return this.getDataHandler().getInputStream();
    }
    
    protected InputStream getContentStream() {
        if (this.contentStream != null) {
            return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
        }
        if (this.content != null) {
            return new ByteArrayInputStream(this.content);
        }
        throw new MessagingException("No MimeBodyPart content");
    }
    
    public InputStream getRawInputStream() {
        return this.getContentStream();
    }
    
    @Override
    public DataHandler getDataHandler() {
        if (this.dh == null) {
            this.dh = new MimePartDataHandler(new MimePartDataSource(this));
        }
        return this.dh;
    }
    
    @Override
    public Object getContent() {
        if (this.cachedContent != null) {
            return this.cachedContent;
        }
        Object content;
        try {
            content = this.getDataHandler().getContent();
        }
        catch (FolderClosedIOException ex) {
            throw new FolderClosedException(ex.getFolder(), ex.getMessage());
        }
        catch (MessageRemovedIOException ex2) {
            throw new MessageRemovedException(ex2.getMessage());
        }
        if (MimeBodyPart.cacheMultipart && (content instanceof Multipart || content instanceof Message) && (this.content != null || this.contentStream != null)) {
            this.cachedContent = content;
            if (content instanceof MimeMultipart) {
                ((MimeMultipart)content).parse();
            }
        }
        return content;
    }
    
    @Override
    public void setDataHandler(final DataHandler dh) {
        this.dh = dh;
        this.cachedContent = null;
        invalidateContentHeaders(this);
    }
    
    @Override
    public void setContent(final Object o, final String s) {
        if (o instanceof Multipart) {
            this.setContent((Multipart)o);
        }
        else {
            this.setDataHandler(new DataHandler(o, s));
        }
    }
    
    @Override
    public void setText(final String s) {
        this.setText(s, null);
    }
    
    @Override
    public void setText(final String s, final String s2) {
        setText(this, s, s2, "plain");
    }
    
    @Override
    public void setText(final String s, final String s2, final String s3) {
        setText(this, s, s2, s3);
    }
    
    @Override
    public void setContent(final Multipart multipart) {
        this.setDataHandler(new DataHandler(multipart, multipart.getContentType()));
        multipart.setParent(this);
    }
    
    public void attachFile(final File file) {
        final FileDataSource fileDataSource = new FileDataSource(file);
        this.setDataHandler(new DataHandler(fileDataSource));
        this.setFileName(fileDataSource.getName());
        this.setDisposition("attachment");
    }
    
    public void attachFile(final String s) {
        this.attachFile(new File(s));
    }
    
    public void attachFile(final File file, final String s, final String s2) {
        final EncodedFileDataSource encodedFileDataSource = new EncodedFileDataSource(file, s, s2);
        this.setDataHandler(new DataHandler(encodedFileDataSource));
        this.setFileName(encodedFileDataSource.getName());
        this.setDisposition("attachment");
    }
    
    public void attachFile(final String s, final String s2, final String s3) {
        this.attachFile(new File(s), s2, s3);
    }
    
    public void saveFile(final File file) {
        OutputStream outputStream = null;
        InputStream inputStream = null;
        try {
            outputStream = new BufferedOutputStream(new FileOutputStream(file));
            inputStream = this.getInputStream();
            final byte[] array = new byte[8192];
            int read;
            while ((read = inputStream.read(array)) > 0) {
                outputStream.write(array, 0, read);
            }
        }
        finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            catch (IOException ex) {}
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            }
            catch (IOException ex2) {}
        }
    }
    
    public void saveFile(final String s) {
        this.saveFile(new File(s));
    }
    
    @Override
    public void writeTo(final OutputStream outputStream) {
        writeTo(this, outputStream, null);
    }
    
    @Override
    public String[] getHeader(final String s) {
        return this.headers.getHeader(s);
    }
    
    @Override
    public String getHeader(final String s, final String s2) {
        return this.headers.getHeader(s, s2);
    }
    
    @Override
    public void setHeader(final String s, final String s2) {
        this.headers.setHeader(s, s2);
    }
    
    @Override
    public void addHeader(final String s, final String s2) {
        this.headers.addHeader(s, s2);
    }
    
    @Override
    public void removeHeader(final String s) {
        this.headers.removeHeader(s);
    }
    
    @Override
    public Enumeration getAllHeaders() {
        return this.headers.getAllHeaders();
    }
    
    @Override
    public Enumeration getMatchingHeaders(final String[] array) {
        return this.headers.getMatchingHeaders(array);
    }
    
    @Override
    public Enumeration getNonMatchingHeaders(final String[] array) {
        return this.headers.getNonMatchingHeaders(array);
    }
    
    @Override
    public void addHeaderLine(final String s) {
        this.headers.addHeaderLine(s);
    }
    
    @Override
    public Enumeration getAllHeaderLines() {
        return this.headers.getAllHeaderLines();
    }
    
    @Override
    public Enumeration getMatchingHeaderLines(final String[] array) {
        return this.headers.getMatchingHeaderLines(array);
    }
    
    @Override
    public Enumeration getNonMatchingHeaderLines(final String[] array) {
        return this.headers.getNonMatchingHeaderLines(array);
    }
    
    protected void updateHeaders() {
        updateHeaders(this);
        if (this.cachedContent != null) {
            this.dh = new DataHandler(this.cachedContent, this.getContentType());
            this.cachedContent = null;
            this.content = null;
            if (this.contentStream != null) {
                try {
                    this.contentStream.close();
                }
                catch (IOException ex) {}
            }
            this.contentStream = null;
        }
    }
    
    static boolean isMimeType(final MimePart mimePart, final String s) {
        try {
            return new ContentType(mimePart.getContentType()).match(s);
        }
        catch (ParseException ex) {
            return mimePart.getContentType().equalsIgnoreCase(s);
        }
    }
    
    static void setText(final MimePart mimePart, final String s, String defaultMIMECharset, final String s2) {
        if (defaultMIMECharset == null) {
            if (MimeUtility.checkAscii(s) != 1) {
                defaultMIMECharset = MimeUtility.getDefaultMIMECharset();
            }
            else {
                defaultMIMECharset = "us-ascii";
            }
        }
        mimePart.setContent(s, "text/" + s2 + "; charset=" + MimeUtility.quote(defaultMIMECharset, "()<>@,;:\\\"\t []/?="));
    }
    
    static String getDisposition(final MimePart mimePart) {
        final String header = mimePart.getHeader("Content-Disposition", null);
        if (header == null) {
            return null;
        }
        return new ContentDisposition(header).getDisposition();
    }
    
    static void setDisposition(final MimePart mimePart, String string) {
        if (string == null) {
            mimePart.removeHeader("Content-Disposition");
        }
        else {
            final String header = mimePart.getHeader("Content-Disposition", null);
            if (header != null) {
                final ContentDisposition contentDisposition = new ContentDisposition(header);
                contentDisposition.setDisposition(string);
                string = contentDisposition.toString();
            }
            mimePart.setHeader("Content-Disposition", string);
        }
    }
    
    static String getDescription(final MimePart mimePart) {
        final String header = mimePart.getHeader("Content-Description", null);
        if (header == null) {
            return null;
        }
        try {
            return MimeUtility.decodeText(MimeUtility.unfold(header));
        }
        catch (UnsupportedEncodingException ex) {
            return header;
        }
    }
    
    static void setDescription(final MimePart mimePart, final String s, final String s2) {
        if (s == null) {
            mimePart.removeHeader("Content-Description");
            return;
        }
        try {
            mimePart.setHeader("Content-Description", MimeUtility.fold(21, MimeUtility.encodeText(s, s2, null)));
        }
        catch (UnsupportedEncodingException ex) {
            throw new MessagingException("Encoding error", ex);
        }
    }
    
    static String getFileName(final MimePart mimePart) {
        String s = null;
        final String header = mimePart.getHeader("Content-Disposition", null);
        if (header != null) {
            s = new ContentDisposition(header).getParameter("filename");
        }
        if (s == null) {
            final String cleanContentType = MimeUtil.cleanContentType(mimePart, mimePart.getHeader("Content-Type", null));
            if (cleanContentType != null) {
                try {
                    s = new ContentType(cleanContentType).getParameter("name");
                }
                catch (ParseException ex2) {}
            }
        }
        if (MimeBodyPart.decodeFileName && s != null) {
            try {
                s = MimeUtility.decodeText(s);
            }
            catch (UnsupportedEncodingException ex) {
                throw new MessagingException("Can't decode filename", ex);
            }
        }
        return s;
    }
    
    static void setFileName(final MimePart mimePart, String encodeText) {
        if (MimeBodyPart.encodeFileName && encodeText != null) {
            try {
                encodeText = MimeUtility.encodeText(encodeText);
            }
            catch (UnsupportedEncodingException ex) {
                throw new MessagingException("Can't encode filename", ex);
            }
        }
        final String header = mimePart.getHeader("Content-Disposition", null);
        final ContentDisposition contentDisposition = new ContentDisposition((header == null) ? "attachment" : header);
        contentDisposition.setParameter("filename", encodeText);
        mimePart.setHeader("Content-Disposition", contentDisposition.toString());
        if (MimeBodyPart.setContentTypeFileName) {
            final String cleanContentType = MimeUtil.cleanContentType(mimePart, mimePart.getHeader("Content-Type", null));
            if (cleanContentType != null) {
                try {
                    final ContentType contentType = new ContentType(cleanContentType);
                    contentType.setParameter("name", encodeText);
                    mimePart.setHeader("Content-Type", contentType.toString());
                }
                catch (ParseException ex2) {}
            }
        }
    }
    
    static String[] getContentLanguage(final MimePart mimePart) {
        final String header = mimePart.getHeader("Content-Language", null);
        if (header == null) {
            return null;
        }
        final HeaderTokenizer headerTokenizer = new HeaderTokenizer(header, "()<>@,;:\\\"\t []/?=");
        final Vector<String> vector = new Vector<String>();
        while (true) {
            final HeaderTokenizer.Token next = headerTokenizer.next();
            final int type = next.getType();
            if (type == -4) {
                break;
            }
            if (type != -1) {
                continue;
            }
            vector.addElement(next.getValue());
        }
        if (vector.size() == 0) {
            return null;
        }
        final String[] array = new String[vector.size()];
        vector.copyInto(array);
        return array;
    }
    
    static void setContentLanguage(final MimePart mimePart, final String[] array) {
        final StringBuffer sb = new StringBuffer(array[0]);
        int n = "Content-Language".length() + 2 + array[0].length();
        for (int i = 1; i < array.length; ++i) {
            sb.append(',');
            if (++n > 76) {
                sb.append("\r\n\t");
                n = 8;
            }
            sb.append(array[i]);
            n += array[i].length();
        }
        mimePart.setHeader("Content-Language", sb.toString());
    }
    
    static String getEncoding(final MimePart mimePart) {
        final String header = mimePart.getHeader("Content-Transfer-Encoding", null);
        if (header == null) {
            return null;
        }
        final String trim = header.trim();
        if (trim.equalsIgnoreCase("7bit") || trim.equalsIgnoreCase("8bit") || trim.equalsIgnoreCase("quoted-printable") || trim.equalsIgnoreCase("binary") || trim.equalsIgnoreCase("base64")) {
            return trim;
        }
        final HeaderTokenizer headerTokenizer = new HeaderTokenizer(trim, "()<>@,;:\\\"\t []/?=");
        int i;
        HeaderTokenizer.Token next;
        do {
            next = headerTokenizer.next();
            i = next.getType();
            if (i == -4) {
                return trim;
            }
        } while (i != -1);
        return next.getValue();
    }
    
    static void setEncoding(final MimePart mimePart, final String s) {
        mimePart.setHeader("Content-Transfer-Encoding", s);
    }
    
    static String restrictEncoding(final MimePart mimePart, final String s) {
        if (!MimeBodyPart.ignoreMultipartEncoding || s == null) {
            return s;
        }
        if (s.equalsIgnoreCase("7bit") || s.equalsIgnoreCase("8bit") || s.equalsIgnoreCase("binary")) {
            return s;
        }
        final String contentType = mimePart.getContentType();
        if (contentType == null) {
            return s;
        }
        try {
            final ContentType contentType2 = new ContentType(contentType);
            if (contentType2.match("multipart/*")) {
                return null;
            }
            if (contentType2.match("message/*") && !PropUtil.getBooleanSystemProperty("mail.mime.allowencodedmessages", false)) {
                return null;
            }
        }
        catch (ParseException ex) {}
        return s;
    }
    
    static void updateHeaders(final MimePart mimePart) {
        final DataHandler dataHandler = mimePart.getDataHandler();
        if (dataHandler == null) {
            return;
        }
        try {
            String s = dataHandler.getContentType();
            boolean b = false;
            final boolean b2 = mimePart.getHeader("Content-Type") == null;
            final ContentType contentType = new ContentType(s);
            if (contentType.match("multipart/*")) {
                b = true;
                Object content;
                if (mimePart instanceof MimeBodyPart) {
                    final MimeBodyPart mimeBodyPart = (MimeBodyPart)mimePart;
                    content = ((mimeBodyPart.cachedContent != null) ? mimeBodyPart.cachedContent : dataHandler.getContent());
                }
                else if (mimePart instanceof MimeMessage) {
                    final MimeMessage mimeMessage = (MimeMessage)mimePart;
                    content = ((mimeMessage.cachedContent != null) ? mimeMessage.cachedContent : dataHandler.getContent());
                }
                else {
                    content = dataHandler.getContent();
                }
                if (!(content instanceof MimeMultipart)) {
                    throw new MessagingException("MIME part of type \"" + s + "\" contains object of type " + ((MimeMultipart)content).getClass().getName() + " instead of MimeMultipart");
                }
                ((MimeMultipart)content).updateHeaders();
            }
            else if (contentType.match("message/rfc822")) {
                b = true;
            }
            if (dataHandler instanceof MimePartDataHandler) {
                return;
            }
            if (!b) {
                if (mimePart.getHeader("Content-Transfer-Encoding") == null) {
                    setEncoding(mimePart, MimeUtility.getEncoding(dataHandler));
                }
                if (b2 && MimeBodyPart.setDefaultTextCharset && contentType.match("text/*") && contentType.getParameter("charset") == null) {
                    final String encoding = mimePart.getEncoding();
                    String defaultMIMECharset;
                    if (encoding != null && encoding.equalsIgnoreCase("7bit")) {
                        defaultMIMECharset = "us-ascii";
                    }
                    else {
                        defaultMIMECharset = MimeUtility.getDefaultMIMECharset();
                    }
                    contentType.setParameter("charset", defaultMIMECharset);
                    s = contentType.toString();
                }
            }
            if (b2) {
                final String header = mimePart.getHeader("Content-Disposition", null);
                if (header != null) {
                    final String parameter = new ContentDisposition(header).getParameter("filename");
                    if (parameter != null) {
                        contentType.setParameter("name", parameter);
                        s = contentType.toString();
                    }
                }
                mimePart.setHeader("Content-Type", s);
            }
        }
        catch (IOException ex) {
            throw new MessagingException("IOException updating headers", ex);
        }
    }
    
    static void invalidateContentHeaders(final MimePart mimePart) {
        mimePart.removeHeader("Content-Type");
        mimePart.removeHeader("Content-Transfer-Encoding");
    }
    
    static void writeTo(final MimePart mimePart, OutputStream encode, final String[] array) {
        LineOutputStream lineOutputStream;
        if (encode instanceof LineOutputStream) {
            lineOutputStream = (LineOutputStream)encode;
        }
        else {
            lineOutputStream = new LineOutputStream(encode);
        }
        final Enumeration nonMatchingHeaderLines = mimePart.getNonMatchingHeaderLines(array);
        while (nonMatchingHeaderLines.hasMoreElements()) {
            lineOutputStream.writeln((String)nonMatchingHeaderLines.nextElement());
        }
        lineOutputStream.writeln();
        InputStream inputStream = null;
        try {
            if (mimePart.getDataHandler() instanceof MimePartDataHandler) {
                if (mimePart instanceof MimeBodyPart) {
                    inputStream = ((MimeBodyPart)mimePart).getContentStream();
                }
                else if (mimePart instanceof MimeMessage) {
                    inputStream = ((MimeMessage)mimePart).getContentStream();
                }
            }
            if (inputStream != null) {
                final byte[] array2 = new byte[8192];
                int read;
                while ((read = inputStream.read(array2)) > 0) {
                    encode.write(array2, 0, read);
                }
            }
            else {
                encode = MimeUtility.encode(encode, restrictEncoding(mimePart, mimePart.getEncoding()));
                mimePart.getDataHandler().writeTo(encode);
            }
        }
        finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        encode.flush();
    }
    
    static {
        setDefaultTextCharset = PropUtil.getBooleanSystemProperty("mail.mime.setdefaulttextcharset", true);
        setContentTypeFileName = PropUtil.getBooleanSystemProperty("mail.mime.setcontenttypefilename", true);
        encodeFileName = PropUtil.getBooleanSystemProperty("mail.mime.encodefilename", false);
        decodeFileName = PropUtil.getBooleanSystemProperty("mail.mime.decodefilename", false);
        ignoreMultipartEncoding = PropUtil.getBooleanSystemProperty("mail.mime.ignoremultipartencoding", true);
        cacheMultipart = PropUtil.getBooleanSystemProperty("mail.mime.cachemultipart", true);
    }
    
    static class MimePartDataHandler extends DataHandler
    {
        public MimePartDataHandler(final DataSource dataSource) {
            super(dataSource);
        }
    }
    
    private static class EncodedFileDataSource extends FileDataSource implements EncodingAware
    {
        private String contentType;
        private String encoding;
        
        public EncodedFileDataSource(final File file, final String contentType, final String encoding) {
            super(file);
            this.contentType = contentType;
            this.encoding = encoding;
        }
        
        @Override
        public String getContentType() {
            return (this.contentType != null) ? this.contentType : super.getContentType();
        }
        
        @Override
        public String getEncoding() {
            return this.encoding;
        }
    }
}
