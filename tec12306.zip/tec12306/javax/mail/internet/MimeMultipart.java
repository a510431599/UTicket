// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.io.EOFException;
import java.io.InputStream;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import com.sun.mail.util.LineInputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import javax.mail.MessagingException;
import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.OutputStream;
import com.sun.mail.util.PropUtil;
import javax.mail.MultipartDataSource;
import javax.mail.MessageAware;
import javax.mail.BodyPart;
import javax.activation.DataSource;
import javax.mail.Multipart;

public class MimeMultipart extends Multipart
{
    protected DataSource ds;
    protected boolean parsed;
    protected boolean complete;
    protected String preamble;
    protected boolean ignoreMissingEndBoundary;
    protected boolean ignoreMissingBoundaryParameter;
    protected boolean ignoreExistingBoundaryParameter;
    protected boolean allowEmpty;
    
    public MimeMultipart() {
        this("mixed");
    }
    
    public MimeMultipart(final String s) {
        this.ds = null;
        this.parsed = true;
        this.complete = true;
        this.preamble = null;
        this.ignoreMissingEndBoundary = true;
        this.ignoreMissingBoundaryParameter = true;
        this.ignoreExistingBoundaryParameter = false;
        this.allowEmpty = false;
        final String uniqueBoundaryValue = UniqueValue.getUniqueBoundaryValue();
        final ContentType contentType = new ContentType("multipart", s, null);
        contentType.setParameter("boundary", uniqueBoundaryValue);
        this.contentType = contentType.toString();
        this.initializeProperties();
    }
    
    public MimeMultipart(final BodyPart... array) {
        this();
        for (int length = array.length, i = 0; i < length; ++i) {
            super.addBodyPart(array[i]);
        }
    }
    
    public MimeMultipart(final String s, final BodyPart... array) {
        this(s);
        for (int length = array.length, i = 0; i < length; ++i) {
            super.addBodyPart(array[i]);
        }
    }
    
    public MimeMultipart(final DataSource ds) {
        this.ds = null;
        this.parsed = true;
        this.complete = true;
        this.preamble = null;
        this.ignoreMissingEndBoundary = true;
        this.ignoreMissingBoundaryParameter = true;
        this.ignoreExistingBoundaryParameter = false;
        this.allowEmpty = false;
        if (ds instanceof MessageAware) {
            this.setParent(((MessageAware)ds).getMessageContext().getPart());
        }
        if (ds instanceof MultipartDataSource) {
            this.setMultipartDataSource((MultipartDataSource)ds);
            return;
        }
        this.parsed = false;
        this.ds = ds;
        this.contentType = ds.getContentType();
    }
    
    protected void initializeProperties() {
        this.ignoreMissingEndBoundary = PropUtil.getBooleanSystemProperty("mail.mime.multipart.ignoremissingendboundary", true);
        this.ignoreMissingBoundaryParameter = PropUtil.getBooleanSystemProperty("mail.mime.multipart.ignoremissingboundaryparameter", true);
        this.ignoreExistingBoundaryParameter = PropUtil.getBooleanSystemProperty("mail.mime.multipart.ignoreexistingboundaryparameter", false);
        this.allowEmpty = PropUtil.getBooleanSystemProperty("mail.mime.multipart.allowempty", false);
    }
    
    public synchronized void setSubType(final String subType) {
        final ContentType contentType = new ContentType(this.contentType);
        contentType.setSubType(subType);
        this.contentType = contentType.toString();
    }
    
    @Override
    public synchronized int getCount() {
        this.parse();
        return super.getCount();
    }
    
    @Override
    public synchronized BodyPart getBodyPart(final int n) {
        this.parse();
        return super.getBodyPart(n);
    }
    
    public synchronized BodyPart getBodyPart(final String s) {
        this.parse();
        for (int count = this.getCount(), i = 0; i < count; ++i) {
            final MimeBodyPart mimeBodyPart = (MimeBodyPart)this.getBodyPart(i);
            final String contentID = mimeBodyPart.getContentID();
            if (contentID != null && contentID.equals(s)) {
                return mimeBodyPart;
            }
        }
        return null;
    }
    
    @Override
    public boolean removeBodyPart(final BodyPart bodyPart) {
        this.parse();
        return super.removeBodyPart(bodyPart);
    }
    
    @Override
    public void removeBodyPart(final int n) {
        this.parse();
        super.removeBodyPart(n);
    }
    
    @Override
    public synchronized void addBodyPart(final BodyPart bodyPart) {
        this.parse();
        super.addBodyPart(bodyPart);
    }
    
    @Override
    public synchronized void addBodyPart(final BodyPart bodyPart, final int n) {
        this.parse();
        super.addBodyPart(bodyPart, n);
    }
    
    public synchronized boolean isComplete() {
        this.parse();
        return this.complete;
    }
    
    public synchronized String getPreamble() {
        this.parse();
        return this.preamble;
    }
    
    public synchronized void setPreamble(final String preamble) {
        this.preamble = preamble;
    }
    
    protected synchronized void updateHeaders() {
        this.parse();
        for (int i = 0; i < this.parts.size(); ++i) {
            ((MimeBodyPart)this.parts.elementAt(i)).updateHeaders();
        }
    }
    
    @Override
    public synchronized void writeTo(final OutputStream outputStream) {
        this.parse();
        final String string = "--" + new ContentType(this.contentType).getParameter("boundary");
        final LineOutputStream lineOutputStream = new LineOutputStream(outputStream);
        if (this.preamble != null) {
            final byte[] bytes = ASCIIUtility.getBytes(this.preamble);
            lineOutputStream.write(bytes);
            if (bytes.length > 0 && bytes[bytes.length - 1] != 13 && bytes[bytes.length - 1] != 10) {
                lineOutputStream.writeln();
            }
        }
        if (this.parts.size() == 0) {
            if (!this.allowEmpty) {
                throw new MessagingException("Empty multipart: " + this.contentType);
            }
            lineOutputStream.writeln(string);
            lineOutputStream.writeln();
        }
        else {
            for (int i = 0; i < this.parts.size(); ++i) {
                lineOutputStream.writeln(string);
                ((MimeBodyPart)this.parts.elementAt(i)).writeTo(outputStream);
                lineOutputStream.writeln();
            }
        }
        lineOutputStream.writeln(string + "--");
    }
    
    protected synchronized void parse() {
        if (this.parsed) {
            return;
        }
        this.initializeProperties();
        SharedInputStream sharedInputStream = null;
        long position = 0L;
        long n = 0L;
        InputStream inputStream;
        try {
            inputStream = this.ds.getInputStream();
            if (!(inputStream instanceof ByteArrayInputStream) && !(inputStream instanceof BufferedInputStream) && !(inputStream instanceof SharedInputStream)) {
                inputStream = new BufferedInputStream(inputStream);
            }
        }
        catch (Exception ex) {
            throw new MessagingException("No inputstream from datasource", ex);
        }
        if (inputStream instanceof SharedInputStream) {
            sharedInputStream = (SharedInputStream)inputStream;
        }
        final ContentType contentType = new ContentType(this.contentType);
        String string = null;
        if (!this.ignoreExistingBoundaryParameter) {
            final String parameter = contentType.getParameter("boundary");
            if (parameter != null) {
                string = "--" + parameter;
            }
        }
        if (string == null && !this.ignoreMissingBoundaryParameter && !this.ignoreExistingBoundaryParameter) {
            throw new MessagingException("Missing boundary parameter");
        }
        try {
            final LineInputStream lineInputStream = new LineInputStream(inputStream);
            StringBuffer sb = null;
            String property = null;
            String s;
            while ((s = lineInputStream.readLine()) != null) {
                int i;
                for (i = s.length() - 1; i >= 0; --i) {
                    final char char1 = s.charAt(i);
                    if (char1 != ' ' && char1 != '\t') {
                        break;
                    }
                }
                s = s.substring(0, i + 1);
                if (string != null) {
                    if (s.equals(string)) {
                        break;
                    }
                    if (s.length() == string.length() + 2 && s.startsWith(string) && s.endsWith("--")) {
                        s = null;
                        break;
                    }
                }
                else if (s.length() > 2 && s.startsWith("--")) {
                    if (s.length() <= 4 || !allDashes(s)) {
                        string = s;
                        break;
                    }
                }
                if (s.length() > 0) {
                    if (property == null) {
                        try {
                            property = System.getProperty("line.separator", "\n");
                        }
                        catch (SecurityException ex3) {
                            property = "\n";
                        }
                    }
                    if (sb == null) {
                        sb = new StringBuffer(s.length() + 2);
                    }
                    sb.append(s).append(property);
                }
            }
            if (sb != null) {
                this.preamble = sb.toString();
            }
            if (s == null) {
                if (this.allowEmpty) {
                    return;
                }
                throw new MessagingException("Missing start boundary");
            }
            else {
                final byte[] bytes = ASCIIUtility.getBytes(string);
                final int length = bytes.length;
                final int[] array = new int[256];
                for (int j = 0; j < length; ++j) {
                    array[bytes[j] & 0xFF] = j + 1;
                }
                final int[] array2 = new int[length];
                int k = length;
            Label_0543:
                while (k > 0) {
                    while (true) {
                        int l;
                        for (l = length - 1; l >= k; --l) {
                            if (bytes[l] != bytes[l - k]) {
                                --k;
                                continue Label_0543;
                            }
                            array2[l - 1] = k;
                        }
                        while (l > 0) {
                            array2[--l] = k;
                        }
                        continue;
                    }
                }
                array2[length - 1] = 1;
                int n2 = 0;
                while (n2 == 0) {
                    InternetHeaders internetHeaders = null;
                    if (sharedInputStream != null) {
                        position = sharedInputStream.getPosition();
                        String line;
                        while ((line = lineInputStream.readLine()) != null && line.length() > 0) {}
                        if (line == null) {
                            if (!this.ignoreMissingEndBoundary) {
                                throw new MessagingException("missing multipart end boundary");
                            }
                            this.complete = false;
                            break;
                        }
                    }
                    else {
                        internetHeaders = this.createInternetHeaders(inputStream);
                    }
                    if (!inputStream.markSupported()) {
                        throw new MessagingException("Stream doesn't support mark");
                    }
                    ByteArrayOutputStream byteArrayOutputStream = null;
                    if (sharedInputStream == null) {
                        byteArrayOutputStream = new ByteArrayOutputStream();
                    }
                    else {
                        n = sharedInputStream.getPosition();
                    }
                    byte[] array3 = new byte[length];
                    byte[] array4 = new byte[length];
                    int n3 = 0;
                    int n4 = 1;
                    int n5;
                    int fully;
                    while (true) {
                        inputStream.mark(length + 4 + 1000);
                        n5 = 0;
                        fully = readFully(inputStream, array3, 0, length);
                        if (fully < length) {
                            if (!this.ignoreMissingEndBoundary) {
                                throw new MessagingException("missing multipart end boundary");
                            }
                            if (sharedInputStream != null) {
                                n = sharedInputStream.getPosition();
                            }
                            this.complete = false;
                            n2 = 1;
                            break;
                        }
                        else {
                            int n6;
                            for (n6 = length - 1; n6 >= 0 && array3[n6] == bytes[n6]; --n6) {}
                            if (n6 < 0) {
                                n5 = 0;
                                if (n4 == 0) {
                                    final byte b = array4[n3 - 1];
                                    if (b == 13 || b == 10) {
                                        n5 = 1;
                                        if (b == 10 && n3 >= 2 && array4[n3 - 2] == 13) {
                                            n5 = 2;
                                        }
                                    }
                                }
                                if (n4 != 0 || n5 > 0) {
                                    if (sharedInputStream != null) {
                                        n = sharedInputStream.getPosition() - length - n5;
                                    }
                                    int n7 = inputStream.read();
                                    if (n7 == 45 && inputStream.read() == 45) {
                                        this.complete = true;
                                        n2 = 1;
                                        break;
                                    }
                                    while (n7 == 32 || n7 == 9) {
                                        n7 = inputStream.read();
                                    }
                                    if (n7 == 10) {
                                        break;
                                    }
                                    if (n7 == 13) {
                                        inputStream.mark(1);
                                        if (inputStream.read() != 10) {
                                            inputStream.reset();
                                            break;
                                        }
                                        break;
                                    }
                                }
                                n6 = 0;
                            }
                            final int max = Math.max(n6 + 1 - array[array3[n6] & 0x7F], array2[n6]);
                            if (max < 2) {
                                if (sharedInputStream == null && n3 > 1) {
                                    byteArrayOutputStream.write(array4, 0, n3 - 1);
                                }
                                inputStream.reset();
                                this.skipFully(inputStream, 1L);
                                if (n3 >= 1) {
                                    array4[0] = array4[n3 - 1];
                                    array4[1] = array3[0];
                                    n3 = 2;
                                }
                                else {
                                    array4[0] = array3[0];
                                    n3 = 1;
                                }
                            }
                            else {
                                if (n3 > 0 && sharedInputStream == null) {
                                    byteArrayOutputStream.write(array4, 0, n3);
                                }
                                n3 = max;
                                inputStream.reset();
                                this.skipFully(inputStream, n3);
                                final byte[] array5 = array3;
                                array3 = array4;
                                array4 = array5;
                            }
                            n4 = 0;
                        }
                    }
                    MimeBodyPart mimeBodyPart;
                    if (sharedInputStream != null) {
                        mimeBodyPart = this.createMimeBodyPartIs(sharedInputStream.newStream(position, n));
                    }
                    else {
                        if (n3 - n5 > 0) {
                            byteArrayOutputStream.write(array4, 0, n3 - n5);
                        }
                        if (!this.complete && fully > 0) {
                            byteArrayOutputStream.write(array3, 0, fully);
                        }
                        mimeBodyPart = this.createMimeBodyPart(internetHeaders, byteArrayOutputStream.toByteArray());
                    }
                    super.addBodyPart(mimeBodyPart);
                }
            }
        }
        catch (IOException ex2) {
            throw new MessagingException("IO Error", ex2);
        }
        finally {
            try {
                inputStream.close();
            }
            catch (IOException ex4) {}
        }
        this.parsed = true;
    }
    
    private static boolean allDashes(final String s) {
        for (int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) != '-') {
                return false;
            }
        }
        return true;
    }
    
    private static int readFully(final InputStream inputStream, final byte[] array, int n, int i) {
        if (i == 0) {
            return 0;
        }
        int n2 = 0;
        while (i > 0) {
            final int read = inputStream.read(array, n, i);
            if (read <= 0) {
                break;
            }
            n += read;
            n2 += read;
            i -= read;
        }
        return (n2 > 0) ? n2 : -1;
    }
    
    private void skipFully(final InputStream inputStream, long n) {
        while (n > 0L) {
            final long skip = inputStream.skip(n);
            if (skip <= 0L) {
                throw new EOFException("can't skip");
            }
            n -= skip;
        }
    }
    
    protected InternetHeaders createInternetHeaders(final InputStream inputStream) {
        return new InternetHeaders(inputStream);
    }
    
    protected MimeBodyPart createMimeBodyPart(final InternetHeaders internetHeaders, final byte[] array) {
        return new MimeBodyPart(internetHeaders, array);
    }
    
    protected MimeBodyPart createMimeBodyPart(final InputStream inputStream) {
        return new MimeBodyPart(inputStream);
    }
    
    private MimeBodyPart createMimeBodyPartIs(final InputStream inputStream) {
        try {
            return this.createMimeBodyPart(inputStream);
        }
        finally {
            try {
                inputStream.close();
            }
            catch (IOException ex) {}
        }
    }
}
