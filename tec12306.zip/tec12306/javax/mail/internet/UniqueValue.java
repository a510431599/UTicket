// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import javax.mail.Session;

class UniqueValue
{
    private static int id;
    
    public static String getUniqueBoundaryValue() {
        final StringBuffer sb = new StringBuffer();
        sb.append("----=_Part_").append(getUniqueId()).append("_").append(sb.hashCode()).append('.').append(System.currentTimeMillis());
        return sb.toString();
    }
    
    public static String getUniqueMessageIDValue(final Session session) {
        final InternetAddress localAddress = InternetAddress.getLocalAddress(session);
        String address;
        if (localAddress != null) {
            address = localAddress.getAddress();
        }
        else {
            address = "javamailuser@localhost";
        }
        final StringBuffer sb = new StringBuffer();
        sb.append(sb.hashCode()).append('.').append(getUniqueId()).append('.').append(System.currentTimeMillis()).append('.').append("JavaMail.").append(address);
        return sb.toString();
    }
    
    private static synchronized int getUniqueId() {
        return UniqueValue.id++;
    }
    
    static {
        UniqueValue.id = 0;
    }
}
