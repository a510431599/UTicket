// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.util.Enumeration;
import com.sun.mail.util.LineOutputStream;
import java.io.OutputStream;

public class PreencodedMimeBodyPart extends MimeBodyPart
{
    private String encoding;
    
    public PreencodedMimeBodyPart(final String encoding) {
        this.encoding = encoding;
    }
    
    @Override
    public String getEncoding() {
        return this.encoding;
    }
    
    @Override
    public void writeTo(final OutputStream outputStream) {
        LineOutputStream lineOutputStream;
        if (outputStream instanceof LineOutputStream) {
            lineOutputStream = (LineOutputStream)outputStream;
        }
        else {
            lineOutputStream = new LineOutputStream(outputStream);
        }
        final Enumeration allHeaderLines = this.getAllHeaderLines();
        while (allHeaderLines.hasMoreElements()) {
            lineOutputStream.writeln((String)allHeaderLines.nextElement());
        }
        lineOutputStream.writeln();
        this.getDataHandler().writeTo(outputStream);
        outputStream.flush();
    }
    
    @Override
    protected void updateHeaders() {
        super.updateHeaders();
        MimeBodyPart.setEncoding(this, this.encoding);
    }
}
