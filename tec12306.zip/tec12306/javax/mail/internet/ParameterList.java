// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.util.ArrayList;
import com.sun.mail.util.PropUtil;
import java.util.Enumeration;
import java.util.Iterator;
import java.io.IOException;
import com.sun.mail.util.ASCIIUtility;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Locale;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Map;

public class ParameterList
{
    private Map list;
    private Set multisegmentNames;
    private Map slist;
    private String lastName;
    private static final boolean encodeParameters;
    private static final boolean decodeParameters;
    private static final boolean decodeParametersStrict;
    private static final boolean applehack;
    private static final boolean windowshack;
    private static final boolean parametersStrict;
    private static final char[] hex;
    
    public ParameterList() {
        this.list = new LinkedHashMap();
        this.lastName = null;
        if (ParameterList.decodeParameters) {
            this.multisegmentNames = new HashSet();
            this.slist = new HashMap();
        }
    }
    
    public ParameterList(final String s) {
        this();
        final HeaderTokenizer headerTokenizer = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
        while (true) {
            final HeaderTokenizer.Token next = headerTokenizer.next();
            final int type = next.getType();
            if (type == -4) {
                break;
            }
            if ((char)type == ';') {
                final HeaderTokenizer.Token next2 = headerTokenizer.next();
                if (next2.getType() == -4) {
                    break;
                }
                if (next2.getType() != -1) {
                    throw new ParseException("Expected parameter name, got \"" + next2.getValue() + "\"");
                }
                final String lowerCase = next2.getValue().toLowerCase(Locale.ENGLISH);
                final HeaderTokenizer.Token next3 = headerTokenizer.next();
                if ((char)next3.getType() != '=') {
                    throw new ParseException("Expected '=', got \"" + next3.getValue() + "\"");
                }
                HeaderTokenizer.Token token;
                if (ParameterList.windowshack && (lowerCase.equals("name") || lowerCase.equals("filename"))) {
                    token = headerTokenizer.next(';', true);
                }
                else if (ParameterList.parametersStrict) {
                    token = headerTokenizer.next();
                }
                else {
                    token = headerTokenizer.next(';');
                }
                final int type2 = token.getType();
                if (type2 != -1 && type2 != -2) {
                    throw new ParseException("Expected parameter value, got \"" + token.getValue() + "\"");
                }
                final String value = token.getValue();
                this.lastName = lowerCase;
                if (ParameterList.decodeParameters) {
                    this.putEncodedName(lowerCase, value);
                }
                else {
                    this.list.put(lowerCase, value);
                }
            }
            else {
                if (type != -1 || this.lastName == null || ((!ParameterList.applehack || (!this.lastName.equals("name") && !this.lastName.equals("filename"))) && ParameterList.parametersStrict)) {
                    throw new ParseException("Expected ';', got \"" + next.getValue() + "\"");
                }
                this.list.put(this.lastName, this.list.get(this.lastName) + " " + next.getValue());
            }
        }
        if (ParameterList.decodeParameters) {
            this.combineMultisegmentNames(false);
        }
    }
    
    public void combineSegments() {
        if (ParameterList.decodeParameters && this.multisegmentNames.size() > 0) {
            try {
                this.combineMultisegmentNames(true);
            }
            catch (ParseException ex) {}
        }
    }
    
    private void putEncodedName(String s, final String s2) {
        final int index = s.indexOf(42);
        if (index < 0) {
            this.list.put(s, s2);
        }
        else if (index == s.length() - 1) {
            s = s.substring(0, index);
            final Value charset = extractCharset(s2);
            try {
                charset.value = decodeBytes(charset.value, charset.charset);
            }
            catch (UnsupportedEncodingException ex) {
                if (ParameterList.decodeParametersStrict) {
                    throw new ParseException(ex.toString());
                }
            }
            this.list.put(s, charset);
        }
        else {
            final String substring = s.substring(0, index);
            this.multisegmentNames.add(substring);
            this.list.put(substring, "");
            Object charset2;
            if (s.endsWith("*")) {
                if (s.endsWith("*0*")) {
                    charset2 = extractCharset(s2);
                }
                else {
                    charset2 = new Value();
                    ((Value)charset2).encodedValue = s2;
                    ((Value)charset2).value = s2;
                }
                s = s.substring(0, s.length() - 1);
            }
            else {
                charset2 = s2;
            }
            this.slist.put(s, charset2);
        }
    }
    
    private void combineMultisegmentNames(final boolean b) {
        boolean b2 = false;
        try {
            for (final String s : this.multisegmentNames) {
                final StringBuffer sb = new StringBuffer();
                final MultiValue multiValue = new MultiValue();
                String charset = null;
                final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                int n = 0;
                while (true) {
                    final String string = s + "*" + n;
                    final Object value = this.slist.get(string);
                    if (value == null) {
                        break;
                    }
                    multiValue.add((String)value);
                    try {
                        if (value instanceof Value) {
                            final Value value2 = (Value)value;
                            if (n == 0) {
                                charset = value2.charset;
                            }
                            else if (charset == null) {
                                this.multisegmentNames.remove(s);
                                break;
                            }
                            decodeBytes(value2.value, byteArrayOutputStream);
                        }
                        else {
                            byteArrayOutputStream.write(ASCIIUtility.getBytes((String)value));
                        }
                    }
                    catch (IOException ex3) {}
                    this.slist.remove(string);
                    ++n;
                }
                if (n == 0) {
                    this.list.remove(s);
                }
                else {
                    try {
                        if (charset != null) {
                            multiValue.value = byteArrayOutputStream.toString(charset);
                        }
                        else {
                            multiValue.value = byteArrayOutputStream.toString();
                        }
                    }
                    catch (UnsupportedEncodingException ex) {
                        if (ParameterList.decodeParametersStrict) {
                            throw new ParseException(ex.toString());
                        }
                        multiValue.value = byteArrayOutputStream.toString(0);
                    }
                    this.list.put(s, multiValue);
                }
            }
            b2 = true;
        }
        finally {
            if (b || b2) {
                if (this.slist.size() > 0) {
                    for (final Value next : this.slist.values()) {
                        if (next instanceof Value) {
                            final Value value3 = next;
                            try {
                                value3.value = decodeBytes(value3.value, value3.charset);
                            }
                            catch (UnsupportedEncodingException ex2) {
                                if (ParameterList.decodeParametersStrict) {
                                    throw new ParseException(ex2.toString());
                                }
                                continue;
                            }
                        }
                    }
                    this.list.putAll(this.slist);
                }
                this.multisegmentNames.clear();
                this.slist.clear();
            }
        }
    }
    
    public int size() {
        return this.list.size();
    }
    
    public String get(final String s) {
        final String value = this.list.get(s.trim().toLowerCase(Locale.ENGLISH));
        String s2;
        if (value instanceof MultiValue) {
            s2 = ((MultiValue)value).value;
        }
        else if (value instanceof Value) {
            s2 = ((Value)value).value;
        }
        else {
            s2 = value;
        }
        return s2;
    }
    
    public void set(String lowerCase, final String s) {
        lowerCase = lowerCase.trim().toLowerCase(Locale.ENGLISH);
        if (ParameterList.decodeParameters) {
            try {
                this.putEncodedName(lowerCase, s);
            }
            catch (ParseException ex) {
                this.list.put(lowerCase, s);
            }
        }
        else {
            this.list.put(lowerCase, s);
        }
    }
    
    public void set(final String s, final String s2, final String s3) {
        if (ParameterList.encodeParameters) {
            final Value encodeValue = encodeValue(s2, s3);
            if (encodeValue != null) {
                this.list.put(s.trim().toLowerCase(Locale.ENGLISH), encodeValue);
            }
            else {
                this.set(s, s2);
            }
        }
        else {
            this.set(s, s2);
        }
    }
    
    public void remove(final String s) {
        this.list.remove(s.trim().toLowerCase(Locale.ENGLISH));
    }
    
    public Enumeration getNames() {
        return new ParamEnum(this.list.keySet().iterator());
    }
    
    @Override
    public String toString() {
        return this.toString(0);
    }
    
    public String toString(final int n) {
        final ToStringBuffer toStringBuffer = new ToStringBuffer(n);
        for (final String s : this.list.keySet()) {
            final Object value = this.list.get(s);
            if (value instanceof MultiValue) {
                final MultiValue multiValue = (MultiValue)value;
                final String string = s + "*";
                for (int i = 0; i < multiValue.size(); ++i) {
                    final Value value2 = multiValue.get(i);
                    if (value2 instanceof Value) {
                        toStringBuffer.addNV(string + i + "*", value2.encodedValue);
                    }
                    else {
                        toStringBuffer.addNV(string + i, (String)value2);
                    }
                }
            }
            else if (value instanceof Value) {
                toStringBuffer.addNV(s + "*", ((Value)value).encodedValue);
            }
            else {
                toStringBuffer.addNV(s, (String)value);
            }
        }
        return toStringBuffer.toString();
    }
    
    private static String quote(final String s) {
        return MimeUtility.quote(s, "()<>@,;:\\\"\t []/?=");
    }
    
    private static Value encodeValue(final String value, final String charset) {
        if (MimeUtility.checkAscii(value) == 1) {
            return null;
        }
        byte[] bytes;
        try {
            bytes = value.getBytes(MimeUtility.javaCharset(charset));
        }
        catch (UnsupportedEncodingException ex) {
            return null;
        }
        final StringBuffer sb = new StringBuffer(bytes.length + charset.length() + 2);
        sb.append(charset).append("''");
        for (int i = 0; i < bytes.length; ++i) {
            final char c = (char)(bytes[i] & 0xFF);
            if (c <= ' ' || c >= '\u007f' || c == '*' || c == '\'' || c == '%' || "()<>@,;:\\\"\t []/?=".indexOf(c) >= 0) {
                sb.append('%').append(ParameterList.hex[c >> 4]).append(ParameterList.hex[c & '\u000f']);
            }
            else {
                sb.append(c);
            }
        }
        final Value value2 = new Value();
        value2.charset = charset;
        value2.value = value;
        value2.encodedValue = sb.toString();
        return value2;
    }
    
    private static Value extractCharset(final String s) {
        final Value value2;
        final Value value = value2 = new Value();
        value.encodedValue = s;
        value2.value = s;
        try {
            final int index = s.indexOf(39);
            if (index <= 0) {
                if (ParameterList.decodeParametersStrict) {
                    throw new ParseException("Missing charset in encoded value: " + s);
                }
                return value;
            }
            else {
                final String substring = s.substring(0, index);
                final int index2 = s.indexOf(39, index + 1);
                if (index2 < 0) {
                    if (ParameterList.decodeParametersStrict) {
                        throw new ParseException("Missing language in encoded value: " + s);
                    }
                    return value;
                }
                else {
                    s.substring(index + 1, index2);
                    value.value = s.substring(index2 + 1);
                    value.charset = substring;
                }
            }
        }
        catch (NumberFormatException ex) {
            if (ParameterList.decodeParametersStrict) {
                throw new ParseException(ex.toString());
            }
        }
        catch (StringIndexOutOfBoundsException ex2) {
            if (ParameterList.decodeParametersStrict) {
                throw new ParseException(ex2.toString());
            }
        }
        return value;
    }
    
    private static String decodeBytes(final String s, String s2) {
        final byte[] array = new byte[s.length()];
        int i = 0;
        int n = 0;
        while (i < s.length()) {
            char char1 = s.charAt(i);
            if (char1 == '%') {
                try {
                    char1 = (char)Integer.parseInt(s.substring(i + 1, i + 3), 16);
                    i += 2;
                }
                catch (NumberFormatException ex) {
                    if (ParameterList.decodeParametersStrict) {
                        throw new ParseException(ex.toString());
                    }
                }
                catch (StringIndexOutOfBoundsException ex2) {
                    if (ParameterList.decodeParametersStrict) {
                        throw new ParseException(ex2.toString());
                    }
                }
            }
            array[n++] = (byte)char1;
            ++i;
        }
        s2 = MimeUtility.javaCharset(s2);
        if (s2 == null) {
            s2 = MimeUtility.getDefaultJavaCharset();
        }
        return new String(array, 0, n, s2);
    }
    
    private static void decodeBytes(final String s, final OutputStream outputStream) {
        for (int i = 0; i < s.length(); ++i) {
            char char1 = s.charAt(i);
            if (char1 == '%') {
                try {
                    char1 = (char)Integer.parseInt(s.substring(i + 1, i + 3), 16);
                    i += 2;
                }
                catch (NumberFormatException ex) {
                    if (ParameterList.decodeParametersStrict) {
                        throw new ParseException(ex.toString());
                    }
                }
                catch (StringIndexOutOfBoundsException ex2) {
                    if (ParameterList.decodeParametersStrict) {
                        throw new ParseException(ex2.toString());
                    }
                }
            }
            outputStream.write((byte)char1);
        }
    }
    
    static {
        encodeParameters = PropUtil.getBooleanSystemProperty("mail.mime.encodeparameters", true);
        decodeParameters = PropUtil.getBooleanSystemProperty("mail.mime.decodeparameters", true);
        decodeParametersStrict = PropUtil.getBooleanSystemProperty("mail.mime.decodeparameters.strict", false);
        applehack = PropUtil.getBooleanSystemProperty("mail.mime.applefilenames", false);
        windowshack = PropUtil.getBooleanSystemProperty("mail.mime.windowsfilenames", false);
        parametersStrict = PropUtil.getBooleanSystemProperty("mail.mime.parameters.strict", true);
        hex = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    }
    
    private static class ToStringBuffer
    {
        private int used;
        private StringBuffer sb;
        
        public ToStringBuffer(final int used) {
            this.sb = new StringBuffer();
            this.used = used;
        }
        
        public void addNV(final String s, String access$200) {
            access$200 = quote(access$200);
            this.sb.append("; ");
            this.used += 2;
            if (this.used + (s.length() + access$200.length() + 1) > 76) {
                this.sb.append("\r\n\t");
                this.used = 8;
            }
            this.sb.append(s).append('=');
            this.used += s.length() + 1;
            if (this.used + access$200.length() > 76) {
                final String fold = MimeUtility.fold(this.used, access$200);
                this.sb.append(fold);
                final int lastIndex = fold.lastIndexOf(10);
                if (lastIndex >= 0) {
                    this.used += fold.length() - lastIndex - 1;
                }
                else {
                    this.used += fold.length();
                }
            }
            else {
                this.sb.append(access$200);
                this.used += access$200.length();
            }
        }
        
        @Override
        public String toString() {
            return this.sb.toString();
        }
    }
    
    private static class ParamEnum implements Enumeration
    {
        private Iterator it;
        
        ParamEnum(final Iterator it) {
            this.it = it;
        }
        
        @Override
        public boolean hasMoreElements() {
            return this.it.hasNext();
        }
        
        @Override
        public Object nextElement() {
            return this.it.next();
        }
    }
    
    private static class MultiValue extends ArrayList
    {
        String value;
    }
    
    private static class Value
    {
        String value;
        String charset;
        String encodedValue;
    }
}
