// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import javax.mail.Part;
import java.net.UnknownServiceException;
import java.io.OutputStream;
import java.io.IOException;
import javax.mail.FolderClosedException;
import com.sun.mail.util.FolderClosedIOException;
import javax.mail.MessagingException;
import java.io.InputStream;
import javax.mail.MessageContext;
import javax.mail.MessageAware;
import javax.activation.DataSource;

public class MimePartDataSource implements DataSource, MessageAware
{
    protected MimePart part;
    private MessageContext context;
    
    public MimePartDataSource(final MimePart part) {
        this.part = part;
    }
    
    @Override
    public InputStream getInputStream() {
        try {
            InputStream inputStream;
            if (this.part instanceof MimeBodyPart) {
                inputStream = ((MimeBodyPart)this.part).getContentStream();
            }
            else {
                if (!(this.part instanceof MimeMessage)) {
                    throw new MessagingException("Unknown part");
                }
                inputStream = ((MimeMessage)this.part).getContentStream();
            }
            final String restrictEncoding = MimeBodyPart.restrictEncoding(this.part, this.part.getEncoding());
            if (restrictEncoding != null) {
                return MimeUtility.decode(inputStream, restrictEncoding);
            }
            return inputStream;
        }
        catch (FolderClosedException ex) {
            throw new FolderClosedIOException(ex.getFolder(), ex.getMessage());
        }
        catch (MessagingException ex2) {
            throw new IOException(ex2.getMessage());
        }
    }
    
    @Override
    public OutputStream getOutputStream() {
        throw new UnknownServiceException("Writing not supported");
    }
    
    @Override
    public String getContentType() {
        try {
            return this.part.getContentType();
        }
        catch (MessagingException ex) {
            return "application/octet-stream";
        }
    }
    
    @Override
    public String getName() {
        try {
            if (this.part instanceof MimeBodyPart) {
                return ((MimeBodyPart)this.part).getFileName();
            }
        }
        catch (MessagingException ex) {}
        return "";
    }
    
    @Override
    public synchronized MessageContext getMessageContext() {
        if (this.context == null) {
            this.context = new MessageContext(this.part);
        }
        return this.context;
    }
}
