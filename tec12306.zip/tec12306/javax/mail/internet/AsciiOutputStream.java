// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.io.EOFException;
import java.io.OutputStream;

class AsciiOutputStream extends OutputStream
{
    private boolean breakOnNonAscii;
    private int ascii;
    private int non_ascii;
    private int linelen;
    private boolean longLine;
    private boolean badEOL;
    private boolean checkEOL;
    private int lastb;
    private int ret;
    
    public AsciiOutputStream(final boolean breakOnNonAscii, final boolean b) {
        this.ascii = 0;
        this.non_ascii = 0;
        this.linelen = 0;
        this.longLine = false;
        this.badEOL = false;
        this.checkEOL = false;
        this.lastb = 0;
        this.ret = 0;
        this.breakOnNonAscii = breakOnNonAscii;
        this.checkEOL = (b && breakOnNonAscii);
    }
    
    @Override
    public void write(final int n) {
        this.check(n);
    }
    
    @Override
    public void write(final byte[] array) {
        this.write(array, 0, array.length);
    }
    
    @Override
    public void write(final byte[] array, final int n, int n2) {
        n2 += n;
        for (int i = n; i < n2; ++i) {
            this.check(array[i]);
        }
    }
    
    private final void check(int lastb) {
        lastb &= 0xFF;
        if (this.checkEOL && ((this.lastb == 13 && lastb != 10) || (this.lastb != 13 && lastb == 10))) {
            this.badEOL = true;
        }
        if (lastb == 13 || lastb == 10) {
            this.linelen = 0;
        }
        else {
            ++this.linelen;
            if (this.linelen > 998) {
                this.longLine = true;
            }
        }
        if (MimeUtility.nonascii(lastb)) {
            ++this.non_ascii;
            if (this.breakOnNonAscii) {
                this.ret = 3;
                throw new EOFException();
            }
        }
        else {
            ++this.ascii;
        }
        this.lastb = lastb;
    }
    
    public int getAscii() {
        if (this.ret != 0) {
            return this.ret;
        }
        if (this.badEOL) {
            return 3;
        }
        if (this.non_ascii == 0) {
            if (this.longLine) {
                return 2;
            }
            return 1;
        }
        else {
            if (this.ascii > this.non_ascii) {
                return 2;
            }
            return 3;
        }
    }
}
