// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import com.sun.mail.util.PropUtil;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.mail.Session;
import java.util.Locale;
import java.io.UnsupportedEncodingException;
import javax.mail.Address;

public class InternetAddress extends Address implements Cloneable
{
    protected String address;
    protected String personal;
    protected String encodedPersonal;
    private static final long serialVersionUID = -7507595530758302903L;
    private static final boolean ignoreBogusGroupName;
    private static final String rfc822phrase;
    private static final String specialsNoDotNoAt = "()<>,;:\\\"[]";
    private static final String specialsNoDot = "()<>,;:\\\"[]@";
    
    public InternetAddress() {
    }
    
    public InternetAddress(final String s) {
        final InternetAddress[] parse = parse(s, true);
        if (parse.length != 1) {
            throw new AddressException("Illegal address", s);
        }
        this.address = parse[0].address;
        this.personal = parse[0].personal;
        this.encodedPersonal = parse[0].encodedPersonal;
    }
    
    public InternetAddress(final String s, final boolean b) {
        this(s);
        if (b) {
            if (this.isGroup()) {
                this.getGroup(true);
            }
            else {
                checkAddress(this.address, true, true);
            }
        }
    }
    
    public InternetAddress(final String s, final String s2) {
        this(s, s2, null);
    }
    
    public InternetAddress(final String address, final String s, final String s2) {
        this.address = address;
        this.setPersonal(s, s2);
    }
    
    public Object clone() {
        Object o = null;
        try {
            o = super.clone();
        }
        catch (CloneNotSupportedException ex) {}
        return o;
    }
    
    @Override
    public String getType() {
        return "rfc822";
    }
    
    public void setAddress(final String address) {
        this.address = address;
    }
    
    public void setPersonal(final String personal, final String s) {
        this.personal = personal;
        if (personal != null) {
            this.encodedPersonal = MimeUtility.encodeWord(personal, s, null);
        }
        else {
            this.encodedPersonal = null;
        }
    }
    
    public void setPersonal(final String personal) {
        this.personal = personal;
        if (personal != null) {
            this.encodedPersonal = MimeUtility.encodeWord(personal);
        }
        else {
            this.encodedPersonal = null;
        }
    }
    
    public String getAddress() {
        return this.address;
    }
    
    public String getPersonal() {
        if (this.personal != null) {
            return this.personal;
        }
        if (this.encodedPersonal != null) {
            try {
                return this.personal = MimeUtility.decodeText(this.encodedPersonal);
            }
            catch (Exception ex) {
                return this.encodedPersonal;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        if (this.encodedPersonal == null && this.personal != null) {
            try {
                this.encodedPersonal = MimeUtility.encodeWord(this.personal);
            }
            catch (UnsupportedEncodingException ex) {}
        }
        if (this.encodedPersonal != null) {
            return quotePhrase(this.encodedPersonal) + " <" + this.address + ">";
        }
        if (this.isGroup() || this.isSimple()) {
            return this.address;
        }
        return "<" + this.address + ">";
    }
    
    public String toUnicodeString() {
        final String personal = this.getPersonal();
        if (personal != null) {
            return quotePhrase(personal) + " <" + this.address + ">";
        }
        if (this.isGroup() || this.isSimple()) {
            return this.address;
        }
        return "<" + this.address + ">";
    }
    
    private static String quotePhrase(final String s) {
        final int length = s.length();
        boolean b = false;
        for (int i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (char1 == '\"' || char1 == '\\') {
                final StringBuffer sb = new StringBuffer(length + 3);
                sb.append('\"');
                for (int j = 0; j < length; ++j) {
                    final char char2 = s.charAt(j);
                    if (char2 == '\"' || char2 == '\\') {
                        sb.append('\\');
                    }
                    sb.append(char2);
                }
                sb.append('\"');
                return sb.toString();
            }
            if ((char1 < ' ' && char1 != '\r' && char1 != '\n' && char1 != '\t') || char1 >= '\u007f' || InternetAddress.rfc822phrase.indexOf(char1) >= 0) {
                b = true;
            }
        }
        if (b) {
            final StringBuffer sb2 = new StringBuffer(length + 2);
            sb2.append('\"').append(s).append('\"');
            return sb2.toString();
        }
        return s;
    }
    
    private static String unquote(String s) {
        if (s.startsWith("\"") && s.endsWith("\"") && s.length() > 1) {
            s = s.substring(1, s.length() - 1);
            if (s.indexOf(92) >= 0) {
                final StringBuffer sb = new StringBuffer(s.length());
                for (int i = 0; i < s.length(); ++i) {
                    char c = s.charAt(i);
                    if (c == '\\' && i < s.length() - 1) {
                        c = s.charAt(++i);
                    }
                    sb.append(c);
                }
                s = sb.toString();
            }
        }
        return s;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof InternetAddress)) {
            return false;
        }
        final String address = ((InternetAddress)o).getAddress();
        return address == this.address || (this.address != null && this.address.equalsIgnoreCase(address));
    }
    
    @Override
    public int hashCode() {
        if (this.address == null) {
            return 0;
        }
        return this.address.toLowerCase(Locale.ENGLISH).hashCode();
    }
    
    public static String toString(final Address[] array) {
        return toString(array, 0);
    }
    
    public static String toString(final Address[] array, int lengthOfLastSegment) {
        if (array == null || array.length == 0) {
            return null;
        }
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < array.length; ++i) {
            if (i != 0) {
                sb.append(", ");
                lengthOfLastSegment += 2;
            }
            final String string = array[i].toString();
            if (lengthOfLastSegment + lengthOfFirstSegment(string) > 76) {
                sb.append("\r\n\t");
                lengthOfLastSegment = 8;
            }
            sb.append(string);
            lengthOfLastSegment = lengthOfLastSegment(string, lengthOfLastSegment);
        }
        return sb.toString();
    }
    
    private static int lengthOfFirstSegment(final String s) {
        final int index;
        if ((index = s.indexOf("\r\n")) != -1) {
            return index;
        }
        return s.length();
    }
    
    private static int lengthOfLastSegment(final String s, final int n) {
        final int lastIndex;
        if ((lastIndex = s.lastIndexOf("\r\n")) != -1) {
            return s.length() - lastIndex - 2;
        }
        return s.length() + n;
    }
    
    public static InternetAddress getLocalAddress(final Session session) {
        try {
            return _getLocalAddress(session);
        }
        catch (SecurityException ex) {}
        catch (AddressException ex2) {}
        catch (UnknownHostException ex3) {}
        return null;
    }
    
    static InternetAddress _getLocalAddress(final Session session) {
        String s = null;
        String s2 = null;
        String s3 = null;
        if (session == null) {
            s = System.getProperty("user.name");
            s2 = getLocalHostName();
        }
        else {
            s3 = session.getProperty("mail.from");
            if (s3 == null) {
                s = session.getProperty("mail.user");
                if (s == null || s.length() == 0) {
                    s = session.getProperty("user.name");
                }
                if (s == null || s.length() == 0) {
                    s = System.getProperty("user.name");
                }
                s2 = session.getProperty("mail.host");
                if (s2 == null || s2.length() == 0) {
                    s2 = getLocalHostName();
                }
            }
        }
        if (s3 == null && s != null && s.length() != 0 && s2 != null && s2.length() != 0) {
            s3 = MimeUtility.quote(s.trim(), "()<>,;:\\\"[]@\t ") + "@" + s2;
        }
        if (s3 == null) {
            return null;
        }
        return new InternetAddress(s3);
    }
    
    private static String getLocalHostName() {
        String s = null;
        final InetAddress localHost = InetAddress.getLocalHost();
        if (localHost != null) {
            s = localHost.getHostName();
            if (s != null && s.length() > 0 && isInetAddressLiteral(s)) {
                s = '[' + s + ']';
            }
        }
        return s;
    }
    
    private static boolean isInetAddressLiteral(final String s) {
        boolean b = false;
        boolean b2 = false;
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            if (char1 < '0' || char1 > '9') {
                if (char1 != '.') {
                    if ((char1 >= 'a' && char1 <= 'z') || (char1 >= 'A' && char1 <= 'Z')) {
                        b = true;
                    }
                    else {
                        if (char1 != ':') {
                            return false;
                        }
                        b2 = true;
                    }
                }
            }
        }
        return !b || b2;
    }
    
    public static InternetAddress[] parse(final String s) {
        return parse(s, true);
    }
    
    public static InternetAddress[] parse(final String s, final boolean b) {
        return parse(s, b, false);
    }
    
    public static InternetAddress[] parseHeader(final String s, final boolean b) {
        return parse(s, b, true);
    }
    
    private static InternetAddress[] parse(final String s, final boolean b, final boolean b2) {
        int n = -1;
        int n2 = -1;
        final int length = s.length();
        final boolean b3 = b2 && !b;
        int n3 = 0;
        boolean b4 = false;
        int n4 = 0;
        final ArrayList<InternetAddress> list = new ArrayList<InternetAddress>();
        int n6;
        int n5 = n6 = -1;
        for (int i = 0; i < length; ++i) {
            Label_1143: {
                switch (s.charAt(i)) {
                    case '(': {
                        n4 = 1;
                        if (n6 >= 0 && n5 == -1) {
                            n5 = i;
                        }
                        final int n7 = i;
                        ++i;
                        int n8;
                        for (n8 = 1; i < length && n8 > 0; ++i) {
                            switch (s.charAt(i)) {
                                case '\\': {
                                    ++i;
                                    break;
                                }
                                case '(': {
                                    ++n8;
                                    break;
                                }
                                case ')': {
                                    --n8;
                                    break;
                                }
                            }
                        }
                        if (n8 > 0) {
                            if (!b3) {
                                throw new AddressException("Missing ')'", s, i);
                            }
                            i = n7 + 1;
                            break;
                        }
                        else {
                            --i;
                            if (n == -1) {
                                n = n7 + 1;
                            }
                            if (n2 == -1) {
                                n2 = i;
                                break;
                            }
                            break;
                        }
                        break;
                    }
                    case ')': {
                        if (!b3) {
                            throw new AddressException("Missing '('", s, i);
                        }
                        if (n6 == -1) {
                            n6 = i;
                            break;
                        }
                        break;
                    }
                    case '<': {
                        n4 = 1;
                        if (b4) {
                            if (!b3) {
                                throw new AddressException("Extra route-addr", s, i);
                            }
                            if (n6 == -1) {
                                b4 = false;
                                n4 = 0;
                                n5 = (n6 = -1);
                                break;
                            }
                            if (n3 == 0) {
                                if (n5 == -1) {
                                    n5 = i;
                                }
                                final String trim = s.substring(n6, n5).trim();
                                final InternetAddress internetAddress = new InternetAddress();
                                internetAddress.setAddress(trim);
                                if (n >= 0) {
                                    internetAddress.encodedPersonal = unquote(s.substring(n, n2).trim());
                                }
                                list.add(internetAddress);
                                b4 = false;
                                n4 = 0;
                                n5 = (n6 = -1);
                                n2 = (n = -1);
                            }
                        }
                        final int n9 = i;
                        boolean b5 = false;
                        ++i;
                    Label_0615:
                        while (i < length) {
                            switch (s.charAt(i)) {
                                case '\\': {
                                    ++i;
                                    break;
                                }
                                case '\"': {
                                    b5 = !b5;
                                    break;
                                }
                                case '>': {
                                    if (b5) {
                                        break;
                                    }
                                    break Label_0615;
                                }
                            }
                            ++i;
                        }
                        if (b5) {
                            if (!b3) {
                                throw new AddressException("Missing '\"'", s, i);
                            }
                            for (i = n9 + 1; i < length; ++i) {
                                final char char1 = s.charAt(i);
                                if (char1 == '\\') {
                                    ++i;
                                }
                                else if (char1 == '>') {
                                    break;
                                }
                            }
                        }
                        if (i < length) {
                            if (n3 == 0) {
                                n = n6;
                                if (n >= 0) {
                                    n2 = n9;
                                }
                                n6 = n9 + 1;
                            }
                            b4 = true;
                            n5 = i;
                            break;
                        }
                        if (!b3) {
                            throw new AddressException("Missing '>'", s, i);
                        }
                        i = n9 + 1;
                        if (n6 == -1) {
                            n6 = n9;
                            break;
                        }
                        break;
                    }
                    case '>': {
                        if (!b3) {
                            throw new AddressException("Missing '<'", s, i);
                        }
                        if (n6 == -1) {
                            n6 = i;
                            break;
                        }
                        break;
                    }
                    case '\"': {
                        final int n10 = i;
                        n4 = 1;
                        if (n6 == -1) {
                            n6 = i;
                        }
                        ++i;
                    Label_0867:
                        while (i < length) {
                            switch (s.charAt(i)) {
                                case '\\': {
                                    ++i;
                                    break;
                                }
                                case '\"': {
                                    break Label_0867;
                                }
                            }
                            ++i;
                        }
                        if (i < length) {
                            break;
                        }
                        if (!b3) {
                            throw new AddressException("Missing '\"'", s, i);
                        }
                        i = n10 + 1;
                        break;
                    }
                    case '[': {
                        n4 = 1;
                        final int n11 = i;
                        ++i;
                    Label_0971:
                        while (i < length) {
                            switch (s.charAt(i)) {
                                case '\\': {
                                    ++i;
                                    break;
                                }
                                case ']': {
                                    break Label_0971;
                                }
                            }
                            ++i;
                        }
                        if (i < length) {
                            break;
                        }
                        if (!b3) {
                            throw new AddressException("Missing ']'", s, i);
                        }
                        i = n11 + 1;
                        break;
                    }
                    case ';': {
                        if (n6 == -1) {
                            b4 = false;
                            n4 = 0;
                            n5 = (n6 = -1);
                            break;
                        }
                        if (n3 != 0) {
                            n3 = 0;
                            if (b2 && !b && i + 1 < length && s.charAt(i + 1) == '@') {
                                break;
                            }
                            final InternetAddress internetAddress2 = new InternetAddress();
                            internetAddress2.setAddress(s.substring(n6, i + 1).trim());
                            list.add(internetAddress2);
                            b4 = false;
                            n4 = 0;
                            n5 = (n6 = -1);
                            n2 = (n = -1);
                            break;
                        }
                        else {
                            if (!b3) {
                                throw new AddressException("Illegal semicolon, not in group", s, i);
                            }
                            break Label_1143;
                        }
                        break;
                    }
                    case ',': {
                        if (n6 == -1) {
                            b4 = false;
                            n4 = 0;
                            n5 = (n6 = -1);
                            break;
                        }
                        if (n3 != 0) {
                            b4 = false;
                            break;
                        }
                        if (n5 == -1) {
                            n5 = i;
                        }
                        String trim2 = s.substring(n6, n5).trim();
                        String unquote = null;
                        if (n4 != 0 && n >= 0) {
                            unquote = unquote(s.substring(n, n2).trim());
                            if (unquote.trim().length() == 0) {
                                unquote = null;
                            }
                        }
                        if (b2 && !b && unquote != null && unquote.indexOf(64) >= 0 && trim2.indexOf(64) < 0 && trim2.indexOf(33) < 0) {
                            final String s2 = trim2;
                            trim2 = unquote;
                            unquote = s2;
                        }
                        if (n4 != 0 || b || b2) {
                            if (!b3) {
                                checkAddress(trim2, b4, false);
                            }
                            final InternetAddress internetAddress3 = new InternetAddress();
                            internetAddress3.setAddress(trim2);
                            if (unquote != null) {
                                internetAddress3.encodedPersonal = unquote;
                            }
                            list.add(internetAddress3);
                        }
                        else {
                            final StringTokenizer stringTokenizer = new StringTokenizer(trim2);
                            while (stringTokenizer.hasMoreTokens()) {
                                final String nextToken = stringTokenizer.nextToken();
                                checkAddress(nextToken, false, false);
                                final InternetAddress internetAddress4 = new InternetAddress();
                                internetAddress4.setAddress(nextToken);
                                list.add(internetAddress4);
                            }
                        }
                        b4 = false;
                        n4 = 0;
                        n5 = (n6 = -1);
                        n2 = (n = -1);
                        break;
                    }
                    case ':': {
                        n4 = 1;
                        if (n3 != 0 && !b3) {
                            throw new AddressException("Nested group", s, i);
                        }
                        if (n6 == -1) {
                            n6 = i;
                        }
                        if (b2 && !b) {
                            if (i + 1 < length) {
                                final String s3 = ")>[]:@\\,.";
                                char c = s.charAt(i + 1);
                                if (s3.indexOf(c) >= 0) {
                                    if (c != '@') {
                                        break;
                                    }
                                    for (int j = i + 2; j < length; ++j) {
                                        c = s.charAt(j);
                                        if (c == ';') {
                                            break;
                                        }
                                        if (s3.indexOf(c) >= 0) {
                                            break;
                                        }
                                    }
                                    if (c == ';') {
                                        break;
                                    }
                                }
                            }
                            final String substring = s.substring(n6, i);
                            if (InternetAddress.ignoreBogusGroupName && (substring.equalsIgnoreCase("mailto") || substring.equalsIgnoreCase("From") || substring.equalsIgnoreCase("To") || substring.equalsIgnoreCase("Cc") || substring.equalsIgnoreCase("Subject") || substring.equalsIgnoreCase("Re"))) {
                                n6 = -1;
                            }
                            else {
                                n3 = 1;
                            }
                            break;
                        }
                        n3 = 1;
                        break;
                    }
                    case '\t':
                    case '\n':
                    case '\r':
                    case ' ': {
                        break;
                    }
                    default: {
                        if (n6 == -1) {
                            n6 = i;
                            break;
                        }
                        break;
                    }
                }
            }
        }
        if (n6 >= 0) {
            if (n5 == -1) {
                n5 = length;
            }
            String trim3 = s.substring(n6, n5).trim();
            String unquote2 = null;
            if (n4 != 0 && n >= 0) {
                unquote2 = unquote(s.substring(n, n2).trim());
                if (unquote2.trim().length() == 0) {
                    unquote2 = null;
                }
            }
            if (b2 && !b && unquote2 != null && unquote2.indexOf(64) >= 0 && trim3.indexOf(64) < 0 && trim3.indexOf(33) < 0) {
                final String s4 = trim3;
                trim3 = unquote2;
                unquote2 = s4;
            }
            if (n4 != 0 || b || b2) {
                if (!b3) {
                    checkAddress(trim3, b4, false);
                }
                final InternetAddress internetAddress5 = new InternetAddress();
                internetAddress5.setAddress(trim3);
                if (unquote2 != null) {
                    internetAddress5.encodedPersonal = unquote2;
                }
                list.add(internetAddress5);
            }
            else {
                final StringTokenizer stringTokenizer2 = new StringTokenizer(trim3);
                while (stringTokenizer2.hasMoreTokens()) {
                    final String nextToken2 = stringTokenizer2.nextToken();
                    checkAddress(nextToken2, false, false);
                    final InternetAddress internetAddress6 = new InternetAddress();
                    internetAddress6.setAddress(nextToken2);
                    list.add(internetAddress6);
                }
            }
        }
        final InternetAddress[] array = new InternetAddress[list.size()];
        list.toArray(array);
        return array;
    }
    
    public void validate() {
        if (this.isGroup()) {
            this.getGroup(true);
        }
        else {
            checkAddress(this.getAddress(), true, true);
        }
    }
    
    private static void checkAddress(final String s, final boolean b, final boolean b2) {
        int n = 0;
        final int length = s.length();
        if (length == 0) {
            throw new AddressException("Empty address", s);
        }
        if (b && s.charAt(0) == '@') {
            int indexOfAny;
            for (n = 0; (indexOfAny = indexOfAny(s, ",:", n)) >= 0; n = indexOfAny + 1) {
                if (s.charAt(n) != '@') {
                    throw new AddressException("Illegal route-addr", s);
                }
                if (s.charAt(indexOfAny) == ':') {
                    n = indexOfAny + 1;
                    break;
                }
            }
        }
        int char1 = 65535;
        int n2 = 65535;
        int n3 = 0;
        int i;
        for (i = n; i < length; ++i) {
            n2 = char1;
            char1 = s.charAt(i);
            if (char1 != 92) {
                if (n2 != 92) {
                    if (char1 == 34) {
                        if (n3 != 0) {
                            if (b2 && i + 1 < length && s.charAt(i + 1) != '@') {
                                throw new AddressException("Quote not at end of local address", s);
                            }
                            n3 = 0;
                        }
                        else {
                            if (b2 && i != 0) {
                                throw new AddressException("Quote not at start of local address", s);
                            }
                            n3 = 1;
                        }
                    }
                    else if (n3 == 0) {
                        if (char1 == 64) {
                            if (i == 0) {
                                throw new AddressException("Missing local name", s);
                            }
                            break;
                        }
                        else {
                            if (char1 <= 32 || char1 >= 127) {
                                throw new AddressException("Local address contains control or whitespace", s);
                            }
                            if ("()<>,;:\\\"[]@".indexOf(char1) >= 0) {
                                throw new AddressException("Local address contains illegal character", s);
                            }
                        }
                    }
                }
            }
        }
        if (n3 != 0) {
            throw new AddressException("Unterminated quote", s);
        }
        if (char1 != 64) {
            if (b2) {
                throw new AddressException("Missing final '@domain'", s);
            }
        }
        else {
            final int n4 = i + 1;
            if (n4 >= length) {
                throw new AddressException("Missing domain", s);
            }
            if (s.charAt(n4) == '.') {
                throw new AddressException("Domain starts with dot", s);
            }
            for (int j = n4; j < length; ++j) {
                final char char2 = s.charAt(j);
                if (char2 == '[') {
                    return;
                }
                if (char2 <= ' ' || char2 >= '\u007f') {
                    throw new AddressException("Domain contains control or whitespace", s);
                }
                if (!Character.isLetterOrDigit(char2) && char2 != '-' && char2 != '.') {
                    throw new AddressException("Domain contains illegal character", s);
                }
                if (char2 == '.' && n2 == 46) {
                    throw new AddressException("Domain contains dot-dot", s);
                }
                n2 = char2;
            }
            if (n2 == 46) {
                throw new AddressException("Domain ends with dot", s);
            }
        }
    }
    
    private boolean isSimple() {
        return this.address == null || indexOfAny(this.address, "()<>,;:\\\"[]") < 0;
    }
    
    public boolean isGroup() {
        return this.address != null && this.address.endsWith(";") && this.address.indexOf(58) > 0;
    }
    
    public InternetAddress[] getGroup(final boolean b) {
        final String address = this.getAddress();
        if (!address.endsWith(";")) {
            return null;
        }
        final int index = address.indexOf(58);
        if (index < 0) {
            return null;
        }
        return parseHeader(address.substring(index + 1, address.length() - 1), b);
    }
    
    private static int indexOfAny(final String s, final String s2) {
        return indexOfAny(s, s2, 0);
    }
    
    private static int indexOfAny(final String s, final String s2, final int n) {
        try {
            for (int length = s.length(), i = n; i < length; ++i) {
                if (s2.indexOf(s.charAt(i)) >= 0) {
                    return i;
                }
            }
            return -1;
        }
        catch (StringIndexOutOfBoundsException ex) {
            return -1;
        }
    }
    
    static {
        ignoreBogusGroupName = PropUtil.getBooleanSystemProperty("mail.mime.address.ignorebogusgroupname", true);
        rfc822phrase = "()<>@,;:\\\"\t .[]".replace(' ', '\0').replace('\t', '\0');
    }
}
