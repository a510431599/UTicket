// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

public class HeaderTokenizer
{
    private String string;
    private boolean skipComments;
    private String delimiters;
    private int currentPos;
    private int maxPos;
    private int nextPos;
    private int peekPos;
    public static final String RFC822 = "()<>@,;:\\\"\t .[]";
    public static final String MIME = "()<>@,;:\\\"\t []/?=";
    private static final Token EOFToken;
    
    public HeaderTokenizer(final String s, final String delimiters, final boolean skipComments) {
        this.string = ((s == null) ? "" : s);
        this.skipComments = skipComments;
        this.delimiters = delimiters;
        final boolean currentPos = false;
        this.peekPos = (currentPos ? 1 : 0);
        this.nextPos = (currentPos ? 1 : 0);
        this.currentPos = (currentPos ? 1 : 0);
        this.maxPos = this.string.length();
    }
    
    public HeaderTokenizer(final String s, final String s2) {
        this(s, s2, true);
    }
    
    public HeaderTokenizer(final String s) {
        this(s, "()<>@,;:\\\"\t .[]");
    }
    
    public Token next() {
        return this.next('\0', false);
    }
    
    public Token next(final char c) {
        return this.next(c, false);
    }
    
    public Token next(final char c, final boolean b) {
        this.currentPos = this.nextPos;
        final Token next = this.getNext(c, b);
        final int currentPos = this.currentPos;
        this.peekPos = currentPos;
        this.nextPos = currentPos;
        return next;
    }
    
    public Token peek() {
        this.currentPos = this.peekPos;
        final Token next = this.getNext('\0', false);
        this.peekPos = this.currentPos;
        return next;
    }
    
    public String getRemainder() {
        return this.string.substring(this.nextPos);
    }
    
    private Token getNext(final char c, final boolean b) {
        if (this.currentPos >= this.maxPos) {
            return HeaderTokenizer.EOFToken;
        }
        if (this.skipWhiteSpace() == -4) {
            return HeaderTokenizer.EOFToken;
        }
        boolean b2 = false;
        char c2;
        for (c2 = this.string.charAt(this.currentPos); c2 == '('; c2 = this.string.charAt(this.currentPos)) {
            final int n = ++this.currentPos;
            int n2 = 1;
            while (n2 > 0 && this.currentPos < this.maxPos) {
                final char char1 = this.string.charAt(this.currentPos);
                if (char1 == '\\') {
                    ++this.currentPos;
                    b2 = true;
                }
                else if (char1 == '\r') {
                    b2 = true;
                }
                else if (char1 == '(') {
                    ++n2;
                }
                else if (char1 == ')') {
                    --n2;
                }
                ++this.currentPos;
            }
            if (n2 != 0) {
                throw new ParseException("Unbalanced comments");
            }
            if (!this.skipComments) {
                String s;
                if (b2) {
                    s = filterToken(this.string, n, this.currentPos - 1, b);
                }
                else {
                    s = this.string.substring(n, this.currentPos - 1);
                }
                return new Token(-3, s);
            }
            if (this.skipWhiteSpace() == -4) {
                return HeaderTokenizer.EOFToken;
            }
        }
        if (c2 == '\"') {
            ++this.currentPos;
            return this.collectString('\"', b);
        }
        if (c2 >= ' ' && c2 < '\u007f' && this.delimiters.indexOf(c2) < 0) {
            final int currentPos = this.currentPos;
            while (this.currentPos < this.maxPos) {
                final char char2 = this.string.charAt(this.currentPos);
                if (char2 < ' ' || char2 >= '\u007f' || char2 == '(' || char2 == ' ' || char2 == '\"' || this.delimiters.indexOf(char2) >= 0) {
                    if (c > '\0' && char2 != c) {
                        this.currentPos = currentPos;
                        return this.collectString(c, b);
                    }
                    break;
                }
                else {
                    ++this.currentPos;
                }
            }
            return new Token(-1, this.string.substring(currentPos, this.currentPos));
        }
        if (c > '\0' && c2 != c) {
            return this.collectString(c, b);
        }
        ++this.currentPos;
        return new Token(c2, new String(new char[] { c2 }));
    }
    
    private Token collectString(final char c, final boolean b) {
        boolean b2 = false;
        final int currentPos = this.currentPos;
        while (this.currentPos < this.maxPos) {
            final char char1 = this.string.charAt(this.currentPos);
            if (char1 == '\\') {
                ++this.currentPos;
                b2 = true;
            }
            else if (char1 == '\r') {
                b2 = true;
            }
            else if (char1 == c) {
                ++this.currentPos;
                String s;
                if (b2) {
                    s = filterToken(this.string, currentPos, this.currentPos - 1, b);
                }
                else {
                    s = this.string.substring(currentPos, this.currentPos - 1);
                }
                if (char1 != '\"') {
                    s = trimWhiteSpace(s);
                    --this.currentPos;
                }
                return new Token(-2, s);
            }
            ++this.currentPos;
        }
        if (c == '\"') {
            throw new ParseException("Unbalanced quoted string");
        }
        String s2;
        if (b2) {
            s2 = filterToken(this.string, currentPos, this.currentPos, b);
        }
        else {
            s2 = this.string.substring(currentPos, this.currentPos);
        }
        return new Token(-2, trimWhiteSpace(s2));
    }
    
    private int skipWhiteSpace() {
        while (this.currentPos < this.maxPos) {
            final char char1;
            if ((char1 = this.string.charAt(this.currentPos)) != ' ' && char1 != '\t' && char1 != '\r' && char1 != '\n') {
                return this.currentPos;
            }
            ++this.currentPos;
        }
        return -4;
    }
    
    private static String trimWhiteSpace(final String s) {
        int n;
        char char1;
        for (n = s.length() - 1; n >= 0 && ((char1 = s.charAt(n)) == ' ' || char1 == '\t' || char1 == '\r' || char1 == '\n'); --n) {}
        if (n <= 0) {
            return "";
        }
        return s.substring(0, n + 1);
    }
    
    private static String filterToken(final String s, final int n, final int n2, final boolean b) {
        final StringBuffer sb = new StringBuffer();
        int n3 = 0;
        int n4 = 0;
        for (int i = n; i < n2; ++i) {
            final char char1 = s.charAt(i);
            if (char1 == '\n' && n4 != 0) {
                n4 = 0;
            }
            else {
                n4 = 0;
                if (n3 == 0) {
                    if (char1 == '\\') {
                        n3 = 1;
                    }
                    else if (char1 == '\r') {
                        n4 = 1;
                    }
                    else {
                        sb.append(char1);
                    }
                }
                else {
                    if (b) {
                        sb.append('\\');
                    }
                    sb.append(char1);
                    n3 = 0;
                }
            }
        }
        return sb.toString();
    }
    
    static {
        EOFToken = new Token(-4, null);
    }
    
    public static class Token
    {
        private int type;
        private String value;
        public static final int ATOM = -1;
        public static final int QUOTEDSTRING = -2;
        public static final int COMMENT = -3;
        public static final int EOF = -4;
        
        public Token(final int type, final String value) {
            this.type = type;
            this.value = value;
        }
        
        public int getType() {
            return this.type;
        }
        
        public String getValue() {
            return this.value;
        }
    }
}
