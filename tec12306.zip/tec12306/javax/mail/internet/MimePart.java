// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.internet;

import java.util.Enumeration;
import javax.mail.Part;

public interface MimePart extends Part
{
    String getHeader(final String p0, final String p1);
    
    void addHeaderLine(final String p0);
    
    Enumeration getAllHeaderLines();
    
    Enumeration getMatchingHeaderLines(final String[] p0);
    
    Enumeration getNonMatchingHeaderLines(final String[] p0);
    
    String getEncoding();
    
    String getContentID();
    
    String getContentMD5();
    
    void setContentMD5(final String p0);
    
    String[] getContentLanguage();
    
    void setContentLanguage(final String[] p0);
    
    void setText(final String p0);
    
    void setText(final String p0, final String p1);
    
    void setText(final String p0, final String p1, final String p2);
}
