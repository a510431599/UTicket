// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import java.util.Enumeration;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.net.URL;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.StringTokenizer;
import com.sun.mail.util.LineInputStream;
import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.Vector;
import com.sun.mail.util.MailLogger;
import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Properties;

public final class Session
{
    private final Properties props;
    private final Authenticator authenticator;
    private final Hashtable authTable;
    private boolean debug;
    private PrintStream out;
    private MailLogger logger;
    private final Vector providers;
    private final Hashtable providersByProtocol;
    private final Hashtable providersByClassName;
    private final Properties addressMap;
    private static Session defaultSession;
    
    private Session(final Properties props, final Authenticator authenticator) {
        this.authTable = new Hashtable();
        this.debug = false;
        this.providers = new Vector();
        this.providersByProtocol = new Hashtable();
        this.providersByClassName = new Hashtable();
        this.addressMap = new Properties();
        this.props = props;
        this.authenticator = authenticator;
        if (Boolean.valueOf(props.getProperty("mail.debug"))) {
            this.debug = true;
        }
        this.initLogger();
        this.logger.log(Level.CONFIG, "JavaMail version {0}", (Object)"1.5.0");
        Serializable s;
        if (authenticator != null) {
            s = authenticator.getClass();
        }
        else {
            s = this.getClass();
        }
        this.loadProviders((Class)s);
        this.loadAddressMap((Class)s);
    }
    
    private final void initLogger() {
        this.logger = new MailLogger((Class)this.getClass(), "DEBUG", this.debug, this.getDebugOut());
    }
    
    public static Session getInstance(final Properties properties, final Authenticator authenticator) {
        return new Session(properties, authenticator);
    }
    
    public static Session getInstance(final Properties properties) {
        return new Session(properties, null);
    }
    
    public static synchronized Session getDefaultInstance(final Properties properties, final Authenticator authenticator) {
        if (Session.defaultSession == null) {
            Session.defaultSession = new Session(properties, authenticator);
        }
        else if (Session.defaultSession.authenticator != authenticator) {
            if (Session.defaultSession.authenticator == null || authenticator == null || Session.defaultSession.authenticator.getClass().getClassLoader() != authenticator.getClass().getClassLoader()) {
                throw new SecurityException("Access to default session denied");
            }
        }
        return Session.defaultSession;
    }
    
    public static Session getDefaultInstance(final Properties properties) {
        return getDefaultInstance(properties, null);
    }
    
    public synchronized void setDebug(final boolean debug) {
        this.debug = debug;
        this.initLogger();
        this.logger.log(Level.CONFIG, "setDebug: JavaMail version {0}", (Object)"1.5.0");
    }
    
    public synchronized boolean getDebug() {
        return this.debug;
    }
    
    public synchronized void setDebugOut(final PrintStream out) {
        this.out = out;
        this.initLogger();
    }
    
    public synchronized PrintStream getDebugOut() {
        if (this.out == null) {
            return System.out;
        }
        return this.out;
    }
    
    public synchronized Provider[] getProviders() {
        final Provider[] array = new Provider[this.providers.size()];
        this.providers.copyInto(array);
        return array;
    }
    
    public synchronized Provider getProvider(final String s) {
        if (s == null || s.length() <= 0) {
            throw new NoSuchProviderException("Invalid protocol: null");
        }
        Provider provider = null;
        final String property = this.props.getProperty("mail." + s + ".class");
        if (property != null) {
            if (this.logger.isLoggable(Level.FINE)) {
                this.logger.fine("mail." + s + ".class property exists and points to " + property);
            }
            provider = (Provider)this.providersByClassName.get(property);
        }
        if (provider != null) {
            return provider;
        }
        final Provider provider2 = this.providersByProtocol.get(s);
        if (provider2 == null) {
            throw new NoSuchProviderException("No provider for " + s);
        }
        if (this.logger.isLoggable(Level.FINE)) {
            this.logger.fine("getProvider() returning " + provider2.toString());
        }
        return provider2;
    }
    
    public synchronized void setProvider(final Provider provider) {
        if (provider == null) {
            throw new NoSuchProviderException("Can't set null provider");
        }
        this.providersByProtocol.put(provider.getProtocol(), provider);
        ((Hashtable<String, String>)this.props).put("mail." + provider.getProtocol() + ".class", provider.getClassName());
    }
    
    public Store getStore() {
        return this.getStore(this.getProperty("mail.store.protocol"));
    }
    
    public Store getStore(final String s) {
        return this.getStore(new URLName(s, null, -1, null, null, null));
    }
    
    public Store getStore(final URLName urlName) {
        return this.getStore(this.getProvider(urlName.getProtocol()), urlName);
    }
    
    public Store getStore(final Provider provider) {
        return this.getStore(provider, null);
    }
    
    private Store getStore(final Provider provider, final URLName urlName) {
        if (provider == null || provider.getType() != Provider.Type.STORE) {
            throw new NoSuchProviderException("invalid provider");
        }
        try {
            return (Store)this.getService(provider, urlName);
        }
        catch (ClassCastException ex) {
            throw new NoSuchProviderException("incorrect class");
        }
    }
    
    public Folder getFolder(final URLName urlName) {
        final Store store = this.getStore(urlName);
        store.connect();
        return store.getFolder(urlName);
    }
    
    public Transport getTransport() {
        return this.getTransport(this.getProperty("mail.transport.protocol"));
    }
    
    public Transport getTransport(final String s) {
        return this.getTransport(new URLName(s, null, -1, null, null, null));
    }
    
    public Transport getTransport(final URLName urlName) {
        return this.getTransport(this.getProvider(urlName.getProtocol()), urlName);
    }
    
    public Transport getTransport(final Provider provider) {
        return this.getTransport(provider, null);
    }
    
    public Transport getTransport(final Address address) {
        final String property = this.getProperty("mail.transport.protocol." + address.getType());
        if (property != null) {
            return this.getTransport(property);
        }
        final String s = ((Hashtable<K, String>)this.addressMap).get(address.getType());
        if (s != null) {
            return this.getTransport(s);
        }
        throw new NoSuchProviderException("No provider for Address type: " + address.getType());
    }
    
    private Transport getTransport(final Provider provider, final URLName urlName) {
        if (provider == null || provider.getType() != Provider.Type.TRANSPORT) {
            throw new NoSuchProviderException("invalid provider");
        }
        try {
            return (Transport)this.getService(provider, urlName);
        }
        catch (ClassCastException ex) {
            throw new NoSuchProviderException("incorrect class");
        }
    }
    
    private Object getService(final Provider provider, URLName urlName) {
        if (provider == null) {
            throw new NoSuchProviderException("null");
        }
        if (urlName == null) {
            urlName = new URLName(provider.getProtocol(), null, -1, null, null, null);
        }
        ClassLoader classLoader;
        if (this.authenticator != null) {
            classLoader = this.authenticator.getClass().getClassLoader();
        }
        else {
            classLoader = this.getClass().getClassLoader();
        }
        Class<?> clazz = null;
        try {
            final ClassLoader contextClassLoader = getContextClassLoader();
            if (contextClassLoader != null) {
                try {
                    clazz = Class.forName(provider.getClassName(), false, contextClassLoader);
                }
                catch (ClassNotFoundException ex3) {}
            }
            if (clazz == null) {
                clazz = Class.forName(provider.getClassName(), false, classLoader);
            }
        }
        catch (Exception ex4) {
            try {
                clazz = Class.forName(provider.getClassName());
            }
            catch (Exception ex) {
                this.logger.log(Level.FINE, "Exception loading provider", (Throwable)ex);
                throw new NoSuchProviderException(provider.getProtocol());
            }
        }
        Object instance;
        try {
            instance = clazz.getConstructor(Session.class, URLName.class).newInstance(this, urlName);
        }
        catch (Exception ex2) {
            this.logger.log(Level.FINE, "Exception loading provider", (Throwable)ex2);
            throw new NoSuchProviderException(provider.getProtocol());
        }
        return instance;
    }
    
    public void setPasswordAuthentication(final URLName urlName, final PasswordAuthentication passwordAuthentication) {
        if (passwordAuthentication == null) {
            this.authTable.remove(urlName);
        }
        else {
            this.authTable.put(urlName, passwordAuthentication);
        }
    }
    
    public PasswordAuthentication getPasswordAuthentication(final URLName urlName) {
        return this.authTable.get(urlName);
    }
    
    public PasswordAuthentication requestPasswordAuthentication(final InetAddress inetAddress, final int n, final String s, final String s2, final String s3) {
        if (this.authenticator != null) {
            return this.authenticator.requestPasswordAuthentication(inetAddress, n, s, s2, s3);
        }
        return null;
    }
    
    public Properties getProperties() {
        return this.props;
    }
    
    public String getProperty(final String s) {
        return this.props.getProperty(s);
    }
    
    private void loadProviders(final Class clazz) {
        final StreamLoader streamLoader = new StreamLoader() {
            @Override
            public void load(final InputStream inputStream) {
                Session.this.loadProvidersFromStream(inputStream);
            }
        };
        try {
            this.loadFile(System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.providers", streamLoader);
        }
        catch (SecurityException ex) {
            this.logger.log(Level.CONFIG, "can't get java.home", (Throwable)ex);
        }
        this.loadAllResources("META-INF/javamail.providers", clazz, streamLoader);
        this.loadResource("/META-INF/javamail.default.providers", clazz, streamLoader);
        if (this.providers.size() == 0) {
            this.logger.config("failed to load any providers, using defaults");
            this.addProvider(new Provider(Provider.Type.STORE, "imap", "com.sun.mail.imap.IMAPStore", "Sun Microsystems, Inc.", "1.5.0"));
            this.addProvider(new Provider(Provider.Type.STORE, "imaps", "com.sun.mail.imap.IMAPSSLStore", "Sun Microsystems, Inc.", "1.5.0"));
            this.addProvider(new Provider(Provider.Type.STORE, "pop3", "com.sun.mail.pop3.POP3Store", "Sun Microsystems, Inc.", "1.5.0"));
            this.addProvider(new Provider(Provider.Type.STORE, "pop3s", "com.sun.mail.pop3.POP3SSLStore", "Sun Microsystems, Inc.", "1.5.0"));
            this.addProvider(new Provider(Provider.Type.TRANSPORT, "smtp", "com.sun.mail.smtp.SMTPTransport", "Sun Microsystems, Inc.", "1.5.0"));
            this.addProvider(new Provider(Provider.Type.TRANSPORT, "smtps", "com.sun.mail.smtp.SMTPSSLTransport", "Sun Microsystems, Inc.", "1.5.0"));
        }
        if (this.logger.isLoggable(Level.CONFIG)) {
            this.logger.config("Tables of loaded providers");
            this.logger.config("Providers Listed By Class Name: " + this.providersByClassName.toString());
            this.logger.config("Providers Listed By Protocol: " + this.providersByProtocol.toString());
        }
    }
    
    private void loadProvidersFromStream(final InputStream inputStream) {
        if (inputStream != null) {
            String line;
            while ((line = new LineInputStream(inputStream).readLine()) != null) {
                if (line.startsWith("#")) {
                    continue;
                }
                Provider.Type type = null;
                String substring = null;
                String substring2 = null;
                String substring3 = null;
                String substring4 = null;
                final StringTokenizer stringTokenizer = new StringTokenizer(line, ";");
                while (stringTokenizer.hasMoreTokens()) {
                    final String trim = stringTokenizer.nextToken().trim();
                    final int index = trim.indexOf("=");
                    if (trim.startsWith("protocol=")) {
                        substring = trim.substring(index + 1);
                    }
                    else if (trim.startsWith("type=")) {
                        final String substring5 = trim.substring(index + 1);
                        if (substring5.equalsIgnoreCase("store")) {
                            type = Provider.Type.STORE;
                        }
                        else {
                            if (!substring5.equalsIgnoreCase("transport")) {
                                continue;
                            }
                            type = Provider.Type.TRANSPORT;
                        }
                    }
                    else if (trim.startsWith("class=")) {
                        substring2 = trim.substring(index + 1);
                    }
                    else if (trim.startsWith("vendor=")) {
                        substring3 = trim.substring(index + 1);
                    }
                    else {
                        if (!trim.startsWith("version=")) {
                            continue;
                        }
                        substring4 = trim.substring(index + 1);
                    }
                }
                if (type == null || substring == null || substring2 == null || substring.length() <= 0 || substring2.length() <= 0) {
                    this.logger.log(Level.CONFIG, "Bad provider entry: {0}", (Object)line);
                }
                else {
                    this.addProvider(new Provider(type, substring, substring2, substring3, substring4));
                }
            }
        }
    }
    
    public synchronized void addProvider(final Provider provider) {
        this.providers.addElement(provider);
        this.providersByClassName.put(provider.getClassName(), provider);
        if (!this.providersByProtocol.containsKey(provider.getProtocol())) {
            this.providersByProtocol.put(provider.getProtocol(), provider);
        }
    }
    
    private void loadAddressMap(final Class clazz) {
        final StreamLoader streamLoader = new StreamLoader() {
            @Override
            public void load(final InputStream inputStream) {
                Session.this.addressMap.load(inputStream);
            }
        };
        this.loadResource("/META-INF/javamail.default.address.map", clazz, streamLoader);
        this.loadAllResources("META-INF/javamail.address.map", clazz, streamLoader);
        try {
            this.loadFile(System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.address.map", streamLoader);
        }
        catch (SecurityException ex) {
            this.logger.log(Level.CONFIG, "can't get java.home", (Throwable)ex);
        }
        if (this.addressMap.isEmpty()) {
            this.logger.config("failed to load address map, using defaults");
            ((Hashtable<String, String>)this.addressMap).put("rfc822", "smtp");
        }
    }
    
    public synchronized void setProtocolForAddress(final String s, final String s2) {
        if (s2 == null) {
            this.addressMap.remove(s);
        }
        else {
            ((Hashtable<String, String>)this.addressMap).put(s, s2);
        }
    }
    
    private void loadFile(final String s, final StreamLoader streamLoader) {
        InputStream inputStream = null;
        try {
            inputStream = new BufferedInputStream(new FileInputStream(s));
            streamLoader.load(inputStream);
            this.logger.log(Level.CONFIG, "successfully loaded file: {0}", (Object)s);
        }
        catch (FileNotFoundException ex3) {}
        catch (IOException ex) {
            if (this.logger.isLoggable(Level.CONFIG)) {
                this.logger.log(Level.CONFIG, "not loading file: " + s, (Throwable)ex);
            }
        }
        catch (SecurityException ex2) {
            if (this.logger.isLoggable(Level.CONFIG)) {
                this.logger.log(Level.CONFIG, "not loading file: " + s, (Throwable)ex2);
            }
        }
        finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            catch (IOException ex4) {}
        }
    }
    
    private void loadResource(final String s, final Class clazz, final StreamLoader streamLoader) {
        InputStream resourceAsStream = null;
        try {
            resourceAsStream = getResourceAsStream(clazz, s);
            if (resourceAsStream != null) {
                streamLoader.load(resourceAsStream);
                this.logger.log(Level.CONFIG, "successfully loaded resource: {0}", (Object)s);
            }
        }
        catch (IOException ex) {
            this.logger.log(Level.CONFIG, "Exception loading resource", (Throwable)ex);
        }
        catch (SecurityException ex2) {
            this.logger.log(Level.CONFIG, "Exception loading resource", (Throwable)ex2);
        }
        finally {
            try {
                if (resourceAsStream != null) {
                    resourceAsStream.close();
                }
            }
            catch (IOException ex3) {}
        }
    }
    
    private void loadAllResources(final String s, final Class clazz, final StreamLoader streamLoader) {
        boolean b = false;
        try {
            ClassLoader classLoader = getContextClassLoader();
            if (classLoader == null) {
                classLoader = clazz.getClassLoader();
            }
            URL[] array;
            if (classLoader != null) {
                array = getResources(classLoader, s);
            }
            else {
                array = getSystemResources(s);
            }
            if (array != null) {
                for (int i = 0; i < array.length; ++i) {
                    final URL url = array[i];
                    InputStream openStream = null;
                    this.logger.log(Level.CONFIG, "URL {0}", (Object)url);
                    try {
                        openStream = openStream(url);
                        if (openStream != null) {
                            streamLoader.load(openStream);
                            b = true;
                            this.logger.log(Level.CONFIG, "successfully loaded resource: {0}", (Object)url);
                        }
                        else {
                            this.logger.log(Level.CONFIG, "not loading resource: {0}", (Object)url);
                        }
                    }
                    catch (FileNotFoundException ex4) {}
                    catch (IOException ex) {
                        this.logger.log(Level.CONFIG, "Exception loading resource", (Throwable)ex);
                    }
                    catch (SecurityException ex2) {
                        this.logger.log(Level.CONFIG, "Exception loading resource", (Throwable)ex2);
                    }
                    finally {
                        try {
                            if (openStream != null) {
                                openStream.close();
                            }
                        }
                        catch (IOException ex5) {}
                    }
                }
            }
        }
        catch (Exception ex3) {
            this.logger.log(Level.CONFIG, "Exception loading resource", (Throwable)ex3);
        }
        if (!b) {
            this.loadResource("/" + s, clazz, streamLoader);
        }
    }
    
    private static ClassLoader getContextClassLoader() {
        return AccessController.doPrivileged((PrivilegedAction<ClassLoader>)new PrivilegedAction() {
            @Override
            public Object run() {
                Object contextClassLoader = null;
                try {
                    contextClassLoader = Thread.currentThread().getContextClassLoader();
                }
                catch (SecurityException ex) {}
                return contextClassLoader;
            }
        });
    }
    
    private static InputStream getResourceAsStream(final Class clazz, final String s) {
        try {
            return AccessController.doPrivileged((PrivilegedExceptionAction<InputStream>)new PrivilegedExceptionAction() {
                @Override
                public Object run() {
                    return clazz.getResourceAsStream(s);
                }
            });
        }
        catch (PrivilegedActionException ex) {
            throw (IOException)ex.getException();
        }
    }
    
    private static URL[] getResources(final ClassLoader classLoader, final String s) {
        return AccessController.doPrivileged((PrivilegedAction<URL[]>)new PrivilegedAction() {
            @Override
            public Object run() {
                Object[] array = null;
                try {
                    final Vector<URL> vector = new Vector<URL>();
                    final Enumeration<URL> resources = classLoader.getResources(s);
                    while (resources != null && resources.hasMoreElements()) {
                        final URL url = resources.nextElement();
                        if (url != null) {
                            vector.addElement(url);
                        }
                    }
                    if (vector.size() > 0) {
                        array = new URL[vector.size()];
                        vector.copyInto(array);
                    }
                }
                catch (IOException ex) {}
                catch (SecurityException ex2) {}
                return array;
            }
        });
    }
    
    private static URL[] getSystemResources(final String s) {
        return AccessController.doPrivileged((PrivilegedAction<URL[]>)new PrivilegedAction() {
            @Override
            public Object run() {
                Object[] array = null;
                try {
                    final Vector<URL> vector = new Vector<URL>();
                    final Enumeration<URL> systemResources = ClassLoader.getSystemResources(s);
                    while (systemResources != null && systemResources.hasMoreElements()) {
                        final URL url = systemResources.nextElement();
                        if (url != null) {
                            vector.addElement(url);
                        }
                    }
                    if (vector.size() > 0) {
                        array = new URL[vector.size()];
                        vector.copyInto(array);
                    }
                }
                catch (IOException ex) {}
                catch (SecurityException ex2) {}
                return array;
            }
        });
    }
    
    private static InputStream openStream(final URL url) {
        try {
            return AccessController.doPrivileged((PrivilegedExceptionAction<InputStream>)new PrivilegedExceptionAction() {
                @Override
                public Object run() {
                    return url.openStream();
                }
            });
        }
        catch (PrivilegedActionException ex) {
            throw (IOException)ex.getException();
        }
    }
    
    static {
        Session.defaultSession = null;
    }
}
