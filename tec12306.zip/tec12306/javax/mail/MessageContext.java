// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public class MessageContext
{
    private Part part;
    
    public MessageContext(final Part part) {
        this.part = part;
    }
    
    public Part getPart() {
        return this.part;
    }
    
    public Message getMessage() {
        try {
            return getMessage(this.part);
        }
        catch (MessagingException ex) {
            return null;
        }
    }
    
    private static Message getMessage(Part parent) {
        while (parent != null) {
            if (parent instanceof Message) {
                return (Message)parent;
            }
            final Multipart parent2 = ((BodyPart)parent).getParent();
            if (parent2 == null) {
                return null;
            }
            parent = parent2.getParent();
        }
        return null;
    }
    
    public Session getSession() {
        final Message message = this.getMessage();
        return (message != null) ? message.getSession() : null;
    }
}
