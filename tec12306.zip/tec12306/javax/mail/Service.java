// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import javax.mail.event.MailEvent;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.util.Vector;

public abstract class Service
{
    protected Session session;
    protected URLName url;
    protected boolean debug;
    private boolean connected;
    private final Vector connectionListeners;
    private EventQueue q;
    private Object qLock;
    
    protected Service(final Session session, final URLName url) {
        this.url = null;
        this.debug = false;
        this.connected = false;
        this.connectionListeners = new Vector();
        this.qLock = new Object();
        this.session = session;
        this.debug = session.getDebug();
        this.url = url;
        String protocol = null;
        String s = null;
        int port = -1;
        String s2 = null;
        String password = null;
        String file = null;
        if (this.url != null) {
            protocol = this.url.getProtocol();
            s = this.url.getHost();
            port = this.url.getPort();
            s2 = this.url.getUsername();
            password = this.url.getPassword();
            file = this.url.getFile();
        }
        if (protocol != null) {
            if (s == null) {
                s = session.getProperty("mail." + protocol + ".host");
            }
            if (s2 == null) {
                s2 = session.getProperty("mail." + protocol + ".user");
            }
        }
        if (s == null) {
            s = session.getProperty("mail.host");
        }
        if (s2 == null) {
            s2 = session.getProperty("mail.user");
        }
        if (s2 == null) {
            try {
                s2 = System.getProperty("user.name");
            }
            catch (SecurityException ex) {}
        }
        this.url = new URLName(protocol, s, port, file, s2, password);
    }
    
    public void connect() {
        this.connect(null, null, null);
    }
    
    public void connect(final String s, final String s2, final String s3) {
        this.connect(s, -1, s2, s3);
    }
    
    public void connect(final String s, final String s2) {
        this.connect(null, s, s2);
    }
    
    public synchronized void connect(String s, int port, String s2, String s3) {
        if (this.isConnected()) {
            throw new IllegalStateException("already connected");
        }
        boolean b = false;
        boolean b2 = false;
        String protocol = null;
        String file = null;
        if (this.url != null) {
            protocol = this.url.getProtocol();
            if (s == null) {
                s = this.url.getHost();
            }
            if (port == -1) {
                port = this.url.getPort();
            }
            if (s2 == null) {
                s2 = this.url.getUsername();
                if (s3 == null) {
                    s3 = this.url.getPassword();
                }
            }
            else if (s3 == null && s2.equals(this.url.getUsername())) {
                s3 = this.url.getPassword();
            }
            file = this.url.getFile();
        }
        if (protocol != null) {
            if (s == null) {
                s = this.session.getProperty("mail." + protocol + ".host");
            }
            if (s2 == null) {
                s2 = this.session.getProperty("mail." + protocol + ".user");
            }
        }
        if (s == null) {
            s = this.session.getProperty("mail.host");
        }
        if (s2 == null) {
            s2 = this.session.getProperty("mail.user");
        }
        if (s2 == null) {
            try {
                s2 = System.getProperty("user.name");
            }
            catch (SecurityException ex3) {}
        }
        if (s3 == null && this.url != null) {
            this.setURLName(new URLName(protocol, s, port, file, s2, null));
            final PasswordAuthentication passwordAuthentication = this.session.getPasswordAuthentication(this.getURLName());
            if (passwordAuthentication != null) {
                if (s2 == null) {
                    s2 = passwordAuthentication.getUserName();
                    s3 = passwordAuthentication.getPassword();
                }
                else if (s2.equals(passwordAuthentication.getUserName())) {
                    s3 = passwordAuthentication.getPassword();
                }
            }
            else {
                b2 = true;
            }
        }
        AuthenticationFailedException ex = null;
        try {
            b = this.protocolConnect(s, port, s2, s3);
        }
        catch (AuthenticationFailedException ex2) {
            ex = ex2;
        }
        if (!b) {
            InetAddress byName;
            try {
                byName = InetAddress.getByName(s);
            }
            catch (UnknownHostException ex4) {
                byName = null;
            }
            final PasswordAuthentication requestPasswordAuthentication = this.session.requestPasswordAuthentication(byName, port, protocol, null, s2);
            if (requestPasswordAuthentication != null) {
                s2 = requestPasswordAuthentication.getUserName();
                s3 = requestPasswordAuthentication.getPassword();
                b = this.protocolConnect(s, port, s2, s3);
            }
        }
        if (b) {
            this.setURLName(new URLName(protocol, s, port, file, s2, s3));
            if (b2) {
                this.session.setPasswordAuthentication(this.getURLName(), new PasswordAuthentication(s2, s3));
            }
            this.setConnected(true);
            this.notifyConnectionListeners(1);
            return;
        }
        if (ex != null) {
            throw ex;
        }
        if (s2 == null) {
            throw new AuthenticationFailedException("failed to connect, no user name specified?");
        }
        if (s3 == null) {
            throw new AuthenticationFailedException("failed to connect, no password specified?");
        }
        throw new AuthenticationFailedException("failed to connect");
    }
    
    protected boolean protocolConnect(final String s, final int n, final String s2, final String s3) {
        return false;
    }
    
    public synchronized boolean isConnected() {
        return this.connected;
    }
    
    protected synchronized void setConnected(final boolean connected) {
        this.connected = connected;
    }
    
    public synchronized void close() {
        this.setConnected(false);
        this.notifyConnectionListeners(3);
    }
    
    public synchronized URLName getURLName() {
        if (this.url != null && (this.url.getPassword() != null || this.url.getFile() != null)) {
            return new URLName(this.url.getProtocol(), this.url.getHost(), this.url.getPort(), null, this.url.getUsername(), null);
        }
        return this.url;
    }
    
    protected synchronized void setURLName(final URLName url) {
        this.url = url;
    }
    
    public void addConnectionListener(final ConnectionListener connectionListener) {
        this.connectionListeners.addElement(connectionListener);
    }
    
    public void removeConnectionListener(final ConnectionListener connectionListener) {
        this.connectionListeners.removeElement(connectionListener);
    }
    
    protected void notifyConnectionListeners(final int n) {
        if (this.connectionListeners.size() > 0) {
            this.queueEvent(new ConnectionEvent(this, n), this.connectionListeners);
        }
        if (n == 3) {
            this.terminateQueue();
        }
    }
    
    @Override
    public String toString() {
        final URLName urlName = this.getURLName();
        if (urlName != null) {
            return urlName.toString();
        }
        return super.toString();
    }
    
    protected void queueEvent(final MailEvent mailEvent, final Vector vector) {
        synchronized (this.qLock) {
            if (this.q == null) {
                this.q = new EventQueue();
            }
        }
        this.q.enqueue(mailEvent, (Vector)vector.clone());
    }
    
    private void terminateQueue() {
        synchronized (this.qLock) {
            if (this.q != null) {
                final Vector vector = new Vector();
                vector.setSize(1);
                this.q.enqueue(new TerminatorEvent(), vector);
                this.q = null;
            }
        }
    }
    
    @Override
    protected void finalize() {
        super.finalize();
        this.terminateQueue();
    }
    
    static class TerminatorEvent extends MailEvent
    {
        private static final long serialVersionUID = 5542172141759168416L;
        
        TerminatorEvent() {
            super(new Object());
        }
        
        @Override
        public void dispatch(final Object o) {
            Thread.currentThread().interrupt();
        }
    }
}
