// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import javax.mail.event.MessageChangedEvent;
import javax.mail.event.MessageChangedListener;
import javax.mail.event.MessageCountEvent;
import javax.mail.event.MessageCountListener;
import javax.mail.event.FolderEvent;
import javax.mail.event.FolderListener;
import javax.mail.event.MailEvent;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.search.SearchTerm;
import java.util.Vector;

public abstract class Folder
{
    protected Store store;
    protected int mode;
    public static final int HOLDS_MESSAGES = 1;
    public static final int HOLDS_FOLDERS = 2;
    public static final int READ_ONLY = 1;
    public static final int READ_WRITE = 2;
    private volatile Vector connectionListeners;
    private volatile Vector folderListeners;
    private volatile Vector messageCountListeners;
    private volatile Vector messageChangedListeners;
    private EventQueue q;
    private Object qLock;
    
    protected Folder(final Store store) {
        this.mode = -1;
        this.connectionListeners = null;
        this.folderListeners = null;
        this.messageCountListeners = null;
        this.messageChangedListeners = null;
        this.qLock = new Object();
        this.store = store;
    }
    
    public abstract String getName();
    
    public abstract String getFullName();
    
    public URLName getURLName() {
        final URLName urlName = this.getStore().getURLName();
        final String fullName = this.getFullName();
        final StringBuffer sb = new StringBuffer();
        if (fullName != null) {
            sb.append(fullName);
        }
        return new URLName(urlName.getProtocol(), urlName.getHost(), urlName.getPort(), sb.toString(), urlName.getUsername(), null);
    }
    
    public Store getStore() {
        return this.store;
    }
    
    public abstract Folder getParent();
    
    public abstract boolean exists();
    
    public abstract Folder[] list(final String p0);
    
    public Folder[] listSubscribed(final String s) {
        return this.list(s);
    }
    
    public Folder[] list() {
        return this.list("%");
    }
    
    public Folder[] listSubscribed() {
        return this.listSubscribed("%");
    }
    
    public abstract char getSeparator();
    
    public abstract int getType();
    
    public abstract boolean create(final int p0);
    
    public boolean isSubscribed() {
        return true;
    }
    
    public void setSubscribed(final boolean b) {
        throw new MethodNotSupportedException();
    }
    
    public abstract boolean hasNewMessages();
    
    public abstract Folder getFolder(final String p0);
    
    public abstract boolean delete(final boolean p0);
    
    public abstract boolean renameTo(final Folder p0);
    
    public abstract void open(final int p0);
    
    public abstract void close(final boolean p0);
    
    public abstract boolean isOpen();
    
    public synchronized int getMode() {
        if (!this.isOpen()) {
            throw new IllegalStateException("Folder not open");
        }
        return this.mode;
    }
    
    public abstract Flags getPermanentFlags();
    
    public abstract int getMessageCount();
    
    public synchronized int getNewMessageCount() {
        if (!this.isOpen()) {
            return -1;
        }
        int n = 0;
        for (int messageCount = this.getMessageCount(), i = 1; i <= messageCount; ++i) {
            try {
                if (this.getMessage(i).isSet(Flags.Flag.RECENT)) {
                    ++n;
                }
            }
            catch (MessageRemovedException ex) {}
        }
        return n;
    }
    
    public synchronized int getUnreadMessageCount() {
        if (!this.isOpen()) {
            return -1;
        }
        int n = 0;
        for (int messageCount = this.getMessageCount(), i = 1; i <= messageCount; ++i) {
            try {
                if (!this.getMessage(i).isSet(Flags.Flag.SEEN)) {
                    ++n;
                }
            }
            catch (MessageRemovedException ex) {}
        }
        return n;
    }
    
    public synchronized int getDeletedMessageCount() {
        if (!this.isOpen()) {
            return -1;
        }
        int n = 0;
        for (int messageCount = this.getMessageCount(), i = 1; i <= messageCount; ++i) {
            try {
                if (this.getMessage(i).isSet(Flags.Flag.DELETED)) {
                    ++n;
                }
            }
            catch (MessageRemovedException ex) {}
        }
        return n;
    }
    
    public abstract Message getMessage(final int p0);
    
    public synchronized Message[] getMessages(final int n, final int n2) {
        final Message[] array = new Message[n2 - n + 1];
        for (int i = n; i <= n2; ++i) {
            array[i - n] = this.getMessage(i);
        }
        return array;
    }
    
    public synchronized Message[] getMessages(final int[] array) {
        final int length = array.length;
        final Message[] array2 = new Message[length];
        for (int i = 0; i < length; ++i) {
            array2[i] = this.getMessage(array[i]);
        }
        return array2;
    }
    
    public synchronized Message[] getMessages() {
        if (!this.isOpen()) {
            throw new IllegalStateException("Folder not open");
        }
        final int messageCount = this.getMessageCount();
        final Message[] array = new Message[messageCount];
        for (int i = 1; i <= messageCount; ++i) {
            array[i - 1] = this.getMessage(i);
        }
        return array;
    }
    
    public abstract void appendMessages(final Message[] p0);
    
    public void fetch(final Message[] array, final FetchProfile fetchProfile) {
    }
    
    public synchronized void setFlags(final Message[] array, final Flags flags, final boolean b) {
        for (int i = 0; i < array.length; ++i) {
            try {
                array[i].setFlags(flags, b);
            }
            catch (MessageRemovedException ex) {}
        }
    }
    
    public synchronized void setFlags(final int n, final int n2, final Flags flags, final boolean b) {
        for (int i = n; i <= n2; ++i) {
            try {
                this.getMessage(i).setFlags(flags, b);
            }
            catch (MessageRemovedException ex) {}
        }
    }
    
    public synchronized void setFlags(final int[] array, final Flags flags, final boolean b) {
        for (int i = 0; i < array.length; ++i) {
            try {
                this.getMessage(array[i]).setFlags(flags, b);
            }
            catch (MessageRemovedException ex) {}
        }
    }
    
    public void copyMessages(final Message[] array, final Folder folder) {
        if (!folder.exists()) {
            throw new FolderNotFoundException(folder.getFullName() + " does not exist", folder);
        }
        folder.appendMessages(array);
    }
    
    public abstract Message[] expunge();
    
    public Message[] search(final SearchTerm searchTerm) {
        return this.search(searchTerm, this.getMessages());
    }
    
    public Message[] search(final SearchTerm searchTerm, final Message[] array) {
        final Vector<Message> vector = new Vector<Message>();
        for (int i = 0; i < array.length; ++i) {
            try {
                if (array[i].match(searchTerm)) {
                    vector.addElement(array[i]);
                }
            }
            catch (MessageRemovedException ex) {}
        }
        final Message[] array2 = new Message[vector.size()];
        vector.copyInto(array2);
        return array2;
    }
    
    public synchronized void addConnectionListener(final ConnectionListener connectionListener) {
        if (this.connectionListeners == null) {
            this.connectionListeners = new Vector();
        }
        this.connectionListeners.addElement(connectionListener);
    }
    
    public synchronized void removeConnectionListener(final ConnectionListener connectionListener) {
        if (this.connectionListeners != null) {
            this.connectionListeners.removeElement(connectionListener);
        }
    }
    
    protected void notifyConnectionListeners(final int n) {
        if (this.connectionListeners != null) {
            this.queueEvent(new ConnectionEvent(this, n), this.connectionListeners);
        }
        if (n == 3) {
            this.terminateQueue();
        }
    }
    
    public synchronized void addFolderListener(final FolderListener folderListener) {
        if (this.folderListeners == null) {
            this.folderListeners = new Vector();
        }
        this.folderListeners.addElement(folderListener);
    }
    
    public synchronized void removeFolderListener(final FolderListener folderListener) {
        if (this.folderListeners != null) {
            this.folderListeners.removeElement(folderListener);
        }
    }
    
    protected void notifyFolderListeners(final int n) {
        if (this.folderListeners != null) {
            this.queueEvent(new FolderEvent(this, this, n), this.folderListeners);
        }
        this.store.notifyFolderListeners(n, this);
    }
    
    protected void notifyFolderRenamedListeners(final Folder folder) {
        if (this.folderListeners != null) {
            this.queueEvent(new FolderEvent(this, this, folder, 3), this.folderListeners);
        }
        this.store.notifyFolderRenamedListeners(this, folder);
    }
    
    public synchronized void addMessageCountListener(final MessageCountListener messageCountListener) {
        if (this.messageCountListeners == null) {
            this.messageCountListeners = new Vector();
        }
        this.messageCountListeners.addElement(messageCountListener);
    }
    
    public synchronized void removeMessageCountListener(final MessageCountListener messageCountListener) {
        if (this.messageCountListeners != null) {
            this.messageCountListeners.removeElement(messageCountListener);
        }
    }
    
    protected void notifyMessageAddedListeners(final Message[] array) {
        if (this.messageCountListeners == null) {
            return;
        }
        this.queueEvent(new MessageCountEvent(this, 1, false, array), this.messageCountListeners);
    }
    
    protected void notifyMessageRemovedListeners(final boolean b, final Message[] array) {
        if (this.messageCountListeners == null) {
            return;
        }
        this.queueEvent(new MessageCountEvent(this, 2, b, array), this.messageCountListeners);
    }
    
    public synchronized void addMessageChangedListener(final MessageChangedListener messageChangedListener) {
        if (this.messageChangedListeners == null) {
            this.messageChangedListeners = new Vector();
        }
        this.messageChangedListeners.addElement(messageChangedListener);
    }
    
    public synchronized void removeMessageChangedListener(final MessageChangedListener messageChangedListener) {
        if (this.messageChangedListeners != null) {
            this.messageChangedListeners.removeElement(messageChangedListener);
        }
    }
    
    protected void notifyMessageChangedListeners(final int n, final Message message) {
        if (this.messageChangedListeners == null) {
            return;
        }
        this.queueEvent(new MessageChangedEvent(this, n, message), this.messageChangedListeners);
    }
    
    private void queueEvent(final MailEvent mailEvent, final Vector vector) {
        synchronized (this.qLock) {
            if (this.q == null) {
                this.q = new EventQueue();
            }
        }
        this.q.enqueue(mailEvent, (Vector)vector.clone());
    }
    
    private void terminateQueue() {
        synchronized (this.qLock) {
            if (this.q != null) {
                final Vector vector = new Vector();
                vector.setSize(1);
                this.q.enqueue(new TerminatorEvent(), vector);
                this.q = null;
            }
        }
    }
    
    @Override
    protected void finalize() {
        super.finalize();
        this.terminateQueue();
    }
    
    @Override
    public String toString() {
        final String fullName = this.getFullName();
        if (fullName != null) {
            return fullName;
        }
        return super.toString();
    }
    
    static class TerminatorEvent extends MailEvent
    {
        private static final long serialVersionUID = 3765761925441296565L;
        
        TerminatorEvent() {
            super(new Object());
        }
        
        @Override
        public void dispatch(final Object o) {
            Thread.currentThread().interrupt();
        }
    }
}
