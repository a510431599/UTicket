// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import java.io.InputStream;

interface StreamLoader
{
    void load(final InputStream p0);
}
