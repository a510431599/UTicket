// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public class IllegalWriteException extends MessagingException
{
    private static final long serialVersionUID = 3974370223328268013L;
    
    public IllegalWriteException() {
    }
    
    public IllegalWriteException(final String s) {
        super(s);
    }
    
    public IllegalWriteException(final String s, final Exception ex) {
        super(s, ex);
    }
}
