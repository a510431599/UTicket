// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.MessagingException;

public class SearchException extends MessagingException
{
    private static final long serialVersionUID = -7092886778226268686L;
    
    public SearchException() {
    }
    
    public SearchException(final String s) {
        super(s);
    }
}
