// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Message;

public final class BodyTerm extends StringTerm
{
    private static final long serialVersionUID = -4888862527916911385L;
    
    public BodyTerm(final String s) {
        super(s);
    }
    
    @Override
    public boolean match(final Message message) {
        return this.matchPart(message);
    }
    
    private boolean matchPart(final Part part) {
        try {
            if (part.isMimeType("text/*")) {
                final String s = (String)part.getContent();
                return s != null && super.match(s);
            }
            if (part.isMimeType("multipart/*")) {
                final Multipart multipart = (Multipart)part.getContent();
                for (int count = multipart.getCount(), i = 0; i < count; ++i) {
                    if (this.matchPart(multipart.getBodyPart(i))) {
                        return true;
                    }
                }
            }
            else if (part.isMimeType("message/rfc822")) {
                return this.matchPart((Part)part.getContent());
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof BodyTerm && super.equals(o);
    }
}
