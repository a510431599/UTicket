// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Message;
import javax.mail.Flags;

public final class FlagTerm extends SearchTerm
{
    private boolean set;
    private Flags flags;
    private static final long serialVersionUID = -142991500302030647L;
    
    public FlagTerm(final Flags flags, final boolean set) {
        this.flags = flags;
        this.set = set;
    }
    
    public Flags getFlags() {
        return (Flags)this.flags.clone();
    }
    
    public boolean getTestSet() {
        return this.set;
    }
    
    @Override
    public boolean match(final Message message) {
        try {
            final Flags flags = message.getFlags();
            if (this.set) {
                return flags.contains(this.flags);
            }
            final Flags.Flag[] systemFlags = this.flags.getSystemFlags();
            for (int i = 0; i < systemFlags.length; ++i) {
                if (flags.contains(systemFlags[i])) {
                    return false;
                }
            }
            final String[] userFlags = this.flags.getUserFlags();
            for (int j = 0; j < userFlags.length; ++j) {
                if (flags.contains(userFlags[j])) {
                    return false;
                }
            }
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof FlagTerm)) {
            return false;
        }
        final FlagTerm flagTerm = (FlagTerm)o;
        return flagTerm.set == this.set && flagTerm.flags.equals(this.flags);
    }
    
    @Override
    public int hashCode() {
        return this.set ? this.flags.hashCode() : (~this.flags.hashCode());
    }
}
