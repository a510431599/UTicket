// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Message;

public final class SubjectTerm extends StringTerm
{
    private static final long serialVersionUID = 7481568618055573432L;
    
    public SubjectTerm(final String s) {
        super(s);
    }
    
    @Override
    public boolean match(final Message message) {
        String subject;
        try {
            subject = message.getSubject();
        }
        catch (Exception ex) {
            return false;
        }
        return subject != null && super.match(subject);
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof SubjectTerm && super.equals(o);
    }
}
