// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Address;
import javax.mail.Message;

public final class FromStringTerm extends AddressStringTerm
{
    private static final long serialVersionUID = 5801127523826772788L;
    
    public FromStringTerm(final String s) {
        super(s);
    }
    
    @Override
    public boolean match(final Message message) {
        Address[] from;
        try {
            from = message.getFrom();
        }
        catch (Exception ex) {
            return false;
        }
        if (from == null) {
            return false;
        }
        for (int i = 0; i < from.length; ++i) {
            if (super.match(from[i])) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof FromStringTerm && super.equals(o);
    }
}
