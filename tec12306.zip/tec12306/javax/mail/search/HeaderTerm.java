// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import java.util.Locale;
import javax.mail.Message;

public final class HeaderTerm extends StringTerm
{
    private String headerName;
    private static final long serialVersionUID = 8342514650333389122L;
    
    public HeaderTerm(final String headerName, final String s) {
        super(s);
        this.headerName = headerName;
    }
    
    public String getHeaderName() {
        return this.headerName;
    }
    
    @Override
    public boolean match(final Message message) {
        String[] header;
        try {
            header = message.getHeader(this.headerName);
        }
        catch (Exception ex) {
            return false;
        }
        if (header == null) {
            return false;
        }
        for (int i = 0; i < header.length; ++i) {
            if (super.match(header[i])) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof HeaderTerm)) {
            return false;
        }
        final HeaderTerm headerTerm = (HeaderTerm)o;
        return headerTerm.headerName.equalsIgnoreCase(this.headerName) && super.equals(headerTerm);
    }
    
    @Override
    public int hashCode() {
        return this.headerName.toLowerCase(Locale.ENGLISH).hashCode() + super.hashCode();
    }
}
