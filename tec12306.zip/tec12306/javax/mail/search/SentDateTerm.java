// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Message;
import java.util.Date;

public final class SentDateTerm extends DateTerm
{
    private static final long serialVersionUID = 5647755030530907263L;
    
    public SentDateTerm(final int n, final Date date) {
        super(n, date);
    }
    
    @Override
    public boolean match(final Message message) {
        Date sentDate;
        try {
            sentDate = message.getSentDate();
        }
        catch (Exception ex) {
            return false;
        }
        return sentDate != null && super.match(sentDate);
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof SentDateTerm && super.equals(o);
    }
}
