// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

public abstract class StringTerm extends SearchTerm
{
    protected String pattern;
    protected boolean ignoreCase;
    private static final long serialVersionUID = 1274042129007696269L;
    
    protected StringTerm(final String pattern) {
        this.pattern = pattern;
        this.ignoreCase = true;
    }
    
    protected StringTerm(final String pattern, final boolean ignoreCase) {
        this.pattern = pattern;
        this.ignoreCase = ignoreCase;
    }
    
    public String getPattern() {
        return this.pattern;
    }
    
    public boolean getIgnoreCase() {
        return this.ignoreCase;
    }
    
    protected boolean match(final String s) {
        for (int n = s.length() - this.pattern.length(), i = 0; i <= n; ++i) {
            if (s.regionMatches(this.ignoreCase, i, this.pattern, 0, this.pattern.length())) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof StringTerm)) {
            return false;
        }
        final StringTerm stringTerm = (StringTerm)o;
        if (this.ignoreCase) {
            return stringTerm.pattern.equalsIgnoreCase(this.pattern) && stringTerm.ignoreCase == this.ignoreCase;
        }
        return stringTerm.pattern.equals(this.pattern) && stringTerm.ignoreCase == this.ignoreCase;
    }
    
    @Override
    public int hashCode() {
        return this.ignoreCase ? this.pattern.hashCode() : (~this.pattern.hashCode());
    }
}
