// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Address;
import javax.mail.Message;

public final class RecipientTerm extends AddressTerm
{
    private Message.RecipientType type;
    private static final long serialVersionUID = 6548700653122680468L;
    
    public RecipientTerm(final Message.RecipientType type, final Address address) {
        super(address);
        this.type = type;
    }
    
    public Message.RecipientType getRecipientType() {
        return this.type;
    }
    
    @Override
    public boolean match(final Message message) {
        Address[] recipients;
        try {
            recipients = message.getRecipients(this.type);
        }
        catch (Exception ex) {
            return false;
        }
        if (recipients == null) {
            return false;
        }
        for (int i = 0; i < recipients.length; ++i) {
            if (super.match(recipients[i])) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof RecipientTerm && ((RecipientTerm)o).type.equals(this.type) && super.equals(o);
    }
    
    @Override
    public int hashCode() {
        return this.type.hashCode() + super.hashCode();
    }
}
