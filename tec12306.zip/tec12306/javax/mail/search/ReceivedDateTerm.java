// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Message;
import java.util.Date;

public final class ReceivedDateTerm extends DateTerm
{
    private static final long serialVersionUID = -2756695246195503170L;
    
    public ReceivedDateTerm(final int n, final Date date) {
        super(n, date);
    }
    
    @Override
    public boolean match(final Message message) {
        Date receivedDate;
        try {
            receivedDate = message.getReceivedDate();
        }
        catch (Exception ex) {
            return false;
        }
        return receivedDate != null && super.match(receivedDate);
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof ReceivedDateTerm && super.equals(o);
    }
}
