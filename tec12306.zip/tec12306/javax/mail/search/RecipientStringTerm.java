// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Address;
import javax.mail.Message;

public final class RecipientStringTerm extends AddressStringTerm
{
    private Message.RecipientType type;
    private static final long serialVersionUID = -8293562089611618849L;
    
    public RecipientStringTerm(final Message.RecipientType type, final String s) {
        super(s);
        this.type = type;
    }
    
    public Message.RecipientType getRecipientType() {
        return this.type;
    }
    
    @Override
    public boolean match(final Message message) {
        Address[] recipients;
        try {
            recipients = message.getRecipients(this.type);
        }
        catch (Exception ex) {
            return false;
        }
        if (recipients == null) {
            return false;
        }
        for (int i = 0; i < recipients.length; ++i) {
            if (super.match(recipients[i])) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof RecipientStringTerm && ((RecipientStringTerm)o).type.equals(this.type) && super.equals(o);
    }
    
    @Override
    public int hashCode() {
        return this.type.hashCode() + super.hashCode();
    }
}
