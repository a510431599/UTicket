// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

import javax.mail.Message;

public final class MessageIDTerm extends StringTerm
{
    private static final long serialVersionUID = -2121096296454691963L;
    
    public MessageIDTerm(final String s) {
        super(s);
    }
    
    @Override
    public boolean match(final Message message) {
        String[] header;
        try {
            header = message.getHeader("Message-ID");
        }
        catch (Exception ex) {
            return false;
        }
        if (header == null) {
            return false;
        }
        for (int i = 0; i < header.length; ++i) {
            if (super.match(header[i])) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof MessageIDTerm && super.equals(o);
    }
}
