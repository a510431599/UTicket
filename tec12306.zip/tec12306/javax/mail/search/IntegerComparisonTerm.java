// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.search;

public abstract class IntegerComparisonTerm extends ComparisonTerm
{
    protected int number;
    private static final long serialVersionUID = -6963571240154302484L;
    
    protected IntegerComparisonTerm(final int comparison, final int number) {
        this.comparison = comparison;
        this.number = number;
    }
    
    public int getNumber() {
        return this.number;
    }
    
    public int getComparison() {
        return this.comparison;
    }
    
    protected boolean match(final int n) {
        switch (this.comparison) {
            case 1: {
                return n <= this.number;
            }
            case 2: {
                return n < this.number;
            }
            case 3: {
                return n == this.number;
            }
            case 4: {
                return n != this.number;
            }
            case 5: {
                return n > this.number;
            }
            case 6: {
                return n >= this.number;
            }
            default: {
                return false;
            }
        }
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof IntegerComparisonTerm && ((IntegerComparisonTerm)o).number == this.number && super.equals(o);
    }
    
    @Override
    public int hashCode() {
        return this.number + super.hashCode();
    }
}
