// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import javax.mail.event.FolderEvent;
import javax.mail.event.FolderListener;
import javax.mail.event.MailEvent;
import javax.mail.event.StoreEvent;
import javax.mail.event.StoreListener;
import java.util.Vector;

public abstract class Store extends Service
{
    private volatile Vector storeListeners;
    private volatile Vector folderListeners;
    
    protected Store(final Session session, final URLName urlName) {
        super(session, urlName);
        this.storeListeners = null;
        this.folderListeners = null;
    }
    
    public abstract Folder getDefaultFolder();
    
    public abstract Folder getFolder(final String p0);
    
    public abstract Folder getFolder(final URLName p0);
    
    public Folder[] getPersonalNamespaces() {
        return new Folder[] { this.getDefaultFolder() };
    }
    
    public Folder[] getUserNamespaces(final String s) {
        return new Folder[0];
    }
    
    public Folder[] getSharedNamespaces() {
        return new Folder[0];
    }
    
    public synchronized void addStoreListener(final StoreListener storeListener) {
        if (this.storeListeners == null) {
            this.storeListeners = new Vector();
        }
        this.storeListeners.addElement(storeListener);
    }
    
    public synchronized void removeStoreListener(final StoreListener storeListener) {
        if (this.storeListeners != null) {
            this.storeListeners.removeElement(storeListener);
        }
    }
    
    protected void notifyStoreListeners(final int n, final String s) {
        if (this.storeListeners == null) {
            return;
        }
        this.queueEvent(new StoreEvent(this, n, s), this.storeListeners);
    }
    
    public synchronized void addFolderListener(final FolderListener folderListener) {
        if (this.folderListeners == null) {
            this.folderListeners = new Vector();
        }
        this.folderListeners.addElement(folderListener);
    }
    
    public synchronized void removeFolderListener(final FolderListener folderListener) {
        if (this.folderListeners != null) {
            this.folderListeners.removeElement(folderListener);
        }
    }
    
    protected void notifyFolderListeners(final int n, final Folder folder) {
        if (this.folderListeners == null) {
            return;
        }
        this.queueEvent(new FolderEvent(this, folder, n), this.folderListeners);
    }
    
    protected void notifyFolderRenamedListeners(final Folder folder, final Folder folder2) {
        if (this.folderListeners == null) {
            return;
        }
        this.queueEvent(new FolderEvent(this, folder, folder2, 3), this.folderListeners);
    }
}
