// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import java.io.UnsupportedEncodingException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.ByteArrayOutputStream;
import java.net.UnknownHostException;
import java.util.Locale;
import java.net.URL;
import java.util.BitSet;
import java.net.InetAddress;

public class URLName
{
    protected String fullURL;
    private String protocol;
    private String username;
    private String password;
    private String host;
    private InetAddress hostAddress;
    private boolean hostAddressKnown;
    private int port;
    private String file;
    private String ref;
    private int hashCode;
    private static boolean doEncode;
    static BitSet dontNeedEncoding;
    static final int caseDiff = 32;
    
    public URLName(final String protocol, final String host, final int port, final String file, final String s, final String s2) {
        this.hostAddressKnown = false;
        this.port = -1;
        this.hashCode = 0;
        this.protocol = protocol;
        this.host = host;
        this.port = port;
        final int index;
        if (file != null && (index = file.indexOf(35)) != -1) {
            this.file = file.substring(0, index);
            this.ref = file.substring(index + 1);
        }
        else {
            this.file = file;
            this.ref = null;
        }
        this.username = (URLName.doEncode ? encode(s) : s);
        this.password = (URLName.doEncode ? encode(s2) : s2);
    }
    
    public URLName(final URL url) {
        this(url.toString());
    }
    
    public URLName(final String s) {
        this.hostAddressKnown = false;
        this.port = -1;
        this.hashCode = 0;
        this.parseString(s);
    }
    
    @Override
    public String toString() {
        if (this.fullURL == null) {
            final StringBuffer sb = new StringBuffer();
            if (this.protocol != null) {
                sb.append(this.protocol);
                sb.append(":");
            }
            if (this.username != null || this.host != null) {
                sb.append("//");
                if (this.username != null) {
                    sb.append(this.username);
                    if (this.password != null) {
                        sb.append(":");
                        sb.append(this.password);
                    }
                    sb.append("@");
                }
                if (this.host != null) {
                    sb.append(this.host);
                }
                if (this.port != -1) {
                    sb.append(":");
                    sb.append(Integer.toString(this.port));
                }
                if (this.file != null) {
                    sb.append("/");
                }
            }
            if (this.file != null) {
                sb.append(this.file);
            }
            if (this.ref != null) {
                sb.append("#");
                sb.append(this.ref);
            }
            this.fullURL = sb.toString();
        }
        return this.fullURL;
    }
    
    protected void parseString(final String s) {
        final String s2 = null;
        this.password = s2;
        this.username = s2;
        this.host = s2;
        this.ref = s2;
        this.file = s2;
        this.protocol = s2;
        this.port = -1;
        final int length = s.length();
        final int index = s.indexOf(58);
        if (index != -1) {
            this.protocol = s.substring(0, index);
        }
        if (s.regionMatches(index + 1, "//", 0, 2)) {
            final int index2 = s.indexOf(47, index + 3);
            String host;
            if (index2 != -1) {
                host = s.substring(index + 3, index2);
                if (index2 + 1 < length) {
                    this.file = s.substring(index2 + 1);
                }
                else {
                    this.file = "";
                }
            }
            else {
                host = s.substring(index + 3);
            }
            final int index3 = host.indexOf(64);
            if (index3 != -1) {
                final String substring = host.substring(0, index3);
                host = host.substring(index3 + 1);
                final int index4 = substring.indexOf(58);
                if (index4 != -1) {
                    this.username = substring.substring(0, index4);
                    this.password = substring.substring(index4 + 1);
                }
                else {
                    this.username = substring;
                }
            }
            int n;
            if (host.length() > 0 && host.charAt(0) == '[') {
                n = host.indexOf(58, host.indexOf(93));
            }
            else {
                n = host.indexOf(58);
            }
            if (n != -1) {
                final String substring2 = host.substring(n + 1);
                if (substring2.length() > 0) {
                    try {
                        this.port = Integer.parseInt(substring2);
                    }
                    catch (NumberFormatException ex) {
                        this.port = -1;
                    }
                }
                this.host = host.substring(0, n);
            }
            else {
                this.host = host;
            }
        }
        else if (index + 1 < length) {
            this.file = s.substring(index + 1);
        }
        final int index5;
        if (this.file != null && (index5 = this.file.indexOf(35)) != -1) {
            this.ref = this.file.substring(index5 + 1);
            this.file = this.file.substring(0, index5);
        }
    }
    
    public int getPort() {
        return this.port;
    }
    
    public String getProtocol() {
        return this.protocol;
    }
    
    public String getFile() {
        return this.file;
    }
    
    public String getRef() {
        return this.ref;
    }
    
    public String getHost() {
        return this.host;
    }
    
    public String getUsername() {
        return URLName.doEncode ? decode(this.username) : this.username;
    }
    
    public String getPassword() {
        return URLName.doEncode ? decode(this.password) : this.password;
    }
    
    public URL getURL() {
        return new URL(this.getProtocol(), this.getHost(), this.getPort(), this.getFile());
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof URLName)) {
            return false;
        }
        final URLName urlName = (URLName)o;
        if (urlName.protocol == null || !urlName.protocol.equals(this.protocol)) {
            return false;
        }
        final InetAddress hostAddress = this.getHostAddress();
        final InetAddress hostAddress2 = urlName.getHostAddress();
        if (hostAddress != null && hostAddress2 != null) {
            if (!hostAddress.equals(hostAddress2)) {
                return false;
            }
        }
        else if (this.host != null && urlName.host != null) {
            if (!this.host.equalsIgnoreCase(urlName.host)) {
                return false;
            }
        }
        else if (this.host != urlName.host) {
            return false;
        }
        return (this.username == urlName.username || (this.username != null && this.username.equals(urlName.username))) && ((this.file == null) ? "" : this.file).equals((urlName.file == null) ? "" : urlName.file) && this.port == urlName.port;
    }
    
    @Override
    public int hashCode() {
        if (this.hashCode != 0) {
            return this.hashCode;
        }
        if (this.protocol != null) {
            this.hashCode += this.protocol.hashCode();
        }
        final InetAddress hostAddress = this.getHostAddress();
        if (hostAddress != null) {
            this.hashCode += hostAddress.hashCode();
        }
        else if (this.host != null) {
            this.hashCode += this.host.toLowerCase(Locale.ENGLISH).hashCode();
        }
        if (this.username != null) {
            this.hashCode += this.username.hashCode();
        }
        if (this.file != null) {
            this.hashCode += this.file.hashCode();
        }
        return this.hashCode += this.port;
    }
    
    private synchronized InetAddress getHostAddress() {
        if (this.hostAddressKnown) {
            return this.hostAddress;
        }
        if (this.host == null) {
            return null;
        }
        try {
            this.hostAddress = InetAddress.getByName(this.host);
        }
        catch (UnknownHostException ex) {
            this.hostAddress = null;
        }
        this.hostAddressKnown = true;
        return this.hostAddress;
    }
    
    static String encode(final String s) {
        if (s == null) {
            return null;
        }
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            if (char1 == ' ' || !URLName.dontNeedEncoding.get(char1)) {
                return _encode(s);
            }
        }
        return s;
    }
    
    private static String _encode(final String s) {
        final int n = 10;
        final StringBuffer sb = new StringBuffer(s.length());
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(n);
        final OutputStreamWriter outputStreamWriter = new OutputStreamWriter(byteArrayOutputStream);
        for (int i = 0; i < s.length(); ++i) {
            int char1 = s.charAt(i);
            if (URLName.dontNeedEncoding.get(char1)) {
                if (char1 == 32) {
                    char1 = 43;
                }
                sb.append((char)char1);
            }
            else {
                try {
                    outputStreamWriter.write(char1);
                    outputStreamWriter.flush();
                }
                catch (IOException ex) {
                    byteArrayOutputStream.reset();
                    continue;
                }
                final byte[] byteArray = byteArrayOutputStream.toByteArray();
                for (int j = 0; j < byteArray.length; ++j) {
                    sb.append('%');
                    char forDigit = Character.forDigit(byteArray[j] >> 4 & 0xF, 16);
                    if (Character.isLetter(forDigit)) {
                        forDigit -= ' ';
                    }
                    sb.append(forDigit);
                    char forDigit2 = Character.forDigit(byteArray[j] & 0xF, 16);
                    if (Character.isLetter(forDigit2)) {
                        forDigit2 -= ' ';
                    }
                    sb.append(forDigit2);
                }
                byteArrayOutputStream.reset();
            }
        }
        return sb.toString();
    }
    
    static String decode(final String s) {
        if (s == null) {
            return null;
        }
        if (indexOfAny(s, "+%") == -1) {
            return s;
        }
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            switch (char1) {
                case 43: {
                    sb.append(' ');
                    break;
                }
                case 37: {
                    try {
                        sb.append((char)Integer.parseInt(s.substring(i + 1, i + 3), 16));
                    }
                    catch (NumberFormatException ex) {
                        throw new IllegalArgumentException("Illegal URL encoded value: " + s.substring(i, i + 3));
                    }
                    i += 2;
                    break;
                }
                default: {
                    sb.append(char1);
                    break;
                }
            }
        }
        String string = sb.toString();
        try {
            string = new String(string.getBytes("8859_1"));
        }
        catch (UnsupportedEncodingException ex2) {}
        return string;
    }
    
    private static int indexOfAny(final String s, final String s2) {
        return indexOfAny(s, s2, 0);
    }
    
    private static int indexOfAny(final String s, final String s2, final int n) {
        try {
            for (int length = s.length(), i = n; i < length; ++i) {
                if (s2.indexOf(s.charAt(i)) >= 0) {
                    return i;
                }
            }
            return -1;
        }
        catch (StringIndexOutOfBoundsException ex) {
            return -1;
        }
    }
    
    static {
        URLName.doEncode = true;
        try {
            URLName.doEncode = !Boolean.getBoolean("mail.URLName.dontencode");
        }
        catch (Exception ex) {}
        URLName.dontNeedEncoding = new BitSet(256);
        for (int i = 97; i <= 122; ++i) {
            URLName.dontNeedEncoding.set(i);
        }
        for (int j = 65; j <= 90; ++j) {
            URLName.dontNeedEncoding.set(j);
        }
        for (int k = 48; k <= 57; ++k) {
            URLName.dontNeedEncoding.set(k);
        }
        URLName.dontNeedEncoding.set(32);
        URLName.dontNeedEncoding.set(45);
        URLName.dontNeedEncoding.set(95);
        URLName.dontNeedEncoding.set(46);
        URLName.dontNeedEncoding.set(42);
    }
}
