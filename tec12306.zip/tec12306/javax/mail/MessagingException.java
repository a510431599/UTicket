// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public class MessagingException extends Exception
{
    private Exception next;
    private static final long serialVersionUID = -7569192289819959253L;
    
    public MessagingException() {
        this.initCause(null);
    }
    
    public MessagingException(final String s) {
        super(s);
        this.initCause(null);
    }
    
    public MessagingException(final String s, final Exception next) {
        super(s);
        this.next = next;
        this.initCause(null);
    }
    
    public synchronized Exception getNextException() {
        return this.next;
    }
    
    @Override
    public synchronized Throwable getCause() {
        return this.next;
    }
    
    public synchronized boolean setNextException(final Exception next) {
        Exception next2;
        for (next2 = this; next2 instanceof MessagingException && ((MessagingException)next2).next != null; next2 = ((MessagingException)next2).next) {}
        if (next2 instanceof MessagingException) {
            ((MessagingException)next2).next = next;
            return true;
        }
        return false;
    }
    
    @Override
    public synchronized String toString() {
        final String string = super.toString();
        Exception ex = this.next;
        if (ex == null) {
            return string;
        }
        final StringBuffer sb = new StringBuffer((string == null) ? "" : string);
        while (ex != null) {
            sb.append(";\n  nested exception is:\n\t");
            if (ex instanceof MessagingException) {
                final MessagingException ex2 = (MessagingException)ex;
                sb.append(ex2.superToString());
                ex = ex2.next;
            }
            else {
                sb.append(ex.toString());
                ex = null;
            }
        }
        return sb.toString();
    }
    
    private final String superToString() {
        return super.toString();
    }
}
