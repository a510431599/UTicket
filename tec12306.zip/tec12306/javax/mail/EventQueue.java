// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import java.util.Vector;
import javax.mail.event.MailEvent;

class EventQueue implements Runnable
{
    private QueueElement head;
    private QueueElement tail;
    private Thread qThread;
    
    public EventQueue() {
        this.head = null;
        this.tail = null;
        (this.qThread = new Thread(this, "JavaMail-EventQueue")).setDaemon(true);
        this.qThread.start();
    }
    
    public synchronized void enqueue(final MailEvent mailEvent, final Vector vector) {
        final QueueElement queueElement = new QueueElement(mailEvent, vector);
        if (this.head == null) {
            this.head = queueElement;
            this.tail = queueElement;
        }
        else {
            queueElement.next = this.head;
            this.head.prev = queueElement;
            this.head = queueElement;
        }
        this.notifyAll();
    }
    
    private synchronized QueueElement dequeue() {
        while (this.tail == null) {
            this.wait();
        }
        final QueueElement tail = this.tail;
        this.tail = tail.prev;
        if (this.tail == null) {
            this.head = null;
        }
        else {
            this.tail.next = null;
        }
        final QueueElement queueElement = tail;
        final QueueElement queueElement2 = tail;
        final QueueElement queueElement3 = null;
        queueElement2.next = queueElement3;
        queueElement.prev = queueElement3;
        return tail;
    }
    
    @Override
    public void run() {
        try {
        Label_0068:
            while (true) {
                final QueueElement dequeue = this.dequeue();
                final MailEvent event = dequeue.event;
                final Vector vector = dequeue.vector;
                for (int i = 0; i < vector.size(); ++i) {
                    try {
                        event.dispatch(vector.elementAt(i));
                    }
                    catch (Throwable t) {
                        if (t instanceof InterruptedException) {
                            break Label_0068;
                        }
                    }
                }
            }
        }
        catch (InterruptedException ex) {}
    }
    
    void stop() {
        if (this.qThread != null) {
            this.qThread.interrupt();
            this.qThread = null;
        }
    }
    
    static class QueueElement
    {
        QueueElement next;
        QueueElement prev;
        MailEvent event;
        Vector vector;
        
        QueueElement(final MailEvent event, final Vector vector) {
            this.next = null;
            this.prev = null;
            this.event = null;
            this.vector = null;
            this.event = event;
            this.vector = vector;
        }
    }
}
