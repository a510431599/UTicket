// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

import javax.mail.event.MailEvent;
import javax.mail.event.TransportEvent;
import javax.mail.event.TransportListener;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public abstract class Transport extends Service
{
    private volatile Vector transportListeners;
    
    public Transport(final Session session, final URLName urlName) {
        super(session, urlName);
        this.transportListeners = null;
    }
    
    public static void send(final Message message) {
        message.saveChanges();
        send0(message, message.getAllRecipients(), null, null);
    }
    
    public static void send(final Message message, final Address[] array) {
        message.saveChanges();
        send0(message, array, null, null);
    }
    
    public static void send(final Message message, final String s, final String s2) {
        message.saveChanges();
        send0(message, message.getAllRecipients(), s, s2);
    }
    
    public static void send(final Message message, final Address[] array, final String s, final String s2) {
        message.saveChanges();
        send0(message, array, s, s2);
    }
    
    private static void send0(final Message message, final Address[] array, final String s, final String s2) {
        if (array == null || array.length == 0) {
            throw new SendFailedException("No recipient addresses");
        }
        final Hashtable<Object, Vector<Address>> hashtable = new Hashtable<Object, Vector<Address>>();
        final Vector<Address> vector = new Vector<Address>();
        final Vector<Address> vector2 = new Vector<Address>();
        final Vector<Address> vector3 = new Vector<Address>();
        for (int i = 0; i < array.length; ++i) {
            if (hashtable.containsKey(array[i].getType())) {
                hashtable.get(array[i].getType()).addElement(array[i]);
            }
            else {
                final Vector<Address> vector4 = new Vector<Address>();
                vector4.addElement(array[i]);
                hashtable.put(array[i].getType(), vector4);
            }
        }
        final int size = hashtable.size();
        if (size == 0) {
            throw new SendFailedException("No recipient addresses");
        }
        final Session session = (message.session != null) ? message.session : Session.getDefaultInstance(System.getProperties(), null);
        if (size == 1) {
            final Transport transport = session.getTransport(array[0]);
            try {
                if (s != null) {
                    transport.connect(s, s2);
                }
                else {
                    transport.connect();
                }
                transport.sendMessage(message, array);
            }
            finally {
                transport.close();
            }
            return;
        }
        MessagingException ex = null;
        boolean b = false;
        final Enumeration<Vector<Address>> elements = hashtable.elements();
        while (elements.hasMoreElements()) {
            final Vector<Address> vector5 = elements.nextElement();
            final Address[] array2 = new Address[vector5.size()];
            vector5.copyInto(array2);
            final Transport transport2;
            if ((transport2 = session.getTransport(array2[0])) == null) {
                for (int j = 0; j < array2.length; ++j) {
                    vector.addElement(array2[j]);
                }
            }
            else {
                try {
                    transport2.connect();
                    transport2.sendMessage(message, array2);
                }
                catch (SendFailedException nextException) {
                    b = true;
                    if (ex == null) {
                        ex = nextException;
                    }
                    else {
                        ex.setNextException(nextException);
                    }
                    final Address[] invalidAddresses = nextException.getInvalidAddresses();
                    if (invalidAddresses != null) {
                        for (int k = 0; k < invalidAddresses.length; ++k) {
                            vector.addElement(invalidAddresses[k]);
                        }
                    }
                    final Address[] validSentAddresses = nextException.getValidSentAddresses();
                    if (validSentAddresses != null) {
                        for (int l = 0; l < validSentAddresses.length; ++l) {
                            vector2.addElement(validSentAddresses[l]);
                        }
                    }
                    final Address[] validUnsentAddresses = nextException.getValidUnsentAddresses();
                    if (validUnsentAddresses != null) {
                        for (int n = 0; n < validUnsentAddresses.length; ++n) {
                            vector3.addElement(validUnsentAddresses[n]);
                        }
                    }
                }
                catch (MessagingException nextException2) {
                    b = true;
                    if (ex == null) {
                        ex = nextException2;
                    }
                    else {
                        ex.setNextException(nextException2);
                    }
                }
                finally {
                    transport2.close();
                }
            }
        }
        if (b || vector.size() != 0 || vector3.size() != 0) {
            Address[] array3 = null;
            Address[] array4 = null;
            Address[] array5 = null;
            if (vector2.size() > 0) {
                array3 = new Address[vector2.size()];
                vector2.copyInto(array3);
            }
            if (vector3.size() > 0) {
                array4 = new Address[vector3.size()];
                vector3.copyInto(array4);
            }
            if (vector.size() > 0) {
                array5 = new Address[vector.size()];
                vector.copyInto(array5);
            }
            throw new SendFailedException("Sending failed", ex, array3, array4, array5);
        }
    }
    
    public abstract void sendMessage(final Message p0, final Address[] p1);
    
    public synchronized void addTransportListener(final TransportListener transportListener) {
        if (this.transportListeners == null) {
            this.transportListeners = new Vector();
        }
        this.transportListeners.addElement(transportListener);
    }
    
    public synchronized void removeTransportListener(final TransportListener transportListener) {
        if (this.transportListeners != null) {
            this.transportListeners.removeElement(transportListener);
        }
    }
    
    protected void notifyTransportListeners(final int n, final Address[] array, final Address[] array2, final Address[] array3, final Message message) {
        if (this.transportListeners == null) {
            return;
        }
        this.queueEvent(new TransportEvent(this, n, array, array2, array3, message), this.transportListeners);
    }
}
