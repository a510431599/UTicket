// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail;

public interface UIDFolder
{
    public static final long LASTUID = -1L;
    
    long getUIDValidity();
    
    Message getMessageByUID(final long p0);
    
    Message[] getMessagesByUID(final long p0, final long p1);
    
    Message[] getMessagesByUID(final long[] p0);
    
    long getUID(final Message p0);
    
    public static class FetchProfileItem extends FetchProfile.Item
    {
        public static final FetchProfileItem UID;
        
        protected FetchProfileItem(final String s) {
            super(s);
        }
        
        static {
            UID = new FetchProfileItem("UID");
        }
    }
}
