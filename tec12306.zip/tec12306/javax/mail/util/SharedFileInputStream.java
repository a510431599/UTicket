// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.util;

import java.io.InputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import javax.mail.internet.SharedInputStream;
import java.io.BufferedInputStream;

public class SharedFileInputStream extends BufferedInputStream implements SharedInputStream
{
    private static int defaultBufferSize;
    protected RandomAccessFile in;
    protected int bufsize;
    protected long bufpos;
    protected long start;
    protected long datalen;
    private boolean master;
    private SharedFile sf;
    
    private void ensureOpen() {
        if (this.in == null) {
            throw new IOException("Stream closed");
        }
    }
    
    public SharedFileInputStream(final File file) {
        this(file, SharedFileInputStream.defaultBufferSize);
    }
    
    public SharedFileInputStream(final String s) {
        this(s, SharedFileInputStream.defaultBufferSize);
    }
    
    public SharedFileInputStream(final File file, final int n) {
        super(null);
        this.start = 0L;
        this.master = true;
        if (n <= 0) {
            throw new IllegalArgumentException("Buffer size <= 0");
        }
        this.init(new SharedFile(file), n);
    }
    
    public SharedFileInputStream(final String s, final int n) {
        super(null);
        this.start = 0L;
        this.master = true;
        if (n <= 0) {
            throw new IllegalArgumentException("Buffer size <= 0");
        }
        this.init(new SharedFile(s), n);
    }
    
    private void init(final SharedFile sf, final int bufsize) {
        this.sf = sf;
        this.in = sf.open();
        this.start = 0L;
        this.datalen = this.in.length();
        this.bufsize = bufsize;
        this.buf = new byte[bufsize];
    }
    
    private SharedFileInputStream(final SharedFile sf, final long n, final long datalen, final int bufsize) {
        super(null);
        this.start = 0L;
        this.master = true;
        this.master = false;
        this.sf = sf;
        this.in = sf.open();
        this.start = n;
        this.bufpos = n;
        this.datalen = datalen;
        this.bufsize = bufsize;
        this.buf = new byte[bufsize];
    }
    
    private void fill() {
        if (this.markpos < 0) {
            this.pos = 0;
            this.bufpos += this.count;
        }
        else if (this.pos >= this.buf.length) {
            if (this.markpos > 0) {
                final int pos = this.pos - this.markpos;
                System.arraycopy(this.buf, this.markpos, this.buf, 0, pos);
                this.pos = pos;
                this.bufpos += this.markpos;
                this.markpos = 0;
            }
            else if (this.buf.length >= this.marklimit) {
                this.markpos = -1;
                this.pos = 0;
                this.bufpos += this.count;
            }
            else {
                int marklimit = this.pos * 2;
                if (marklimit > this.marklimit) {
                    marklimit = this.marklimit;
                }
                final byte[] buf = new byte[marklimit];
                System.arraycopy(this.buf, 0, buf, 0, this.pos);
                this.buf = buf;
            }
        }
        this.count = this.pos;
        this.in.seek(this.bufpos + this.pos);
        int n = this.buf.length - this.pos;
        if (this.bufpos - this.start + this.pos + n > this.datalen) {
            n = (int)(this.datalen - (this.bufpos - this.start + this.pos));
        }
        final int read = this.in.read(this.buf, this.pos, n);
        if (read > 0) {
            this.count = read + this.pos;
        }
    }
    
    @Override
    public synchronized int read() {
        this.ensureOpen();
        if (this.pos >= this.count) {
            this.fill();
            if (this.pos >= this.count) {
                return -1;
            }
        }
        return this.buf[this.pos++] & 0xFF;
    }
    
    private int read1(final byte[] array, final int n, final int n2) {
        int n3 = this.count - this.pos;
        if (n3 <= 0) {
            this.fill();
            n3 = this.count - this.pos;
            if (n3 <= 0) {
                return -1;
            }
        }
        final int n4 = (n3 < n2) ? n3 : n2;
        System.arraycopy(this.buf, this.pos, array, n, n4);
        this.pos += n4;
        return n4;
    }
    
    @Override
    public synchronized int read(final byte[] array, final int n, final int n2) {
        this.ensureOpen();
        if ((n | n2 | n + n2 | array.length - (n + n2)) < 0) {
            throw new IndexOutOfBoundsException();
        }
        if (n2 == 0) {
            return 0;
        }
        int i = this.read1(array, n, n2);
        if (i <= 0) {
            return i;
        }
        while (i < n2) {
            final int read1 = this.read1(array, n + i, n2 - i);
            if (read1 <= 0) {
                break;
            }
            i += read1;
        }
        return i;
    }
    
    @Override
    public synchronized long skip(final long n) {
        this.ensureOpen();
        if (n <= 0L) {
            return 0L;
        }
        long n2 = this.count - this.pos;
        if (n2 <= 0L) {
            this.fill();
            n2 = this.count - this.pos;
            if (n2 <= 0L) {
                return 0L;
            }
        }
        final long n3 = (n2 < n) ? n2 : n;
        this.pos += (int)n3;
        return n3;
    }
    
    @Override
    public synchronized int available() {
        this.ensureOpen();
        return this.count - this.pos + this.in_available();
    }
    
    private int in_available() {
        return (int)(this.start + this.datalen - (this.bufpos + this.count));
    }
    
    @Override
    public synchronized void mark(final int marklimit) {
        this.marklimit = marklimit;
        this.markpos = this.pos;
    }
    
    @Override
    public synchronized void reset() {
        this.ensureOpen();
        if (this.markpos < 0) {
            throw new IOException("Resetting to invalid mark");
        }
        this.pos = this.markpos;
    }
    
    @Override
    public boolean markSupported() {
        return true;
    }
    
    @Override
    public void close() {
        if (this.in == null) {
            return;
        }
        try {
            if (this.master) {
                this.sf.forceClose();
            }
            else {
                this.sf.close();
            }
        }
        finally {
            this.sf = null;
            this.in = null;
            this.buf = null;
        }
    }
    
    @Override
    public long getPosition() {
        if (this.in == null) {
            throw new RuntimeException("Stream closed");
        }
        return this.bufpos + this.pos - this.start;
    }
    
    @Override
    public synchronized InputStream newStream(final long n, long datalen) {
        if (this.in == null) {
            throw new RuntimeException("Stream closed");
        }
        if (n < 0L) {
            throw new IllegalArgumentException("start < 0");
        }
        if (datalen == -1L) {
            datalen = this.datalen;
        }
        return new SharedFileInputStream(this.sf, this.start + (int)n, (int)(datalen - n), this.bufsize);
    }
    
    @Override
    protected void finalize() {
        super.finalize();
        this.close();
    }
    
    static {
        SharedFileInputStream.defaultBufferSize = 2048;
    }
    
    static class SharedFile
    {
        private int cnt;
        private RandomAccessFile in;
        
        SharedFile(final String s) {
            this.in = new RandomAccessFile(s, "r");
        }
        
        SharedFile(final File file) {
            this.in = new RandomAccessFile(file, "r");
        }
        
        public synchronized RandomAccessFile open() {
            ++this.cnt;
            return this.in;
        }
        
        public synchronized void close() {
            if (this.cnt > 0 && --this.cnt <= 0) {
                this.in.close();
            }
        }
        
        public synchronized void forceClose() {
            if (this.cnt > 0) {
                this.cnt = 0;
                this.in.close();
            }
            else {
                try {
                    this.in.close();
                }
                catch (IOException ex) {}
            }
        }
        
        @Override
        protected void finalize() {
            super.finalize();
            this.in.close();
        }
    }
}
