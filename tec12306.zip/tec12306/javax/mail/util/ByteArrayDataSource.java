// 
// Decompiled by Procyon v0.5.30
// 

package javax.mail.util;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import javax.mail.internet.MimeUtility;
import javax.mail.internet.ParseException;
import javax.mail.internet.ContentType;
import java.io.InputStream;
import javax.activation.DataSource;

public class ByteArrayDataSource implements DataSource
{
    private byte[] data;
    private int len;
    private String type;
    private String name;
    
    public ByteArrayDataSource(final InputStream inputStream, final String type) {
        this.len = -1;
        this.name = "";
        final DSByteArrayOutputStream dsByteArrayOutputStream = new DSByteArrayOutputStream();
        final byte[] array = new byte[8192];
        int read;
        while ((read = inputStream.read(array)) > 0) {
            dsByteArrayOutputStream.write(array, 0, read);
        }
        this.data = dsByteArrayOutputStream.getBuf();
        this.len = dsByteArrayOutputStream.getCount();
        if (this.data.length - this.len > 262144) {
            this.data = dsByteArrayOutputStream.toByteArray();
            this.len = this.data.length;
        }
        this.type = type;
    }
    
    public ByteArrayDataSource(final byte[] data, final String type) {
        this.len = -1;
        this.name = "";
        this.data = data;
        this.type = type;
    }
    
    public ByteArrayDataSource(final String s, final String type) {
        this.len = -1;
        this.name = "";
        String parameter = null;
        try {
            parameter = new ContentType(type).getParameter("charset");
        }
        catch (ParseException ex) {}
        String s2 = MimeUtility.javaCharset(parameter);
        if (s2 == null) {
            s2 = MimeUtility.getDefaultJavaCharset();
        }
        this.data = s.getBytes(s2);
        this.type = type;
    }
    
    @Override
    public InputStream getInputStream() {
        if (this.data == null) {
            throw new IOException("no data");
        }
        if (this.len < 0) {
            this.len = this.data.length;
        }
        return new SharedByteArrayInputStream(this.data, 0, this.len);
    }
    
    @Override
    public OutputStream getOutputStream() {
        throw new IOException("cannot do this");
    }
    
    @Override
    public String getContentType() {
        return this.type;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    public void setName(final String name) {
        this.name = name;
    }
    
    static class DSByteArrayOutputStream extends ByteArrayOutputStream
    {
        public byte[] getBuf() {
            return this.buf;
        }
        
        public int getCount() {
            return this.count;
        }
    }
}
