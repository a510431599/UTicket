// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

public abstract class CommandMap
{
    private static CommandMap defaultCommandMap;
    static Class class$javax$activation$CommandMap;
    
    public static CommandMap getDefaultCommandMap() {
        if (CommandMap.defaultCommandMap == null) {
            CommandMap.defaultCommandMap = new MailcapCommandMap();
        }
        return CommandMap.defaultCommandMap;
    }
    
    public static void setDefaultCommandMap(final CommandMap defaultCommandMap) {
        final SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            try {
                securityManager.checkSetFactory();
            }
            catch (SecurityException ex) {
                if (((CommandMap.class$javax$activation$CommandMap == null) ? (CommandMap.class$javax$activation$CommandMap = class$("javax.activation.CommandMap")) : CommandMap.class$javax$activation$CommandMap).getClassLoader() != defaultCommandMap.getClass().getClassLoader()) {
                    throw ex;
                }
            }
        }
        CommandMap.defaultCommandMap = defaultCommandMap;
    }
    
    public abstract CommandInfo[] getPreferredCommands(final String p0);
    
    public CommandInfo[] getPreferredCommands(final String s, final DataSource dataSource) {
        return this.getPreferredCommands(s);
    }
    
    public abstract CommandInfo[] getAllCommands(final String p0);
    
    public CommandInfo[] getAllCommands(final String s, final DataSource dataSource) {
        return this.getAllCommands(s);
    }
    
    public abstract CommandInfo getCommand(final String p0, final String p1);
    
    public CommandInfo getCommand(final String s, final String s2, final DataSource dataSource) {
        return this.getCommand(s, s2);
    }
    
    public abstract DataContentHandler createDataContentHandler(final String p0);
    
    public DataContentHandler createDataContentHandler(final String s, final DataSource dataSource) {
        return this.createDataContentHandler(s);
    }
    
    public String[] getMimeTypes() {
        return null;
    }
    
    static Class class$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException ex) {
            throw new NoClassDefFoundError().initCause(ex);
        }
    }
    
    static {
        CommandMap.defaultCommandMap = null;
    }
}
