// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

public interface CommandObject
{
    void setCommandContext(final String p0, final DataHandler p1);
}
