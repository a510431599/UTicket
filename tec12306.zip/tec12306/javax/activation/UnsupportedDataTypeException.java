// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.IOException;

public class UnsupportedDataTypeException extends IOException
{
    public UnsupportedDataTypeException() {
    }
    
    public UnsupportedDataTypeException(final String s) {
        super(s);
    }
}
