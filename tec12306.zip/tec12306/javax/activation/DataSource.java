// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.OutputStream;
import java.io.InputStream;

public interface DataSource
{
    InputStream getInputStream();
    
    OutputStream getOutputStream();
    
    String getContentType();
    
    String getName();
}
