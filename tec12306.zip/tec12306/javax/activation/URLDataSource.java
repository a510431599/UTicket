// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.net.URL;

public class URLDataSource implements DataSource
{
    private URL url;
    private URLConnection url_conn;
    
    public URLDataSource(final URL url) {
        this.url = null;
        this.url_conn = null;
        this.url = url;
    }
    
    @Override
    public String getContentType() {
        String contentType = null;
        try {
            if (this.url_conn == null) {
                this.url_conn = this.url.openConnection();
            }
        }
        catch (IOException ex) {}
        if (this.url_conn != null) {
            contentType = this.url_conn.getContentType();
        }
        if (contentType == null) {
            contentType = "application/octet-stream";
        }
        return contentType;
    }
    
    @Override
    public String getName() {
        return this.url.getFile();
    }
    
    @Override
    public InputStream getInputStream() {
        return this.url.openStream();
    }
    
    @Override
    public OutputStream getOutputStream() {
        this.url_conn = this.url.openConnection();
        if (this.url_conn != null) {
            this.url_conn.setDoOutput(true);
            return this.url_conn.getOutputStream();
        }
        return null;
    }
    
    public URL getURL() {
        return this.url;
    }
}
