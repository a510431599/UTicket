// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.Externalizable;
import java.beans.Beans;

public class CommandInfo
{
    private String verb;
    private String className;
    
    public CommandInfo(final String verb, final String className) {
        this.verb = verb;
        this.className = className;
    }
    
    public String getCommandName() {
        return this.verb;
    }
    
    public String getCommandClass() {
        return this.className;
    }
    
    public Object getCommandObject(final DataHandler dataHandler, final ClassLoader classLoader) {
        final Object instantiate = Beans.instantiate(classLoader, this.className);
        if (instantiate != null) {
            if (instantiate instanceof CommandObject) {
                ((CommandObject)instantiate).setCommandContext(this.verb, dataHandler);
            }
            else if (instantiate instanceof Externalizable && dataHandler != null) {
                final InputStream inputStream = dataHandler.getInputStream();
                if (inputStream != null) {
                    ((Externalizable)instantiate).readExternal(new ObjectInputStream(inputStream));
                }
            }
        }
        return instantiate;
    }
}
