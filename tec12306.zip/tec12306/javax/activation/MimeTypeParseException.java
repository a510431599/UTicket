// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

public class MimeTypeParseException extends Exception
{
    public MimeTypeParseException() {
    }
    
    public MimeTypeParseException(final String s) {
        super(s);
    }
}
