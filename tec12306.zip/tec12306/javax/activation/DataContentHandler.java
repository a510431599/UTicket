// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.OutputStream;
import java.awt.datatransfer.DataFlavor;

public interface DataContentHandler
{
    DataFlavor[] getTransferDataFlavors();
    
    Object getTransferData(final DataFlavor p0, final DataSource p1);
    
    Object getContent(final DataSource p0);
    
    void writeTo(final Object p0, final String p1, final OutputStream p2);
}
