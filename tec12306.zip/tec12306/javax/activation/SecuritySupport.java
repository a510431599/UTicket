// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.util.Enumeration;
import java.util.ArrayList;
import java.net.URL;
import java.security.PrivilegedActionException;
import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.io.InputStream;
import java.security.AccessController;
import java.security.PrivilegedAction;

class SecuritySupport
{
    public static ClassLoader getContextClassLoader() {
        return AccessController.doPrivileged((PrivilegedAction<ClassLoader>)new PrivilegedAction() {
            @Override
            public Object run() {
                Object contextClassLoader = null;
                try {
                    contextClassLoader = Thread.currentThread().getContextClassLoader();
                }
                catch (SecurityException ex) {}
                return contextClassLoader;
            }
        });
    }
    
    public static InputStream getResourceAsStream(final Class clazz, final String s) {
        try {
            return AccessController.doPrivileged((PrivilegedExceptionAction<InputStream>)new PrivilegedExceptionAction(clazz, s) {
                private final Class val$c;
                private final String val$name;
                
                @Override
                public Object run() {
                    return this.val$c.getResourceAsStream(this.val$name);
                }
            });
        }
        catch (PrivilegedActionException ex) {
            throw (IOException)ex.getException();
        }
    }
    
    public static URL[] getResources(final ClassLoader classLoader, final String s) {
        return AccessController.doPrivileged((PrivilegedAction<URL[]>)new PrivilegedAction(classLoader, s) {
            private final ClassLoader val$cl;
            private final String val$name;
            
            @Override
            public Object run() {
                URL[] array = null;
                try {
                    final ArrayList<URL> list = new ArrayList<URL>();
                    final Enumeration<URL> resources = this.val$cl.getResources(this.val$name);
                    while (resources != null && resources.hasMoreElements()) {
                        final URL url = resources.nextElement();
                        if (url != null) {
                            list.add(url);
                        }
                    }
                    if (list.size() > 0) {
                        array = new URL[list.size()];
                        array = list.toArray(array);
                    }
                }
                catch (IOException ex) {}
                catch (SecurityException ex2) {}
                return array;
            }
        });
    }
    
    public static URL[] getSystemResources(final String s) {
        return AccessController.doPrivileged((PrivilegedAction<URL[]>)new PrivilegedAction(s) {
            private final String val$name;
            
            @Override
            public Object run() {
                URL[] array = null;
                try {
                    final ArrayList<URL> list = new ArrayList<URL>();
                    final Enumeration<URL> systemResources = ClassLoader.getSystemResources(this.val$name);
                    while (systemResources != null && systemResources.hasMoreElements()) {
                        final URL url = systemResources.nextElement();
                        if (url != null) {
                            list.add(url);
                        }
                    }
                    if (list.size() > 0) {
                        array = new URL[list.size()];
                        array = list.toArray(array);
                    }
                }
                catch (IOException ex) {}
                catch (SecurityException ex2) {}
                return array;
            }
        });
    }
    
    public static InputStream openStream(final URL url) {
        try {
            return AccessController.doPrivileged((PrivilegedExceptionAction<InputStream>)new PrivilegedExceptionAction(url) {
                private final URL val$url;
                
                @Override
                public Object run() {
                    return this.val$url.openStream();
                }
            });
        }
        catch (PrivilegedActionException ex) {
            throw (IOException)ex.getException();
        }
    }
}
