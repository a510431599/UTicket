// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.OutputStream;
import java.io.InputStream;

class DataHandlerDataSource implements DataSource
{
    DataHandler dataHandler;
    
    public DataHandlerDataSource(final DataHandler dataHandler) {
        this.dataHandler = null;
        this.dataHandler = dataHandler;
    }
    
    @Override
    public InputStream getInputStream() {
        return this.dataHandler.getInputStream();
    }
    
    @Override
    public OutputStream getOutputStream() {
        return this.dataHandler.getOutputStream();
    }
    
    @Override
    public String getContentType() {
        return this.dataHandler.getContentType();
    }
    
    @Override
    public String getName() {
        return this.dataHandler.getName();
    }
}
