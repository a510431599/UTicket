// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Externalizable;

public class MimeType implements Externalizable
{
    private String primaryType;
    private String subType;
    private MimeTypeParameterList parameters;
    private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";
    
    public MimeType() {
        this.primaryType = "application";
        this.subType = "*";
        this.parameters = new MimeTypeParameterList();
    }
    
    public MimeType(final String s) {
        this.parse(s);
    }
    
    public MimeType(final String s, final String s2) {
        if (!this.isValidToken(s)) {
            throw new MimeTypeParseException("Primary type is invalid.");
        }
        this.primaryType = s.toLowerCase();
        if (this.isValidToken(s2)) {
            this.subType = s2.toLowerCase();
            this.parameters = new MimeTypeParameterList();
            return;
        }
        throw new MimeTypeParseException("Sub type is invalid.");
    }
    
    private void parse(final String s) {
        final int index = s.indexOf(47);
        final int index2 = s.indexOf(59);
        if (index < 0 && index2 < 0) {
            throw new MimeTypeParseException("Unable to find a sub type.");
        }
        if (index < 0 && index2 >= 0) {
            throw new MimeTypeParseException("Unable to find a sub type.");
        }
        if (index >= 0 && index2 < 0) {
            this.primaryType = s.substring(0, index).trim().toLowerCase();
            this.subType = s.substring(index + 1).trim().toLowerCase();
            this.parameters = new MimeTypeParameterList();
        }
        else {
            if (index >= index2) {
                throw new MimeTypeParseException("Unable to find a sub type.");
            }
            this.primaryType = s.substring(0, index).trim().toLowerCase();
            this.subType = s.substring(index + 1, index2).trim().toLowerCase();
            this.parameters = new MimeTypeParameterList(s.substring(index2));
        }
        if (!this.isValidToken(this.primaryType)) {
            throw new MimeTypeParseException("Primary type is invalid.");
        }
        if (!this.isValidToken(this.subType)) {
            throw new MimeTypeParseException("Sub type is invalid.");
        }
    }
    
    public String getPrimaryType() {
        return this.primaryType;
    }
    
    public void setPrimaryType(final String s) {
        if (!this.isValidToken(this.primaryType)) {
            throw new MimeTypeParseException("Primary type is invalid.");
        }
        this.primaryType = s.toLowerCase();
    }
    
    public String getSubType() {
        return this.subType;
    }
    
    public void setSubType(final String s) {
        if (!this.isValidToken(this.subType)) {
            throw new MimeTypeParseException("Sub type is invalid.");
        }
        this.subType = s.toLowerCase();
    }
    
    public MimeTypeParameterList getParameters() {
        return this.parameters;
    }
    
    public String getParameter(final String s) {
        return this.parameters.get(s);
    }
    
    public void setParameter(final String s, final String s2) {
        this.parameters.set(s, s2);
    }
    
    public void removeParameter(final String s) {
        this.parameters.remove(s);
    }
    
    @Override
    public String toString() {
        return new StringBuffer().append(this.getBaseType()).append(this.parameters.toString()).toString();
    }
    
    public String getBaseType() {
        return new StringBuffer().append(this.primaryType).append("/").append(this.subType).toString();
    }
    
    public boolean match(final MimeType mimeType) {
        return this.primaryType.equals(mimeType.getPrimaryType()) && (this.subType.equals("*") || mimeType.getSubType().equals("*") || this.subType.equals(mimeType.getSubType()));
    }
    
    public boolean match(final String s) {
        return this.match(new MimeType(s));
    }
    
    @Override
    public void writeExternal(final ObjectOutput objectOutput) {
        objectOutput.writeUTF(this.toString());
        objectOutput.flush();
    }
    
    @Override
    public void readExternal(final ObjectInput objectInput) {
        try {
            this.parse(objectInput.readUTF());
        }
        catch (MimeTypeParseException ex) {
            throw new IOException(ex.toString());
        }
    }
    
    private static boolean isTokenChar(final char c) {
        return c > ' ' && c < '\u007f' && "()<>@,;:/[]?=\\\"".indexOf(c) < 0;
    }
    
    private boolean isValidToken(final String s) {
        final int length = s.length();
        if (length > 0) {
            for (int i = 0; i < length; ++i) {
                if (!isTokenChar(s.charAt(i))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}
