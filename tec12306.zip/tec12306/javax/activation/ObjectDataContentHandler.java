// 
// Decompiled by Procyon v0.5.30
// 

package javax.activation;

import java.io.OutputStream;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.datatransfer.DataFlavor;

class ObjectDataContentHandler implements DataContentHandler
{
    private DataFlavor[] transferFlavors;
    private Object obj;
    private String mimeType;
    private DataContentHandler dch;
    
    public ObjectDataContentHandler(final DataContentHandler dch, final Object obj, final String mimeType) {
        this.transferFlavors = null;
        this.dch = null;
        this.obj = obj;
        this.mimeType = mimeType;
        this.dch = dch;
    }
    
    public DataContentHandler getDCH() {
        return this.dch;
    }
    
    @Override
    public DataFlavor[] getTransferDataFlavors() {
        if (this.transferFlavors == null) {
            if (this.dch != null) {
                this.transferFlavors = this.dch.getTransferDataFlavors();
            }
            else {
                (this.transferFlavors = new DataFlavor[1])[0] = new ActivationDataFlavor(this.obj.getClass(), this.mimeType, this.mimeType);
            }
        }
        return this.transferFlavors;
    }
    
    @Override
    public Object getTransferData(final DataFlavor dataFlavor, final DataSource dataSource) {
        if (this.dch != null) {
            return this.dch.getTransferData(dataFlavor, dataSource);
        }
        if (dataFlavor.equals(this.transferFlavors[0])) {
            return this.obj;
        }
        throw new UnsupportedFlavorException(dataFlavor);
    }
    
    @Override
    public Object getContent(final DataSource dataSource) {
        return this.obj;
    }
    
    @Override
    public void writeTo(final Object o, final String s, final OutputStream outputStream) {
        if (this.dch != null) {
            this.dch.writeTo(o, s, outputStream);
            return;
        }
        throw new UnsupportedDataTypeException(new StringBuffer().append("no object DCH for MIME type ").append(this.mimeType).toString());
    }
}
