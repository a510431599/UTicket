// 
// Decompiled by Procyon v0.5.30
// 

package javafx.a;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

public class d
{
    private static final Map<Object, a<?>> a;
    
    static {
        a = new HashMap<Object, a<?>>();
    }
    
    public static <T, K> T a(final Class<? extends a<K>> clazz) {
        a<?> b = d.a.get(clazz);
        if (b == null) {
            b = b(clazz);
            d.a.put(clazz, b);
        }
        return (T)b;
    }
    
    public static <T, K> T a(final Class<? extends a<K>> clazz, final String s) {
        final String string = String.valueOf(clazz.getName()) + "_" + s;
        a<?> b = d.a.get(string);
        if (b == null) {
            b = b(clazz);
            d.a.put(string, b);
        }
        return (T)b;
    }
    
    public static void b(final Class<?> clazz, final String s) {
        d.a.remove(String.valueOf(clazz.getName()) + "_" + s);
    }
    
    private static a<?> b(final Class<? extends a<?>> clazz) {
        a<?> a = null;
        try {
            a = (a<?>)clazz.getConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
        }
        catch (NoSuchMethodException | SecurityException ex5) {
            final Throwable t;
            t.printStackTrace();
        }
        catch (InstantiationException ex) {
            ex.printStackTrace();
        }
        catch (IllegalAccessException ex2) {
            ex2.printStackTrace();
        }
        catch (IllegalArgumentException ex3) {
            ex3.printStackTrace();
        }
        catch (InvocationTargetException ex4) {
            ex4.printStackTrace();
        }
        return a;
    }
}
