// 
// Decompiled by Procyon v0.5.30
// 

package javafx.a;

import javafx.controller.AbstractController;
import javafx.concurrent.Task;
import javafx.application.Platform;
import javafx.concurrent.Worker;
import javafx.concurrent.Service;

public abstract class a<T> extends Service<T>
{
    private c<T> a;
    private Object[] b;
    
    public void a(final Object... b) {
        this.b = b;
    }
    
    public <T> T a(final int n) {
        if (this.b == null || this.b.length <= n) {
            return null;
        }
        return (T)this.b[n];
    }
    
    public void start() {
        if (super.isRunning()) {
            super.cancel();
        }
        if (this.getState() != Worker.State.SCHEDULED && this.getState() != Worker.State.RUNNING) {
            super.reset();
        }
        super.start();
    }
    
    public void a() {
    }
    
    protected abstract T b();
    
    public void c() {
    }
    
    public void d() {
    }
    
    public void a(final T t) {
        this.f().updateValue(t);
    }
    
    public void a(final long n, final long n2) {
        this.f().updateProgress(n, n2);
    }
    
    public void a(final Runnable runnable) {
        Platform.runLater(runnable);
    }
    
    public boolean e() {
        return this.f().isCancelled();
    }
    
    protected Task<T> createTask() {
        return this.a = new b(this);
    }
    
    public boolean cancel() {
        this.c();
        return super.cancel();
    }
    
    public c<T> f() {
        return this.a;
    }
    
    public <C> C a(final Class<? extends AbstractController> clazz) {
        return javafx.controller.a.a(clazz);
    }
}
