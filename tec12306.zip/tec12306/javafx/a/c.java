// 
// Decompiled by Procyon v0.5.30
// 

package javafx.a;

import javafx.concurrent.Task;

public abstract class c<T> extends Task<T>
{
    public void updateValue(final T t) {
        super.updateValue((Object)t);
    }
    
    public void updateMessage(final String s) {
        super.updateMessage(s);
    }
    
    public void updateProgress(final long n, final long n2) {
        super.updateProgress(n, n2);
    }
    
    public void updateProgress(final double n, final double n2) {
        super.updateProgress(n, n2);
    }
    
    public void updateTitle(final String s) {
        super.updateTitle(s);
    }
}
