// 
// Decompiled by Procyon v0.5.30
// 

package javafx.controller;

import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.control.dialog.AbstractWindow;
import javafx.stage.Window;
import javafx.scene.Node;
import javafx.application.Platform;
import java.util.ResourceBundle;
import java.net.URL;
import javafx.fxml.Initializable;

public abstract class AbstractController implements b, Initializable
{
    public final void initialize(final URL url, final ResourceBundle resourceBundle) {
        a.a(this);
        this.initialize();
        Platform.runLater(() -> this.afterPropertySet());
    }
    
    public abstract Node getRootNode();
    
    public final Window getWindow() {
        return this.getScene().getWindow();
    }
    
    public final AbstractWindow getAbstractWindow() {
        return (AbstractWindow)this.getScene().getWindow();
    }
    
    public final Stage getStage() {
        return (Stage)this.getWindow();
    }
    
    public final Scene getScene() {
        return this.getRootNode().getScene();
    }
    
    public void afterPropertySet() {
    }
    
    public <T> T getArgument(final int n) {
        if (this.getWindow() == null) {
            return null;
        }
        return ((AbstractWindow)this.getWindow()).getArgument(n);
    }
}
