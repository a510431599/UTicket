// 
// Decompiled by Procyon v0.5.30
// 

package javafx.controller;

interface b
{
    void initialize();
}
