// 
// Decompiled by Procyon v0.5.30
// 

package javafx.controller;

import java.util.HashMap;
import java.util.Map;

public class a
{
    private static final Map<Class<?>, AbstractController> a;
    
    static {
        a = new HashMap<Class<?>, AbstractController>();
    }
    
    public static final void a(final AbstractController abstractController) {
        javafx.controller.a.a.put(abstractController.getClass(), abstractController);
    }
    
    public static final <T> T a(final Class<? extends AbstractController> clazz) {
        return (T)javafx.controller.a.a.get(clazz);
    }
}
