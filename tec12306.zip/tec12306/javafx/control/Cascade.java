// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control;

import javafx.beans.property.IntegerProperty;
import javafx.collections.ObservableList;
import javafx.control.bean.SelectedProperty;

public interface Cascade<T extends SelectedProperty>
{
    void setProvider(final Provider<T> p0);
    
    void add(final T p0);
    
    void removeAll();
    
    void remove(final T p0);
    
    ObservableList<T> getItems();
    
    IntegerProperty maxSizeProperty();
    
    IntegerProperty checkedProperty();
}
