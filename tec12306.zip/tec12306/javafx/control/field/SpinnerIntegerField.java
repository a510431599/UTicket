// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

public class SpinnerIntegerField extends SpinnerField<Integer>
{
    public SpinnerIntegerField() {
        this(null, null, null, null);
    }
    
    public SpinnerIntegerField(final Integer n) {
        this(n, null, null, null);
    }
    
    public SpinnerIntegerField(final Integer n, final Integer n2, final Integer n3, final Integer n4) {
        super(n, n2, n3, n4, "number", null);
    }
}
