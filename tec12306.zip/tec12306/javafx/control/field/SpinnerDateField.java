// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

import java.time.LocalDate;

public class SpinnerDateField extends SpinnerField<Long>
{
    public SpinnerDateField() {
        this(null, null, null, null, null);
    }
    
    public SpinnerDateField(final Long n) {
        this(n, null, null, null, null);
    }
    
    public SpinnerDateField(final Long n, final Long n2, final Long n3, final Long n4) {
        this(n, n2, n3, n4, null);
    }
    
    public SpinnerDateField(final Long n, final Long n2, final Long n3, final Long n4, final String s) {
        super(n, n2, n3, n4, "date", s);
    }
    
    @Override
    public void setStep(final Long step) {
        super.setStep(step);
    }
    
    public void setMaxDate(final LocalDate localDate) {
        super.setMaxValue(localDate.toEpochDay());
    }
    
    public LocalDate getMaxDate() {
        return LocalDate.ofEpochDay(this.getMaxValue());
    }
    
    public void setMinDate(final LocalDate localDate) {
        super.setMinValue(localDate.toEpochDay());
    }
    
    public LocalDate getMinDate() {
        return LocalDate.ofEpochDay(this.getMinValue());
    }
    
    public LocalDate getDate() {
        return LocalDate.ofEpochDay(this.getValue());
    }
    
    public void setDate(final LocalDate localDate) {
        this.setValue(localDate.toEpochDay());
    }
}
