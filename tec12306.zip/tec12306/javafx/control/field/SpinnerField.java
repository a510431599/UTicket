// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

import javafx.scene.input.InputMethodEvent;
import javafx.scene.control.TextField;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import javafx.scene.Node;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import java.util.regex.Matcher;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.LocalDateTime;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.PathElement;
import javafx.geometry.Insets;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Pos;
import java.lang.reflect.ParameterizedType;
import java.util.HashMap;
import javafx.application.Platform;
import java.math.BigDecimal;
import javafx.concurrent.Task;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleObjectProperty;
import java.util.Map;
import javafx.concurrent.Service;
import javafx.util.StringConverter;
import javafx.beans.property.StringProperty;
import javafx.beans.property.ObjectProperty;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Path;
import javafx.scene.layout.StackPane;

public abstract class SpinnerField<T extends Number> extends StackPane
{
    private NumberTextField<T> editer;
    private StackPane downArrow;
    private StackPane upArrow;
    private StackPane downBtn;
    private StackPane upBtn;
    private Path downPath;
    private Path upPath;
    private VBox arrowContainer;
    private ObjectProperty<T> value;
    private ObjectProperty<T> step;
    private ObjectProperty<T> max;
    private ObjectProperty<T> min;
    private StringProperty spinner;
    private StringProperty pattern;
    private Position[] pos;
    private Class<T> clazz;
    static final String NUMBER = "number";
    static final String DATE_TIME = "datetime";
    static final String TIME = "time";
    static final String DATE = "date";
    static final String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";
    static final String DATE_PATTERN = "yyyy-MM-dd";
    static final String TIME_PATTERN = "HH:mm:ss";
    private final double MIN_HEIGHT_SIZE = 20.0;
    private final double MIN_WIDTH_SIZE = 50.0;
    private boolean arrowPressed;
    private boolean arrowAdd;
    private StringConverter<T> stringConverter;
    private Service<Void> service;
    private Map<String, String> methods;
    
    SpinnerField() {
        this(null, null, null, null, null, null);
    }
    
    SpinnerField(final T t) {
        this(t, null, null, null, null, null);
    }
    
    SpinnerField(final T t, final T t2, final T t3, final T t4) {
        this(t, t2, t3, t4, null, null);
    }
    
    SpinnerField(final T t, final T t2, final T t3, final T t4, final String s, final String s2) {
        this.value = (ObjectProperty<T>)new SimpleObjectProperty((Object)this, "value");
        this.step = (ObjectProperty<T>)new SimpleObjectProperty((Object)this, "step");
        this.max = (ObjectProperty<T>)new SimpleObjectProperty((Object)this, "max");
        this.min = (ObjectProperty<T>)new SimpleObjectProperty((Object)this, "min");
        this.spinner = (StringProperty)new SimpleStringProperty((Object)this, "spinner");
        this.pattern = (StringProperty)new SimpleStringProperty((Object)this, "pattern");
        this.pos = null;
        this.arrowPressed = false;
        this.arrowAdd = false;
        this.service = new Service<Void>() {
            protected Task<Void> createTask() {
                return new Task<Void>() {
                    protected Void call() {
                        while (SpinnerField.this.arrowPressed) {
                            Platform.runLater((Runnable)new Runnable() {
                                @Override
                                public void run() {
                                    final String string = String.valueOf(SpinnerField.this.arrowAdd ? "" : "-") + String.valueOf(SpinnerField.this.getStep());
                                    final Number n = (Number)((SpinnerField.this.getValue() != null) ? SpinnerField.this.getValue() : SpinnerField.this.stringConverter.fromString("0"));
                                    BigDecimal add = new BigDecimal(String.valueOf(n));
                                    if (SpinnerField.this.getSpinner().equalsIgnoreCase("number")) {
                                        add = add.add(new BigDecimal(string));
                                    }
                                    else if (SpinnerField.this.getSpinner().equalsIgnoreCase("datetime") || SpinnerField.this.getSpinner().equalsIgnoreCase("date") || SpinnerField.this.getSpinner().equalsIgnoreCase("time")) {
                                        add = new BigDecimal(String.valueOf(SpinnerField.this.plusValue(string)));
                                    }
                                    if (SpinnerField.this.arrowAdd) {
                                        final Number n2 = (SpinnerField.this.getMaxValue() != null) ? SpinnerField.this.getMaxValue() : SpinnerField.this.MAX_VALUE();
                                        if (n.doubleValue() == n2.doubleValue()) {
                                            add = new BigDecimal(String.valueOf((SpinnerField.this.getMinValue() != null) ? SpinnerField.this.getMinValue() : SpinnerField.this.MIN_VALUE()));
                                        }
                                        else if (add.doubleValue() > n2.doubleValue()) {
                                            add = new BigDecimal(String.valueOf(n2));
                                        }
                                    }
                                    else {
                                        final Number n3 = (SpinnerField.this.getMinValue() != null) ? SpinnerField.this.getMinValue() : SpinnerField.this.MIN_VALUE();
                                        if (n.doubleValue() == n3.doubleValue()) {
                                            add = new BigDecimal(String.valueOf((SpinnerField.this.getMaxValue() != null) ? SpinnerField.this.getMaxValue() : SpinnerField.this.MAX_VALUE()));
                                        }
                                        else if (add.doubleValue() < n3.doubleValue()) {
                                            add = new BigDecimal(String.valueOf(n3));
                                        }
                                    }
                                    SpinnerField.this.setValue(SpinnerField.this.bigDecimalValueConver(add));
                                }
                            });
                            try {
                                Thread.sleep(150L);
                            }
                            catch (InterruptedException ex) {}
                        }
                        return null;
                    }
                };
            }
        };
        this.methods = new HashMap<String, String>() {
            private static final long serialVersionUID = 1L;
            
            {
                this.put("Integer", "intValue");
                this.put("Long", "longValue");
                this.put("Double", "doubleValue");
                this.put("Float", "floatValue");
                this.put("Short", "shortValue");
                this.put("Byte", "byteValue");
                this.put("yyyy", "plusYears");
                this.put("MM", "plusMonths");
                this.put("dd", "plusDays");
                this.put("HH", "plusHours");
                this.put("mm", "plusMinutes");
                this.put("ss", "plusSeconds");
            }
        };
        this.clazz = (Class<T>)((ParameterizedType)this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
        this.getStylesheets().add((Object)this.getClass().getResource("/javafx/control/resource/css/spinnerField.css").toExternalForm());
        this.setAlignment(Pos.CENTER_RIGHT);
        this.getStyleClass().add((Object)"spinner");
        this.setPrefSize(50.0, 20.0);
        this.initDefaultValue(t, t2, t3, t4, s, s2);
        this.defaultStringConverter();
        this.createTextField();
        this.createArrow();
        this.widthProperty().addListener((ChangeListener)new ChangeListener<Number>() {
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n2.doubleValue() < 50.0) {
                    SpinnerField.this.setPrefWidth(50.0);
                    return;
                }
                SpinnerField.this.arrowContainer.setPrefWidth(SpinnerField.this.prefHeightProperty().divide(2).add(10).doubleValue());
                SpinnerField.this.arrowContainer.setMaxWidth(SpinnerField.this.arrowContainer.getPrefWidth());
                SpinnerField.this.downArrow.setPrefWidth(SpinnerField.this.arrowContainer.getPrefWidth());
                SpinnerField.this.upArrow.setPrefWidth(SpinnerField.this.arrowContainer.getPrefWidth());
            }
        });
        this.heightProperty().addListener((ChangeListener)new ChangeListener<Number>() {
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                if (n2.doubleValue() < 20.0) {
                    SpinnerField.this.setPrefHeight(20.0);
                    return;
                }
                final BigDecimal bigDecimal = new BigDecimal(n2.doubleValue());
                final BigDecimal divide = bigDecimal.divide(new BigDecimal(2), 0, 4);
                final BigDecimal subtract = bigDecimal.subtract(divide);
                final double doubleValue = new BigDecimal(n2.doubleValue()).divide(new BigDecimal(8), 0, 4).doubleValue();
                SpinnerField.this.editer.setPrefHeight(n2.doubleValue());
                SpinnerField.this.editer.setPadding(new Insets(0.0, (double)SpinnerField.this.prefHeightProperty().divide(2).add(13).intValue(), 0.0, 3.0));
                SpinnerField.this.arrowContainer.setPrefHeight(n2.doubleValue());
                SpinnerField.this.upArrow.setPrefHeight(divide.doubleValue());
                SpinnerField.this.downArrow.setPrefHeight(subtract.doubleValue());
                SpinnerField.this.downPath.getElements().clear();
                SpinnerField.this.upPath.getElements().clear();
                SpinnerField.this.downPath.getElements().addAll((Object[])new PathElement[] { new MoveTo(-doubleValue, 0.0), new LineTo(doubleValue, 0.0), new LineTo(0.0, doubleValue), new LineTo(-doubleValue, 0.0) });
                SpinnerField.this.upPath.getElements().addAll((Object[])new PathElement[] { new MoveTo(-doubleValue, 0.0), new LineTo(doubleValue, 0.0), new LineTo(0.0, -doubleValue), new LineTo(-doubleValue, 0.0) });
            }
        });
        this.valueProperty().addListener((ChangeListener)new ChangeListener<T>() {
            public void changed(final ObservableValue<? extends T> observableValue, final T t, final T t2) {
                SpinnerField.this.getEditer().setText(SpinnerField.this.stringConverter.toString((Object)t2));
                if (SpinnerField.this.getSpinner().equalsIgnoreCase("datetime") || SpinnerField.this.getSpinner().equalsIgnoreCase("date") || SpinnerField.this.getSpinner().equalsIgnoreCase("time")) {
                    final Position position = (Position)((SpinnerField.this.editer.getUserData() != null) ? SpinnerField.this.editer.getUserData() : SpinnerField.this.pos[SpinnerField.this.pos.length - 1]);
                    SpinnerField.this.editer.selectRange(position.start, position.end);
                }
                else {
                    SpinnerField.this.editer.positionCaret(SpinnerField.this.editer.getLength());
                }
            }
        });
    }
    
    private void initDefaultValue(final T t, final T maxValue, final T minValue, final T t2, final String s, final String s2) {
        if ("number".equalsIgnoreCase(s)) {
            this.useNumberSpinner();
        }
        else if ("datetime".equalsIgnoreCase(s)) {
            this.useDateTimeSpinner((s2 != null) ? s2 : "yyyy-MM-dd HH:mm:ss");
        }
        else if ("date".equalsIgnoreCase(s)) {
            this.useDateSpinner((s2 != null) ? s2 : "yyyy-MM-dd");
        }
        else if ("time".equalsIgnoreCase(s)) {
            this.useTimeSpinner((s2 != null) ? s2 : "HH:mm:ss");
        }
        else {
            this.useNumberSpinner();
        }
        if (this.clazz.getSimpleName().equalsIgnoreCase("Integer") || this.clazz.getSimpleName().equalsIgnoreCase("Long") || this.clazz.getSimpleName().equalsIgnoreCase("Short") || this.clazz.getSimpleName().equalsIgnoreCase("Byte")) {
            this.setStep(this.valueOf((t2 != null) ? String.valueOf(t2) : "1", String.class));
        }
        else if (this.clazz.getSimpleName().equalsIgnoreCase("Double") || this.clazz.getSimpleName().equalsIgnoreCase("Float")) {
            this.setStep(this.valueOf((t2 != null) ? String.valueOf(t2) : "0.1", String.class));
        }
        if (this.getSpinner().equalsIgnoreCase("number")) {
            this.setValue(this.valueOf((t != null) ? String.valueOf(t) : "0", String.class));
        }
        else if (this.getSpinner().equalsIgnoreCase("datetime")) {
            this.setValue(this.valueOf((t != null) ? t.longValue() : LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), Long.TYPE));
        }
        else if (this.getSpinner().equalsIgnoreCase("date")) {
            this.setValue(this.valueOf((t != null) ? t.longValue() : LocalDate.now().toEpochDay(), Long.TYPE));
        }
        else if (this.getSpinner().equalsIgnoreCase("time")) {
            this.setValue(this.valueOf((t != null) ? t.longValue() : LocalTime.now().toSecondOfDay(), Long.TYPE));
        }
        if (maxValue != null) {
            this.setMaxValue(maxValue);
        }
        if (minValue != null) {
            this.setMinValue(minValue);
        }
    }
    
    private void parseDateTimePattern() {
        final Matcher matcher = Pattern.compile("(y+|M+|d+|H+|h+|K+|k+|m+|s+)").matcher(this.getPattern());
        final ArrayList<Position> list = new ArrayList<Position>();
        while (matcher.find()) {
            final Position position = new Position(null);
            position.start = matcher.start();
            position.end = matcher.end();
            position.pattern = matcher.group();
            list.add(position);
        }
        if (list.size() == 0) {
            throw new IllegalArgumentException("Time format is wrong! pattern:" + this.getPattern());
        }
        list.toArray(this.pos = new Position[list.size()]);
    }
    
    private void createTextField() {
        final ChangeListener<Boolean> changeListener = (ChangeListener<Boolean>)new ChangeListener<Boolean>() {
            public void changed(final ObservableValue<? extends Boolean> observableValue, final Boolean b, final Boolean b2) {
                if (b2) {
                    SpinnerField.this.editer.getStyleClass().add((Object)"arrow-button-focus");
                    SpinnerField.this.downBtn.getStyleClass().remove((Object)"arrow-button-fill");
                    SpinnerField.this.downBtn.getStyleClass().add((Object)"arrow-button-focus");
                    SpinnerField.this.upBtn.getStyleClass().remove((Object)"arrow-button-fill");
                    SpinnerField.this.upBtn.getStyleClass().add((Object)"arrow-button-focus");
                }
                else {
                    SpinnerField.this.editer.getStyleClass().remove((Object)"arrow-button-focus");
                    SpinnerField.this.downBtn.getStyleClass().remove((Object)"arrow-button-focus");
                    SpinnerField.this.downBtn.getStyleClass().add((Object)"arrow-button-fill");
                    SpinnerField.this.upBtn.getStyleClass().remove((Object)"arrow-button-focus");
                    SpinnerField.this.upBtn.getStyleClass().add((Object)"arrow-button-fill");
                }
            }
        };
        (this.editer = new NumberTextField<T>(this.stringConverter.toString(this.getValue()))).setPadding(new Insets(0.0, (double)this.prefHeightProperty().divide(2).add(13).intValue(), 0.0, 3.0));
        this.editer.setPrefHeight(this.getPrefHeight());
        if (this.getSpinner().equalsIgnoreCase("datetime") || this.getSpinner().equalsIgnoreCase("date") || this.getSpinner().equalsIgnoreCase("time")) {
            this.editer.setRegex("[^0-9\\:\\-]+");
            this.editer.setEditable(false);
            this.editer.editableProperty().addListener((ChangeListener)new ChangeListener<Boolean>() {
                public void changed(final ObservableValue<? extends Boolean> observableValue, final Boolean b, final Boolean b2) {
                    SpinnerField.this.editer.setEditable(false);
                }
            });
            this.editer.setUserData((Object)this.pos[this.pos.length - 1]);
            this.editer.focusedProperty().addListener((ChangeListener)new ChangeListener<Boolean>() {
                public void changed(final ObservableValue<? extends Boolean> observableValue, final Boolean b, final Boolean b2) {
                    if (b2) {
                        Platform.runLater((Runnable)new Runnable() {
                            @Override
                            public void run() {
                                final Position position = (Position)((SpinnerField.this.editer.getUserData() != null) ? SpinnerField.this.editer.getUserData() : SpinnerField.this.pos[SpinnerField.this.pos.length - 1]);
                                SpinnerField.this.editer.selectRange(position.start, position.end);
                            }
                        });
                    }
                }
            });
            this.editer.setOnMouseClicked((EventHandler)new EventHandler<MouseEvent>() {
                public void handle(final MouseEvent mouseEvent) {
                    Position userData = null;
                    final int caretPosition = SpinnerField.this.editer.getCaretPosition();
                    for (int i = 0; i < SpinnerField.this.pos.length; ++i) {
                        if (SpinnerField.this.pos[i].end >= caretPosition && SpinnerField.this.pos[i].start <= caretPosition) {
                            userData = SpinnerField.this.pos[i];
                            break;
                        }
                    }
                    if (userData != null) {
                        SpinnerField.this.editer.selectRange(userData.start, userData.end);
                        SpinnerField.this.editer.setUserData((Object)userData);
                    }
                }
            });
            this.editer.addEventHandler(KeyEvent.KEY_PRESSED, (EventHandler)new EventHandler<KeyEvent>() {
                public void handle(final KeyEvent keyEvent) {
                    if (keyEvent.getCode() == KeyCode.LEFT || keyEvent.getCode() == KeyCode.RIGHT) {
                        int index = ((Position)((SpinnerField.this.editer.getUserData() != null) ? SpinnerField.this.editer.getUserData() : SpinnerField.this.pos[SpinnerField.this.pos.length - 1])).indexOf(SpinnerField.this.pos);
                        if (keyEvent.getCode() == KeyCode.LEFT) {
                            if (index == 0) {
                                index = SpinnerField.this.pos.length - 1;
                            }
                            else {
                                --index;
                            }
                        }
                        else if (index == SpinnerField.this.pos.length - 1) {
                            index = 0;
                        }
                        else {
                            ++index;
                        }
                        Platform.runLater((Runnable)new Runnable() {
                            private final /* synthetic */ Position val$p2 = SpinnerField.this.pos[index];
                            
                            @Override
                            public void run() {
                                SpinnerField.this.editer.selectRange(this.val$p2.start, this.val$p2.end);
                                SpinnerField.this.editer.setUserData((Object)this.val$p2);
                            }
                        });
                    }
                }
            });
        }
        else if (this.clazz.getSimpleName().equals("Float") || this.clazz.getSimpleName().equals("Double")) {
            this.editer.setRegex("[^0-9\\.\\-]+");
        }
        this.editer.focusedProperty().addListener((ChangeListener)changeListener);
        this.editer.textProperty().addListener((ChangeListener)new ChangeListener<String>() {
            public void changed(final ObservableValue<? extends String> observableValue, final String s, String s2) {
                s2 = ((s2 == null || s2.equals("") || s2.equals("-") || s2.equals(".")) ? "0" : s2);
                SpinnerField.this.setValue((Number)SpinnerField.this.stringConverter.fromString(s2));
                SpinnerField.this.editer.setText(SpinnerField.this.stringConverter.toString(SpinnerField.this.getValue()));
            }
        });
        this.editer.setOnKeyPressed((EventHandler)new EventHandler<KeyEvent>() {
            public void handle(final KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.DOWN) {
                    SpinnerField.access$16(SpinnerField.this, false);
                    SpinnerField.this.arrowPressed();
                    keyEvent.consume();
                }
                else if (keyEvent.getCode() == KeyCode.UP) {
                    SpinnerField.access$16(SpinnerField.this, true);
                    SpinnerField.this.arrowPressed();
                    keyEvent.consume();
                }
            }
        });
        this.editer.setOnKeyReleased((EventHandler)new EventHandler<KeyEvent>() {
            public void handle(final KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.DOWN || keyEvent.getCode() == KeyCode.UP) {
                    SpinnerField.access$18(SpinnerField.this, false);
                }
            }
        });
        this.getChildren().add((Object)this.editer);
    }
    
    private void createArrow() {
        final BigDecimal bigDecimal = new BigDecimal(this.getPrefHeight());
        final BigDecimal divide = bigDecimal.divide(new BigDecimal(2), 0, 4);
        final BigDecimal subtract = bigDecimal.subtract(divide);
        final double doubleValue = new BigDecimal(this.getPrefHeight()).divide(new BigDecimal(8), 0, 4).doubleValue();
        (this.arrowContainer = new VBox()).setMouseTransparent(false);
        this.arrowContainer.setFocusTraversable(false);
        this.arrowContainer.setPrefHeight(this.getPrefHeight());
        this.arrowContainer.setPrefWidth(this.prefHeightProperty().divide(2).add(10).doubleValue());
        this.arrowContainer.setMaxWidth(this.arrowContainer.getPrefWidth());
        this.arrowContainer.setOnMousePressed((EventHandler)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                Platform.runLater((Runnable)new Runnable() {
                    @Override
                    public void run() {
                        SpinnerField.this.editer.requestFocus();
                    }
                });
            }
        });
        this.getChildren().add((Object)this.arrowContainer);
        this.upPath = new Path(new PathElement[] { new MoveTo(-doubleValue, 0.0), new LineTo(doubleValue, 0.0), new LineTo(0.0, -doubleValue), new LineTo(-doubleValue, 0.0) });
        this.upPath.getStyleClass().add((Object)"arrow");
        this.upPath.setMouseTransparent(true);
        this.upBtn = new StackPane();
        this.upBtn.getStyleClass().add((Object)"arrow-up-button");
        this.upBtn.getStyleClass().add((Object)"arrow-button-fill");
        (this.upArrow = new StackPane()).setPrefSize(this.arrowContainer.getPrefWidth(), divide.doubleValue());
        this.upArrow.getChildren().addAll((Object[])new Node[] { this.upBtn, this.upPath });
        this.upArrow.setOnMousePressed((EventHandler)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                SpinnerField.access$16(SpinnerField.this, true);
                SpinnerField.this.arrowPressed();
            }
        });
        this.upArrow.setOnMouseReleased((EventHandler)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                SpinnerField.access$18(SpinnerField.this, false);
            }
        });
        this.downPath = new Path(new PathElement[] { new MoveTo(-doubleValue, 0.0), new LineTo(doubleValue, 0.0), new LineTo(0.0, doubleValue), new LineTo(-doubleValue, 0.0) });
        this.downPath.getStyleClass().add((Object)"arrow");
        this.downPath.setMouseTransparent(true);
        this.downBtn = new StackPane();
        this.downBtn.getStyleClass().add((Object)"arrow-down-button");
        this.downBtn.getStyleClass().add((Object)"arrow-button-fill");
        (this.downArrow = new StackPane()).setPrefSize(this.arrowContainer.getPrefWidth(), subtract.doubleValue());
        this.downArrow.getChildren().addAll((Object[])new Node[] { this.downBtn, this.downPath });
        this.downArrow.setOnMousePressed((EventHandler)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                SpinnerField.access$16(SpinnerField.this, false);
                SpinnerField.this.arrowPressed();
            }
        });
        this.downArrow.setOnMouseReleased((EventHandler)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                SpinnerField.access$18(SpinnerField.this, false);
            }
        });
        this.arrowContainer.getChildren().addAll((Object[])new Node[] { this.upArrow, this.downArrow });
    }
    
    public void defaultStringConverter() {
        this.setStringConverter(new StringConverter<T>() {
            public T fromString(final String s) {
                Number n = null;
                if (s != null) {
                    if (SpinnerField.this.getSpinner().equalsIgnoreCase("number")) {
                        n = SpinnerField.this.valueOf(s, String.class);
                    }
                    else if (SpinnerField.this.getSpinner().equalsIgnoreCase("datetime")) {
                        n = LocalDateTime.parse(s, DateTimeFormatter.ofPattern(SpinnerField.this.getPattern())).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                    }
                    else if (SpinnerField.this.getSpinner().equalsIgnoreCase("date")) {
                        n = LocalDate.parse(s, DateTimeFormatter.ofPattern(SpinnerField.this.getPattern())).toEpochDay();
                    }
                    else if (SpinnerField.this.getSpinner().equalsIgnoreCase("time")) {
                        n = LocalTime.parse(s, DateTimeFormatter.ofPattern(SpinnerField.this.getPattern())).toSecondOfDay();
                    }
                }
                return (T)n;
            }
            
            public String toString(final T t) {
                String access$20 = "";
                if (t != null) {
                    if (SpinnerField.this.getSpinner().equalsIgnoreCase("number")) {
                        access$20 = SpinnerField.this.numberValueConver(t);
                    }
                    else {
                        if (SpinnerField.this.getSpinner().equalsIgnoreCase("datetime")) {
                            return LocalDateTime.ofInstant(Instant.ofEpochMilli(t.longValue()), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern(SpinnerField.this.getPattern()));
                        }
                        if (SpinnerField.this.getSpinner().equalsIgnoreCase("date")) {
                            return LocalDate.ofEpochDay(t.longValue()).format(DateTimeFormatter.ofPattern(SpinnerField.this.getPattern()));
                        }
                        if (SpinnerField.this.getSpinner().equalsIgnoreCase("time")) {
                            return LocalTime.ofSecondOfDay(t.longValue()).format(DateTimeFormatter.ofPattern(SpinnerField.this.getPattern()));
                        }
                    }
                }
                return access$20;
            }
        });
    }
    
    private void arrowPressed() {
        this.arrowPressed = true;
        if (!this.service.isRunning()) {
            this.service.cancel();
            this.service.reset();
            this.service.start();
        }
    }
    
    private T plusValue(final String s) {
        Number n = null;
        try {
            final String pattern = ((Position)this.editer.getUserData()).pattern;
            if (this.getSpinner().equalsIgnoreCase("datetime")) {
                n = ((LocalDateTime)LocalDateTime.class.getMethod(this.methods.get(((Position)this.editer.getUserData()).pattern), Long.TYPE).invoke(LocalDateTime.ofInstant(Instant.ofEpochMilli(this.getValue().longValue()), ZoneId.systemDefault()), Long.valueOf(this.getPattern().endsWith(pattern) ? s : (s.startsWith("-") ? "-1" : "1")))).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
            }
            else if (this.getSpinner().equalsIgnoreCase("date")) {
                n = ((LocalDate)LocalDate.class.getMethod(this.methods.get(((Position)this.editer.getUserData()).pattern), Long.TYPE).invoke(LocalDate.ofEpochDay(this.getValue().longValue()), Long.valueOf(this.getPattern().endsWith(pattern) ? s : (s.startsWith("-") ? "-1" : "1")))).toEpochDay();
            }
            else if (this.getSpinner().equalsIgnoreCase("time")) {
                n = ((LocalTime)LocalTime.class.getMethod(this.methods.get(((Position)this.editer.getUserData()).pattern), Long.TYPE).invoke(LocalTime.ofSecondOfDay(this.getValue().longValue()), Long.valueOf(this.getPattern().endsWith(pattern) ? s : (s.startsWith("-") ? "-1" : "1")))).toSecondOfDay();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return (T)n;
    }
    
    private T bigDecimalValueConver(final BigDecimal bigDecimal) {
        Number n = null;
        try {
            n = (Number)bigDecimal.getClass().getMethod(this.methods.get(this.clazz.getSimpleName()), (Class<?>[])new Class[0]).invoke(bigDecimal, new Object[0]);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return (T)n;
    }
    
    private String numberValueConver(final T t) {
        String value = null;
        try {
            value = String.valueOf(t.getClass().getMethod(this.methods.get(this.clazz.getSimpleName()), (Class<?>[])new Class[0]).invoke(t, new Object[0]));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return value;
    }
    
    private T MAX_VALUE() {
        try {
            return (T)this.clazz.getField("MAX_VALUE").get(this.clazz);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    private T MIN_VALUE() {
        Number n = null;
        try {
            if (this.clazz.getSimpleName().equals("Float")) {
                n = -this.MAX_VALUE().floatValue();
            }
            else if (this.clazz.getSimpleName().equals("Double")) {
                n = -this.MAX_VALUE().doubleValue();
            }
            else {
                n = (Number)this.clazz.getField("MIN_VALUE").get(this.clazz);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return (T)n;
    }
    
    private T valueOf(final Object o, final Class<?> clazz) {
        Number n = null;
        try {
            n = (Number)this.clazz.getMethod("valueOf", clazz).invoke(null, o);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return (T)n;
    }
    
    public void setPrefSize(final double n, final double n2) {
        super.setPrefSize(Math.max(n, 50.0), Math.max(n2, 20.0));
    }
    
    public void setValue(final T t) {
        if (t != null) {
            final Number n = (this.getMinValue() != null) ? this.getMinValue() : this.MIN_VALUE();
            final Number n2 = (this.getMaxValue() != null) ? this.getMaxValue() : this.MAX_VALUE();
            if (t.doubleValue() >= n.doubleValue() && t.doubleValue() <= n2.doubleValue()) {
                this.value.set((Object)t);
            }
            else if (t.doubleValue() < n.doubleValue()) {
                this.value.set((Object)n);
            }
            else if (t.doubleValue() > n2.doubleValue()) {
                this.value.set((Object)n2);
            }
        }
    }
    
    public T getValue() {
        return (T)this.value.get();
    }
    
    public T getStep() {
        return (T)this.step.get();
    }
    
    public void setStep(final T t) {
        this.step.set((Object)t);
    }
    
    public T getMaxValue() {
        return (T)this.max.get();
    }
    
    public void setMaxValue(final T value) {
        this.max.set((Object)value);
        if (value.doubleValue() < this.getValue().doubleValue()) {
            this.setValue(value);
        }
    }
    
    public T getMinValue() {
        return (T)this.min.get();
    }
    
    public void setMinValue(final T value) {
        if (((this.getMaxValue() != null) ? this.getMaxValue() : this.MAX_VALUE()).doubleValue() < value.doubleValue()) {
            throw new IllegalArgumentException("The minimum value must be smaller than the maximum.");
        }
        this.min.set((Object)value);
        if (value.doubleValue() > this.getValue().doubleValue()) {
            this.setValue(value);
        }
    }
    
    public void useNumberSpinner() {
        this.spinner.set((Object)"number");
    }
    
    public void useDateTimeSpinner() {
        this.spinner.set((Object)"datetime");
    }
    
    public void useDateSpinner() {
        this.spinner.set((Object)"date");
    }
    
    public void useTimeSpinner() {
        this.spinner.set((Object)"time");
    }
    
    public void useDateTimeSpinner(final String pattern) {
        if (pattern == null || pattern.trim().equals("")) {
            throw new NullPointerException();
        }
        this.spinner.set((Object)"datetime");
        this.setPattern(pattern);
    }
    
    public void useDateSpinner(final String pattern) {
        if (pattern == null || pattern.trim().equals("")) {
            throw new NullPointerException();
        }
        this.spinner.set((Object)"date");
        this.setPattern(pattern);
    }
    
    public void useTimeSpinner(final String pattern) {
        if (pattern == null || pattern.trim().equals("")) {
            throw new NullPointerException();
        }
        this.spinner.set((Object)"time");
        this.setPattern(pattern);
    }
    
    public void setPattern(final String s) {
        if (s == null || s.trim().equals("")) {
            throw new NullPointerException();
        }
        this.pattern.set((Object)s);
        if (this.getSpinner().equalsIgnoreCase("datetime") || this.getSpinner().equalsIgnoreCase("date") || this.getSpinner().equalsIgnoreCase("time")) {
            this.parseDateTimePattern();
            if (this.getValue() != null) {
                this.getEditer().setText(this.stringConverter.toString(this.getValue()));
            }
        }
    }
    
    public String getPattern() {
        return (String)this.pattern.get();
    }
    
    public String getSpinner() {
        return (String)this.spinner.get();
    }
    
    public ObjectProperty<T> valueProperty() {
        return this.value;
    }
    
    public TextField getEditer() {
        return this.editer;
    }
    
    public StringConverter<T> getStringConverter() {
        return this.stringConverter;
    }
    
    public void setStringConverter(final StringConverter<T> stringConverter) {
        this.stringConverter = stringConverter;
    }
    
    static /* synthetic */ void access$16(final SpinnerField spinnerField, final boolean arrowAdd) {
        spinnerField.arrowAdd = arrowAdd;
    }
    
    static /* synthetic */ void access$18(final SpinnerField spinnerField, final boolean arrowPressed) {
        spinnerField.arrowPressed = arrowPressed;
    }
    
    protected static class NumberTextField<T> extends TextField
    {
        private String regex;
        
        protected NumberTextField(final String s) {
            this(s, null, null);
        }
        
        protected NumberTextField(final String s, final T t, final T t2) {
            super(s);
            this.regex = "[^0-9\\-]+";
            this.setOnInputMethodTextChanged((EventHandler)this.inputMethodTextChanged());
        }
        
        public void replaceText(final int n, final int n2, String replaceAll) {
            if (!replaceAll.isEmpty()) {
                final Matcher matcher = Pattern.compile(this.regex).matcher(replaceAll);
                if (matcher.find()) {
                    replaceAll = matcher.replaceAll("");
                }
            }
            boolean b = false;
            boolean b2 = false;
            if (replaceAll.equals("-")) {
                b = true;
                replaceAll = "";
            }
            if (replaceAll.equals(".")) {
                b2 = true;
                replaceAll = "";
            }
            super.replaceText(n, n2, replaceAll);
            if (b && !this.getText().equals("0") && !this.getText().equals("0.0") && !this.getText().contains("-")) {
                final int caretPosition = this.getCaretPosition();
                this.setText("-" + this.getText());
                this.positionCaret(caretPosition + 1);
            }
            if (b2) {
                this.positionCaret(this.getText().indexOf(".") + 1);
            }
        }
        
        public void replaceSelection(final String s) {
            super.replaceSelection("");
        }
        
        private EventHandler<InputMethodEvent> inputMethodTextChanged() {
            return (EventHandler<InputMethodEvent>)new EventHandler<InputMethodEvent>() {
                public void handle(final InputMethodEvent inputMethodEvent) {
                    if (!inputMethodEvent.getCommitted().isEmpty()) {
                        final TextField textField = (TextField)inputMethodEvent.getSource();
                        textField.deleteText(textField.getSelection());
                        textField.insertText(textField.getCaretPosition(), inputMethodEvent.getCommitted());
                    }
                    else {
                        inputMethodEvent.consume();
                    }
                }
            };
        }
        
        public void setRegex(final String regex) {
            this.regex = regex;
        }
    }
    
    private static class Position
    {
        protected String pattern;
        protected int start;
        protected int end;
        
        @Override
        public boolean equals(final Object o) {
            return this.pattern.equals(((Position)o).pattern);
        }
        
        protected int indexOf(final Position[] array) {
            for (int i = 0; i < array.length; ++i) {
                if (array[i].equals(this)) {
                    return i;
                }
            }
            return array.length - 1;
        }
    }
}
