// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

import java.time.Instant;
import java.time.ZoneId;
import java.time.LocalDateTime;

public class SpinnerDateTimeField extends SpinnerField<Long>
{
    public SpinnerDateTimeField() {
        this(null, null, null, null, null);
    }
    
    public SpinnerDateTimeField(final Long n) {
        this(n, null, null, null, null);
    }
    
    public SpinnerDateTimeField(final Long n, final Long n2, final Long n3, final Long n4) {
        this(n, n2, n3, n4, null);
    }
    
    public SpinnerDateTimeField(final Long n, final Long n2, final Long n3, final Long n4, final String s) {
        super(n, n2, n3, n4, "datetime", s);
    }
    
    @Override
    public void setStep(final Long step) {
        super.setStep(step);
    }
    
    public void setMaxDateTime(final LocalDateTime localDateTime) {
        super.setMaxValue(localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
    }
    
    public LocalDateTime getMaxDateTime() {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(this.getMaxValue()), ZoneId.systemDefault());
    }
    
    public void setMinDateTime(final LocalDateTime localDateTime) {
        super.setMinValue(localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
    }
    
    public LocalDateTime getMinDateTime() {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(this.getMinValue()), ZoneId.systemDefault());
    }
    
    public LocalDateTime getDateTime() {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(this.getValue()), ZoneId.systemDefault());
    }
    
    public void setDateTime(final LocalDateTime localDateTime) {
        this.setValue(localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
    }
}
