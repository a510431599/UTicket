// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

public class SpinnerLongField extends SpinnerField<Long>
{
    public SpinnerLongField() {
        this(null, null, null, null);
    }
    
    public SpinnerLongField(final Long n) {
        this(n, null, null, null);
    }
    
    public SpinnerLongField(final Long n, final Long n2, final Long n3, final Long n4) {
        super(n, n2, n3, n4, "number", null);
    }
}
