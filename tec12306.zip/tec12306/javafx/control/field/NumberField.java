// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.BooleanProperty;

public class NumberField extends AbstractTextField
{
    private BooleanProperty negative;
    private BooleanProperty decimals;
    
    public NumberField() {
        this("");
    }
    
    public NumberField(final String s) {
        super(s);
        this.negative = (BooleanProperty)new SimpleBooleanProperty((Object)this, "negative", true);
        this.decimals = (BooleanProperty)new SimpleBooleanProperty((Object)this, "decimals", true);
        this.resetRegex();
    }
    
    public BooleanProperty negativeProperty() {
        return this.negative;
    }
    
    public BooleanProperty decimalsProperty() {
        return this.decimals;
    }
    
    public boolean getNegative() {
        return this.negative.get();
    }
    
    public void setNegative(final boolean b) {
        this.negative.set(b);
        this.resetRegex();
    }
    
    public boolean getDecimals() {
        return this.decimals.get();
    }
    
    public void setDecimals(final boolean b) {
        this.decimals.set(b);
        this.resetRegex();
    }
    
    private void resetRegex() {
        final StringBuilder sb = new StringBuilder();
        sb.append("[^0-9");
        if (this.getDecimals()) {
            sb.append("\\.");
        }
        if (this.getNegative()) {
            sb.append("\\-");
        }
        sb.append("]+");
        super.setRegex(sb.toString());
    }
}
