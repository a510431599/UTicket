// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

public class SpinnerByteField extends SpinnerField<Byte>
{
    public SpinnerByteField() {
        this(null, null, null, null);
    }
    
    public SpinnerByteField(final Byte b) {
        this(b, null, null, null);
    }
    
    public SpinnerByteField(final Byte b, final Byte b2, final Byte b3, final Byte b4) {
        super(b, b2, b3, b4, "number", null);
    }
}
