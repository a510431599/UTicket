// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

import javafx.event.Event;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.event.EventHandler;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.TextArea;

public class AbstractTextArea extends TextArea
{
    private StringProperty regex;
    private IntegerProperty maxLength;
    
    public AbstractTextArea() {
        this.regex = (StringProperty)new SimpleStringProperty((Object)this, "regex");
        this.maxLength = (IntegerProperty)new SimpleIntegerProperty((Object)this, "maxLength", 0);
        this.setOnInputMethodTextChanged((EventHandler)this.inputMethodTextChanged());
    }
    
    public AbstractTextArea(final String s) {
        super(s);
        this.regex = (StringProperty)new SimpleStringProperty((Object)this, "regex");
        this.maxLength = (IntegerProperty)new SimpleIntegerProperty((Object)this, "maxLength", 0);
        this.setOnInputMethodTextChanged((EventHandler)this.inputMethodTextChanged());
    }
    
    public void replaceText(final int n, final int n2, String s) {
        if (this.getMaxLength() > 0 && !s.isEmpty() && this.getText() != null && this.getText().length() >= this.getMaxLength() && (this.getSelectedText() == null || this.getSelectedText().length() == 0)) {
            return;
        }
        if (this.checkRegex() && !s.isEmpty()) {
            final Matcher matcher = Pattern.compile(this.getRegex()).matcher(s);
            if (matcher.find()) {
                s = matcher.replaceAll("");
            }
            s = s.toUpperCase();
            if (this.getMaxLength() > 0 && this.getLength() - ((this.getSelectedText() != null) ? this.getSelectedText() : "").length() + s.length() > this.getMaxLength()) {
                s = s.substring(0, this.getMaxLength() - this.getLength());
            }
        }
        super.replaceText(n, n2, s);
    }
    
    public void replaceSelection(String s) {
        final String s2 = (this.getText() != null) ? this.getText() : "";
        final String s3 = (this.getSelectedText() != null) ? this.getSelectedText() : "";
        if (this.getMaxLength() > 0 && !s.isEmpty() && s2.length() >= this.getMaxLength() && s3.length() == 0) {
            return;
        }
        if (this.checkRegex() && !s.isEmpty()) {
            final Matcher matcher = Pattern.compile(this.getRegex()).matcher(s);
            if (matcher.find()) {
                s = matcher.replaceAll("");
            }
            s = s.toUpperCase();
        }
        if (this.getMaxLength() > 0 && s.length() + s2.length() - s3.length() >= this.getMaxLength()) {
            s = s.substring(0, this.getMaxLength() - s2.length() + s3.length());
        }
        super.replaceSelection(s);
    }
    
    private EventHandler<InputMethodEvent> inputMethodTextChanged() {
        return (EventHandler<InputMethodEvent>)new EventHandler<InputMethodEvent>() {
            public void handle(final InputMethodEvent inputMethodEvent) {
                if (!inputMethodEvent.getCommitted().isEmpty()) {
                    final TextField textField = (TextField)inputMethodEvent.getSource();
                    textField.deleteText(textField.getSelection());
                    textField.insertText(textField.getCaretPosition(), inputMethodEvent.getCommitted());
                }
                else {
                    inputMethodEvent.consume();
                }
            }
        };
    }
    
    private boolean checkRegex() {
        return this.getRegex() != null && !this.getRegex().trim().equals("");
    }
    
    public void setRegex(final String s) {
        this.regex.set((Object)s);
    }
    
    public String getRegex() {
        return (String)this.regex.get();
    }
    
    public int getMaxLength() {
        return this.maxLength.get();
    }
    
    public void setMaxLength(final int n) {
        this.maxLength.set(n);
    }
    
    public IntegerProperty maxLengthProperty() {
        return this.maxLength;
    }
    
    public StringProperty regexProperty() {
        return this.regex;
    }
}
