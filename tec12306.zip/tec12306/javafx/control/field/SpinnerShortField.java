// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

public class SpinnerShortField extends SpinnerField<Short>
{
    public SpinnerShortField() {
        this(null, null, null, null);
    }
    
    public SpinnerShortField(final Short n) {
        this(n, null, null, null);
    }
    
    public SpinnerShortField(final Short n, final Short n2, final Short n3, final Short n4) {
        super(n, n2, n3, n4, "number", null);
    }
}
