// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

public class SpinnerFloatField extends SpinnerField<Float>
{
    public SpinnerFloatField() {
        this(null, null, null, null);
    }
    
    public SpinnerFloatField(final Float n) {
        this(n, null, null, null);
    }
    
    public SpinnerFloatField(final Float n, final Float n2, final Float n3, final Float n4) {
        super(n, n2, n3, n4, "number", null);
    }
}
