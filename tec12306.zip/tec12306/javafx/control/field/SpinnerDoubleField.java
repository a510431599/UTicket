// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.field;

public class SpinnerDoubleField extends SpinnerField<Double>
{
    public SpinnerDoubleField() {
        this(null, null, null, null);
    }
    
    public SpinnerDoubleField(final Double n) {
        this(n, null, null, null);
    }
    
    public SpinnerDoubleField(final Double n, final Double n2, final Double n3, final Double n4) {
        super(n, n2, n3, n4, "number", null);
    }
}
