// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control;

import javafx.collections.ObservableList;

public interface Provider<T>
{
    ObservableList<T> getSource();
}
