// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.dialog;

import javafx.concurrent.Task;
import javafx.application.Platform;
import javafx.concurrent.Service;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.Node;
import javafx.animation.FadeTransition;
import javafx.util.Duration;
import javafx.stage.WindowEvent;
import javafx.event.EventHandler;
import javafx.beans.value.ObservableNumberValue;
import javafx.geometry.Pos;
import javafx.stage.Window;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Popup;

public class Tooltips extends Popup
{
    private StackPane root;
    private Label message;
    private Window owner;
    private PopupMessageService service;
    private static Tooltips tooltip;
    
    public static void show(final Window window, final String s) {
        if (Tooltips.tooltip == null) {
            Tooltips.tooltip = new Tooltips();
        }
        Tooltips.tooltip.show(s, window);
    }
    
    private Tooltips() {
        this.root = new StackPane();
        this.message = new Label();
        this.owner = null;
        this.service = new PopupMessageService(this);
        this.setHideOnEscape(true);
        this.root.setStyle("-fx-font-family: 'Microsoft YaHei', 'SimHei', 'NSimSun', 'sans-serif';-fx-text-fill: #ffffff;-fx-font-size: 12;-fx-padding: 10 18;-fx-border-width:1;-fx-border-radius:5;-fx-max-width:350;-fx-border-color:#3a3e3f;-fx-font-weight: bold;-fx-background-radius:5;-fx-background-color:linear-gradient(from 0% 0% to 0% 100%, #818789, #3a3e3f 1%, #3a3e3f 99%, #818789 100%);-fx-effect: dropshadow(gaussian, #818789, 30, 0.3, 0, 0);");
        this.setOpacity(0.9);
        this.message.setStyle("-fx-text-fill: #ffffff;");
        this.message.setWrapText(true);
        this.message.setAlignment(Pos.BASELINE_CENTER);
        this.message.widthProperty().add((ObservableNumberValue)this.widthProperty());
        this.message.heightProperty().add((ObservableNumberValue)this.heightProperty());
        this.root.getChildren().add((Object)this.message);
        this.getContent().add((Object)this.root);
        this.setOnShown((EventHandler)new EventHandler<WindowEvent>() {
            public void handle(final WindowEvent windowEvent) {
                Tooltips.this.setX(Tooltips.this.owner.getX() + Tooltips.this.owner.getWidth() / 2.0 - Tooltips.this.getWidth() / 2.0);
                Tooltips.this.setY(Tooltips.this.owner.getY() + Tooltips.this.owner.getHeight() / 2.0 - Tooltips.this.getHeight() / 2.0);
                final FadeTransition fadeTransition = new FadeTransition(Duration.millis(300.0), (Node)Tooltips.this.root);
                fadeTransition.setFromValue(0.0);
                fadeTransition.setToValue(1.0);
                fadeTransition.play();
            }
        });
    }
    
    public void show(final String text, final Window owner) {
        this.owner = owner;
        this.message.setText(text);
        this.service.cancel();
        this.service.reset();
        this.service.start();
    }
    
    private void showMessage() {
        this.show(this.owner);
    }
    
    private void hideMessage() {
        final FadeTransition fadeTransition = new FadeTransition(Duration.millis(300.0), (Node)this.root);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.0);
        fadeTransition.play();
        fadeTransition.setOnFinished((EventHandler)new EventHandler<ActionEvent>() {
            public void handle(final ActionEvent actionEvent) {
                Tooltips.this.hide();
            }
        });
    }
    
    private static class PopupMessageService extends Service<Void>
    {
        private Tooltips popup;
        private long showtime;
        private boolean hideFlag;
        
        public PopupMessageService(final Tooltips popup) {
            this.popup = popup;
        }
        
        protected void scheduled() {
            super.scheduled();
            this.showtime = 2000L;
            if (!this.popup.isShowing()) {
                this.hideFlag = true;
                Platform.runLater((Runnable)new Runnable() {
                    @Override
                    public void run() {
                        PopupMessageService.this.popup.showMessage();
                    }
                });
            }
            else {
                this.hideFlag = false;
            }
        }
        
        protected Task<Void> createTask() {
            return new Task<Void>() {
                protected Void call() {
                    while ((PopupMessageService.this.showtime > 0L || PopupMessageService.this.popup.root.isHover()) && !this.isCancelled()) {
                        Thread.sleep(50L);
                        final PopupMessageService this$1 = PopupMessageService.this;
                        PopupMessageService.access$2(this$1, this$1.showtime - 50L);
                    }
                    if (PopupMessageService.this.hideFlag || !this.isCancelled()) {
                        Platform.runLater((Runnable)new Runnable() {
                            @Override
                            public void run() {
                                PopupMessageService.this.popup.hideMessage();
                            }
                        });
                    }
                    return null;
                }
            };
        }
        
        static /* synthetic */ void access$2(final PopupMessageService popupMessageService, final long showtime) {
            popupMessageService.showtime = showtime;
        }
    }
}
