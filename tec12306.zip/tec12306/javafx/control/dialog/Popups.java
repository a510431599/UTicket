// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.dialog;

import javafx.stage.Window;
import javafx.scene.Node;

public class Popups extends AbstractWindow
{
    private Popups() {
        this.modal();
    }
    
    public static Popups create() {
        return new Popups();
    }
    
    @Override
    public Popups title(final String s) {
        return (Popups)super.title(s);
    }
    
    public Popups size(final double n, final double n2) {
        this.setSize(n, n2);
        return this;
    }
    
    public Popups size(final double width) {
        this.setWidth(width);
        return this;
    }
    
    public Popups content(final Node content) {
        this.setContent(content);
        return this;
    }
    
    @Override
    public Popups owner(final Window window) {
        return (Popups)super.owner(window);
    }
}
