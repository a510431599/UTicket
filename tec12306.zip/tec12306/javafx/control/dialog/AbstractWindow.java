// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.dialog;

import javafx.stage.WindowEvent;
import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.stage.Window;
import javafx.stage.Modality;
import javafx.collections.ObservableMap;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.event.EventHandler;
import javafx.stage.StageStyle;
import javafx.scene.paint.Paint;
import javafx.scene.paint.Color;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.geometry.Pos;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.Priority;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.Node;
import javafx.geometry.Insets;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public abstract class AbstractWindow extends Stage
{
    private StackPane shadow;
    private StackPane titlePane;
    private Label titleLabel;
    private Label close;
    private VBox root;
    private StackPane body;
    private double offsetX;
    private double offsetY;
    private Object[] arguments;
    
    public AbstractWindow() {
        this.shadow = new StackPane();
        this.shadow.getStyleClass().add((Object)"dialog-root-shadow");
        StackPane.setMargin((Node)(this.root = new VBox()), new Insets(8.0));
        this.root.getStyleClass().add((Object)"dialog-root");
        this.shadow.getChildren().add((Object)this.root);
        final GridPane gridPane = new GridPane();
        gridPane.getStyleClass().add((Object)"dialog-title");
        final ColumnConstraints columnConstraints = new ColumnConstraints();
        columnConstraints.setHgrow(Priority.ALWAYS);
        columnConstraints.setFillWidth(true);
        final ColumnConstraints columnConstraints2 = new ColumnConstraints();
        columnConstraints.setMinWidth(28.0);
        columnConstraints.setPrefWidth(28.0);
        columnConstraints.setFillWidth(true);
        gridPane.getColumnConstraints().addAll((Object[])new ColumnConstraints[] { columnConstraints, columnConstraints2 });
        gridPane.getRowConstraints().add((Object)new RowConstraints());
        this.titleLabel = new Label();
        this.titleLabel.getStyleClass().add((Object)"dialog-title-text");
        this.close = new Label();
        this.close.getStyleClass().add((Object)"dialog-title-close");
        this.titlePane = new StackPane();
        this.titlePane.getChildren().add((Object)this.titleLabel);
        StackPane.setAlignment((Node)this.titleLabel, Pos.CENTER_LEFT);
        gridPane.add((Node)this.titlePane, 0, 0);
        gridPane.add((Node)this.close, 1, 0);
        this.body = new StackPane();
        this.body.getStyleClass().add((Object)"dialog-body");
        VBox.setVgrow((Node)this.body, Priority.ALWAYS);
        this.root.getChildren().addAll((Object[])new Node[] { gridPane, this.body });
        final Scene scene = new Scene((Parent)this.shadow);
        scene.getStylesheets().add((Object)"/javafx/control/resource/css/window.css");
        scene.setFill((Paint)Color.TRANSPARENT);
        this.initStyle(StageStyle.TRANSPARENT);
        this.setOnCloseRequest(windowEvent -> {
            windowEvent.consume();
            this.close();
        });
        this.setResizable(false);
        this.setScene(scene);
        this.titlePane.setOnMousePressed((EventHandler)this.handleTitlePaneMousePressed());
        this.titlePane.setOnMouseDragged((EventHandler)this.handleTitlePaneMouseDragged());
        this.close.setOnMouseClicked((EventHandler)this.handleWinCloseMouseClicked());
        final KeyCodeCombination keyCodeCombination = new KeyCodeCombination(KeyCode.ESCAPE, new KeyCombination.Modifier[0]);
        final KeyCodeCombination keyCodeCombination2 = new KeyCodeCombination(KeyCode.W, new KeyCombination.Modifier[] { KeyCombination.CONTROL_DOWN });
        final KeyCodeCombination keyCodeCombination3 = new KeyCodeCombination(KeyCode.F4, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final Runnable runnable = () -> this.close();
        final ObservableMap accelerators = scene.getAccelerators();
        accelerators.put((Object)keyCodeCombination, (Object)runnable);
        accelerators.put((Object)keyCodeCombination2, (Object)runnable);
        accelerators.put((Object)keyCodeCombination3, (Object)runnable);
    }
    
    public AbstractWindow modal() {
        this.initModality(Modality.WINDOW_MODAL);
        return this;
    }
    
    public void setSize(final double prefWidth, final double prefHeight) {
        this.root.setPrefWidth(prefWidth);
        this.root.setPrefHeight(prefHeight);
    }
    
    public void setPrefWidth(final double prefWidth) {
        this.root.setPrefWidth(prefWidth);
    }
    
    public void setPrefHeight(final double prefHeight) {
        this.root.setPrefHeight(prefHeight);
    }
    
    public AbstractWindow title(final String text) {
        this.titleLabel.setText(text);
        return this;
    }
    
    public AbstractWindow owner(final Window window) {
        this.initOwner(window);
        return this;
    }
    
    public void setContent(final Node node) {
        this.body.getChildren().clear();
        this.body.getChildren().add((Object)node);
        VBox.setVgrow(node, Priority.ALWAYS);
    }
    
    public VBox getRootNode() {
        return this.root;
    }
    
    private EventHandler<MouseEvent> handleTitlePaneMousePressed() {
        return (EventHandler<MouseEvent>)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                AbstractWindow.access$0(AbstractWindow.this, mouseEvent.getSceneX());
                AbstractWindow.access$1(AbstractWindow.this, mouseEvent.getSceneY());
            }
        };
    }
    
    private EventHandler<MouseEvent> handleTitlePaneMouseDragged() {
        return (EventHandler<MouseEvent>)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                final AbstractWindow abstractWindow = (AbstractWindow)AbstractWindow.this.shadow.getScene().getWindow();
                abstractWindow.setX(mouseEvent.getScreenX() - AbstractWindow.this.offsetX);
                abstractWindow.setY(mouseEvent.getScreenY() - AbstractWindow.this.offsetY);
            }
        };
    }
    
    private EventHandler<MouseEvent> handleWinCloseMouseClicked() {
        return (EventHandler<MouseEvent>)new EventHandler<MouseEvent>() {
            public void handle(final MouseEvent mouseEvent) {
                ((AbstractWindow)AbstractWindow.this.shadow.getScene().getWindow()).close();
            }
        };
    }
    
    public AbstractWindow setArguments(final Object... arguments) {
        this.arguments = arguments;
        return this;
    }
    
    public <T> T getArgument(final int n) {
        if (this.arguments == null || this.arguments.length <= n) {
            return null;
        }
        return (T)this.arguments[n];
    }
    
    static /* synthetic */ void access$0(final AbstractWindow abstractWindow, final double offsetX) {
        abstractWindow.offsetX = offsetX;
    }
    
    static /* synthetic */ void access$1(final AbstractWindow abstractWindow, final double offsetY) {
        abstractWindow.offsetY = offsetY;
    }
}
