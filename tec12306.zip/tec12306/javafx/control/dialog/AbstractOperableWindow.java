// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.dialog;

import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.geometry.Pos;
import javafx.scene.layout.HBox;

public abstract class AbstractOperableWindow extends AbstractWindow
{
    private HBox bottom;
    
    public AbstractOperableWindow() {
        (this.bottom = new HBox()).setFillHeight(false);
        this.bottom.setSpacing(10.0);
        this.bottom.getStyleClass().add((Object)"dialog-bottom");
        this.bottom.setAlignment(Pos.CENTER_RIGHT);
        this.getRootNode().getChildren().add((Object)this.bottom);
    }
    
    @Override
    public void setSize(final double n, final double n2) {
        super.setSize(n, n2 + 70.0);
    }
    
    @Override
    public void setPrefWidth(final double prefWidth) {
        super.setPrefWidth(prefWidth);
    }
    
    @Override
    public void setPrefHeight(final double n) {
        super.setPrefHeight(n + 70.0);
    }
    
    public void removeBottomChildren(final Node node) {
        this.bottom.getChildren().remove((Object)node);
    }
    
    public void setBottomChildren(final Node... array) {
        for (int i = 0; i < array.length; ++i) {
            this.bottom.getChildren().add(i, (Object)array[i]);
        }
    }
    
    public ObservableList<Node> getBottomChildren() {
        return (ObservableList<Node>)this.bottom.getChildren();
    }
}
