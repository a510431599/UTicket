// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.dialog;

import javafx.animation.Animation;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.stage.Window;
import javafx.scene.input.Mnemonic;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.animation.Timeline;
import javafx.scene.control.Button;

public class Dialogs extends AbstractOperableWindow
{
    private static final String CONFIRM_STYLE = "dialog-graphic-confirm";
    private static final String ALERT_STYLE = "dialog-graphic-alert";
    public static final int ACTION_CANCEL = 0;
    public static final int ACTION_OK = 1;
    private DialogsController controller;
    private Button ok;
    private Button cancel;
    public Integer actionReturn;
    private Timeline time;
    private Runnable callable;
    private static Dialogs old;
    
    static {
        Dialogs.old = null;
    }
    
    public Dialogs() {
        this.controller = null;
        this.actionReturn = 0;
        this.time = null;
        this.ok = new Button("\u786e\u5b9a(O)");
        this.ok.getStyleClass().add((Object)"dialog-action-button");
        this.cancel = new Button("\u5173\u95ed(C)");
        this.cancel.getStyleClass().add((Object)"dialog-action-button");
        this.cancel.setOnAction(actionEvent -> this.close());
        this.setBottomChildren(this.ok, this.cancel);
        this.setSize(350.0, 92.0);
        Object content = null;
        try {
            final FXMLLoader fxmlLoader = new FXMLLoader(Dialogs.class.getResource("/javafx/control/resource/fxml/dialog.fxml"));
            content = fxmlLoader.load();
            this.controller = (DialogsController)fxmlLoader.getController();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        this.modal();
        this.setConfirmHander((EventHandler<ActionEvent>)new EventHandler<ActionEvent>() {
            public void handle(final ActionEvent actionEvent) {
                Dialogs.this.actionReturn = 1;
                Dialogs.this.close();
                if (Dialogs.this.callable != null) {
                    Dialogs.this.callable.run();
                }
            }
        });
        this.setCancelHander((EventHandler<ActionEvent>)new EventHandler<ActionEvent>() {
            public void handle(final ActionEvent actionEvent) {
                Dialogs.this.actionReturn = 0;
                Dialogs.this.close();
            }
        });
        this.setContent((Node)content);
        final KeyCodeCombination keyCodeCombination = new KeyCodeCombination(KeyCode.C, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final KeyCodeCombination keyCodeCombination2 = new KeyCodeCombination(KeyCode.O, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final KeyCodeCombination keyCodeCombination3 = new KeyCodeCombination(KeyCode.ENTER, new KeyCombination.Modifier[0]);
        this.getScene().addMnemonic(new Mnemonic((Node)this.cancel, (KeyCombination)keyCodeCombination));
        this.getScene().addMnemonic(new Mnemonic((Node)this.ok, (KeyCombination)keyCodeCombination2));
        this.getScene().getAccelerators().put((Object)keyCodeCombination3, () -> {
            if (this.ok.isFocused()) {
                this.ok.fire();
            }
            else if (this.cancel.isFocused()) {
                this.cancel.fire();
            }
        });
    }
    
    public static Dialogs create() {
        return new Dialogs();
    }
    
    @Override
    public Dialogs owner(final Window window) {
        this.initOwner(window);
        return this;
    }
    
    public Dialogs hideOldWindow() {
        if (Dialogs.old != null) {
            Dialogs.old.close();
        }
        return Dialogs.old = this;
    }
    
    public Dialogs autoHide(final int n) {
        this.time = new Timeline(new KeyFrame[] { new KeyFrame(Duration.millis((double)n), (EventHandler)new EventHandler<ActionEvent>() {
                public void handle(final ActionEvent actionEvent) {
                    Dialogs.this.close();
                }
            }, new KeyValue[0]) });
        return this;
    }
    
    @Override
    public Dialogs title(final String s) {
        return (Dialogs)super.title(s);
    }
    
    public Dialogs message(final String text) {
        this.controller.contentLabel.setText(text);
        return this;
    }
    
    public int confirmAndWait() {
        this.confirm(true);
        return this.actionReturn;
    }
    
    public void confirm() {
        this.confirm(false);
    }
    
    public void confirm(final Runnable callable) {
        this.callable = callable;
        this.confirm(false);
    }
    
    private void confirm(final boolean b) {
        this.controller.graphicLabel.getStyleClass().clear();
        this.controller.graphicLabel.getStyleClass().add((Object)"dialog-graphic-confirm");
        this.showing(b);
    }
    
    public void alertAndWait() {
        this.alert(true);
    }
    
    public void alert(final Runnable callable) {
        this.callable = callable;
        this.alert(false);
    }
    
    public void alert() {
        this.alert(false);
    }
    
    private void alert(final boolean b) {
        this.controller.graphicLabel.getStyleClass().clear();
        this.controller.graphicLabel.getStyleClass().add((Object)"dialog-graphic-alert");
        this.removeBottomChildren((Node)this.cancel);
        this.showing(b);
    }
    
    public void close() {
        this.hideBefore();
        super.close();
    }
    
    private void showing(final boolean b) {
        this.showBefore();
        if (b) {
            this.showAndWait();
        }
        else {
            this.show();
        }
    }
    
    private void showBefore() {
        if (this.time != null) {
            this.time.play();
        }
    }
    
    private void hideBefore() {
        if (this.time != null && this.time.getStatus().equals((Object)Animation.Status.RUNNING)) {
            this.time.stop();
        }
        if (this.callable != null && !this.getBottomChildren().contains((Object)this.cancel)) {
            this.callable.run();
        }
    }
    
    private void setConfirmHander(final EventHandler<ActionEvent> onAction) {
        this.showConfirmButton();
        this.ok.setOnAction((EventHandler)onAction);
    }
    
    private void setCancelHander(final EventHandler<ActionEvent> onAction) {
        this.cancel.setOnAction((EventHandler)onAction);
    }
    
    private void showConfirmButton() {
        if (!this.getBottomChildren().contains((Object)this.ok)) {
            this.getBottomChildren().add(this.getBottomChildren().size() - 1, (Object)this.ok);
        }
    }
}
