// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.dialog;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.layout.GridPane;
import javafx.controller.AbstractController;

public class DialogsController extends AbstractController
{
    @FXML
    GridPane root;
    @FXML
    Label graphicLabel;
    @FXML
    Label contentLabel;
    
    @Override
    public void initialize() {
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
}
