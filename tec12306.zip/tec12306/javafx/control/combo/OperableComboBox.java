// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.combo;

import java.util.List;
import javafx.event.EventTarget;
import javafx.scene.text.Text;
import javafx.scene.Parent;
import javafx.event.EventDispatchChain;
import com.sun.javafx.scene.control.skin.ComboBoxListViewSkin;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.geometry.HPos;
import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.layout.Priority;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.Node;
import javafx.scene.control.ContentDisplay;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import javafx.event.EventDispatcher;
import javafx.control.bean.SelectedProperty;

public class OperableComboBox<T extends SelectedProperty> extends CompleteComboBox<T>
{
    private EventDispatcher dispatcher;
    private Handler<T> handler;
    private String buttonStyle;
    private Callback<ListView<T>, ListCell<T>> RIGHTBUTTON_FACTORY;
    
    public OperableComboBox() {
        this(FXCollections.observableArrayList());
    }
    
    public OperableComboBox(final ObservableList<T> list) {
        super(list);
        this.dispatcher = null;
        this.handler = null;
        this.buttonStyle = null;
        this.RIGHTBUTTON_FACTORY = (Callback<ListView<T>, ListCell<T>>)new Callback<ListView<T>, ListCell<T>>() {
            public ListCell<T> call(final ListView<T> listView) {
                return new ListCell<T>() {
                    private final /* synthetic */ ListView val$param = listView;
                    
                    protected void updateItem(final T t, final boolean b) {
                        super.updateItem((Object)t, b);
                        this.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                        this.setPrefHeight(Math.max(OperableComboBox.this.getFixedCellSize(), this.val$param.getFixedCellSize()));
                        if (b) {
                            this.setGraphic((Node)null);
                        }
                        else {
                            final GridPane graphic = new GridPane();
                            final Label label = new Label(t.getItemDisplayText());
                            label.prefHeight(this.getPrefHeight());
                            GridPane.setHgrow((Node)label, Priority.ALWAYS);
                            GridPane.setVgrow((Node)label, Priority.ALWAYS);
                            GridPane.setValignment((Node)label, VPos.CENTER);
                            final Label label2 = new Label();
                            label2.getStyleClass().add((Object)"operate");
                            if (OperableComboBox.this.buttonStyle != null && !OperableComboBox.this.buttonStyle.isEmpty()) {
                                label2.getStyleClass().add((Object)OperableComboBox.this.buttonStyle);
                            }
                            else {
                                label2.getStyleClass().add((Object)"default-operate");
                            }
                            label2.prefHeight(this.getPrefHeight());
                            label2.setAlignment(Pos.BASELINE_CENTER);
                            label2.setOnMouseClicked((EventHandler)new EventHandler<MouseEvent>() {
                                public void handle(final MouseEvent mouseEvent) {
                                    if (OperableComboBox.this.handler != null) {
                                        OperableComboBox.this.handler.call(OperableComboBox.this, OperableComboBox.this.getOptions(), (SelectedProperty)ListCell.this.getItem());
                                    }
                                }
                            });
                            GridPane.setVgrow((Node)label2, Priority.ALWAYS);
                            GridPane.setValignment((Node)label2, VPos.CENTER);
                            GridPane.setHalignment((Node)label2, HPos.CENTER);
                            graphic.add((Node)label, 0, 0);
                            graphic.add((Node)label2, 1, 0);
                            this.setGraphic((Node)graphic);
                        }
                    }
                };
            }
        };
        this.getStylesheets().add((Object)"/javafx/control/resource/css/comboBox.css");
        this.skinProperty().addListener((InvalidationListener)new InvalidationListener() {
            public void invalidated(final Observable observable) {
                final ListView listView = ((ComboBoxListViewSkin)OperableComboBox.this.getSkin()).getListView();
                OperableComboBox.access$2(OperableComboBox.this, listView.getEventDispatcher());
                OperableComboBox.this.updateEventDispatcher(listView);
            }
        });
    }
    
    public void setOnHandler(final Handler<T> handler) {
        this.handler = handler;
    }
    
    public void setButtonStyle(final String buttonStyle) {
        this.buttonStyle = buttonStyle;
    }
    
    private void updateEventDispatcher(final ListView<T> listView) {
        this.setCellFactory((Callback)this.RIGHTBUTTON_FACTORY);
        listView.setEventDispatcher((EventDispatcher)new EventDispatcher() {
            public Event dispatchEvent(Event dispatchEvent, final EventDispatchChain eventDispatchChain) {
                if (dispatchEvent.getEventType().equals(MouseEvent.MOUSE_RELEASED) || dispatchEvent.getEventType().equals(MouseEvent.MOUSE_PRESSED)) {
                    final EventTarget target = dispatchEvent.getTarget();
                    if (target instanceof Parent) {
                        if (((List)((Parent)target).getStyleClass()).contains("operate")) {
                            dispatchEvent.consume();
                            return null;
                        }
                    }
                    else if (target instanceof Text) {
                        final Parent parent = ((Text)target).getParent();
                        if (parent != null && ((List)parent.getStyleClass()).contains("operate")) {
                            dispatchEvent.consume();
                            return null;
                        }
                    }
                }
                return dispatchEvent = OperableComboBox.this.dispatcher.dispatchEvent(dispatchEvent, eventDispatchChain);
            }
        });
    }
    
    static /* synthetic */ void access$2(final OperableComboBox operableComboBox, final EventDispatcher dispatcher) {
        operableComboBox.dispatcher = dispatcher;
    }
    
    public interface Handler<T extends SelectedProperty>
    {
        void call(final OperableComboBox<T> p0, final ObservableList<T> p1, final T p2);
    }
}
