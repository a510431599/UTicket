// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.combo;

import java.util.Iterator;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;
import java.util.regex.Pattern;
import javafx.scene.control.ListView;
import com.sun.javafx.scene.control.skin.ComboBoxListViewSkin;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import java.util.Collection;
import javafx.collections.FXCollections;
import javafx.util.StringConverter;
import javafx.collections.ListChangeListener;
import javafx.beans.property.StringProperty;
import javafx.beans.property.BooleanProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.ComboBox;
import javafx.control.bean.SelectedProperty;

public class CompleteComboBox<T extends SelectedProperty> extends ComboBox<T>
{
    private ObjectProperty<ObservableList<T>> options;
    private BooleanProperty showOnFocus;
    private StringProperty textStyle;
    private StringProperty textFilter;
    private String oldValue;
    private String newValue;
    private double fixedCellSize;
    private boolean enabled;
    public static final String UPPERCASE = "UPPERCASE";
    public static final String LOWERCASE = "LOWERCASE";
    public static final String DEFAULT = "DEFAULT";
    private final ListChangeListener<T> listChangeListener;
    private StringConverter<T> stringConverter;
    
    public CompleteComboBox() {
        this(FXCollections.observableArrayList());
    }
    
    public CompleteComboBox(ObservableList<T> observableArrayList) {
        super((observableArrayList == null) ? FXCollections.observableArrayList() : FXCollections.observableArrayList((Collection)observableArrayList));
        this.options = (ObjectProperty<ObservableList<T>>)new SimpleObjectProperty<ObservableList<T>>((Object)this, "options") {
            protected void invalidated() {
                super.invalidated();
                ((ObservableList)this.get()).addListener(CompleteComboBox.this.listChangeListener);
            }
        };
        this.showOnFocus = (BooleanProperty)new SimpleBooleanProperty((Object)this, "showOnFocus", false);
        this.textStyle = (StringProperty)new SimpleStringProperty((Object)this, "textStyle", "DEFAULT");
        this.textFilter = (StringProperty)new SimpleStringProperty((Object)this, "textFilter");
        final String s = "";
        this.oldValue = s;
        this.newValue = s;
        this.fixedCellSize = 25.0;
        this.enabled = true;
        this.listChangeListener = (ListChangeListener<T>)new ListChangeListener<T>() {
            public void onChanged(final ListChangeListener.Change<? extends T> change) {
                if (change.next() && change.wasRemoved()) {
                    final List removed = change.getRemoved();
                    for (int i = 0; i < change.getRemovedSize(); ++i) {
                        removed.get(i).setChecked(false);
                    }
                    CompleteComboBox.this.getItems().removeAll((Collection)removed);
                }
            }
        };
        this.stringConverter = new StringConverter<T>() {
            public T fromString(final String s) {
                final SelectedProperty selectedProperty = null;
                if (s != null && !s.isEmpty()) {
                    for (int i = 0; i < CompleteComboBox.this.getItems().size(); ++i) {
                        if (((SelectedProperty)CompleteComboBox.this.getItems().get(i)).isEquals(s)) {
                            return (T)CompleteComboBox.this.getItems().get(i);
                        }
                    }
                }
                return (T)selectedProperty;
            }
            
            public String toString(final T t) {
                if (t != null) {
                    return t.getItemDisplayText();
                }
                return "";
            }
        };
        if (observableArrayList == null) {
            observableArrayList = FXCollections.observableArrayList();
        }
        this.options.set((Object)observableArrayList);
        this.setEditable(true);
        this.getEditor().setOnInputMethodTextChanged((EventHandler)this.inputMethodTextChanged());
        this.setConverter((StringConverter)this.stringConverter);
        this.getEditor().addEventHandler(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            if (!this.isShowOnFocus() && this.getItems() != null && !this.getItems().isEmpty()) {
                this.show();
            }
        });
        this.getEditor().focusedProperty().addListener((ChangeListener)new ChangeListener<Boolean>() {
            public void changed(final ObservableValue<? extends Boolean> observableValue, final Boolean b, final Boolean b2) {
                if (b2 && CompleteComboBox.this.isShowOnFocus() && CompleteComboBox.this.getItems() != null && !CompleteComboBox.this.getItems().isEmpty()) {
                    CompleteComboBox.this.show();
                }
            }
        });
        this.optionsProperty().addListener((ChangeListener)new ChangeListener<ObservableList<T>>() {
            public void changed(final ObservableValue<? extends ObservableList<T>> observableValue, final ObservableList<T> list, final ObservableList<T> list2) {
                if (list2 == null) {
                    CompleteComboBox.this.setItems(FXCollections.observableArrayList());
                }
                else {
                    CompleteComboBox.this.setItems(FXCollections.observableArrayList((Collection)list2));
                }
            }
        });
        this.skinProperty().addListener((InvalidationListener)new InvalidationListener() {
            public void invalidated(final Observable observable) {
                final ListView listView = ((ComboBoxListViewSkin)CompleteComboBox.this.getSkin()).getListView();
                listView.setFixedCellSize(Math.max(CompleteComboBox.this.getFixedCellSize(), listView.getFixedCellSize()));
            }
        });
        this.getEditor().textProperty().addListener((ChangeListener)new ChangeListener<String>() {
            public void changed(final ObservableValue<? extends String> observableValue, final String s, final String s2) {
                final SelectedProperty selectedProperty = (SelectedProperty)CompleteComboBox.this.getSelectionModel().getSelectedItem();
                if (selectedProperty != null && selectedProperty.getItemDisplayText().equals(s2)) {
                    ((StringProperty)observableValue).set((Object)selectedProperty.getItemValue());
                    return;
                }
                if (CompleteComboBox.this.getTextFilter() != null && !CompleteComboBox.this.getTextFilter().equals("")) {
                    final StringProperty stringProperty = (StringProperty)observableValue;
                    String replaceAll = Pattern.compile(CompleteComboBox.this.getTextFilter()).matcher(s2).replaceAll("");
                    if (!"DEFAULT".equals(CompleteComboBox.this.getTextStyle())) {
                        replaceAll = ("UPPERCASE".equals(CompleteComboBox.this.getTextStyle()) ? replaceAll.toUpperCase() : replaceAll.toLowerCase());
                    }
                    if (!replaceAll.equals(s2)) {
                        stringProperty.set((Object)replaceAll);
                        return;
                    }
                }
                else if (!"DEFAULT".equals(CompleteComboBox.this.getTextStyle())) {
                    final StringProperty stringProperty2 = (StringProperty)observableValue;
                    final String s3 = "UPPERCASE".equals(CompleteComboBox.this.getTextStyle()) ? s2.toUpperCase() : s2.toLowerCase();
                    if (!s3.equals(s2)) {
                        stringProperty2.set((Object)s3);
                        return;
                    }
                }
                if (CompleteComboBox.this.enabled && !CompleteComboBox.this.getOptions().isEmpty()) {
                    CompleteComboBox.access$2(CompleteComboBox.this, s);
                    CompleteComboBox.access$3(CompleteComboBox.this, s2);
                    CompleteComboBox.this.autocomplete(CompleteComboBox.this, CompleteComboBox.this.getItems(), CompleteComboBox.this.oldValue, CompleteComboBox.this.newValue);
                }
            }
        });
        this.armedProperty().addListener((ChangeListener)new ChangeListener<Boolean>() {
            public void changed(final ObservableValue<? extends Boolean> observableValue, final Boolean b, final Boolean b2) {
                CompleteComboBox.this.getEditor().positionCaret(CompleteComboBox.this.getEditor().getLength());
            }
        });
        this.getSelectionModel().selectedItemProperty().addListener((ChangeListener)new ChangeListener<T>() {
            public void changed(final ObservableValue<? extends T> observableValue, final T t, final T t2) {
                if (t2 != null) {
                    CompleteComboBox.this.getEditor().positionCaret(CompleteComboBox.this.getEditor().getLength());
                }
            }
        });
    }
    
    public ObservableList<T> getOptions() {
        return (ObservableList<T>)this.options.get();
    }
    
    public void setOptions(final ObservableList<T> list) {
        this.options.set((Object)list);
    }
    
    public ObjectProperty<ObservableList<T>> optionsProperty() {
        return this.options;
    }
    
    public boolean isShowOnFocus() {
        return this.showOnFocus.get();
    }
    
    public void setShowOnFocus(final boolean b) {
        this.showOnFocus.set(b);
    }
    
    private EventHandler<InputMethodEvent> inputMethodTextChanged() {
        return (EventHandler<InputMethodEvent>)new EventHandler<InputMethodEvent>() {
            public void handle(final InputMethodEvent inputMethodEvent) {
                if (!inputMethodEvent.getCommitted().isEmpty()) {
                    TextField editor = null;
                    if (inputMethodEvent.getSource() instanceof ComboBox) {
                        editor = ((ComboBox)inputMethodEvent.getSource()).getEditor();
                    }
                    else if (inputMethodEvent.getSource() instanceof TextField) {
                        editor = (TextField)inputMethodEvent.getSource();
                    }
                    if (editor != null) {
                        editor.deleteText(editor.getSelection());
                        editor.insertText(editor.getCaretPosition(), inputMethodEvent.getCommitted());
                    }
                }
                else {
                    ComboBox comboBox = null;
                    if (inputMethodEvent.getSource() instanceof ComboBox) {
                        comboBox = (ComboBox)inputMethodEvent.getSource();
                    }
                    else if (inputMethodEvent.getSource() instanceof TextField) {
                        comboBox = (ComboBox)((TextField)inputMethodEvent.getSource()).getParent();
                    }
                    if (comboBox != null && comboBox.isShowing()) {
                        comboBox.hide();
                    }
                    inputMethodEvent.consume();
                }
            }
        };
    }
    
    public StringConverter<T> getStringConverter() {
        return this.stringConverter;
    }
    
    private void autocomplete(final ComboBox<T> comboBox, final ObservableList<T> list, final String s, final String text) {
        final SelectedProperty selectedProperty = (SelectedProperty)comboBox.getSelectionModel().getSelectedItem();
        if (selectedProperty == null || !selectedProperty.isEquals(text)) {
            if (text.isEmpty() && !s.isEmpty()) {
                this.enabled = false;
                list.clear();
                comboBox.getSelectionModel().clearSelection();
                comboBox.setValue((Object)null);
                comboBox.getEditor().setText(text);
                this.enabled = true;
                list.addAll((Collection)this.getOptions());
                if (list.isEmpty()) {
                    comboBox.hide();
                }
                else {
                    Platform.runLater(() -> comboBox.show());
                }
            }
            else if (text.startsWith(s)) {
                this.enabled = false;
                comboBox.getSelectionModel().clearSelection();
                comboBox.setValue((Object)null);
                comboBox.getEditor().setText(text);
                for (int i = list.size() - 1; i > -1; --i) {
                    if (!((SelectedProperty)list.get(i)).matcher(text)) {
                        list.remove(i);
                    }
                }
                this.enabled = true;
                if (list.isEmpty()) {
                    comboBox.hide();
                }
                else {
                    Platform.runLater(() -> comboBox.show());
                }
            }
            else if (!text.equals(s)) {
                this.enabled = false;
                list.clear();
                comboBox.getSelectionModel().clearSelection();
                comboBox.setValue((Object)null);
                comboBox.getEditor().setText(text);
                this.enabled = true;
                for (final SelectedProperty selectedProperty2 : this.getOptions()) {
                    if (selectedProperty2.matcher(text)) {
                        list.add((Object)selectedProperty2);
                    }
                }
                if (list.isEmpty()) {
                    comboBox.hide();
                }
                else {
                    Platform.runLater(() -> comboBox.show());
                }
            }
        }
    }
    
    public void setFixedCellSize(final double fixedCellSize) {
        this.fixedCellSize = fixedCellSize;
    }
    
    public double getFixedCellSize() {
        return this.fixedCellSize;
    }
    
    public void setCompleteValue(final T value) {
        this.enabled = false;
        this.getItems().clear();
        if (value == null) {
            this.getItems().addAll((Collection)this.getOptions());
        }
        else {
            for (final SelectedProperty selectedProperty : this.getOptions()) {
                if (selectedProperty.matcher(value.getItemValue())) {
                    this.getItems().add((Object)selectedProperty);
                }
            }
            this.getSelectionModel().select((Object)value);
        }
        this.setValue((Object)value);
        this.enabled = true;
    }
    
    public void removeItem(final T t) {
        final SelectedProperty value = (SelectedProperty)this.getValue();
        this.enabled = false;
        if (t.equals(value)) {
            this.setValue((Object)null);
            this.getSelectionModel().clearSelection();
            this.getOptions().remove((Object)t);
        }
        else {
            this.getOptions().remove((Object)t);
            this.setValue((Object)value);
        }
        this.enabled = true;
    }
    
    public void addItem(final T t) {
        this.getOptions().add((Object)t);
    }
    
    public void addItem(final int n, final T t) {
        this.getOptions().add(n, (Object)t);
    }
    
    public void setCompleteValue(final String text) {
        this.enabled = false;
        this.getItems().clear();
        Object value = null;
        if (text == null) {
            this.getItems().addAll((Collection)this.getOptions());
            this.setValue((Object)null);
        }
        else {
            for (final SelectedProperty selectedProperty : this.getOptions()) {
                if (selectedProperty.matcher(text)) {
                    if (selectedProperty.isEquals(text)) {
                        value = selectedProperty;
                    }
                    this.getItems().add((Object)selectedProperty);
                }
            }
            if (value != null) {
                this.getSelectionModel().select(value);
                this.setValue(value);
            }
            else {
                this.getEditor().setText(text);
            }
        }
        this.enabled = true;
    }
    
    public void setOneValue(final String text) {
        this.enabled = false;
        this.getItems().clear();
        Object value = null;
        if (text == null) {
            this.getItems().addAll((Collection)this.getOptions());
            this.setValue((Object)null);
        }
        else {
            for (final SelectedProperty selectedProperty : this.getOptions()) {
                if (selectedProperty.isEquals(text)) {
                    value = selectedProperty;
                    this.getItems().add((Object)selectedProperty);
                    break;
                }
            }
            if (value != null) {
                this.getSelectionModel().select(value);
                this.setValue(value);
            }
            else {
                this.getEditor().setText(text);
            }
        }
        this.enabled = true;
    }
    
    public void setTextFilter(final String s) {
        this.textFilter.set((Object)s);
    }
    
    public String getTextFilter() {
        return (String)this.textFilter.get();
    }
    
    public StringProperty textFilterProperty() {
        return this.textFilter;
    }
    
    public void setTextStyle(final String s) {
        this.textStyle.set((Object)s);
    }
    
    public String getTextStyle() {
        return (String)this.textStyle.get();
    }
    
    public StringProperty textStyleProperty() {
        return this.textStyle;
    }
    
    static /* synthetic */ void access$2(final CompleteComboBox completeComboBox, final String oldValue) {
        completeComboBox.oldValue = oldValue;
    }
    
    static /* synthetic */ void access$3(final CompleteComboBox completeComboBox, final String newValue) {
        completeComboBox.newValue = newValue;
    }
}
