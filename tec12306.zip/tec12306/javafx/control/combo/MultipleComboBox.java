// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.combo;

import java.util.List;
import javafx.event.EventTarget;
import javafx.scene.text.Text;
import javafx.scene.Parent;
import javafx.event.EventDispatchChain;
import javafx.beans.property.Property;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import com.sun.javafx.scene.control.skin.ComboBoxListViewSkin;
import javafx.beans.property.BooleanProperty;
import javafx.scene.control.CheckBox;
import javafx.beans.Observable;
import javafx.beans.InvalidationListener;
import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.util.StringConverter;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import javafx.control.Cascade;
import javafx.event.EventDispatcher;
import javafx.beans.property.IntegerProperty;
import javafx.control.Provider;
import javafx.control.bean.SelectedProperty;

public class MultipleComboBox<T extends SelectedProperty> extends CompleteComboBox<T> implements Provider<T>
{
    private IntegerProperty maxSize;
    private EventDispatcher dispatcher;
    private IntegerProperty checked;
    private Cascade<T> cascade;
    private boolean init;
    private Callback<ListView<T>, ListCell<T>> CHECKBOXLISTCELL_FACTORY;
    private Callback<T, ObservableValue<Boolean>> checkedProperty;
    
    public MultipleComboBox() {
        this(FXCollections.observableArrayList());
    }
    
    public MultipleComboBox(final ObservableList<T> list) {
        super(list);
        this.maxSize = (IntegerProperty)new SimpleIntegerProperty((Object)this, "maxSize", 0);
        this.dispatcher = null;
        this.checked = (IntegerProperty)new SimpleIntegerProperty((Object)this, "checked", 0);
        this.cascade = null;
        this.init = false;
        this.CHECKBOXLISTCELL_FACTORY = (Callback<ListView<T>, ListCell<T>>)new Callback<ListView<T>, ListCell<T>>() {
            final /* synthetic */ MultipleComboBox this$0;
            
            public ListCell<T> call(final ListView<T> listView) {
                return (ListCell<T>)new CheckBoxListCell<T>() {
                    final /* synthetic */ MultipleComboBox$1 this$1;
                    
                    {
                        this.setPrefHeight(Math.max(((MultipleComboBox$1)Callback.this).this$0.getFixedCellSize(), listView.getFixedCellSize()));
                        this.setOnMouseClicked((EventHandler)new EventHandler<MouseEvent>() {
                            final /* synthetic */ MultipleComboBox$1$1 this$2 = MultipleComboBox.this.checkedProperty;
                            
                            public void handle(final MouseEvent mouseEvent) {
                                this.this$2.this$1.this$0.setChecked((SelectedProperty)this.this$2.getItem());
                            }
                        });
                        this.skinProperty().addListener((InvalidationListener)new InvalidationListener() {
                            final /* synthetic */ MultipleComboBox$1$1 this$2 = MultipleComboBox.this.checkedProperty;
                            
                            public void invalidated(final Observable observable) {
                                if (this.this$2.getGraphic() != null && this.this$2.getGraphic() instanceof CheckBox) {
                                    ((CheckBox)this.this$2.getGraphic()).setOnMouseClicked((EventHandler)new EventHandler<MouseEvent>() {
                                        public void handle(final MouseEvent mouseEvent) {
                                            InvalidationListener.this.this$2.this$1.this$0.setChecked((SelectedProperty)InvalidationListener.this.this$2.getItem());
                                        }
                                    });
                                }
                            }
                        });
                    }
                };
            }
        };
        this.checkedProperty = (Callback<T, ObservableValue<Boolean>>)new Callback<T, ObservableValue<Boolean>>() {
            public BooleanProperty call(final T t) {
                return t.checkedProperty();
            }
        };
        this.skinProperty().addListener((InvalidationListener)new InvalidationListener() {
            public void invalidated(final Observable observable) {
                final ListView listView = ((ComboBoxListViewSkin)MultipleComboBox.this.getSkin()).getListView();
                listView.addEventFilter(KeyEvent.KEY_PRESSED, (EventHandler)new EventHandler<KeyEvent>() {
                    public void handle(final KeyEvent keyEvent) {
                        if (MultipleComboBox.this.isShowing() && keyEvent.getCode().equals((Object)KeyCode.ENTER)) {
                            final SelectedProperty checked = (SelectedProperty)MultipleComboBox.this.getSelectionModel().getSelectedItem();
                            if (checked != null) {
                                MultipleComboBox.this.setChecked(checked);
                            }
                            else {
                                keyEvent.consume();
                            }
                        }
                    }
                });
                MultipleComboBox.access$1(MultipleComboBox.this, listView.getEventDispatcher());
                MultipleComboBox.this.updateEventDispatcher(listView);
            }
        });
        this.optionsProperty().addListener((ChangeListener)new ChangeListener<ObservableList<T>>() {
            public void changed(final ObservableValue<? extends ObservableList<T>> observableValue, final ObservableList<T> list, final ObservableList<T> list2) {
                MultipleComboBox.access$4(MultipleComboBox.this, MultipleComboBox.this.cascade != null);
                for (int i = 0; i < MultipleComboBox.this.getOptions().size(); ++i) {
                    if (((SelectedProperty)MultipleComboBox.this.getOptions().get(i)).isChecked()) {
                        if (MultipleComboBox.this.maxSize.get() > 0 && MultipleComboBox.this.checked.get() >= MultipleComboBox.this.maxSize.get()) {
                            ((SelectedProperty)MultipleComboBox.this.getOptions().get(i)).setChecked(false);
                        }
                        else if (MultipleComboBox.this.init) {
                            if (!MultipleComboBox.this.cascade.getItems().contains(MultipleComboBox.this.getOptions().get(i))) {
                                MultipleComboBox.this.cascade.add((SelectedProperty)MultipleComboBox.this.getOptions().get(i));
                            }
                        }
                        else {
                            MultipleComboBox.this.checked.set(MultipleComboBox.this.checked.get() + 1);
                        }
                    }
                }
            }
        });
    }
    
    public void bind(final Cascade<T> cascade) {
        (this.cascade = cascade).setProvider(this);
        this.cascade.removeAll();
        this.checkedProperty().set(0);
        Bindings.bindBidirectional((Property)this.cascade.maxSizeProperty(), (Property)this.maxSize);
        Bindings.bindBidirectional((Property)this.cascade.checkedProperty(), (Property)this.checked);
        if (!this.init) {
            for (int i = 0; i < this.getItems().size(); ++i) {
                if (this.maxSize.get() > 0 && this.checked.get() >= this.maxSize.get()) {
                    ((SelectedProperty)this.getOptions().get(i)).setChecked(false);
                }
                else if (((SelectedProperty)this.getItems().get(i)).isChecked()) {
                    this.cascade.add((T)this.getItems().get(i));
                }
            }
        }
    }
    
    public void unbind() {
        this.cascade.setProvider(null);
        Bindings.unbindBidirectional((Property)this.cascade.maxSizeProperty(), (Property)this.maxSize);
        Bindings.unbindBidirectional((Property)this.cascade.checkedProperty(), (Property)this.checked);
    }
    
    public void setChecked(final T t) {
        t.setChecked(!t.isChecked());
        if (t.isChecked()) {
            if (this.getMaxSize() > 0 && this.getCheckedSize() >= this.getMaxSize()) {
                t.setChecked(false);
            }
            else if (this.cascade != null) {
                this.cascade.add(t);
            }
            else {
                this.checked.set(this.checked.get() + 1);
            }
        }
        else if (this.cascade == null) {
            this.checked.set(Math.max(0, this.checked.subtract(1).intValue()));
        }
        else {
            this.cascade.remove(t);
        }
    }
    
    private void updateEventDispatcher(final ListView<T> listView) {
        this.setCellFactory((Callback)this.CHECKBOXLISTCELL_FACTORY);
        listView.setEventDispatcher((EventDispatcher)new EventDispatcher() {
            public Event dispatchEvent(Event event, final EventDispatchChain eventDispatchChain) {
                if (event.getEventType().equals(MouseEvent.MOUSE_RELEASED) || event.getEventType().equals(MouseEvent.MOUSE_PRESSED)) {
                    final EventTarget target = event.getTarget();
                    if (target instanceof Parent) {
                        final ObservableList styleClass = ((Parent)target).getStyleClass();
                        if (((List)styleClass).contains("thumb") || ((List)styleClass).contains("track") || ((List)styleClass).contains("decrement-arrow") || ((List)styleClass).contains("increment-arrow")) {
                            return event = MultipleComboBox.this.dispatcher.dispatchEvent(event, eventDispatchChain);
                        }
                        event.consume();
                        return null;
                    }
                    else if (target instanceof Text) {
                        event.consume();
                        return null;
                    }
                }
                return event = MultipleComboBox.this.dispatcher.dispatchEvent(event, eventDispatchChain);
            }
        });
    }
    
    public IntegerProperty checkedProperty() {
        return this.checked;
    }
    
    public int getCheckedSize() {
        return this.checked.get();
    }
    
    public IntegerProperty maxSizeProperty() {
        return this.maxSize;
    }
    
    public int getMaxSize() {
        return this.maxSize.get();
    }
    
    public void setMaxSize(final int n) {
        this.maxSize.set(n);
    }
    
    @Override
    public ObservableList<T> getSource() {
        return this.getOptions();
    }
    
    static /* synthetic */ void access$1(final MultipleComboBox multipleComboBox, final EventDispatcher dispatcher) {
        multipleComboBox.dispatcher = dispatcher;
    }
    
    static /* synthetic */ void access$4(final MultipleComboBox multipleComboBox, final boolean init) {
        multipleComboBox.init = init;
    }
}
