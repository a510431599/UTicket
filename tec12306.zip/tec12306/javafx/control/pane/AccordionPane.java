// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane;

import javafx.scene.Node;
import javafx.scene.control.Skin;
import javafx.control.pane.skin.TitledPaneSkin;
import javafx.scene.control.TitledPane;

public class AccordionPane extends TitledPane
{
    public AccordionPane() {
        this.setSkin((Skin)new TitledPaneSkin(this));
    }
    
    public AccordionPane(final String s, final Node node) {
        this.setSkin((Skin)new TitledPaneSkin(this));
    }
}
