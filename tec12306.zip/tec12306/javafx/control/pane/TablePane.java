// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane;

import javafx.scene.control.TableCell;
import javafx.beans.binding.DoubleBinding;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.util.Callback;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.beans.value.ObservableNumberValue;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TableColumn;
import java.math.BigDecimal;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;

public class TablePane<T> extends TableView<T>
{
    private ObservableList<Column<T>> columns;
    
    public TablePane() {
        this((ObservableList)null, FXCollections.observableArrayList());
    }
    
    public TablePane(final ObservableList<Column<T>> list) {
        this((ObservableList)list, FXCollections.observableArrayList());
    }
    
    public TablePane(final ObservableList<Column<T>> tableColumn, final ObservableList<T> list) {
        super((ObservableList)list);
        this.getStylesheets().add((Object)"/javafx/control/resource/css/table.css");
        if (tableColumn != null) {
            this.setTableColumn(tableColumn);
        }
        this.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        this.widthProperty().addListener((observableValue, n, n2) -> {
            final ObservableList columns = this.getColumns();
            if (columns != null && !columns.isEmpty()) {
                final TableColumn tableColumn = (TableColumn)columns.get(columns.size() - 1);
                tableColumn.prefWidthProperty().unbind();
                DoubleBinding doubleBinding = this.widthProperty().add(0);
                for (int i = 0; i < columns.size() - 1; ++i) {
                    doubleBinding = doubleBinding.subtract((ObservableNumberValue)((TableColumn)columns.get(i)).prefWidthProperty());
                }
                if (((Stage)this.getScene().getWindow()).isMaximized()) {
                    tableColumn.prefWidthProperty().bind((ObservableValue)doubleBinding.subtract(3.35));
                }
                else {
                    tableColumn.prefWidthProperty().bind((ObservableValue)doubleBinding.subtract(3.75));
                }
            }
        });
    }
    
    public void setPlaceholder(final String s) {
        this.setPlaceholder((Node)new Label(s));
    }
    
    public void setTableColumn(final ObservableList<Column<T>> columns) {
        this.getColumns().clear();
        this.columns = columns;
        BigDecimal bigDecimal = BigDecimal.valueOf(0L);
        final BigDecimal bigDecimal2 = new BigDecimal(1000);
        for (int i = 0; i < columns.size(); ++i) {
            bigDecimal = bigDecimal.add(new BigDecimal(((Column)columns.get(i)).getWidth()).multiply(bigDecimal2).setScale(0, 4));
        }
        BigDecimal bigDecimal3 = BigDecimal.ZERO;
        for (int j = 0; j < columns.size(); ++j) {
            final BigDecimal setScale = new BigDecimal(((Column)columns.get(j)).getWidth()).multiply(bigDecimal2).setScale(0, 4);
            if (j != columns.size() - 1) {
                bigDecimal3 = bigDecimal3.add(setScale);
            }
            final TableColumn tableColumn = new TableColumn();
            if (j != columns.size() - 1) {
                tableColumn.prefWidthProperty().bind((ObservableValue)this.widthProperty().multiply(setScale.longValue()).divide(bigDecimal.longValue()));
            }
            else {
                tableColumn.prefWidthProperty().bind((ObservableValue)this.widthProperty().subtract((ObservableNumberValue)this.widthProperty().multiply(bigDecimal3.longValue()).divide(bigDecimal.longValue())).subtract(3.75));
            }
            tableColumn.setText(((Column)columns.get(j)).getText());
            tableColumn.setEditable(((Column)columns.get(j)).isEditable());
            tableColumn.setSortable(((Column)columns.get(j)).isSortable());
            tableColumn.setResizable(((Column)columns.get(j)).isResizable());
            final Pos align = ((Column)columns.get(j)).getAlign();
            final TableCellFactory tableCellFactory = ((Column)columns.get(j)).getTableCellFactory();
            if (tableCellFactory != null || align != null) {
                tableColumn.setCellFactory(tableColumn -> {
                    TableCell call = null;
                    if (tableCellFactory != null) {
                        call = tableCellFactory.call();
                    }
                    if (call == null) {
                        call = new TableCell<T, String>() {
                            protected void updateItem(final String text, final boolean b) {
                                super.updateItem((Object)text, b);
                                this.setText(text);
                            }
                        };
                    }
                    if (align != null) {
                        call.setAlignment(align);
                    }
                    return call;
                });
            }
            tableColumn.setCellValueFactory((Callback)new PropertyValueFactory(((Column)columns.get(j)).getField()));
            this.getColumns().add((Object)tableColumn);
        }
    }
    
    public void setCellFactory(final int n, final TableCellFactory<T> tableCellFactory) {
        ((TableColumn)this.getColumns().get(n)).setCellFactory(tableColumn -> {
            final TableCell call = tableCellFactory.call();
            if (((Column)this.columns.get(n)).getAlign() != null) {
                call.setAlignment(((Column)this.columns.get(n)).getAlign());
            }
            return call;
        });
    }
    
    public static class Column<T>
    {
        private String text;
        private String field;
        private double width;
        private Pos align;
        private TableCellFactory<T> tableCellFactory;
        private boolean resizable;
        private boolean sortable;
        private boolean editable;
        
        public Column() {
            this.resizable = false;
            this.sortable = false;
            this.editable = false;
        }
        
        public String getText() {
            return this.text;
        }
        
        public void setText(final String text) {
            this.text = text;
        }
        
        public String getField() {
            return this.field;
        }
        
        public void setField(final String field) {
            this.field = field;
        }
        
        public double getWidth() {
            return this.width;
        }
        
        public void setWidth(final double width) {
            this.width = width;
        }
        
        public Pos getAlign() {
            return this.align;
        }
        
        public void setAlign(final Pos align) {
            this.align = align;
        }
        
        public boolean isResizable() {
            return this.resizable;
        }
        
        public void setResizable(final boolean resizable) {
            this.resizable = resizable;
        }
        
        public boolean isSortable() {
            return this.sortable;
        }
        
        public void setSortable(final boolean sortable) {
            this.sortable = sortable;
        }
        
        public boolean isEditable() {
            return this.editable;
        }
        
        public void setEditable(final boolean editable) {
            this.editable = editable;
        }
        
        public TableCellFactory<T> getTableCellFactory() {
            return this.tableCellFactory;
        }
        
        public void setTableCellFactory(final TableCellFactory<T> tableCellFactory) {
            this.tableCellFactory = tableCellFactory;
        }
    }
    
    public interface TableCellFactory<T>
    {
        TableCell<T, String> call();
    }
}
