// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane;

import javafx.util.StringConverter;
import javafx.scene.input.MouseEvent;
import javafx.beans.Observable;
import java.math.BigDecimal;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.InvalidationListener;
import javafx.scene.layout.HBox;
import javafx.scene.control.ScrollPane;
import javafx.beans.property.DoubleProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.scene.layout.StackPane;

public class Scrollbar<T> extends StackPane
{
    private IntegerProperty active;
    private IntegerProperty step;
    private StringProperty itemCls;
    private StringProperty activeCls;
    private ObjectProperty<ObservableList<T>> items;
    private DoubleProperty itemWidth;
    private ObjectProperty<ScrollbarConverter<T>> converter;
    private ScrollPane scrollPane;
    private HBox hbox;
    private StackPane _active;
    private InvalidationListener il;
    private EventHandler<T> eventHandler;
    private ScrollbarConverter<T> defaultConverter;
    
    public Scrollbar() {
        this(null);
    }
    
    public Scrollbar(final ObservableList<T> items) {
        this.active = (IntegerProperty)new SimpleIntegerProperty((Object)this, "active");
        this.step = (IntegerProperty)new SimpleIntegerProperty((Object)this, "step", 1);
        this.itemCls = (StringProperty)new SimpleStringProperty((Object)this, "itemCls", "item");
        this.activeCls = (StringProperty)new SimpleStringProperty((Object)this, "activeCls", "item-active");
        this.items = (ObjectProperty<ObservableList<T>>)new SimpleObjectProperty((Object)this, "items", (Object)FXCollections.observableArrayList());
        this.itemWidth = (DoubleProperty)new SimpleDoubleProperty((Object)this, "itemWidth", 100.0);
        this.converter = (ObjectProperty<ScrollbarConverter<T>>)new SimpleObjectProperty((Object)this, "converter", (Object)null);
        this.scrollPane = new ScrollPane();
        this.hbox = new HBox();
        this.defaultConverter = new ScrollbarConverter<T>() {
            public String toString(final T t) {
                if (t != null) {
                    return t.toString();
                }
                return "";
            }
        };
        this.getStylesheets().addAll((Object[])new String[] { "/javafx/control/resource/css/scrollbar.css", "/javafx/control/resource/css/scrollPane.css" });
        this.getStyleClass().add((Object)"scrollbar");
        this.scrollPane.getStyleClass().add((Object)"custom-scroll");
        this.scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        this.scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        this.scrollPane.setFocusTraversable(false);
        this.scrollPane.setHmax(1.0);
        this.scrollPane.setContent((Node)this.hbox);
        this.scrollPane.setFitToHeight(true);
        this.scrollPane.setMinHeight(0.0);
        this.getChildren().add((Object)this.scrollPane);
        this.setItems(items);
    }
    
    public void setActive(final T t) {
        final int index = this.getItems().indexOf((Object)t);
        if (index != -1) {
            this.setActive(index);
        }
    }
    
    public void setActive(final int n) {
        this.activeProperty().set(Math.max(Math.min(n, this.getItems().size() - 1), 0));
        if (this.scrollPane.getScene() != null) {
            this.scrollTo(this.getActive());
        }
        else {
            this.il = (observable -> {
                this.scrollTo(this.getActive());
                this.widthProperty().removeListener(this.il);
                this.il = null;
            });
            this.widthProperty().addListener(this.il);
        }
    }
    
    public int getActive() {
        return this.activeProperty().get();
    }
    
    public IntegerProperty activeProperty() {
        return this.active;
    }
    
    public int getStep() {
        return this.stepProperty().get();
    }
    
    public void setStep(final int n) {
        this.stepProperty().set(n);
    }
    
    public IntegerProperty stepProperty() {
        return this.step;
    }
    
    public String getItemCls() {
        return (String)this.itemClsProperty().get();
    }
    
    public void setItemCls(final String s) {
        this.itemClsProperty().set((Object)s);
    }
    
    public StringProperty itemClsProperty() {
        return this.itemCls;
    }
    
    public String getActiveCls() {
        return (String)this.activeClsProperty().get();
    }
    
    public void setActiveCls(final String s) {
        this.activeClsProperty().set((Object)s);
    }
    
    public StringProperty activeClsProperty() {
        return this.activeCls;
    }
    
    public ObservableList<T> getItems() {
        return (ObservableList<T>)this.items.get();
    }
    
    public void setItems(final ObservableList<T> list) {
        this.hbox.getChildren().clear();
        this._active = null;
        this.items.set((Object)list);
        if (list != null) {
            for (int i = 0; i < list.size(); ++i) {
                final StackPane stackPane = new StackPane();
                stackPane.maxWidthProperty().bind((ObservableValue)this.itemWidthProperty());
                stackPane.minWidthProperty().bind((ObservableValue)this.itemWidthProperty());
                if (this.getItemCls() != null && !this.getItemCls().equals("")) {
                    stackPane.getStyleClass().add((Object)this.getItemCls());
                }
                if (i == 0) {
                    stackPane.getStyleClass().add((Object)"item-first");
                }
                final Label label = new Label(this.getConverter().toString(list.get(i)));
                label.setAlignment(Pos.CENTER);
                stackPane.getChildren().add((Object)label);
                this.hbox.getChildren().add((Object)stackPane);
                stackPane.setOnMouseClicked(mouseEvent -> {
                    final int index = this.hbox.getChildren().indexOf(mouseEvent.getSource());
                    this.setActive(index);
                    if (this.eventHandler != null) {
                        this.eventHandler.handler(index, (T)this.getItems().get(index));
                    }
                });
            }
        }
    }
    
    public void setOnItemClicked(final EventHandler<T> eventHandler) {
        this.eventHandler = eventHandler;
    }
    
    public final ObjectProperty<ObservableList<T>> itemsProperty() {
        return this.items;
    }
    
    public double getItemWidth() {
        return this.itemWidth.get();
    }
    
    public void setItemWidth(final double n) {
        this.itemWidth.set(n);
    }
    
    public final DoubleProperty itemWidthProperty() {
        return this.itemWidth;
    }
    
    private void scrollTo(int n) {
        if (n != ((this._active != null) ? this.hbox.getChildren().indexOf((Object)this._active) : -1)) {
            final boolean b = this.getActiveCls() != null && !this.getActiveCls().equals("");
            if (b && this._active != null) {
                this._active.getStyleClass().remove((Object)this.getActiveCls());
            }
            this._active = (StackPane)this.hbox.getChildren().get(n);
            if (b) {
                this._active.getStyleClass().add((Object)this.getActiveCls());
            }
            final double width = this.scrollPane.getViewportBounds().getWidth();
            final double n2 = this.hbox.getBoundsInLocal().getWidth() - width;
            if (n2 <= 0.0) {
                return;
            }
            ++n;
            final int n3 = (int)(width / this.getItemWidth());
            final int intValue = new BigDecimal(this.scrollPane.getHvalue()).multiply(new BigDecimal(n2)).divide(new BigDecimal(this.getItemWidth()), 0, 4).intValue();
            final double doubleValue = new BigDecimal(this.getItemWidth()).divide(new BigDecimal(n2), 6, 4).doubleValue();
            final int n4 = 1;
            if (n - n4 - 1 <= intValue) {
                this.scrollPane.setHvalue(Math.max(this.scrollPane.getHvalue() - (intValue - n + n4 + 2) * doubleValue, 0.0));
            }
            else if (n - intValue >= n3 - n4) {
                this.scrollPane.setHvalue(Math.min(this.scrollPane.getHvalue() + (n - intValue - n3 + n4 + 1) * doubleValue, 1.0));
            }
        }
    }
    
    public final ObjectProperty<ScrollbarConverter<T>> converterProperty() {
        return this.converter;
    }
    
    public final void setConverter(final ScrollbarConverter<T> scrollbarConverter) {
        this.converterProperty().set((Object)scrollbarConverter);
    }
    
    public final ScrollbarConverter<T> getConverter() {
        final ScrollbarConverter scrollbarConverter = (ScrollbarConverter)this.converterProperty().get();
        if (scrollbarConverter != null) {
            return (ScrollbarConverter<T>)scrollbarConverter;
        }
        return this.defaultConverter;
    }
    
    public interface EventHandler<T>
    {
        void handler(final int p0, final T p1);
    }
    
    public abstract static class ScrollbarConverter<T> extends StringConverter<T>
    {
        public T fromString(final String s) {
            return null;
        }
    }
}
