// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane;

import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.HBox;
import javafx.geometry.Insets;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.control.Provider;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.control.Cascade;
import javafx.scene.layout.StackPane;
import javafx.control.bean.SelectedProperty;

public class TagBox<T extends SelectedProperty> extends StackPane implements Cascade<T>
{
    private IntegerProperty checked;
    private BooleanProperty allowClick;
    private IntegerProperty maxSize;
    private StringProperty promptText;
    private ObjectProperty<ObservableList<T>> items;
    private Tooltip tooltip;
    private Label prompt;
    private ScrollPane scroll;
    private FlowPane flowPane;
    private Provider<T> provider;
    
    public TagBox() {
        this(null);
    }
    
    public TagBox(final ObservableList<T> list) {
        this.checked = (IntegerProperty)new SimpleIntegerProperty((Object)this, "checked", 0);
        this.allowClick = (BooleanProperty)new SimpleBooleanProperty((Object)this, "allowClick", false);
        this.maxSize = (IntegerProperty)new SimpleIntegerProperty((Object)this, "maxSize", 0);
        this.promptText = (StringProperty)new SimpleStringProperty((Object)this, "promptText", "");
        this.items = (ObjectProperty<ObservableList<T>>)new SimpleObjectProperty((Object)this, "items", (Object)FXCollections.observableArrayList());
        this.scroll = new ScrollPane();
        this.flowPane = new FlowPane();
        this.getStylesheets().add((Object)"/javafx/control/resource/css/scrollPane.css");
        this.scroll.setStyle("-fx-padding:0px;-fx-margin:0px;-fx-border:0px;");
        this.flowPane.setStyle("-fx-padding:0px;-fx-margin:0px;-fx-border:0px;");
        this.scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        this.scroll.getStyleClass().add((Object)"custom-scroll");
        this.scroll.setContent((Node)this.flowPane);
        this.scroll.setFitToWidth(true);
        (this.prompt = new Label((String)this.promptText.get())).setWrapText(true);
        this.prompt.setStyle("-fx-text-fill:#8b8b8f;-fx-padding:3px;");
        StackPane.setAlignment((Node)this.prompt, Pos.TOP_LEFT);
        this.getChildren().add((Object)this.prompt);
        this.widthProperty().addListener((ChangeListener)new ChangeListener<Number>() {
            public void changed(final ObservableValue<? extends Number> observableValue, final Number n, final Number n2) {
                TagBox.this.relayout();
            }
        });
        if (list != null) {
            for (int i = 0; i < list.size(); ++i) {
                this.add((SelectedProperty)list.get(i));
            }
        }
    }
    
    private void relayout() {
        final ObservableList children = this.flowPane.getChildren();
        for (int size = children.size(), i = 0; i < size; ++i) {
            if (i != size - 1) {
                FlowPane.setMargin((Node)children.get(i), new Insets(1.0, 20.0, 1.0, 0.0));
            }
            else {
                FlowPane.setMargin((Node)children.get(i), new Insets(1.0, 0.0, 1.0, 0.0));
            }
        }
    }
    
    public Provider<T> getProvider() {
        return this.provider;
    }
    
    public void setProvider(final Provider<T> provider) {
        this.provider = provider;
    }
    
    public ObservableList<T> getItems() {
        return (ObservableList<T>)this.items.get();
    }
    
    public boolean contains(final T t) {
        return this.getItems() != null && this.getItems().contains((Object)t);
    }
    
    public boolean contains(final String s) {
        if (this.getItems() == null) {
            return false;
        }
        for (int i = 0; i < this.getItems().size(); ++i) {
            if (s.equals(((SelectedProperty)this.getItems().get(i)).getItemValue())) {
                return true;
            }
        }
        return false;
    }
    
    public int size() {
        return this.getItems().size();
    }
    
    public IntegerProperty checkedProperty() {
        return this.checked;
    }
    
    public int getChecked() {
        return this.checkedProperty().get();
    }
    
    public void setChecked(final Integer n) {
        this.checked.set((int)n);
    }
    
    public IntegerProperty maxSizeProperty() {
        return this.maxSize;
    }
    
    public void setAllowClick(final boolean b) {
        this.allowClick.set(b);
    }
    
    public boolean isAllowClick() {
        return this.allowClick.get();
    }
    
    public int getMaxSize() {
        return this.maxSize.get();
    }
    
    public void setMaxSize(final int n) {
        this.maxSize.set(n);
    }
    
    public void setTooltip(final Tooltip tooltip) {
        this.tooltip = tooltip;
    }
    
    public final StringProperty promptTextProperty() {
        return this.promptText;
    }
    
    public final String getPromptText() {
        return (String)this.promptText.get();
    }
    
    public final void setPromptText(final String s) {
        this.promptText.set((Object)s);
        this.prompt.setText((String)this.promptText.get());
    }
    
    public void add(final T t) {
        if (this.getMaxSize() > 0 && this.getChecked() >= this.getMaxSize()) {
            return;
        }
        if (!t.isChecked()) {
            t.setChecked(true);
        }
        if (this.getItems().size() == 0) {
            this.getChildren().remove((Object)this.prompt);
            this.getChildren().add((Object)this.scroll);
        }
        final Element<T> element = new Element<T>(this);
        element.create(t, false);
        element.setTooltip(this.tooltip);
        element.setCallback(new Callback<T>() {
            @Override
            public void call(final T t) {
                if (TagBox.this.isAllowClick()) {
                    if (TagBox.this.getMaxSize() > 0 && TagBox.this.getChecked() >= TagBox.this.getMaxSize()) {
                        return;
                    }
                    final int index = TagBox.this.getItems().indexOf((Object)t);
                    final SelectedProperty clone = t.clone();
                    t.addChildren();
                    ((Element)TagBox.this.flowPane.getChildren().get(index)).setHasChild(true);
                    TagBox.this.insert(index + 1, clone);
                }
            }
        });
        this.flowPane.getChildren().add((Object)element);
        this.getItems().add((Object)t);
        this.checkedProperty().set(this.checkedProperty().get() + 1);
        if (!t.isCopy() && t.getChildren() > 0) {
            final int index = this.getItems().indexOf((Object)t);
            element.setHasChild(true);
            for (int i = 0; i < t.getChildren(); ++i) {
                this.insert(index + 1, t.clone());
            }
        }
        this.relayout();
        if (this.getProvider() != null) {
            final int index2 = this.getProvider().getSource().indexOf((Object)t);
            if (index2 != -1) {
                ((SelectedProperty)this.getProvider().getSource().get(index2)).setChecked(true);
            }
        }
    }
    
    private void insert(final int n, final T t) {
        if (this.getItems().size() == 0) {
            this.getChildren().remove((Object)this.prompt);
            this.getChildren().add((Object)this.scroll);
        }
        if (this.getMaxSize() > 0 && this.getChecked() >= this.getMaxSize()) {
            return;
        }
        final Element<T> element = new Element<T>(this);
        element.create(t, true);
        this.flowPane.getChildren().add(n, (Object)element);
        this.getItems().add(n, (Object)t);
        this.checkedProperty().set(this.checkedProperty().get() + 1);
        if (!t.isCopy() && t.getChildren() > 0) {
            final int index = this.getItems().indexOf((Object)t);
            element.setHasChild(true);
            for (int i = 0; i < t.getChildren(); ++i) {
                this.insert(index + 1, t.clone());
            }
        }
        this.relayout();
    }
    
    public void remove(final T t) {
        int index = -1;
        for (int i = 0; i < this.getItems().size(); ++i) {
            if (this.getItems().get(i) == t) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            index = this.getItems().indexOf((Object)t);
        }
        if (index >= 0) {
            this.remove(index);
        }
    }
    
    public void removeAll() {
        this.getItems().clear();
        this.flowPane.getChildren().clear();
        this.checked.set(0);
        if (this.getChildren().contains((Object)this.scroll)) {
            this.getChildren().remove((Object)this.scroll);
        }
        if (!this.getChildren().contains((Object)this.prompt)) {
            this.getChildren().add((Object)this.prompt);
        }
    }
    
    public void remove(final int n) {
        final Element element = (Element)this.flowPane.getChildren().get(n);
        final SelectedProperty selectedProperty = (SelectedProperty)this.getItems().get(n);
        if (!selectedProperty.isCopy()) {
            if (this.getProvider() != null) {
                final javafx.collections.ObservableList<T> source = this.getProvider().getSource();
                final int index = source.indexOf((Object)selectedProperty);
                if (index != -1) {
                    ((SelectedProperty)source.get(index)).setChecked(false);
                }
            }
            else {
                selectedProperty.setChecked(false);
            }
        }
        else {
            selectedProperty.getParent().subtractChildren();
        }
        if (element.hasChild) {
            for (int i = this.getItems().size() - 1; i > -1; --i) {
                if (((SelectedProperty)this.getItems().get(i)).isEquals(selectedProperty.getItemValue())) {
                    this.flowPane.getChildren().remove(i);
                    this.getItems().remove(i);
                    this.checkedProperty().set(this.checkedProperty().get() - 1);
                }
            }
        }
        else {
            this.flowPane.getChildren().remove(n);
            this.getItems().remove(n);
            this.checkedProperty().set(this.checkedProperty().get() - 1);
        }
        if (this.getItems().size() == 0) {
            this.getChildren().remove((Object)this.scroll);
            this.getChildren().add((Object)this.prompt);
        }
        this.relayout();
    }
    
    public interface Callback<T extends SelectedProperty>
    {
        void call(final T p0);
    }
    
    private static class Element<T extends SelectedProperty> extends HBox
    {
        private Callback<T> callback;
        private Tooltip tooltip;
        private boolean hasChild;
        private TagBox<T> tagBox;
        private Label label1;
        
        public Element(final TagBox<T> tagBox) {
            this.hasChild = false;
            this.label1 = null;
            this.tagBox = tagBox;
        }
        
        public void setTooltip(final Tooltip tooltip) {
            this.tooltip = tooltip;
            this.label1.setTooltip(tooltip);
        }
        
        public void setCallback(final Callback<T> callback) {
            this.callback = callback;
        }
        
        public void setHasChild(final boolean hasChild) {
            this.hasChild = hasChild;
        }
        
        public Element<T> create(final T t, final boolean b) {
            String s = "#2b599b";
            String s2 = "#6da0d4";
            String s3 = "white";
            this.label1 = new Label(t.getItemValue());
            if (!b) {
                this.label1.setOnMouseClicked((EventHandler)new EventHandler<MouseEvent>() {
                    private final /* synthetic */ SelectedProperty val$o = t;
                    
                    public void handle(final MouseEvent mouseEvent) {
                        if (mouseEvent.getClickCount() == 1 && Element.this.callback != null) {
                            Element.this.callback.call(this.val$o);
                        }
                    }
                });
                this.label1.setTooltip(this.tooltip);
            }
            else {
                s = "#6b77b3";
                s3 = "black";
                s2 = "white";
            }
            this.label1.setStyle("-fx-cursor: hand;-fx-pref-width:45;-fx-pref-height:23;-fx-border-width: 1 0 1 1; -fx-border-radius:2 0 0 2; -fx-border-color: " + s + "; -fx-label-padding: 1; -fx-background-color: " + s2 + "; -fx-background-radius:2 0 0 2; -fx-text-fill: " + s3 + ";");
            final Label label = new Label("\u00d7");
            label.setAlignment(Pos.BASELINE_CENTER);
            label.setStyle("-fx-pref-width:15;-fx-pref-height:23;-fx-border-color: #000000; -fx-border-width: 1 1 1 0; -fx-border-radius:0 2 2 0; -fx-border-color: " + s + "; -fx-label-padding: 1; -fx-background-color: " + s2 + "; -fx-background-radius:0 2 2 0; -fx-text-fill: " + s3 + "; -fx-cursor: hand;");
            label.setOnMouseClicked((EventHandler)new EventHandler<MouseEvent>() {
                public void handle(final MouseEvent mouseEvent) {
                    Element.this.tagBox.remove(((FlowPane)Element.this.getParent()).getChildren().indexOf((Object)Element.this));
                }
            });
            this.setStyle("-fx-pref-width:60;-fx-pref-height:23;");
            this.getChildren().addAll((Object[])new Node[] { this.label1, label });
            return this;
        }
    }
}
