// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane.skin;

import javafx.collections.ObservableList;
import java.util.Iterator;
import com.sun.javafx.stage.StageHelper;
import javafx.geometry.BoundingBox;
import javafx.stage.Window;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.scene.paint.Stop;
import javafx.scene.paint.Color;
import java.util.ArrayList;
import java.text.Bidi;
import javafx.geometry.Bounds;
import javafx.geometry.Point2D;
import com.sun.javafx.tk.Toolkit;
import com.sun.javafx.scene.text.TextLayout;
import javafx.scene.text.TextBoundsType;
import javafx.scene.text.Text;
import javafx.geometry.NodeOrientation;
import javafx.geometry.Orientation;
import javafx.geometry.VPos;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.image.ImageView;
import javafx.scene.input.Mnemonic;
import javafx.scene.control.OverrunStyle;
import javafx.scene.text.Font;
import javafx.scene.control.ContentDisplay;
import javafx.application.Platform;
import com.sun.javafx.PlatformUtil;
import javafx.scene.control.Label;
import javafx.beans.value.ObservableValue;
import javafx.beans.Observable;
import javafx.scene.control.Control;
import javafx.scene.input.KeyCombination;
import javafx.scene.Scene;
import javafx.scene.shape.Line;
import com.sun.javafx.scene.control.behavior.TextBinding;
import javafx.scene.shape.Rectangle;
import javafx.beans.InvalidationListener;
import javafx.scene.Node;
import com.sun.javafx.scene.control.skin.LabeledText;
import com.sun.javafx.scene.control.skin.BehaviorSkinBase;
import com.sun.javafx.scene.control.behavior.BehaviorBase;
import javafx.scene.control.Labeled;

public abstract class LabeledSkinBase<C extends Labeled, B extends BehaviorBase<C>> extends BehaviorSkinBase<C, B>
{
    LabeledText text;
    boolean invalidText;
    Node graphic;
    double textWidth;
    double ellipsisWidth;
    final InvalidationListener graphicPropertyChangedListener;
    private Rectangle textClip;
    private double wrapWidth;
    private double wrapHeight;
    public TextBinding bindings;
    Line mnemonic_underscore;
    private boolean containsMnemonic;
    private Scene mnemonicScene;
    private KeyCombination mnemonicCode;
    private Node labeledNode;
    
    public LabeledSkinBase(final C c, final B b) {
        super((Control)c, (BehaviorBase)b);
        this.invalidText = true;
        this.textWidth = Double.NEGATIVE_INFINITY;
        this.ellipsisWidth = Double.NEGATIVE_INFINITY;
        this.graphicPropertyChangedListener = (InvalidationListener)new InvalidationListener() {
            public void invalidated(final Observable observable) {
                LabeledSkinBase.this.invalidText = true;
                ((Labeled)LabeledSkinBase.this.getSkinnable()).requestLayout();
            }
        };
        this.containsMnemonic = false;
        this.mnemonicScene = null;
        this.labeledNode = null;
        this.text = new LabeledText((Labeled)c);
        this.updateChildren();
        this.registerChangeListener((ObservableValue)c.ellipsisStringProperty(), "ELLIPSIS_STRING");
        this.registerChangeListener((ObservableValue)c.widthProperty(), "WIDTH");
        this.registerChangeListener((ObservableValue)c.heightProperty(), "HEIGHT");
        this.registerChangeListener((ObservableValue)c.textFillProperty(), "TEXT_FILL");
        this.registerChangeListener((ObservableValue)c.fontProperty(), "FONT");
        this.registerChangeListener((ObservableValue)c.graphicProperty(), "GRAPHIC");
        this.registerChangeListener((ObservableValue)c.contentDisplayProperty(), "CONTENT_DISPLAY");
        this.registerChangeListener((ObservableValue)c.labelPaddingProperty(), "LABEL_PADDING");
        this.registerChangeListener((ObservableValue)c.graphicTextGapProperty(), "GRAPHIC_TEXT_GAP");
        this.registerChangeListener((ObservableValue)c.alignmentProperty(), "ALIGNMENT");
        this.registerChangeListener((ObservableValue)c.mnemonicParsingProperty(), "MNEMONIC_PARSING");
        this.registerChangeListener((ObservableValue)c.textProperty(), "TEXT");
        this.registerChangeListener((ObservableValue)c.textAlignmentProperty(), "TEXT_ALIGNMENT");
        this.registerChangeListener((ObservableValue)c.textOverrunProperty(), "TEXT_OVERRUN");
        this.registerChangeListener((ObservableValue)c.wrapTextProperty(), "WRAP_TEXT");
        this.registerChangeListener((ObservableValue)c.underlineProperty(), "UNDERLINE");
        this.registerChangeListener((ObservableValue)c.lineSpacingProperty(), "LINE_SPACING");
        this.registerChangeListener((ObservableValue)c.sceneProperty(), "SCENE");
    }
    
    protected void handleControlPropertyChanged(final String s) {
        super.handleControlPropertyChanged(s);
        if ("WIDTH".equals(s)) {
            this.updateWrappingWidth();
            this.invalidText = true;
        }
        else if ("HEIGHT".equals(s)) {
            this.invalidText = true;
        }
        else if ("FONT".equals(s)) {
            this.textMetricsChanged();
            this.invalidateWidths();
            this.ellipsisWidth = Double.NEGATIVE_INFINITY;
        }
        else if ("GRAPHIC".equals(s)) {
            this.updateChildren();
            this.textMetricsChanged();
        }
        else if ("CONTENT_DISPLAY".equals(s)) {
            this.updateChildren();
            this.textMetricsChanged();
        }
        else if ("LABEL_PADDING".equals(s)) {
            this.textMetricsChanged();
        }
        else if ("GRAPHIC_TEXT_GAP".equals(s)) {
            this.textMetricsChanged();
        }
        else if ("ALIGNMENT".equals(s)) {
            ((Labeled)this.getSkinnable()).requestLayout();
        }
        else if ("MNEMONIC_PARSING".equals(s)) {
            this.containsMnemonic = false;
            this.textMetricsChanged();
        }
        else if ("TEXT".equals(s)) {
            this.updateChildren();
            this.textMetricsChanged();
            this.invalidateWidths();
        }
        else if (!"TEXT_ALIGNMENT".equals(s)) {
            if ("TEXT_OVERRUN".equals(s)) {
                this.textMetricsChanged();
            }
            else if ("ELLIPSIS_STRING".equals(s)) {
                this.textMetricsChanged();
                this.invalidateWidths();
                this.ellipsisWidth = Double.NEGATIVE_INFINITY;
            }
            else if ("WRAP_TEXT".equals(s)) {
                this.updateWrappingWidth();
                this.textMetricsChanged();
            }
            else if ("UNDERLINE".equals(s)) {
                this.textMetricsChanged();
            }
            else if ("LINE_SPACING".equals(s)) {
                this.textMetricsChanged();
            }
            else if ("SCENE".equals(s)) {
                this.sceneChanged();
            }
        }
    }
    
    protected double topLabelPadding() {
        return this.snapSize(((Labeled)this.getSkinnable()).getLabelPadding().getTop());
    }
    
    protected double bottomLabelPadding() {
        return this.snapSize(((Labeled)this.getSkinnable()).getLabelPadding().getBottom());
    }
    
    protected double leftLabelPadding() {
        return this.snapSize(((Labeled)this.getSkinnable()).getLabelPadding().getLeft());
    }
    
    protected double rightLabelPadding() {
        return this.snapSize(((Labeled)this.getSkinnable()).getLabelPadding().getRight());
    }
    
    private void textMetricsChanged() {
        this.invalidText = true;
        ((Labeled)this.getSkinnable()).requestLayout();
    }
    
    protected void mnemonicTargetChanged() {
        if (this.containsMnemonic) {
            this.removeMnemonic();
            final Control skinnable = this.getSkinnable();
            if (skinnable instanceof Label) {
                this.labeledNode = ((Label)skinnable).getLabelFor();
                this.addMnemonic();
            }
            else {
                this.labeledNode = null;
            }
        }
    }
    
    private void sceneChanged() {
        if (((Labeled)this.getSkinnable()).getScene() != null && this.containsMnemonic) {
            this.addMnemonic();
        }
    }
    
    private void invalidateWidths() {
        this.textWidth = Double.NEGATIVE_INFINITY;
    }
    
    void updateDisplayedText() {
        this.updateDisplayedText(-1.0, -1.0);
    }
    
    private void updateDisplayedText(double n, double n2) {
        if (this.invalidText) {
            final Labeled labeled = (Labeled)this.getSkinnable();
            final String text = labeled.getText();
            int mnemonicIndex = -1;
            if (text != null && text.length() > 0) {
                this.bindings = new TextBinding(text);
                if (!PlatformUtil.isMac() && ((Labeled)this.getSkinnable()).isMnemonicParsing()) {
                    if (labeled instanceof Label) {
                        this.labeledNode = ((Label)labeled).getLabelFor();
                    }
                    else {
                        this.labeledNode = (Node)labeled;
                    }
                    if (this.labeledNode == null) {
                        this.labeledNode = (Node)labeled;
                    }
                    mnemonicIndex = this.bindings.getMnemonicIndex();
                }
            }
            if (this.containsMnemonic) {
                if (this.mnemonicScene != null) {
                    if (mnemonicIndex == -1 || (this.bindings != null && !this.bindings.getMnemonicKeyCombination().equals((Object)this.mnemonicCode))) {
                        this.removeMnemonic();
                    }
                    this.containsMnemonic = false;
                }
            }
            else {
                this.removeMnemonic();
            }
            if (text != null && text.length() > 0 && mnemonicIndex >= 0 && !this.containsMnemonic) {
                this.containsMnemonic = true;
                this.mnemonicCode = this.bindings.getMnemonicKeyCombination();
                this.addMnemonic();
            }
            String s;
            if (this.containsMnemonic) {
                s = this.bindings.getText();
                if (this.mnemonic_underscore == null) {
                    (this.mnemonic_underscore = new Line()).setStartX(0.0);
                    this.mnemonic_underscore.setStartY(0.0);
                    this.mnemonic_underscore.setEndY(0.0);
                    this.mnemonic_underscore.getStyleClass().clear();
                    this.mnemonic_underscore.getStyleClass().setAll((Object[])new String[] { "mnemonic-underline" });
                }
                if (!this.getChildren().contains((Object)this.mnemonic_underscore)) {
                    this.getChildren().add((Object)this.mnemonic_underscore);
                }
            }
            else {
                if (((Labeled)this.getSkinnable()).isMnemonicParsing() && PlatformUtil.isMac() && this.bindings != null) {
                    s = this.bindings.getText();
                }
                else {
                    s = labeled.getText();
                }
                if (this.mnemonic_underscore != null && this.getChildren().contains((Object)this.mnemonic_underscore)) {
                    Platform.runLater((Runnable)new Runnable() {
                        @Override
                        public void run() {
                            LabeledSkinBase.this.getChildren().remove((Object)LabeledSkinBase.this.mnemonic_underscore);
                            LabeledSkinBase.this.mnemonic_underscore = null;
                        }
                    });
                }
            }
            final int n3 = (s != null) ? s.length() : 0;
            boolean b = false;
            if (s != null && n3 > 0) {
                final int index = s.indexOf(10);
                if (index > -1 && index < n3 - 1) {
                    b = true;
                }
            }
            final boolean b2 = labeled.getContentDisplay() == ContentDisplay.LEFT || labeled.getContentDisplay() == ContentDisplay.RIGHT;
            final double max = Math.max(labeled.getWidth() - this.snappedLeftInset() - this.leftLabelPadding() - this.snappedRightInset() - this.rightLabelPadding(), 0.0);
            if (n == -1.0) {
                n = max;
            }
            double min = Math.min(this.computeMinLabeledPartWidth(-1.0, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset()), max);
            if (b2 && !this.isIgnoreGraphic()) {
                final double n4 = labeled.getGraphic().getLayoutBounds().getWidth() + labeled.getGraphicTextGap();
                n -= n4;
                min -= n4;
            }
            this.wrapWidth = Math.max(min, n);
            final boolean b3 = labeled.getContentDisplay() == ContentDisplay.TOP || labeled.getContentDisplay() == ContentDisplay.BOTTOM;
            final double max2 = Math.max(labeled.getHeight() - this.snappedTopInset() - this.topLabelPadding() - this.snappedBottomInset() - this.bottomLabelPadding(), 0.0);
            if (n2 == -1.0) {
                n2 = max2;
            }
            double min2 = Math.min(this.computeMinLabeledPartHeight(this.wrapWidth, this.snappedTopInset(), this.snappedRightInset(), this.snappedBottomInset(), this.snappedLeftInset()), max2);
            if (b3 && labeled.getGraphic() != null) {
                final double n5 = labeled.getGraphic().getLayoutBounds().getHeight() + labeled.getGraphicTextGap();
                n2 -= n5;
                min2 -= n5;
            }
            this.wrapHeight = Math.max(min2, n2);
            this.updateWrappingWidth();
            final Font font = this.text.getFont();
            final OverrunStyle textOverrun = labeled.getTextOverrun();
            final String ellipsisString = labeled.getEllipsisString();
            String text2;
            if (labeled.isWrapText()) {
                text2 = Utils.computeClippedWrappedText(font, s, this.wrapWidth, this.wrapHeight, textOverrun, ellipsisString, this.text.getBoundsType());
            }
            else if (b) {
                final StringBuilder sb = new StringBuilder();
                final String[] split = s.split("\n");
                for (int i = 0; i < split.length; ++i) {
                    sb.append(Utils.computeClippedText(font, split[i], this.wrapWidth, textOverrun, ellipsisString));
                    if (i < split.length - 1) {
                        sb.append('\n');
                    }
                }
                text2 = sb.toString();
            }
            else {
                text2 = Utils.computeClippedText(font, s, this.wrapWidth, textOverrun, ellipsisString);
            }
            if (text2 != null && text2.endsWith("\n")) {
                text2 = text2.substring(0, text2.length() - 1);
            }
            this.text.setText(text2);
            this.updateWrappingWidth();
            this.invalidText = false;
        }
    }
    
    private void addMnemonic() {
        if (this.labeledNode != null) {
            this.mnemonicScene = this.labeledNode.getScene();
            if (this.mnemonicScene != null) {
                this.mnemonicScene.addMnemonic(new Mnemonic(this.labeledNode, this.mnemonicCode));
            }
        }
    }
    
    private void removeMnemonic() {
        if (this.mnemonicScene != null && this.labeledNode != null) {
            this.mnemonicScene.removeMnemonic(new Mnemonic(this.labeledNode, this.mnemonicCode));
            this.mnemonicScene = null;
        }
    }
    
    private void updateWrappingWidth() {
        final Labeled labeled = (Labeled)this.getSkinnable();
        this.text.setWrappingWidth(0.0);
        if (labeled.isWrapText()) {
            this.text.setWrappingWidth(Math.min(this.text.prefWidth(-1.0), this.wrapWidth));
        }
    }
    
    protected void updateChildren() {
        final Labeled labeled = (Labeled)this.getSkinnable();
        if (this.graphic != null) {
            this.graphic.layoutBoundsProperty().removeListener(this.graphicPropertyChangedListener);
        }
        this.graphic = labeled.getGraphic();
        if (this.graphic instanceof ImageView) {
            this.graphic.setMouseTransparent(true);
        }
        if (this.isIgnoreGraphic()) {
            if (labeled.getContentDisplay() == ContentDisplay.GRAPHIC_ONLY) {
                this.getChildren().clear();
            }
            else {
                this.getChildren().setAll((Object[])new Node[] { this.text });
            }
        }
        else {
            this.graphic.layoutBoundsProperty().addListener(this.graphicPropertyChangedListener);
            if (this.isIgnoreText()) {
                this.getChildren().setAll((Object[])new Node[] { this.graphic });
            }
            else {
                this.getChildren().setAll((Object[])new Node[] { this.graphic, this.text });
            }
            this.graphic.impl_processCSS(false);
        }
    }
    
    protected boolean isIgnoreGraphic() {
        return this.graphic == null || !this.graphic.isManaged() || ((Labeled)this.getSkinnable()).getContentDisplay() == ContentDisplay.TEXT_ONLY;
    }
    
    protected boolean isIgnoreText() {
        final Labeled labeled = (Labeled)this.getSkinnable();
        final String text = labeled.getText();
        return text == null || text.equals("") || labeled.getContentDisplay() == ContentDisplay.GRAPHIC_ONLY;
    }
    
    protected double computeMinWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computeMinLabeledPartWidth(n, n2, n3, n4, n5);
    }
    
    private double computeMinLabeledPartWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = (Labeled)this.getSkinnable();
        final ContentDisplay contentDisplay = labeled.getContentDisplay();
        final double graphicTextGap = labeled.getGraphicTextGap();
        double n6 = 0.0;
        final Font font = this.text.getFont();
        final OverrunStyle textOverrun = labeled.getTextOverrun();
        final String ellipsisString = labeled.getEllipsisString();
        final String text = labeled.getText();
        if (text != null && !text.isEmpty()) {
            if (textOverrun == OverrunStyle.CLIP) {
                if (this.textWidth == Double.NEGATIVE_INFINITY) {
                    this.textWidth = Utils.computeTextWidth(font, text.substring(0, 1), 0.0);
                }
                n6 = this.textWidth;
            }
            else {
                if (this.textWidth == Double.NEGATIVE_INFINITY) {
                    this.textWidth = Utils.computeTextWidth(font, text, 0.0);
                }
                if (this.ellipsisWidth == Double.NEGATIVE_INFINITY) {
                    this.ellipsisWidth = Utils.computeTextWidth(font, ellipsisString, 0.0);
                }
                n6 = Math.min(this.textWidth, this.ellipsisWidth);
            }
        }
        final Node graphic = labeled.getGraphic();
        double n7;
        if (this.isIgnoreGraphic()) {
            n7 = n6;
        }
        else if (this.isIgnoreText()) {
            n7 = graphic.minWidth(-1.0);
        }
        else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
            n7 = n6 + graphic.minWidth(-1.0) + graphicTextGap;
        }
        else {
            n7 = Math.max(n6, graphic.minWidth(-1.0));
        }
        return n7 + n5 + this.leftLabelPadding() + n3 + this.rightLabelPadding();
    }
    
    protected double computeMinHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return this.computeMinLabeledPartHeight(n, n2, n3, n4, n5);
    }
    
    private double computeMinLabeledPartHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = (Labeled)this.getSkinnable();
        final Font font = this.text.getFont();
        String s = labeled.getText();
        if (s != null && s.length() > 0) {
            final int index = s.indexOf(10);
            if (index >= 0) {
                s = s.substring(0, index);
            }
        }
        double n7;
        final double n6 = n7 = Utils.computeTextHeight(font, s, 0.0, labeled.getLineSpacing(), this.text.getBoundsType());
        if (!this.isIgnoreGraphic()) {
            final Node graphic = labeled.getGraphic();
            if (labeled.getContentDisplay() == ContentDisplay.TOP || labeled.getContentDisplay() == ContentDisplay.BOTTOM) {
                n7 = graphic.minHeight(n) + labeled.getGraphicTextGap() + n6;
            }
            else {
                n7 = Math.max(n6, graphic.minHeight(n));
            }
        }
        return n2 + n7 + n4 + this.topLabelPadding() - this.bottomLabelPadding();
    }
    
    protected double computePrefWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = (Labeled)this.getSkinnable();
        final Font font = this.text.getFont();
        final String text = labeled.getText();
        final boolean b = text == null || text.isEmpty();
        final double n6 = n5 + this.leftLabelPadding() + n3 + this.rightLabelPadding();
        final double n7 = b ? 0.0 : Utils.computeTextWidth(font, text, 0.0);
        final Node graphic = labeled.getGraphic();
        if (this.isIgnoreGraphic()) {
            return n7 + n6;
        }
        if (this.isIgnoreText()) {
            return graphic.prefWidth(-1.0) + n6;
        }
        if (labeled.getContentDisplay() == ContentDisplay.LEFT || labeled.getContentDisplay() == ContentDisplay.RIGHT) {
            return n7 + labeled.getGraphicTextGap() + graphic.prefWidth(-1.0) + n6;
        }
        return Math.max(n7, graphic.prefWidth(-1.0)) + n6;
    }
    
    protected double computePrefHeight(double n, final double n2, final double n3, final double n4, final double n5) {
        final Labeled labeled = (Labeled)this.getSkinnable();
        final Font font = this.text.getFont();
        final ContentDisplay contentDisplay = labeled.getContentDisplay();
        final double graphicTextGap = labeled.getGraphicTextGap();
        n -= n5 + this.leftLabelPadding() + n3 + this.rightLabelPadding();
        String s = labeled.getText();
        if (s != null && s.endsWith("\n")) {
            s = s.substring(0, s.length() - 1);
        }
        double n6 = n;
        if (!this.isIgnoreGraphic() && (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT)) {
            n6 -= this.graphic.prefWidth(-1.0) + graphicTextGap;
        }
        double n8;
        final double n7 = n8 = Utils.computeTextHeight(font, s, labeled.isWrapText() ? n6 : 0.0, labeled.getLineSpacing(), this.text.getBoundsType());
        if (!this.isIgnoreGraphic()) {
            final Node graphic = labeled.getGraphic();
            if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
                n8 = graphic.prefHeight(n) + graphicTextGap + n7;
            }
            else {
                n8 = Math.max(n7, graphic.prefHeight(n));
            }
        }
        return n2 + n8 + n4 + this.topLabelPadding() + this.bottomLabelPadding();
    }
    
    protected double computeMaxWidth(final double n, final double n2, final double n3, final double n4, final double n5) {
        return ((Labeled)this.getSkinnable()).prefWidth(n);
    }
    
    protected double computeMaxHeight(final double n, final double n2, final double n3, final double n4, final double n5) {
        return ((Labeled)this.getSkinnable()).prefHeight(n);
    }
    
    public double computeBaselineOffset(final double n, final double n2, final double n3, final double n4) {
        double baselineOffset;
        final double n5 = baselineOffset = this.text.getBaselineOffset();
        final Labeled labeled = (Labeled)this.getSkinnable();
        final Node graphic = labeled.getGraphic();
        if (!this.isIgnoreGraphic()) {
            final ContentDisplay contentDisplay = labeled.getContentDisplay();
            if (contentDisplay == ContentDisplay.TOP) {
                baselineOffset = graphic.prefHeight(-1.0) + labeled.getGraphicTextGap() + n5;
            }
            else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
                baselineOffset = n5 + (graphic.prefHeight(-1.0) - this.text.prefHeight(-1.0)) / 2.0;
            }
        }
        return n + this.topLabelPadding() + baselineOffset;
    }
    
    protected void layoutChildren(final double n, final double n2, final double n3, final double n4) {
        this.layoutLabelInArea(n, n2, n3, n4);
    }
    
    protected void layoutLabelInArea(final double n, final double n2, final double n3, final double n4) {
        this.layoutLabelInArea(n, n2, n3, n4, null);
    }
    
    protected void layoutLabelInArea(double n, double n2, double n3, double n4, Pos alignment) {
        final Labeled labeled = (Labeled)this.getSkinnable();
        final ContentDisplay contentDisplay = labeled.getContentDisplay();
        if (alignment == null) {
            alignment = labeled.getAlignment();
        }
        final HPos hPos = (alignment == null) ? HPos.LEFT : alignment.getHpos();
        final VPos vPos = (alignment == null) ? VPos.CENTER : alignment.getVpos();
        final boolean ignoreGraphic = this.isIgnoreGraphic();
        final boolean ignoreText = this.isIgnoreText();
        n += this.leftLabelPadding();
        n2 += this.topLabelPadding();
        n3 -= this.leftLabelPadding() + this.rightLabelPadding();
        n4 -= this.topLabelPadding() + this.bottomLabelPadding();
        double n6;
        double n5;
        if (ignoreGraphic) {
            n5 = (n6 = 0.0);
        }
        else if (ignoreText) {
            if (this.graphic.isResizable()) {
                final Orientation contentBias = this.graphic.getContentBias();
                if (contentBias == Orientation.HORIZONTAL) {
                    n6 = Utils.boundedSize(n3, this.graphic.minWidth(-1.0), this.graphic.maxWidth(-1.0));
                    n5 = Utils.boundedSize(n4, this.graphic.minHeight(n6), this.graphic.maxHeight(n6));
                }
                else if (contentBias == Orientation.VERTICAL) {
                    n5 = Utils.boundedSize(n4, this.graphic.minHeight(-1.0), this.graphic.maxHeight(-1.0));
                    n6 = Utils.boundedSize(n3, this.graphic.minWidth(n5), this.graphic.maxWidth(n5));
                }
                else {
                    n6 = Utils.boundedSize(n3, this.graphic.minWidth(-1.0), this.graphic.maxWidth(-1.0));
                    n5 = Utils.boundedSize(n4, this.graphic.minHeight(-1.0), this.graphic.maxHeight(-1.0));
                }
                this.graphic.resize(n6, n5);
            }
            else {
                n6 = this.graphic.getLayoutBounds().getWidth();
                n5 = this.graphic.getLayoutBounds().getHeight();
            }
        }
        else {
            this.graphic.autosize();
            n6 = this.graphic.getLayoutBounds().getWidth();
            n5 = this.graphic.getLayoutBounds().getHeight();
        }
        double snapSize2;
        double snapSize;
        if (ignoreText) {
            snapSize = (snapSize2 = 0.0);
            this.text.setText("");
        }
        else {
            this.updateDisplayedText(n3, n4);
            snapSize2 = this.snapSize(Math.min(this.text.getLayoutBounds().getWidth(), this.wrapWidth));
            snapSize = this.snapSize(Math.min(this.text.getLayoutBounds().getHeight(), this.wrapHeight));
        }
        final double n7 = (ignoreText || ignoreGraphic) ? 0.0 : labeled.getGraphicTextGap();
        double max = Math.max(n6, snapSize2);
        double max2 = Math.max(n5, snapSize);
        if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
            max2 = n5 + n7 + snapSize;
        }
        else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
            max = n6 + n7 + snapSize2;
        }
        double n8;
        if (hPos == HPos.LEFT) {
            n8 = n;
        }
        else if (hPos == HPos.RIGHT) {
            n8 = n + (n3 - max);
        }
        else {
            n8 = n + (n3 - max) / 2.0;
        }
        double n9;
        if (vPos == VPos.TOP) {
            n9 = n2;
        }
        else if (vPos == VPos.BOTTOM) {
            n9 = n2 + (n4 - max2);
        }
        else {
            n9 = n2 + (n4 - max2) / 2.0;
        }
        double computeTextWidth = 0.0;
        double computeTextWidth2 = 0.0;
        double computeTextHeight = 0.0;
        if (this.containsMnemonic) {
            final Font font = this.text.getFont();
            final String text = this.bindings.getText();
            computeTextWidth = Utils.computeTextWidth(font, text.substring(0, this.bindings.getMnemonicIndex()), 0.0);
            computeTextWidth2 = Utils.computeTextWidth(font, text.substring(this.bindings.getMnemonicIndex(), this.bindings.getMnemonicIndex() + 1), 0.0);
            computeTextHeight = Utils.computeTextHeight(font, "_", 0.0, this.text.getBoundsType());
        }
        if ((!ignoreGraphic || !ignoreText) && !this.text.isManaged()) {
            this.text.setManaged(true);
        }
        if (ignoreGraphic && ignoreText) {
            if (this.text.isManaged()) {
                this.text.setManaged(false);
            }
            this.text.relocate(this.snapPosition(n8), this.snapPosition(n9));
        }
        else if (ignoreGraphic) {
            this.text.relocate(this.snapPosition(n8), this.snapPosition(n9));
            if (this.containsMnemonic) {
                this.mnemonic_underscore.setEndX(computeTextWidth2 - 2.0);
                this.mnemonic_underscore.relocate(n8 + computeTextWidth, n9 + computeTextHeight - 1.0);
            }
        }
        else if (ignoreText) {
            this.text.relocate(this.snapPosition(n8), this.snapPosition(n9));
            this.graphic.relocate(this.snapPosition(n8), this.snapPosition(n9));
            if (this.containsMnemonic) {
                this.mnemonic_underscore.setEndX(computeTextWidth2);
                this.mnemonic_underscore.setStrokeWidth(computeTextHeight / 10.0);
                this.mnemonic_underscore.relocate(n8 + computeTextWidth, n9 + computeTextHeight - 1.0);
            }
        }
        else {
            double n10 = 0.0;
            double n11 = 0.0;
            double n12 = 0.0;
            double n13 = 0.0;
            if (contentDisplay == ContentDisplay.TOP) {
                n10 = n8 + (max - n6) / 2.0;
                n12 = n8 + (max - snapSize2) / 2.0;
                n11 = n9;
                n13 = n11 + n5 + n7;
            }
            else if (contentDisplay == ContentDisplay.RIGHT) {
                n12 = n8;
                n10 = n12 + snapSize2 + n7;
                n11 = n9 + (max2 - n5) / 2.0;
                n13 = n9 + (max2 - snapSize) / 2.0;
            }
            else if (contentDisplay == ContentDisplay.BOTTOM) {
                n10 = n8 + (max - n6) / 2.0;
                n12 = n8 + (max - snapSize2) / 2.0;
                n13 = n9;
                n11 = n13 + snapSize + n7;
            }
            else if (contentDisplay == ContentDisplay.LEFT) {
                n10 = n8;
                n12 = n10 + n6 + n7;
                n11 = n9 + (max2 - n5) / 2.0;
                n13 = n9 + (max2 - snapSize) / 2.0;
            }
            else if (contentDisplay == ContentDisplay.CENTER) {
                n10 = n8 + (max - n6) / 2.0;
                n12 = n8 + (max - snapSize2) / 2.0;
                n11 = n9 + (max2 - n5) / 2.0;
                n13 = n9 + (max2 - snapSize) / 2.0;
            }
            this.text.relocate(this.snapPosition(n12), this.snapPosition(n13));
            if (this.containsMnemonic) {
                this.mnemonic_underscore.setEndX(computeTextWidth2);
                this.mnemonic_underscore.setStrokeWidth(computeTextHeight / 10.0);
                this.mnemonic_underscore.relocate(this.snapPosition(n12 + computeTextWidth), this.snapPosition(n13 + computeTextHeight - 1.0));
            }
            this.graphic.relocate(this.snapPosition(n10), this.snapPosition(n11));
        }
        if (this.text != null && (this.text.getLayoutBounds().getHeight() > this.wrapHeight || this.text.getLayoutBounds().getWidth() > this.wrapWidth)) {
            if (this.textClip == null) {
                this.textClip = new Rectangle();
            }
            if (labeled.getEffectiveNodeOrientation() == NodeOrientation.LEFT_TO_RIGHT) {
                this.textClip.setX(this.text.getLayoutBounds().getMinX());
            }
            else {
                this.textClip.setX(this.text.getLayoutBounds().getMaxX() - this.wrapWidth);
            }
            this.textClip.setY(this.text.getLayoutBounds().getMinY());
            this.textClip.setWidth(this.wrapWidth);
            this.textClip.setHeight(this.wrapHeight);
            if (this.text.getClip() == null) {
                this.text.setClip((Node)this.textClip);
            }
        }
        else if (this.text.getClip() != null) {
            this.text.setClip((Node)null);
        }
    }
    
    public static class Utils
    {
        static final Text helper;
        static final double DEFAULT_WRAPPING_WIDTH;
        static final double DEFAULT_LINE_SPACING;
        static final String DEFAULT_TEXT;
        static final TextBoundsType DEFAULT_BOUNDS_TYPE;
        static final TextLayout layout;
        
        static {
            helper = new Text();
            DEFAULT_WRAPPING_WIDTH = Utils.helper.getWrappingWidth();
            DEFAULT_LINE_SPACING = Utils.helper.getLineSpacing();
            DEFAULT_TEXT = Utils.helper.getText();
            DEFAULT_BOUNDS_TYPE = Utils.helper.getBoundsType();
            layout = Toolkit.getToolkit().getTextLayoutFactory().createLayout();
        }
        
        static double computeXOffset(final double n, final double n2, final HPos hPos) {
            if (hPos == null) {
                return 0.0;
            }
            switch (hPos) {
                case LEFT: {
                    return 0.0;
                }
                case CENTER: {
                    return (n - n2) / 2.0;
                }
                case RIGHT: {
                    return n - n2;
                }
                default: {
                    return 0.0;
                }
            }
        }
        
        static double computeYOffset(final double n, final double n2, final VPos vPos) {
            if (vPos == null) {
                return 0.0;
            }
            switch (vPos) {
                case TOP: {
                    return 0.0;
                }
                case CENTER: {
                    return (n - n2) / 2.0;
                }
                case BOTTOM: {
                    return n - n2;
                }
                default: {
                    return 0.0;
                }
            }
        }
        
        static int computeTruncationIndex(final Font font, final String text, final double n) {
            Utils.helper.setText(text);
            Utils.helper.setFont(font);
            Utils.helper.setWrappingWidth(0.0);
            Utils.helper.setLineSpacing(0.0);
            final Bounds layoutBounds = Utils.helper.getLayoutBounds();
            final int charIndex = Utils.helper.impl_hitTestChar(new Point2D(n - 2.0, layoutBounds.getMinY() + layoutBounds.getHeight() / 2.0)).getCharIndex();
            Utils.helper.setWrappingWidth(Utils.DEFAULT_WRAPPING_WIDTH);
            Utils.helper.setLineSpacing(Utils.DEFAULT_LINE_SPACING);
            Utils.helper.setText(Utils.DEFAULT_TEXT);
            return charIndex;
        }
        
        static String computeClippedText(final Font font, final String s, final double n, final OverrunStyle overrunStyle, final String s2) {
            if (font == null) {
                throw new IllegalArgumentException("Must specify a font");
            }
            final OverrunStyle overrunStyle2 = (overrunStyle == null || overrunStyle == OverrunStyle.CLIP) ? OverrunStyle.ELLIPSIS : overrunStyle;
            final String s3 = (overrunStyle == OverrunStyle.CLIP) ? "" : s2;
            if (s == null || "".equals(s)) {
                return s;
            }
            if (computeTextWidth(font, s, 0.0) - n < 0.0010000000474974513) {
                return s;
            }
            final double computeTextWidth = computeTextWidth(font, s3, 0.0);
            final double n2 = n - computeTextWidth;
            if (n < computeTextWidth) {
                return "";
            }
            if (overrunStyle2 == OverrunStyle.ELLIPSIS || overrunStyle2 == OverrunStyle.WORD_ELLIPSIS || overrunStyle2 == OverrunStyle.LEADING_ELLIPSIS || overrunStyle2 == OverrunStyle.LEADING_WORD_ELLIPSIS) {
                final boolean b = overrunStyle2 == OverrunStyle.WORD_ELLIPSIS || overrunStyle2 == OverrunStyle.LEADING_WORD_ELLIPSIS;
                if (overrunStyle2 == OverrunStyle.ELLIPSIS && !new Bidi(s, 0).isMixed()) {
                    final int computeTruncationIndex = computeTruncationIndex(font, s, n - computeTextWidth);
                    if (computeTruncationIndex < 0 || computeTruncationIndex >= s.length()) {
                        return s;
                    }
                    return String.valueOf(s.substring(0, computeTruncationIndex)) + s3;
                }
                else {
                    int n3 = -1;
                    int n4 = 0;
                    final int n5 = (overrunStyle2 == OverrunStyle.LEADING_ELLIPSIS || overrunStyle2 == OverrunStyle.LEADING_WORD_ELLIPSIS) ? (s.length() - 1) : 0;
                    final int n6 = (n5 == 0) ? (s.length() - 1) : 0;
                    final int n7 = (n5 == 0) ? 1 : -1;
                    boolean b2 = (n5 == 0) ? (n5 > n6) : (n5 < n6);
                    for (int n8 = n5; !b2; b2 = ((n5 == 0) ? (n8 >= n6) : (n8 <= n6)), n8 += n7) {
                        n4 = n8;
                        final char char1 = s.charAt(n4);
                        final double computeTextWidth2 = computeTextWidth(font, (n5 == 0) ? s.substring(0, n8 + 1) : s.substring(n8, n5 + 1), 0.0);
                        if (Character.isWhitespace(char1)) {
                            n3 = n4;
                        }
                        if (computeTextWidth2 > n2) {
                            break;
                        }
                    }
                    final boolean b3 = !b || n3 == -1;
                    final String s4 = (n5 == 0) ? s.substring(0, b3 ? n4 : n3) : s.substring((b3 ? n4 : n3) + 1);
                    assert !s.equals(s4);
                    if (overrunStyle2 == OverrunStyle.ELLIPSIS || overrunStyle2 == OverrunStyle.WORD_ELLIPSIS) {
                        return String.valueOf(s4) + s3;
                    }
                    return String.valueOf(s3) + s4;
                }
            }
            else {
                int n9 = -1;
                int n10 = -1;
                int n11 = -1;
                int n12 = -1;
                double n13 = 0.0;
                for (int i = 0; i <= s.length() - 1; ++i) {
                    final char char2 = s.charAt(i);
                    final double n14 = n13 + computeTextWidth(font, new StringBuilder().append(char2).toString(), 0.0);
                    if (n14 > n2) {
                        break;
                    }
                    n11 = i;
                    if (Character.isWhitespace(char2)) {
                        n9 = n11;
                    }
                    final int n15 = s.length() - 1 - i;
                    final char char3 = s.charAt(n15);
                    n13 = n14 + computeTextWidth(font, new StringBuilder().append(char3).toString(), 0.0);
                    if (n13 > n2) {
                        break;
                    }
                    n12 = n15;
                    if (Character.isWhitespace(char3)) {
                        n10 = n12;
                    }
                }
                if (n11 < 0) {
                    return s3;
                }
                if (overrunStyle2 == OverrunStyle.CENTER_ELLIPSIS) {
                    if (n12 < 0) {
                        return String.valueOf(s.substring(0, n11 + 1)) + s3;
                    }
                    return String.valueOf(s.substring(0, n11 + 1)) + s3 + s.substring(n12);
                }
                else {
                    final boolean whitespace = Character.isWhitespace(s.charAt(n11 + 1));
                    final String substring = s.substring(0, (n9 == -1 || whitespace) ? (n11 + 1) : n9);
                    if (n12 < 0) {
                        return String.valueOf(substring) + s3;
                    }
                    final boolean whitespace2 = Character.isWhitespace(s.charAt(n12 - 1));
                    return String.valueOf(substring) + s3 + s.substring((n10 == -1 || whitespace2) ? n12 : (n10 + 1));
                }
            }
        }
        
        public static double boundedSize(final double n, final double n2, final double n3) {
            return Math.min(Math.max(n, n2), Math.max(n2, n3));
        }
        
        static String computeClippedWrappedText(final Font font, final String text, final double n, final double n2, final OverrunStyle overrunStyle, final String s, final TextBoundsType boundsType) {
            if (font == null) {
                throw new IllegalArgumentException("Must specify a font");
            }
            final String s2 = (overrunStyle == OverrunStyle.CLIP) ? "" : s;
            final int length = s2.length();
            final double computeTextWidth = computeTextWidth(font, s2, 0.0);
            final double computeTextHeight = computeTextHeight(font, s2, 0.0, boundsType);
            if (n < computeTextWidth || n2 < computeTextHeight) {
                return "";
            }
            Utils.helper.setText(text);
            Utils.helper.setFont(font);
            Utils.helper.setWrappingWidth((double)(int)Math.ceil(n));
            Utils.helper.setBoundsType(boundsType);
            Utils.helper.setLineSpacing(0.0);
            final boolean b = overrunStyle == OverrunStyle.LEADING_ELLIPSIS || overrunStyle == OverrunStyle.LEADING_WORD_ELLIPSIS;
            final boolean b2 = overrunStyle == OverrunStyle.CENTER_ELLIPSIS || overrunStyle == OverrunStyle.CENTER_WORD_ELLIPSIS;
            final boolean b3 = !b && !b2;
            final boolean b4 = overrunStyle == OverrunStyle.WORD_ELLIPSIS || overrunStyle == OverrunStyle.LEADING_WORD_ELLIPSIS || overrunStyle == OverrunStyle.CENTER_WORD_ELLIPSIS;
            String text2 = text;
            final int n3 = (text2 != null) ? text2.length() : 0;
            int n4 = -1;
            Point2D point2D = null;
            if (b2) {
                point2D = new Point2D((n - computeTextWidth) / 2.0, n2 / 2.0 - Utils.helper.getBaselineOffset());
            }
            final Point2D point2D2 = new Point2D(0.0, n2 - Utils.helper.getBaselineOffset());
            int n5 = Utils.helper.impl_hitTestChar(point2D2).getCharIndex();
            if (n5 >= n3) {
                Utils.helper.setBoundsType(TextBoundsType.LOGICAL);
                return text;
            }
            if (b2) {
                n5 = Utils.helper.impl_hitTestChar(point2D).getCharIndex();
            }
            if (n5 > 0 && n5 < n3) {
                if (b2 || b3) {
                    int n6 = n5;
                    if (b2) {
                        if (b4) {
                            final int lastBreakCharIndex = lastBreakCharIndex(text, n6 + 1);
                            if (lastBreakCharIndex >= 0) {
                                n6 = lastBreakCharIndex + 1;
                            }
                            else {
                                final int firstBreakCharIndex = firstBreakCharIndex(text, n6);
                                if (firstBreakCharIndex >= 0) {
                                    n6 = firstBreakCharIndex + 1;
                                }
                            }
                        }
                        n4 = n6 + length;
                    }
                    text2 = String.valueOf(text2.substring(0, n6)) + s2;
                }
                if (b || b2) {
                    int max = Math.max(0, n3 - n5 - 10);
                    if (max > 0 && b4) {
                        final int lastBreakCharIndex2 = lastBreakCharIndex(text, max + 1);
                        if (lastBreakCharIndex2 >= 0) {
                            max = lastBreakCharIndex2 + 1;
                        }
                        else {
                            final int firstBreakCharIndex2 = firstBreakCharIndex(text, max);
                            if (firstBreakCharIndex2 >= 0) {
                                max = firstBreakCharIndex2 + 1;
                            }
                        }
                    }
                    if (b2) {
                        text2 = String.valueOf(text2) + text.substring(max);
                    }
                    else {
                        text2 = String.valueOf(s2) + text.substring(max);
                    }
                }
                while (true) {
                    Utils.helper.setText(text2);
                    int charIndex = Utils.helper.impl_hitTestChar(point2D2).getCharIndex();
                    if (b2 && charIndex < n4) {
                        if (charIndex > 0 && text2.charAt(charIndex - 1) == '\n') {
                            --charIndex;
                        }
                        text2 = String.valueOf(text.substring(0, charIndex)) + s2;
                        break;
                    }
                    if (charIndex <= 0 || charIndex >= text2.length()) {
                        break;
                    }
                    if (b) {
                        int n7 = length + 1;
                        if (b4) {
                            final int firstBreakCharIndex3 = firstBreakCharIndex(text2, n7);
                            if (firstBreakCharIndex3 >= 0) {
                                n7 = firstBreakCharIndex3 + 1;
                            }
                        }
                        text2 = String.valueOf(s2) + text2.substring(n7);
                    }
                    else if (b2) {
                        int n8 = n4 + 1;
                        if (b4) {
                            final int firstBreakCharIndex4 = firstBreakCharIndex(text2, n8);
                            if (firstBreakCharIndex4 >= 0) {
                                n8 = firstBreakCharIndex4 + 1;
                            }
                        }
                        text2 = String.valueOf(text2.substring(0, n4)) + text2.substring(n8);
                    }
                    else {
                        int n9 = text2.length() - length - 1;
                        if (b4) {
                            final int lastBreakCharIndex3 = lastBreakCharIndex(text2, n9);
                            if (lastBreakCharIndex3 >= 0) {
                                n9 = lastBreakCharIndex3;
                            }
                        }
                        text2 = String.valueOf(text2.substring(0, n9)) + s2;
                    }
                }
            }
            Utils.helper.setWrappingWidth(Utils.DEFAULT_WRAPPING_WIDTH);
            Utils.helper.setLineSpacing(Utils.DEFAULT_LINE_SPACING);
            Utils.helper.setText(Utils.DEFAULT_TEXT);
            Utils.helper.setBoundsType(Utils.DEFAULT_BOUNDS_TYPE);
            return text2;
        }
        
        static double computeTextWidth(final Font font, final String s, final double n) {
            Utils.layout.setContent((s != null) ? s : "", font.impl_getNativeFont());
            Utils.layout.setWrapWidth((float)n);
            return Utils.layout.getBounds().getWidth();
        }
        
        static double computeTextHeight(final Font font, final String s, final double n, final TextBoundsType textBoundsType) {
            return computeTextHeight(font, s, n, 0.0, textBoundsType);
        }
        
        static double computeTextHeight(final Font font, final String s, final double n, final double n2, final TextBoundsType textBoundsType) {
            Utils.layout.setContent((s != null) ? s : "", font.impl_getNativeFont());
            Utils.layout.setWrapWidth((float)n);
            Utils.layout.setLineSpacing((float)n2);
            if (textBoundsType == TextBoundsType.LOGICAL_VERTICAL_CENTER) {
                Utils.layout.setBoundsType(16384);
            }
            else {
                Utils.layout.setBoundsType(0);
            }
            return Utils.layout.getBounds().getHeight();
        }
        
        private static int firstBreakCharIndex(final String s, final int n) {
            final char[] charArray = s.toCharArray();
            for (int i = n; i < charArray.length; ++i) {
                if (isPreferredBreakCharacter(charArray[i])) {
                    return i;
                }
            }
            return -1;
        }
        
        private static int lastBreakCharIndex(final String s, final int n) {
            final char[] charArray = s.toCharArray();
            for (int i = n; i >= 0; --i) {
                if (isPreferredBreakCharacter(charArray[i])) {
                    return i;
                }
            }
            return -1;
        }
        
        private static boolean isPreferredBreakCharacter(final char c) {
            if (Character.isWhitespace(c)) {
                return true;
            }
            switch (c) {
                case '.':
                case ':':
                case ';': {
                    return true;
                }
                default: {
                    return false;
                }
            }
        }
        
        public static float clamp(final float n, final float n2, final float n3) {
            if (n2 < n) {
                return n;
            }
            if (n2 > n3) {
                return n3;
            }
            return n2;
        }
        
        public static int clamp(final int n, final int n2, final int n3) {
            if (n2 < n) {
                return n;
            }
            if (n2 > n3) {
                return n3;
            }
            return n2;
        }
        
        public static double clamp(final double n, final double n2, final double n3) {
            if (n2 < n) {
                return n;
            }
            if (n2 > n3) {
                return n3;
            }
            return n2;
        }
        
        public static double clampMin(final double n, final double n2) {
            if (n < n2) {
                return n2;
            }
            return n;
        }
        
        public static int clampMax(final int n, final int n2) {
            if (n > n2) {
                return n2;
            }
            return n;
        }
        
        public static double nearest(final double n, final double n2, final double n3) {
            if (n2 - n < n3 - n2) {
                return n;
            }
            return n3;
        }
        
        public static String stripQuotes(final String s) {
            if (s == null) {
                return s;
            }
            if (s.length() == 0) {
                return s;
            }
            int n = 0;
            final char char1 = s.charAt(n);
            if (char1 == '\"' || char1 == '\'') {
                ++n;
            }
            int length = s.length();
            final char char2 = s.charAt(length - 1);
            if (char2 == '\"' || char2 == '\'') {
                --length;
            }
            if (length - n < 0) {
                return s;
            }
            return s.substring(n, length);
        }
        
        public static String[] split(String substring, final String s) {
            if (substring == null || substring.length() == 0) {
                return new String[0];
            }
            if (s == null || s.length() == 0) {
                return new String[0];
            }
            if (s.length() > substring.length()) {
                return new String[0];
            }
            final ArrayList<String> list = new ArrayList<String>();
            for (int i = substring.indexOf(s); i >= 0; i = substring.indexOf(s)) {
                final String substring2 = substring.substring(0, i);
                if (substring2 != null && substring2.length() > 0) {
                    list.add(substring2);
                }
                substring = substring.substring(i + s.length());
            }
            if (substring != null && substring.length() > 0) {
                list.add(substring);
            }
            return list.toArray(new String[0]);
        }
        
        public static boolean contains(final String s, final String s2) {
            return s != null && s.length() != 0 && s2 != null && s2.length() != 0 && s2.length() <= s.length() && s.indexOf(s2) > -1;
        }
        
        public static double calculateBrightness(final Color color) {
            return 0.3 * color.getRed() + 0.59 * color.getGreen() + 0.11 * color.getBlue();
        }
        
        public static Color deriveColor(final Color color, final double n) {
            final double calculateBrightness = calculateBrightness(color);
            double n2 = n;
            if (n > 0.0) {
                if (calculateBrightness > 0.85) {
                    n2 *= 1.6;
                }
                else if (calculateBrightness <= 0.6) {
                    if (calculateBrightness > 0.5) {
                        n2 *= 0.9;
                    }
                    else if (calculateBrightness > 0.4) {
                        n2 *= 0.8;
                    }
                    else if (calculateBrightness > 0.3) {
                        n2 *= 0.7;
                    }
                    else {
                        n2 *= 0.6;
                    }
                }
            }
            else if (calculateBrightness < 0.2) {
                n2 *= 0.6;
            }
            if (n2 < -1.0) {
                n2 = -1.0;
            }
            else if (n2 > 1.0) {
                n2 = 1.0;
            }
            final double[] rgBtoHSB = RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue());
            if (n2 > 0.0) {
                final double[] array = rgBtoHSB;
                final int n3 = 1;
                array[n3] *= 1.0 - n2;
                final double[] array2 = rgBtoHSB;
                final int n4 = 2;
                array2[n4] += (1.0 - rgBtoHSB[2]) * n2;
            }
            else {
                final double[] array3 = rgBtoHSB;
                final int n5 = 2;
                array3[n5] *= n2 + 1.0;
            }
            if (rgBtoHSB[1] < 0.0) {
                rgBtoHSB[1] = 0.0;
            }
            else if (rgBtoHSB[1] > 1.0) {
                rgBtoHSB[1] = 1.0;
            }
            if (rgBtoHSB[2] < 0.0) {
                rgBtoHSB[2] = 0.0;
            }
            else if (rgBtoHSB[2] > 1.0) {
                rgBtoHSB[2] = 1.0;
            }
            return Color.hsb((double)(int)rgBtoHSB[0], rgBtoHSB[1], rgBtoHSB[2], color.getOpacity());
        }
        
        private static Color interpolateLinear(final double n, final Color color, final Color color2) {
            final Color convertSRGBtoLinearRGB = convertSRGBtoLinearRGB(color);
            final Color convertSRGBtoLinearRGB2 = convertSRGBtoLinearRGB(color2);
            return convertLinearRGBtoSRGB(Color.color(convertSRGBtoLinearRGB.getRed() + (convertSRGBtoLinearRGB2.getRed() - convertSRGBtoLinearRGB.getRed()) * n, convertSRGBtoLinearRGB.getGreen() + (convertSRGBtoLinearRGB2.getGreen() - convertSRGBtoLinearRGB.getGreen()) * n, convertSRGBtoLinearRGB.getBlue() + (convertSRGBtoLinearRGB2.getBlue() - convertSRGBtoLinearRGB.getBlue()) * n, convertSRGBtoLinearRGB.getOpacity() + (convertSRGBtoLinearRGB2.getOpacity() - convertSRGBtoLinearRGB.getOpacity()) * n));
        }
        
        private static Color ladder(final double n, final Stop[] array) {
            Stop stop = null;
            int i = 0;
            while (i < array.length) {
                final Stop stop2 = array[i];
                if (n <= stop2.getOffset()) {
                    if (stop == null) {
                        return stop2.getColor();
                    }
                    return interpolateLinear((n - stop.getOffset()) / (stop2.getOffset() - stop.getOffset()), stop.getColor(), stop2.getColor());
                }
                else {
                    stop = stop2;
                    ++i;
                }
            }
            return stop.getColor();
        }
        
        public static Color ladder(final Color color, final Stop[] array) {
            return ladder(calculateBrightness(color), array);
        }
        
        public static double[] HSBtoRGB(double n, final double n2, final double n3) {
            n = (n % 360.0 + 360.0) % 360.0 / 360.0;
            double n4 = 0.0;
            double n5 = 0.0;
            double n6 = 0.0;
            if (n2 == 0.0) {
                n6 = n3;
                n5 = n3;
                n4 = n3;
            }
            else {
                final double n7 = (n - Math.floor(n)) * 6.0;
                final double n8 = n7 - Math.floor(n7);
                final double n9 = n3 * (1.0 - n2);
                final double n10 = n3 * (1.0 - n2 * n8);
                final double n11 = n3 * (1.0 - n2 * (1.0 - n8));
                switch ((int)n7) {
                    case 0: {
                        n4 = n3;
                        n5 = n11;
                        n6 = n9;
                        break;
                    }
                    case 1: {
                        n4 = n10;
                        n5 = n3;
                        n6 = n9;
                        break;
                    }
                    case 2: {
                        n4 = n9;
                        n5 = n3;
                        n6 = n11;
                        break;
                    }
                    case 3: {
                        n4 = n9;
                        n5 = n10;
                        n6 = n3;
                        break;
                    }
                    case 4: {
                        n4 = n11;
                        n5 = n9;
                        n6 = n3;
                        break;
                    }
                    case 5: {
                        n4 = n3;
                        n5 = n9;
                        n6 = n10;
                        break;
                    }
                }
            }
            return new double[] { n4, n5, n6 };
        }
        
        public static double[] RGBtoHSB(final double n, final double n2, final double n3) {
            final double[] array = new double[3];
            double n4 = (n > n2) ? n : n2;
            if (n3 > n4) {
                n4 = n3;
            }
            double n5 = (n < n2) ? n : n2;
            if (n3 < n5) {
                n5 = n3;
            }
            final double n6 = n4;
            double n7;
            if (n4 != 0.0) {
                n7 = (n4 - n5) / n4;
            }
            else {
                n7 = 0.0;
            }
            double n8;
            if (n7 == 0.0) {
                n8 = 0.0;
            }
            else {
                final double n9 = (n4 - n) / (n4 - n5);
                final double n10 = (n4 - n2) / (n4 - n5);
                final double n11 = (n4 - n3) / (n4 - n5);
                double n12;
                if (n == n4) {
                    n12 = n11 - n10;
                }
                else if (n2 == n4) {
                    n12 = 2.0 + n9 - n11;
                }
                else {
                    n12 = 4.0 + n10 - n9;
                }
                n8 = n12 / 6.0;
                if (n8 < 0.0) {
                    ++n8;
                }
            }
            array[0] = n8 * 360.0;
            array[1] = n7;
            array[2] = n6;
            return array;
        }
        
        public static Color convertSRGBtoLinearRGB(final Color color) {
            final double[] array = { color.getRed(), color.getGreen(), color.getBlue() };
            for (int i = 0; i < array.length; ++i) {
                if (array[i] <= 0.04045) {
                    array[i] /= 12.92;
                }
                else {
                    array[i] = Math.pow((array[i] + 0.055) / 1.055, 2.4);
                }
            }
            return Color.color(array[0], array[1], array[2], color.getOpacity());
        }
        
        public static Color convertLinearRGBtoSRGB(final Color color) {
            final double[] array = { color.getRed(), color.getGreen(), color.getBlue() };
            for (int i = 0; i < array.length; ++i) {
                if (array[i] <= 0.0031308) {
                    array[i] *= 12.92;
                }
                else {
                    array[i] = 1.055 * Math.pow(array[i], 0.4166666666666667) - 0.055;
                }
            }
            return Color.color(array[0], array[1], array[2], color.getOpacity());
        }
        
        public static double sum(final double[] array) {
            double n = 0.0;
            for (int length = array.length, i = 0; i < length; ++i) {
                n += array[i];
            }
            return n / array.length;
        }
        
        public static Point2D pointRelativeTo(final Node node, final Node node2, final HPos hPos, final VPos vPos, final double n, final double n2, final boolean b) {
            return pointRelativeTo(node, node2.getLayoutBounds().getWidth(), node2.getLayoutBounds().getHeight(), hPos, vPos, n, n2, b);
        }
        
        public static Point2D pointRelativeTo(final Node node, final double n, final double n2, HPos hPos, final VPos vPos, double n3, final double n4, final boolean b) {
            final Bounds bounds = getBounds(node);
            final Scene scene = node.getScene();
            final NodeOrientation effectiveNodeOrientation = node.getEffectiveNodeOrientation();
            if (effectiveNodeOrientation == NodeOrientation.RIGHT_TO_LEFT) {
                if (hPos == HPos.LEFT) {
                    hPos = HPos.RIGHT;
                }
                else if (hPos == HPos.RIGHT) {
                    hPos = HPos.LEFT;
                }
                n3 *= -1.0;
            }
            double n5 = positionX(bounds, n, hPos) + n3;
            final double n6 = positionY(bounds, n2, vPos) + n4;
            if (effectiveNodeOrientation == NodeOrientation.RIGHT_TO_LEFT && hPos == HPos.CENTER) {
                if (scene.getWindow() instanceof Stage) {
                    n5 = n5 + bounds.getWidth() - n;
                }
                else {
                    n5 = n5 - bounds.getWidth() - n;
                }
            }
            if (b) {
                return pointRelativeTo(node, n, n2, n5, n6, hPos, vPos);
            }
            return new Point2D(n5, n6);
        }
        
        public static Point2D pointRelativeTo(final Object o, final double n, final double n2, final double n3, final double n4, final HPos hPos, final VPos vPos) {
            double n5 = n3;
            double n6 = n4;
            final Bounds bounds = getBounds(o);
            final Screen screen = getScreen(o);
            final Rectangle2D rectangle2D = hasFullScreenStage(screen) ? screen.getBounds() : screen.getVisualBounds();
            if (hPos != null) {
                if (n5 + n > rectangle2D.getMaxX()) {
                    n5 = positionX(bounds, n, getHPosOpposite(hPos, vPos));
                }
                if (n5 < rectangle2D.getMinX()) {
                    n5 = positionX(bounds, n, getHPosOpposite(hPos, vPos));
                }
            }
            if (vPos != null) {
                if (n6 + n2 > rectangle2D.getMaxY()) {
                    n6 = positionY(bounds, n2, getVPosOpposite(hPos, vPos));
                }
                if (n6 < rectangle2D.getMinY()) {
                    n6 = positionY(bounds, n2, getVPosOpposite(hPos, vPos));
                }
            }
            if (n5 + n > rectangle2D.getMaxX()) {
                n5 -= n5 + n - rectangle2D.getMaxX();
            }
            if (n5 < rectangle2D.getMinX()) {
                n5 = rectangle2D.getMinX();
            }
            if (n6 + n2 > rectangle2D.getMaxY()) {
                n6 -= n6 + n2 - rectangle2D.getMaxY();
            }
            if (n6 < rectangle2D.getMinY()) {
                n6 = rectangle2D.getMinY();
            }
            return new Point2D(n5, n6);
        }
        
        private static double positionX(final Bounds bounds, final double n, final HPos hPos) {
            if (hPos == HPos.CENTER) {
                return bounds.getMinX();
            }
            if (hPos == HPos.RIGHT) {
                return bounds.getMaxX();
            }
            if (hPos == HPos.LEFT) {
                return bounds.getMinX() - n;
            }
            return 0.0;
        }
        
        private static double positionY(final Bounds bounds, final double n, final VPos vPos) {
            if (vPos == VPos.BOTTOM) {
                return bounds.getMaxY();
            }
            if (vPos == VPos.CENTER) {
                return bounds.getMinY();
            }
            if (vPos == VPos.TOP) {
                return bounds.getMinY() - n;
            }
            return 0.0;
        }
        
        private static Bounds getBounds(final Object o) {
            if (o instanceof Node) {
                final Node node = (Node)o;
                return node.localToScreen(node.getLayoutBounds());
            }
            if (o instanceof Window) {
                final Window window = (Window)o;
                return (Bounds)new BoundingBox(window.getX(), window.getY(), window.getWidth(), window.getHeight());
            }
            return (Bounds)new BoundingBox(0.0, 0.0, 0.0, 0.0);
        }
        
        private static HPos getHPosOpposite(final HPos hPos, final VPos vPos) {
            if (vPos != VPos.CENTER) {
                return HPos.CENTER;
            }
            if (hPos == HPos.LEFT) {
                return HPos.RIGHT;
            }
            if (hPos == HPos.RIGHT) {
                return HPos.LEFT;
            }
            if (hPos == HPos.CENTER) {
                return HPos.CENTER;
            }
            return HPos.CENTER;
        }
        
        private static VPos getVPosOpposite(final HPos hPos, final VPos vPos) {
            if (hPos != HPos.CENTER) {
                return VPos.CENTER;
            }
            if (vPos == VPos.BASELINE) {
                return VPos.BASELINE;
            }
            if (vPos == VPos.BOTTOM) {
                return VPos.TOP;
            }
            if (vPos == VPos.CENTER) {
                return VPos.CENTER;
            }
            if (vPos == VPos.TOP) {
                return VPos.BOTTOM;
            }
            return VPos.CENTER;
        }
        
        public static boolean hasFullScreenStage(final Screen screen) {
            for (final Stage stage : StageHelper.getStages()) {
                if (stage.isFullScreen() && getScreen(stage) == screen) {
                    return true;
                }
            }
            return false;
        }
        
        public static boolean isQVGAScreen() {
            final Rectangle2D bounds = Screen.getPrimary().getBounds();
            return (bounds.getWidth() == 320.0 && bounds.getHeight() == 240.0) || (bounds.getWidth() == 240.0 && bounds.getHeight() == 320.0);
        }
        
        public static Screen getScreen(final Object o) {
            final Bounds bounds = getBounds(o);
            return getScreenForRectangle(new Rectangle2D(bounds.getMinX(), bounds.getMinY(), bounds.getWidth(), bounds.getHeight()));
        }
        
        public static Screen getScreenForRectangle(final Rectangle2D rectangle2D) {
            final ObservableList screens = Screen.getScreens();
            final double minX = rectangle2D.getMinX();
            final double maxX = rectangle2D.getMaxX();
            final double minY = rectangle2D.getMinY();
            final double maxY = rectangle2D.getMaxY();
            Screen screen = null;
            double n = 0.0;
            for (final Screen screen2 : screens) {
                final Rectangle2D bounds = screen2.getBounds();
                final double n2 = getIntersectionLength(minX, maxX, bounds.getMinX(), bounds.getMaxX()) * getIntersectionLength(minY, maxY, bounds.getMinY(), bounds.getMaxY());
                if (n < n2) {
                    n = n2;
                    screen = screen2;
                }
            }
            if (screen != null) {
                return screen;
            }
            Screen primary = Screen.getPrimary();
            double n3 = Double.MAX_VALUE;
            for (final Screen screen3 : screens) {
                final Rectangle2D bounds2 = screen3.getBounds();
                final double outerDistance = getOuterDistance(minX, maxX, bounds2.getMinX(), bounds2.getMaxX());
                final double outerDistance2 = getOuterDistance(minY, maxY, bounds2.getMinY(), bounds2.getMaxY());
                final double n4 = outerDistance * outerDistance + outerDistance2 * outerDistance2;
                if (n3 > n4) {
                    n3 = n4;
                    primary = screen3;
                }
            }
            return primary;
        }
        
        public static Screen getScreenForPoint(final double n, final double n2) {
            final ObservableList screens = Screen.getScreens();
            for (final Screen screen : screens) {
                final Rectangle2D bounds = screen.getBounds();
                if (n >= bounds.getMinX() && n < bounds.getMaxX() && n2 >= bounds.getMinY() && n2 < bounds.getMaxY()) {
                    return screen;
                }
            }
            Screen primary = Screen.getPrimary();
            double n3 = Double.MAX_VALUE;
            for (final Screen screen2 : screens) {
                final Rectangle2D bounds2 = screen2.getBounds();
                final double outerDistance = getOuterDistance(bounds2.getMinX(), bounds2.getMaxX(), n);
                final double outerDistance2 = getOuterDistance(bounds2.getMinY(), bounds2.getMaxY(), n2);
                final double n4 = outerDistance * outerDistance + outerDistance2 * outerDistance2;
                if (n3 >= n4) {
                    n3 = n4;
                    primary = screen2;
                }
            }
            return primary;
        }
        
        private static double getIntersectionLength(final double n, final double n2, final double n3, final double n4) {
            return (n <= n3) ? getIntersectionLengthImpl(n3, n4, n2) : getIntersectionLengthImpl(n, n2, n4);
        }
        
        private static double getIntersectionLengthImpl(final double n, final double n2, final double n3) {
            if (n3 <= n) {
                return 0.0;
            }
            return (n3 <= n2) ? (n3 - n) : (n2 - n);
        }
        
        private static double getOuterDistance(final double n, final double n2, final double n3, final double n4) {
            if (n2 <= n3) {
                return n3 - n2;
            }
            if (n4 <= n) {
                return n4 - n;
            }
            return 0.0;
        }
        
        private static double getOuterDistance(final double n, final double n2, final double n3) {
            if (n3 <= n) {
                return n - n3;
            }
            if (n3 >= n2) {
                return n3 - n2;
            }
            return 0.0;
        }
        
        public static boolean assertionEnabled() {
            boolean b = false;
            assert b = true;
            return b;
        }
        
        public static boolean isWindows() {
            return PlatformUtil.isWindows();
        }
        
        public static boolean isMac() {
            return PlatformUtil.isMac();
        }
        
        public static boolean isUnix() {
            return PlatformUtil.isUnix();
        }
        
        public static String convertUnicode(final String s) {
            int n = -1;
            final char[] charArray = s.toCharArray();
            final int length = charArray.length;
            int i = -1;
            final char[] array = new char[length];
            int n2 = 0;
            while (i < length - 1) {
                char c = charArray[++i];
                if (c == '\\' && n != i) {
                    ++i;
                    if (charArray[i] == 'u') {
                        do {
                            ++i;
                            c = charArray[i];
                        } while (c == 'u');
                        final int n3 = i + 3;
                        if (n3 < length) {
                            final char c2 = c;
                            final int digit = Character.digit(c2, 16);
                            if (digit >= 0 && c2 > '\u007f') {
                                c = "0123456789abcdef".charAt(digit);
                            }
                            int n5;
                            int n4;
                            int digit2;
                            for (n4 = (n5 = digit); i < n3 && n4 >= 0; n4 = digit2, n5 = (n5 << 4) + n4) {
                                ++i;
                                final char c3;
                                c = (c3 = charArray[i]);
                                digit2 = Character.digit(c3, 16);
                                if (digit2 >= 0 && c3 > '\u007f') {
                                    c = "0123456789abcdef".charAt(digit2);
                                }
                            }
                            if (n4 >= 0) {
                                c = (char)n5;
                                n = i;
                            }
                        }
                    }
                    else {
                        --i;
                        c = '\\';
                    }
                }
                array[n2++] = c;
            }
            return new String(array, 0, n2);
        }
    }
}
