// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;

public class FramePane extends TabPane
{
    public FramePane() {
        this((Tab[])null);
    }
    
    public FramePane(final Tab... array) {
        super(array);
        this.getStylesheets().add((Object)"/javafx/control/resource/css/framePane.css");
    }
}
