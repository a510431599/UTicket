// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane;

import javafx.scene.Node;
import javafx.scene.control.ScrollPane;

public class ScrollContainer extends ScrollPane
{
    public ScrollContainer() {
        this.getStylesheets().addAll((Object[])new String[] { "/javafx/control/resource/css/scrollPane.css" });
        this.getStyleClass().add((Object)"custom-scroll");
    }
    
    public ScrollContainer(final Node content) {
        this();
        this.setContent(content);
    }
}
