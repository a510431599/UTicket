// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.pane;

import javafx.event.ActionEvent;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;
import javafx.scene.control.CheckBox;
import javafx.beans.property.Property;
import javafx.beans.binding.Bindings;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.collections.ListChangeListener;
import javafx.control.Cascade;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Label;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.DoubleProperty;
import javafx.control.Provider;
import javafx.scene.layout.StackPane;
import javafx.control.bean.SelectedProperty;

public class CheckBoxArea<T extends SelectedProperty> extends StackPane implements Provider<T>
{
    private DoubleProperty itemWidth;
    private IntegerProperty checked;
    private IntegerProperty maxSize;
    private StringProperty promptText;
    private ObjectProperty<ObservableList<T>> items;
    private Label prompt;
    private ScrollPane scroll;
    private FlowPane flowPane;
    private Cascade<T> cascade;
    private ListChangeListener<T> listChangeListener;
    
    public CheckBoxArea() {
        this(null);
    }
    
    public CheckBoxArea(final ObservableList<T> items) {
        this.itemWidth = (DoubleProperty)new SimpleDoubleProperty((Object)this, "itemWidth", 100.0);
        this.checked = (IntegerProperty)new SimpleIntegerProperty((Object)this, "checked", 0);
        this.maxSize = (IntegerProperty)new SimpleIntegerProperty((Object)this, "maxSize", 0);
        this.promptText = (StringProperty)new SimpleStringProperty((Object)this, "promptText", "");
        this.items = (ObjectProperty<ObservableList<T>>)new SimpleObjectProperty((Object)this, "items", (Object)FXCollections.observableArrayList());
        this.scroll = new ScrollPane();
        this.flowPane = new FlowPane();
        this.cascade = null;
        this.listChangeListener = (ListChangeListener<T>)new ListChangeListener<T>() {
            public void onChanged(final ListChangeListener.Change<? extends T> change) {
                if (change.next()) {
                    if (change.wasAdded()) {
                        for (int i = 0; i < change.getAddedSize(); ++i) {
                            CheckBoxArea.this.add((SelectedProperty)change.getAddedSubList().get(i));
                        }
                    }
                    else if (change.wasRemoved()) {
                        for (int j = 0; j < change.getRemovedSize(); ++j) {
                            CheckBoxArea.this.remove((SelectedProperty)change.getRemoved().get(j));
                        }
                    }
                }
            }
        };
        this.getStylesheets().addAll((Object[])new String[] { "/javafx/control/resource/css/scrollPane.css", "/javafx/control/resource/css/checkBoxArea.css" });
        this.getStyleClass().add((Object)"check-box-area");
        this.setMinHeight(28.0);
        this.scroll.setMinHeight(28.0);
        this.scroll.setStyle("-fx-padding:0px;-fx-margin:0px;-fx-border:0px;");
        this.flowPane.setMinHeight(28.0);
        this.flowPane.setStyle("-fx-padding:0px;-fx-margin:0px;-fx-border:0px;");
        this.scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        this.scroll.getStyleClass().add((Object)"custom-scroll");
        this.scroll.setContent((Node)this.flowPane);
        this.scroll.setFitToWidth(true);
        (this.prompt = new Label((String)this.promptText.get())).setWrapText(true);
        this.prompt.setStyle("-fx-text-fill:#8b8b8f;-fx-padding:3px;");
        StackPane.setAlignment((Node)this.prompt, Pos.TOP_LEFT);
        this.getChildren().add((Object)this.prompt);
        this.itemsProperty().addListener((observableValue, list, list2) -> {
            if (list2 == null || list2.isEmpty()) {
                if (!this.getChildren().contains((Object)this.prompt)) {
                    this.getChildren().remove((Object)this.scroll);
                    this.getChildren().add((Object)this.prompt);
                }
            }
            else if (this.getChildren().contains((Object)this.prompt)) {
                this.getChildren().remove((Object)this.prompt);
                this.getChildren().add((Object)this.scroll);
            }
            this.removeAll();
            if (list != null) {
                list.removeListener((ListChangeListener)this.listChangeListener);
            }
            if (list2 != null) {
                list2.addListener((ListChangeListener)this.listChangeListener);
                for (int i = 0; i < this.getItems().size(); ++i) {
                    this.add((SelectedProperty)this.getItems().get(i));
                }
            }
        });
        if (items != null) {
            this.setItems(items);
        }
    }
    
    public void bind(final Cascade<T> cascade) {
        (this.cascade = cascade).setProvider(this);
        this.cascade.removeAll();
        Bindings.bindBidirectional((Property)this.cascade.maxSizeProperty(), (Property)this.maxSize);
        Bindings.bindBidirectional((Property)this.cascade.checkedProperty(), (Property)this.checked);
        if (this.getItems() != null) {
            for (int i = 0; i < this.getItems().size(); ++i) {
                if (((SelectedProperty)this.getItems().get(i)).isChecked()) {
                    cascade.add((T)this.getItems().get(i));
                }
            }
        }
    }
    
    public void unbind() {
        this.cascade.setProvider(null);
        Bindings.unbindBidirectional((Property)this.cascade.maxSizeProperty(), (Property)this.maxSize);
        Bindings.unbindBidirectional((Property)this.cascade.checkedProperty(), (Property)this.checked);
    }
    
    private void add(final T userData) {
        final CheckBox checkBox = new CheckBox();
        checkBox.setText(userData.getItemValue());
        checkBox.setPrefWidth(this.getItemWidth());
        checkBox.setUserData((Object)userData);
        checkBox.selectedProperty().bindBidirectional((Property)userData.checkedProperty());
        checkBox.selectedProperty().addListener((ChangeListener)this.changeListener(checkBox));
        checkBox.setOnAction(actionEvent -> {
            final CheckBox checkBox = (CheckBox)actionEvent.getSource();
            final SelectedProperty selectedProperty = (SelectedProperty)checkBox.getUserData();
            if (!checkBox.isSelected() && this.cascade != null && this.cascade.getItems().contains((Object)selectedProperty)) {
                this.cascade.remove((T)selectedProperty);
            }
        });
        this.flowPane.getChildren().add((Object)checkBox);
        if (userData.isChecked()) {
            if (this.getMaxSize() <= 0 || this.getCheckedSize() < this.getMaxSize()) {
                if (this.cascade != null) {
                    this.cascade.add(userData);
                }
            }
            else {
                userData.setChecked(false);
            }
        }
    }
    
    private void remove(final T t) {
        final ObservableList children = this.flowPane.getChildren();
        for (int i = 0; i < children.size(); ++i) {
            if (t.equals(((Node)children.get(i)).getUserData())) {
                final CheckBox checkBox = (CheckBox)children.get(i);
                checkBox.setSelected(false);
                checkBox.selectedProperty().unbindBidirectional((Property)t.checkedProperty());
                children.remove(i);
                break;
            }
        }
    }
    
    private void removeAll() {
        final ObservableList children = this.flowPane.getChildren();
        for (int i = children.size() - 1; i >= 0; --i) {
            final CheckBox checkBox = (CheckBox)children.get(i);
            checkBox.selectedProperty().unbindBidirectional((Property)((SelectedProperty)checkBox.getUserData()).checkedProperty());
            children.remove(i);
        }
        if (this.cascade != null) {
            this.cascade.removeAll();
        }
        else {
            this.setChecked(0);
        }
    }
    
    private ChangeListener<Boolean> changeListener(final CheckBox checkBox) {
        return (ChangeListener<Boolean>)new ChangeListener<Boolean>() {
            Boolean flag = true;
            
            public void changed(final ObservableValue<? extends Boolean> observableValue, final Boolean b, final Boolean b2) {
                final SelectedProperty selectedProperty = (SelectedProperty)checkBox.getUserData();
                if (b2 && (CheckBoxArea.this.getMaxSize() <= 0 || CheckBoxArea.this.getCheckedSize() < CheckBoxArea.this.getMaxSize())) {
                    if (CheckBoxArea.this.cascade != null) {
                        CheckBoxArea.this.cascade.add(selectedProperty);
                    }
                    else {
                        CheckBoxArea.this.checkedProperty().set(CheckBoxArea.this.checkedProperty().get() + 1);
                    }
                }
                else if (b && this.flag) {
                    if (CheckBoxArea.this.cascade == null) {
                        CheckBoxArea.this.checkedProperty().set(CheckBoxArea.this.checkedProperty().get() - 1);
                    }
                }
                else if (checkBox.isSelected()) {
                    this.flag = false;
                    checkBox.setSelected(false);
                    this.flag = true;
                }
            }
        };
    }
    
    public void bind(final IntegerProperty integerProperty, final IntegerProperty integerProperty2) {
        Bindings.bindBidirectional((Property)this.maxSize, (Property)integerProperty);
        Bindings.bindBidirectional((Property)this.checked, (Property)integerProperty2);
    }
    
    public void unbind(final IntegerProperty integerProperty, final IntegerProperty integerProperty2) {
        Bindings.unbindBidirectional((Property)this.maxSize, (Property)integerProperty);
        Bindings.unbindBidirectional((Property)this.checked, (Property)integerProperty2);
    }
    
    public double getItemWidth() {
        return this.itemWidth.get();
    }
    
    public void setItemWidth(final double n) {
        this.itemWidth.set(n);
    }
    
    public DoubleProperty itemWidthProperty() {
        return this.itemWidth;
    }
    
    public ObservableList<T> getItems() {
        return (ObservableList<T>)this.items.get();
    }
    
    public void setItems(final ObservableList<T> list) {
        this.items.set((Object)list);
    }
    
    public ObjectProperty<ObservableList<T>> itemsProperty() {
        return this.items;
    }
    
    public final int getMaxSize() {
        return this.maxSize.get();
    }
    
    public final void setMaxSize(final int n) {
        this.maxSize.set(n);
    }
    
    public final IntegerProperty maxSizeProperty() {
        return this.maxSize;
    }
    
    public final IntegerProperty checkedProperty() {
        return this.checked;
    }
    
    public final int getCheckedSize() {
        return this.checkedProperty().get();
    }
    
    public final void setChecked(final Integer n) {
        this.checked.set((int)n);
    }
    
    public final StringProperty promptTextProperty() {
        return this.promptText;
    }
    
    public final String getPromptText() {
        return (String)this.promptText.get();
    }
    
    public final void setPromptText(final String s) {
        this.promptText.set((Object)s);
        this.prompt.setText((String)this.promptText.get());
    }
    
    public ObservableList<T> getSource() {
        return this.getItems();
    }
}
