// 
// Decompiled by Procyon v0.5.30
// 

package javafx.control.bean;

import com.sun.javafx.binding.ExpressionHelper;
import com.sun.javafx.binding.BidirectionalBinding;
import com.sun.xml.internal.bind.v2.schemagen.episode.Bindings;
import javafx.beans.InvalidationListener;
import javafx.beans.value.ChangeListener;
import com.rits.cloning.Cloner;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.BooleanProperty;

public abstract class SelectedProperty implements Cloneable
{
    public BooleanProperty checked;
    private Boolean copy;
    private Integer children;
    private SelectedProperty parent;
    
    public SelectedProperty() {
        this.checked = (BooleanProperty)new SimpleBooleanProperty(false);
        this.copy = false;
        this.children = 0;
    }
    
    public abstract String getItemValue();
    
    public String getItemDisplayText() {
        return this.getItemValue();
    }
    
    public String getRegex() {
        return this.getItemValue();
    }
    
    public boolean isChecked() {
        return this.checked.get();
    }
    
    public void setChecked(final boolean b) {
        this.checked.set(b);
    }
    
    public BooleanProperty checkedProperty() {
        return this.checked;
    }
    
    public boolean matcher(final String s) {
        final String[] split = this.getRegex().split("\\|");
        boolean b = false;
        for (int i = 0; i < split.length; ++i) {
            if (split[i].contains(s)) {
                b = true;
                break;
            }
        }
        return b;
    }
    
    public boolean isEquals(final String s) {
        final String[] split = this.getRegex().split("\\|");
        boolean b = false;
        for (int i = 0; i < split.length; ++i) {
            if (split[i].equalsIgnoreCase(s)) {
                b = true;
                break;
            }
        }
        return b;
    }
    
    public void setCopy(final boolean b) {
        this.copy = b;
    }
    
    public boolean isCopy() {
        return this.copy;
    }
    
    public void addChildren() {
        ++this.children;
    }
    
    public void subtractChildren() {
        --this.children;
    }
    
    public void setChildren(final int n) {
        this.children = n;
    }
    
    public int getChildren() {
        return this.children;
    }
    
    public SelectedProperty getParent() {
        return this.parent;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof SelectedProperty && this.getItemValue().equals(((SelectedProperty)o).getItemValue());
    }
    
    public SelectedProperty clone() {
        try {
            final SelectedProperty selectedProperty = (SelectedProperty)super.clone();
            selectedProperty.copy = true;
            selectedProperty.parent = this;
            return selectedProperty;
        }
        catch (CloneNotSupportedException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public SelectedProperty deepClone() {
        final Cloner standard = Cloner.standard();
        standard.nullInsteadOfClone(ChangeListener.class, InvalidationListener.class, Bindings.class, BidirectionalBinding.class, ExpressionHelper.class);
        standard.setDontCloneInstanceOf(ChangeListener.class, InvalidationListener.class, Bindings.class, BidirectionalBinding.class, ExpressionHelper.class);
        final SelectedProperty selectedProperty = standard.deepClone(this);
        selectedProperty.copy = true;
        selectedProperty.parent = this;
        return selectedProperty;
    }
    
    public SelectedProperty cloneNewInstance() {
        final Cloner standard = Cloner.standard();
        standard.nullInsteadOfClone(ChangeListener.class, InvalidationListener.class, Bindings.class, BidirectionalBinding.class, ExpressionHelper.class);
        standard.setDontCloneInstanceOf(ChangeListener.class, InvalidationListener.class, Bindings.class, BidirectionalBinding.class, ExpressionHelper.class);
        return standard.deepClone(this);
    }
}
