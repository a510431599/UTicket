// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import java.util.ArrayList;
import org.apache.http.HttpHost;
import java.util.List;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import net.tec.kyfw.e;
import org.json.JSONObject;
import net.tec.kyfw.util.p;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;

final class k extends Thread
{
    @Override
    public void run() {
        try {
            int i = 0;
            while (i < 5) {
                final String b = g.b(f.c(), "https://raw.githubusercontent.com/ebert-chan/kyfw12306/master/hosts.json");
                if (p.b((Object)b)) {
                    final JSONObject jsonObject = new JSONObject(b);
                    final String string = jsonObject.getString("DATE");
                    boolean b2 = true;
                    if (string.equals(net.tec.kyfw.a.i.c)) {
                        final String a = e.a(e.a.HOSTS);
                        if (p.b((Object)a)) {
                            final String[] split = a.split("\\|");
                            if (split.length > 1) {
                                net.tec.kyfw.a.i.c = string;
                                for (int j = 0; j < split.length; ++j) {
                                    net.tec.kyfw.a.i.b.add(split[j]);
                                }
                                b2 = false;
                            }
                        }
                    }
                    if (b2) {
                        final JSONArray jsonArray = jsonObject.getJSONArray("DATA");
                        for (int k = 0; k < jsonArray.length(); ++k) {
                            net.tec.kyfw.a.i.b.add(jsonArray.getString(k));
                        }
                        if (!net.tec.kyfw.a.i.b.isEmpty()) {
                            net.tec.kyfw.a.i.c = string;
                            net.tec.kyfw.a.i.b.add(0, "kyfw.12306.cn");
                        }
                        break;
                    }
                    break;
                }
                else {
                    ++i;
                }
            }
            if (net.tec.kyfw.a.i.b.isEmpty()) {
                net.tec.kyfw.a.i.f = true;
                net.tec.kyfw.a.i.b();
            }
        }
        catch (Exception ex) {
            i.d.warn("CDN\u52a0\u8f7d\u5931\u8d25", ex);
        }
    }
}
