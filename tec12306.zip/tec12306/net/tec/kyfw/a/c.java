// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.control.dialog.Dialogs;
import javafx.controller.AbstractController;
import javafx.controller.a;
import net.tec.kyfw.controller.MainController;

final class c implements Runnable
{
    @Override
    public void run() {
        final Stage stage = a.a(MainController.class).getStage();
        if (!stage.isShowing()) {
            stage.show();
            stage.requestFocus();
        }
        Dialogs.create().title("\u8fdc\u7a0b\u6253\u7801\u63d0\u793a").owner((Window)stage).message("\u8fdc\u7a0b\u6253\u7801\u5931\u8d25\uff0c\u60a8\u7684\u4f59\u989d\u4e0d\u8db3\uff0c\u8bf7\u5148\u5145\u503c\uff01").alert();
    }
}
