// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import java.util.ArrayList;
import org.apache.http.HttpHost;
import java.util.List;
import org.apache.log4j.Logger;
import java.util.regex.Matcher;
import net.tec.kyfw.e;
import java.util.regex.Pattern;
import net.tec.kyfw.util.p;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;

final class j extends Thread
{
    @Override
    public void run() {
        try {
            final String s = "http://pc.huochepiao.360.cn/";
            final String b = g.b(f.c(), s);
            if (p.b((Object)b)) {
                final Matcher matcher = Pattern.compile("(?m)(?s)var\\s*index\\s*\\=\\s*['\"]{1}\\.?\\/?([^\\/]*)").matcher(b);
                if (matcher.find()) {
                    final String group = matcher.group(1);
                    boolean b2 = true;
                    if (group.equals(i.c)) {
                        final String a = e.a(e.a.HOSTS);
                        if (p.b((Object)a)) {
                            final String[] split = a.split("\\|");
                            if (split.length > 1) {
                                i.c = group;
                                for (int i = 0; i < split.length; ++i) {
                                    i.b.add(split[i]);
                                }
                                b2 = false;
                            }
                        }
                    }
                    if (b2) {
                        final Matcher matcher2 = Pattern.compile("(?m)(?s)(\\d{1,3}\\.{1}\\d{1,3}\\.{1}\\d{1,3}\\.{1}\\d{1,3})").matcher(g.b(f.c(), s + group + "/index.js"));
                        while (matcher2.find()) {
                            i.b.add(matcher2.group());
                        }
                        if (!i.b.isEmpty()) {
                            i.c = group;
                            i.b.add(0, "kyfw.12306.cn");
                        }
                        else {
                            i.f = true;
                        }
                    }
                }
            }
        }
        catch (Exception ex) {
            i.d.warn("CDN\u52a0\u8f7d\u5931\u8d25", ex);
        }
    }
}
