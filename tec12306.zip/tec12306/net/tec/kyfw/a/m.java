// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import net.tec.kyfw.util.p;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import java.util.List;

public class m
{
    public static List<String[]> a() {
        List<String[]> list = null;
        final String s = "http://www.12306.cn/mormhweb";
        final String b = g.b(f.c(), s + "/tlxw_tip.html");
        if (p.b((Object)b)) {
            list = new ArrayList<String[]>();
            final Matcher matcher = Pattern.compile("(?m)(?s)\\<a\\s*href\\s*=\\s*[\"\\']*[\\.]*([^\"\\']*)[\"\\']*\\s*target\\s*=\\s*[\"\\']*\\_blank[\"\\']*\\s*title\\s*=\\s*[\"\\']*([^\"\\']*)").matcher(b);
            while (matcher.find()) {
                list.add(new String[] { matcher.group(2), s + matcher.group(1) });
            }
        }
        return list;
    }
}
