// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import net.tec.kyfw.util.j;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import org.json.JSONException;
import net.tec.kyfw.util.o;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.Map;
import java.util.HashMap;
import javafx.application.Platform;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import org.apache.log4j.Logger;
import org.json.JSONObject;

class h implements c
{
    final /* synthetic */ a a;
    
    h(final a a) {
        this.a = a;
    }
    
    @Override
    public e a(final JSONObject jsonObject) {
        return new e(jsonObject.optInt("ret"), this.a.d(jsonObject.optInt("ret")));
    }
}
