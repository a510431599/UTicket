// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import java.util.ArrayList;
import net.tec.kyfw.f;
import net.tec.kyfw.e;
import org.apache.http.HttpHost;
import java.util.List;
import org.apache.log4j.Logger;

public class i
{
    private static Logger d;
    public static String[] a;
    public static List<String> b;
    private static Integer e;
    private static boolean f;
    public static String c;
    
    public static HttpHost a() {
        HttpHost httpHost;
        try {
            if (net.tec.kyfw.e.c(net.tec.kyfw.e.a.CDN_OPTION) && !i.b.isEmpty()) {
                if (i.e >= i.b.size()) {
                    i.e = 0;
                }
                httpHost = new HttpHost(i.b.get(i.e), 443, "https");
                final Integer e = i.e;
                ++i.e;
            }
            else {
                httpHost = net.tec.kyfw.f.b().u();
            }
        }
        catch (Exception ex) {
            i.d.warn("Host", ex);
            httpHost = net.tec.kyfw.f.b().u();
        }
        return httpHost;
    }
    
    public static void a(final String s) {
        i.b.remove(s);
    }
    
    public static void b() {
        if (net.tec.kyfw.e.c(net.tec.kyfw.e.a.CDN_OPTION) && i.f) {
            i.f = false;
            new j().start();
        }
    }
    
    public static void c() {
        if (net.tec.kyfw.e.c(net.tec.kyfw.e.a.CDN_OPTION) && i.f) {
            i.f = false;
            new k().start();
        }
    }
    
    static {
        i.d = net.tec.kyfw.util.j.a(i.class);
        i.a = new String[] { "http://kyfw12306.jd-app.com/" };
        i.b = new ArrayList<String>();
        i.e = 0;
        i.f = true;
        i.c = "";
    }
}
