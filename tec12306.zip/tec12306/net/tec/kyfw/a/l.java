// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import java.awt.Color;

public class l
{
    public static int[] a(final int[] array, final int n, final int n2) {
        for (int i = 0; i < array.length; ++i) {
            array[i] = (((int)(0.2125 * (array[i] >> 16 & 0xFF) + 0.7154 * (array[i] >> 8 & 0xFF) + 0.0721 * (array[i] >> 0 & 0xFF)) >= n2) ? Color.WHITE.getRGB() : Color.BLACK.getRGB());
        }
        return array;
    }
}
