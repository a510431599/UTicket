// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import java.util.Map;

class f implements b
{
    final /* synthetic */ Map a;
    final /* synthetic */ a b;
    
    f(final a b, final Map a) {
        this.b = b;
        this.a = a;
    }
    
    @Override
    public Map<String, String> a() {
        return (Map<String, String>)this.a;
    }
    
    @Override
    public byte[] b() {
        return null;
    }
}
