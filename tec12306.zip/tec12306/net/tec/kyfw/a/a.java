// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.a;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import net.tec.kyfw.util.j;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import org.json.JSONException;
import org.json.JSONObject;
import net.tec.kyfw.util.o;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.Map;
import java.util.HashMap;
import javafx.application.Platform;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import org.apache.log4j.Logger;

public class a
{
    static Logger a;
    private static a b;
    private static boolean c;
    private String d;
    private String e;
    private final int f = 30;
    
    public static boolean a() {
        return net.tec.kyfw.a.a.c;
    }
    
    public static void b() {
        net.tec.kyfw.a.a.c = false;
    }
    
    public static e a(final String s, final String s2) {
        net.tec.kyfw.a.a.b = new a(s, s2);
        final d d = net.tec.kyfw.a.a.b.d();
        net.tec.kyfw.a.a.c = (d.c >= 0);
        return d;
    }
    
    public static d b(final String s, final String s2) {
        net.tec.kyfw.a.a.b = new a(s, s2);
        final d d = net.tec.kyfw.a.a.b.d();
        net.tec.kyfw.a.a.c = (d.c >= 0);
        return d;
    }
    
    public static int c() {
        if (!a()) {
            return 0;
        }
        return net.tec.kyfw.a.a.b.d().a;
    }
    
    private static byte[] b(final f f, final boolean b) {
        return g.a(f, Boolean.valueOf(b));
    }
    
    private static boolean a(final String s, final f f, final boolean b) {
        return g.b(f, s, Boolean.valueOf(b));
    }
    
    public static void a(final int n) {
        if (a()) {
            return;
        }
        new net.tec.kyfw.a.b(n).start();
    }
    
    public static String a(final f f, final boolean b) {
        if (!a()) {
            return null;
        }
        final byte[] b2 = b(f, b);
        if (b2 == null) {
            return null;
        }
        a a = net.tec.kyfw.a.a.b.a(b2);
        if (a.c == -303 && a.a > 0) {
            for (int i = 0; i < 2; ++i) {
                a = net.tec.kyfw.a.a.b.b(a.a);
                if (a.c >= 0) {
                    break;
                }
            }
        }
        if (a.c >= 0) {
            final String[] split = a.b.replaceAll("\\|", ",").split(",");
            for (int j = 1; j < split.length; j += 2) {
                split[j] = String.valueOf((int)(Object)Double.valueOf(Double.parseDouble(split[j])) - 30);
            }
            final StringBuffer sb = new StringBuffer();
            for (int k = 0; k < split.length; ++k) {
                sb.append(split[k]);
                if (k != split.length - 1) {
                    sb.append(",");
                }
            }
            final String string = sb.toString();
            if (a(string, f, b)) {
                return string;
            }
        }
        else if (a.c == -304) {
            Platform.runLater((Runnable)new net.tec.kyfw.a.c());
        }
        if (a.a >= 0) {
            a(a.a);
        }
        return null;
    }
    
    a(final String d, final String e) {
        this.d = d;
        this.e = e;
    }
    
    private String d(final int n) {
        switch (n) {
            case 0: {
                return "\u6210\u529f";
            }
            case -1: {
                return "\u7cfb\u7edf\u9519\u8bef";
            }
            case -9993: {
                return "\u7528\u6237\u540d\u6216\u5bc6\u7801\u9519\u8bef";
            }
            case -105: {
                return "\u7528\u6237\u88ab\u7981\u7528";
            }
            case -102: {
                return "\u60a8\u7684ip\u5730\u5740\u88ab\u7981\u7528";
            }
            case -101: {
                return "\u9ed1\u540d\u5355\u673a\u5668\u4fe1\u606f";
            }
            case -100: {
                return "\u65e0\u6548\u8f6f\u4ef6KEY";
            }
            case -206: {
                return "\u6ca1\u6709\u6307\u5b9a\u7684\u9a8c\u8bc1\u7801ID\u8bb0\u5f55";
            }
            case -1000008: {
                return "IO\u5f02\u5e38\uff08\u5305\u62ec\u7f51\u7edc\u5f02\u5e38\uff09";
            }
            case -1000009: {
                return "\u9a8c\u8bc1\u7801\u83b7\u53d6\u8d85\u65f6";
            }
            case -303: {
                return "\u9a8c\u8bc1\u7801\u5c1a\u672a\u6253\u7801\u5b8c\u6210";
            }
            case -304: {
                return "\u4f59\u989d\u4e0d\u8db3\uff0c\u9898\u5206\u4e0d\u8db3";
            }
            case -406: {
                return "\u7528\u6237\u65e0\u6743\u4f7f\u7528\u8be5APP";
            }
            case -10027: {
                return "\u7b7e\u540d\u9519\u8bef";
            }
            case -10000: {
                return "\u7cfb\u7edf\u7e41\u5fd9";
            }
            case -1000005: {
                return "HTTP\u9519\u8bef\uff08" + n + "\uff09";
            }
            case -1000006: {
                return "JSON\u89e3\u6790\u9519\u8bef";
            }
            default: {
                return "\u672a\u77e5\u9519\u8bef\uff08" + n + "\uff09";
            }
        }
    }
    
    public d d() {
        final e a = this.a("http://api.dama2.com:7777/app/" + String.format("d2Balance?appID=%s&user=%s&pwd=%s&sign=%s", 40205, this.d, a(this.d, this.e, "852d256e6b79292e2f51baade58b6b9f"), c("852d256e6b79292e2f51baade58b6b9f", this.d)), new net.tec.kyfw.a.d(this));
        if (a instanceof d) {
            return (d)a;
        }
        return new d(a.c, this.d(a.c), 0);
    }
    
    public a a(final byte[] array) {
        final String b = b(array);
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("fileData", b);
        hashMap.put("appID", Integer.toString(40205));
        hashMap.put("user", this.d);
        hashMap.put("pwd", a(this.d, this.e, "852d256e6b79292e2f51baade58b6b9f"));
        hashMap.put("type", "287");
        hashMap.put("len", Integer.toString(array.length));
        hashMap.put("timeout", Integer.toString(30));
        hashMap.put("sign", a("852d256e6b79292e2f51baade58b6b9f", this.d, array));
        final e a = this.a("http://api.dama2.com:7777/app/d2File", new net.tec.kyfw.a.e(this), new net.tec.kyfw.a.f(this, hashMap));
        if (a instanceof a) {
            return (a)a;
        }
        return new a(a.c, a.c, this.d(a.c), null);
    }
    
    public a b(final int n) {
        final e a = this.a("http://api.dama2.com:7777/app/" + String.format("d2Result?appID=%s&user=%s&pwd=%s&id=%d&sign=%s", 40205, this.d, a(this.d, this.e, "852d256e6b79292e2f51baade58b6b9f"), n, b("852d256e6b79292e2f51baade58b6b9f", this.d, Integer.toString(n))), new net.tec.kyfw.a.g(this));
        if (a instanceof a) {
            return (a)a;
        }
        return new a(a.c, a.c, this.d(a.c), null);
    }
    
    public e c(final int n) {
        return this.a("http://api.dama2.com:7777/app/" + String.format("d2ReportError?appID=%s&user=%s&pwd=%s&id=%d&sign=%s", 40205, this.d, a(this.d, this.e, "852d256e6b79292e2f51baade58b6b9f"), n, b("852d256e6b79292e2f51baade58b6b9f", this.d, Integer.toString(n))), new h(this));
    }
    
    private e a(final String s, final c c) {
        return this.a(s, c, null);
    }
    
    private e a(final String s, final c c, final b b) {
        try {
            final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(s).openConnection();
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(30000);
            if (b != null) {
                Map<String, String> a = b.a();
                if (a == null) {
                    a = new HashMap<String, String>();
                }
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setRequestProperty("Charsert", "UTF-8");
                if (b.b() != null) {
                    final String s2 = "------WebKitFormBoundary";
                    httpURLConnection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + s2);
                    final OutputStream outputStream = httpURLConnection.getOutputStream();
                    if (a != null) {
                        for (final String s3 : a.keySet()) {
                            final String s4 = a.get(s3);
                            final StringBuilder sb = new StringBuilder();
                            sb.append("\r\n--").append(s2).append("\r\nContent-Disposition: form-data;name=\"").append(s3).append("\";").append("\r\nContent-Type:plain/text\r\n\r\n").append(s4);
                            outputStream.write(sb.toString().getBytes());
                        }
                    }
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append("\r\n--").append(s2).append("\r\nContent-Disposition: form-data;name=\"data\";filename=\"pic.jpg\"\r\nContent-Type:image/jpg\r\n\r\n");
                    outputStream.write(sb2.toString().getBytes());
                    outputStream.write(b.b());
                    final StringBuilder sb3 = new StringBuilder();
                    sb3.append("\r\n--").append(s2).append("--\r\n");
                    outputStream.write(sb3.toString().getBytes());
                    outputStream.flush();
                }
                else if (a != null && a.size() > 0) {
                    final StringBuilder sb4 = new StringBuilder();
                    for (final String s5 : a.keySet()) {
                        final String s6 = a.get(s5);
                        if (sb4.length() > 0) {
                            sb4.append("&");
                        }
                        sb4.append(s5).append("=").append(s6);
                    }
                    final byte[] bytes = sb4.toString().getBytes();
                    httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    httpURLConnection.setRequestProperty("Content-Length", String.valueOf(bytes.length));
                    final OutputStream outputStream2 = httpURLConnection.getOutputStream();
                    outputStream2.write(bytes);
                    outputStream2.flush();
                }
            }
            httpURLConnection.connect();
            if (httpURLConnection.getResponseCode() != 200) {
                return this.e(-1000005);
            }
            final byte[] a2 = o.a(httpURLConnection.getInputStream());
            if (net.tec.kyfw.a.a.a.isInfoEnabled()) {
                net.tec.kyfw.a.a.a.info(new String(a2, "utf-8"));
            }
            final JSONObject jsonObject = new JSONObject(new String(a2, "utf-8"));
            final int optInt = jsonObject.optInt("ret");
            if (optInt < 0) {
                return this.e(optInt);
            }
            return c.a(jsonObject);
        }
        catch (JSONException ex) {
            ex.printStackTrace();
            return this.e(-1000006);
        }
        catch (SocketTimeoutException ex2) {
            return this.e(-1000009);
        }
        catch (Exception ex3) {
            return this.e(-1000008);
        }
    }
    
    public static String a(final String s, final String s2, final String s3) {
        return a(s3 + a(a(s) + a(s2)));
    }
    
    public static String c(final String s, final String s2) {
        return a(s + s2).substring(0, 8);
    }
    
    public static String a(final String s, final String s2, final byte[] array) {
        try {
            return a(s.getBytes("utf-8"), s2.getBytes("utf-8"), array);
        }
        catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static String b(final String s, final String s2, final String s3) {
        return a(s + s2 + s3).substring(0, 8);
    }
    
    private static String a(final byte[] array, final byte[] array2, final byte[] array3) {
        final byte[] array4 = new byte[array.length + array2.length + ((array3 != null) ? array3.length : 0)];
        for (int i = 0; i < array.length; ++i) {
            array4[i] = array[i];
        }
        for (int j = 0; j < array2.length; ++j) {
            array4[array.length + j] = array2[j];
        }
        if (array3 != null) {
            for (int k = 0; k < array3.length; ++k) {
                array4[array.length + array2.length + k] = array3[k];
            }
        }
        return c(array4).substring(0, 8);
    }
    
    private static String b(final byte[] array) {
        final StringBuilder sb = new StringBuilder();
        for (int length = array.length, i = 0; i < length; ++i) {
            final String hexString = Integer.toHexString(array[i] & 0xFF);
            if (hexString.length() == 1) {
                sb.append("0" + hexString);
            }
            else {
                sb.append(hexString);
            }
        }
        return sb.toString();
    }
    
    private static String c(final byte[] array) {
        try {
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(array, 0, array.length);
            return b(instance.digest());
        }
        catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    private static String a(final String s) {
        try {
            final byte[] bytes = s.getBytes("utf-8");
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(bytes, 0, bytes.length);
            return b(instance.digest());
        }
        catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
        }
        catch (NoSuchAlgorithmException ex2) {
            ex2.printStackTrace();
        }
        return null;
    }
    
    private e e(final int n) {
        return new e(n, this.d(n));
    }
    
    static {
        net.tec.kyfw.a.a.a = j.a(a.class);
        net.tec.kyfw.a.a.b = null;
        net.tec.kyfw.a.a.c = false;
    }
    
    public static class a extends e
    {
        public int a;
        public String b;
        
        a(final int n, final int a, final String s, final String b) {
            super(n, s);
            this.a = a;
            this.b = b;
        }
    }
    
    public static class e
    {
        public int c;
        public String d;
        
        e(final int c, final String d) {
            this.c = c;
            this.d = d;
        }
    }
    
    public class d extends e
    {
        public int a;
        
        d(final int n, final String s, final int a) {
            super(n, s);
            this.a = a;
        }
    }
    
    private interface b
    {
        byte[] b();
        
        Map<String, String> a();
    }
    
    private interface c
    {
        e a(final JSONObject p0);
    }
}
