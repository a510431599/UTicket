// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import javafx.collections.FXCollections;
import java.util.ArrayList;
import net.tec.kyfw.util.p;
import java.util.List;
import java.lang.reflect.Method;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class dProperty extends SelectedProperty
{
    private StringProperty name;
    private StringProperty cardType;
    private StringProperty cardCode;
    private StringProperty mobileNo;
    private StringProperty passengerType;
    private StringProperty checkState;
    private StringProperty seatType;
    public static final ObservableList<String> CARD_TYPE_LIST;
    public static final ObservableList<String> PASSENGER_TYPE_LIST;
    
    public dProperty(final String s, final String s2, final String s3, final String s4, final String s5, final String s6) {
        this.name = (StringProperty)new SimpleStringProperty();
        this.cardType = (StringProperty)new SimpleStringProperty();
        this.cardCode = (StringProperty)new SimpleStringProperty();
        this.mobileNo = (StringProperty)new SimpleStringProperty();
        this.passengerType = (StringProperty)new SimpleStringProperty();
        this.checkState = (StringProperty)new SimpleStringProperty();
        this.seatType = (StringProperty)new SimpleStringProperty();
        this.name.set(s);
        this.cardType.set(s2);
        this.cardCode.set(s3);
        this.mobileNo.set(s4);
        this.passengerType.set(s5);
        this.checkState.set(s6);
    }
    
    public dProperty(final String s, final String s2, final String s3, final String s4) {
        this.name = (StringProperty)new SimpleStringProperty();
        this.cardType = (StringProperty)new SimpleStringProperty();
        this.cardCode = (StringProperty)new SimpleStringProperty();
        this.mobileNo = (StringProperty)new SimpleStringProperty();
        this.passengerType = (StringProperty)new SimpleStringProperty();
        this.checkState = (StringProperty)new SimpleStringProperty();
        this.seatType = (StringProperty)new SimpleStringProperty();
        this.name.set(s);
        this.cardType.set(s2);
        this.cardCode.set(s3);
        this.passengerType.set(s4);
    }
    
    public String getName() {
        return (String)this.name.get();
    }
    
    public void setName(final String s) {
        this.name.set(s);
    }
    
    public String getCardType() {
        return (String)this.cardType.get();
    }
    
    public void setCardType(final String s) {
        this.cardType.set(s);
    }
    
    public String getCardCode() {
        return (String)this.cardCode.get();
    }
    
    public void setCardCode(final String s) {
        this.cardCode.set(s);
    }
    
    public String getMobileNo() {
        return (String)((this.mobileNo.get() == null) ? "" : this.mobileNo.get());
    }
    
    public void setMobileNo(final String s) {
        this.mobileNo.set(s);
    }
    
    public String getPassengerType() {
        return (String)this.passengerType.get();
    }
    
    public void setPassengerType(final String s) {
        this.passengerType.set(s);
    }
    
    public String getCheckState() {
        return (String)this.checkState.get();
    }
    
    public void setCheckState(final String s) {
        this.checkState.set(s);
    }
    
    public String getSeatType() {
        return (String)this.seatType.get();
    }
    
    public void setSeatType(final String s) {
        this.seatType.set(s);
    }
    
    public Method getMethod(final String s) {
        final Method[] methods = this.getClass().getMethods();
        for (int i = 0; i < methods.length; ++i) {
            if (methods[i].getName().equalsIgnoreCase("set" + s)) {
                return methods[i];
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return this.getName() + "," + this.getCardType() + "," + this.getCardCode() + "," + this.getMobileNo() + "," + this.getPassengerType() + "," + this.getCheckState() + "," + this.isChecked() + "," + this.getChildren();
    }
    
    public static String listToString(final List<dProperty> list) {
        final StringBuffer sb = new StringBuffer();
        if (list != null) {
            for (int i = 0; i < list.size(); ++i) {
                sb.append(list.get(i).toString()).append("|");
            }
        }
        return sb.toString();
    }
    
    public static List<dProperty> stringToList(final String s) {
        List<dProperty> list = null;
        if (p.b((Object)s)) {
            list = new ArrayList<dProperty>();
            final String[] split = s.split("\\|");
            for (int i = 0; i < split.length; ++i) {
                final String[] split2 = split[i].split(",");
                final dProperty d = new dProperty(split2[0], split2[1], split2[2], split2[3], split2[4], split2[5]);
                d.setChecked("true".equals(split2[6]));
                if (split2.length > 7) {
                    d.setChildren(Integer.parseInt(split2[7]));
                }
                list.add(d);
            }
        }
        return list;
    }
    
    public static String getCheckState(final String s, final String s2) {
        String s3 = "\u672a\u901a\u8fc7";
        if ("2".equals(s)) {
            s3 = "\u672a\u901a\u8fc7";
        }
        else if ("95".equals(s2) || "97".equals(s2)) {
            s3 = "\u5df2\u901a\u8fc7";
        }
        else if ("93".equals(s2) || "99".equals(s2)) {
            if ("1".equals(s)) {
                s3 = "\u5df2\u901a\u8fc7";
            }
            else {
                s3 = "\u9884\u901a\u8fc7";
            }
        }
        else if ("94".equals(s2) || "96".equals(s2)) {
            s3 = "\u672a\u901a\u8fc7";
        }
        else if ("92".equals(s2) || "98".equals(s2)) {
            if ("B".equals(s) || "C".equals(s) || "G".equals(s)) {
                s3 = "\u8bf7\u62a5\u9a8c";
            }
            else {
                s3 = "\u5f85\u6838\u9a8c";
            }
        }
        else if ("91".equals(s2)) {
            if ("B".equals(s) || "C".equals(s) || "G".equals(s)) {
                s3 = "\u8bf7\u62a5\u9a8c";
            }
        }
        else {
            s3 = "\u8bf7\u62a5\u9a8c";
        }
        return s3;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o instanceof dProperty) {
            final dProperty d = (dProperty)o;
            return this.getCardCode().equals(d.getCardCode()) && this.getName().equals(d.getName());
        }
        return false;
    }
    
    @Override
    public String getItemValue() {
        return this.getName();
    }
    
    static {
        CARD_TYPE_LIST = FXCollections.observableArrayList(new String[] { "\u4e8c\u4ee3\u8eab\u4efd\u8bc1", "\u6e2f\u6fb3\u901a\u884c\u8bc1", "\u53f0\u6e7e\u901a\u884c\u8bc1", "\u62a4\u7167" });
        PASSENGER_TYPE_LIST = FXCollections.observableArrayList(new String[] { "\u6210\u4eba", "\u513f\u7ae5", "\u5b66\u751f", "\u6b8b\u519b" });
    }
    
    public enum a
    {
        IDCARD("\u4e8c\u4ee3\u8eab\u4efd\u8bc1", "1"), 
        HKPASS("\u6e2f\u6fb3\u901a\u884c\u8bc1", "C"), 
        TWPASS("\u53f0\u6e7e\u901a\u884c\u8bc1", "G"), 
        PASSPORT("\u62a4\u7167", "B"), 
        ADULT("\u6210\u4eba", "1"), 
        CHILD("\u513f\u7ae5", "2"), 
        STUDENT("\u5b66\u751f", "3"), 
        POLICE("\u6b8b\u519b", "4"), 
        ADULT_T("\u6210\u4eba\u7968", "1"), 
        CHILD_T("\u513f\u7ae5\u7968", "2"), 
        STUDENT_T("\u5b66\u751f\u7968", "3"), 
        POLICE_T("\u6b8b\u519b\u7968", "4");
        
        private String value;
        private String name;
        
        private a(final String name, final String value) {
            this.value = value;
            this.name = name;
        }
        
        public String getName() {
            return this.name;
        }
        
        public void setName(final String name) {
            this.name = name;
        }
        
        public String getValue() {
            return this.value;
        }
        
        public void setValue(final String value) {
            this.value = value;
        }
        
        public static String getValue(final String s) {
            String value = "";
            for (final a a : values()) {
                if (a.name.equals(s)) {
                    value = a.value;
                    break;
                }
            }
            return value;
        }
        
        public static String getName(final String s) {
            String s2 = a.ADULT.name;
            for (final a a : values()) {
                if (a.value.equals(s)) {
                    s2 = a.name;
                    break;
                }
            }
            return s2;
        }
    }
}
