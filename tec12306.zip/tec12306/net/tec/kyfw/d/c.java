// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class c extends SelectedProperty
{
    private StringProperty index;
    private StringProperty sequenceNo;
    private StringProperty ticketNo;
    private StringProperty trainInfo;
    private StringProperty seatInfo;
    private StringProperty passengerInfo;
    private StringProperty ticketInfo;
    private StringProperty status;
    private StringProperty ticketkey;
    private BooleanProperty resignFlag;
    private BooleanProperty returnFlag;
    private StringProperty name;
    private StringProperty cardType;
    private StringProperty cardCode;
    private StringProperty passengerType;
    private StringProperty stationTrainCode;
    private StringProperty trainDate;
    private StringProperty fromStationName;
    private StringProperty fromStationTelecode;
    private StringProperty toStationName;
    private StringProperty toStationTelecode;
    
    public c() {
        this.index = (StringProperty)new SimpleStringProperty();
        this.sequenceNo = (StringProperty)new SimpleStringProperty();
        this.ticketNo = (StringProperty)new SimpleStringProperty();
        this.trainInfo = (StringProperty)new SimpleStringProperty();
        this.seatInfo = (StringProperty)new SimpleStringProperty();
        this.passengerInfo = (StringProperty)new SimpleStringProperty();
        this.ticketInfo = (StringProperty)new SimpleStringProperty();
        this.status = (StringProperty)new SimpleStringProperty();
        this.ticketkey = (StringProperty)new SimpleStringProperty();
        this.resignFlag = (BooleanProperty)new SimpleBooleanProperty(false);
        this.returnFlag = (BooleanProperty)new SimpleBooleanProperty(false);
        this.name = (StringProperty)new SimpleStringProperty();
        this.cardType = (StringProperty)new SimpleStringProperty();
        this.cardCode = (StringProperty)new SimpleStringProperty();
        this.passengerType = (StringProperty)new SimpleStringProperty();
        this.stationTrainCode = (StringProperty)new SimpleStringProperty();
        this.trainDate = (StringProperty)new SimpleStringProperty();
        this.fromStationName = (StringProperty)new SimpleStringProperty();
        this.fromStationTelecode = (StringProperty)new SimpleStringProperty();
        this.toStationName = (StringProperty)new SimpleStringProperty();
        this.toStationTelecode = (StringProperty)new SimpleStringProperty();
    }
    
    public String getIndex() {
        return (String)this.index.get();
    }
    
    public void setIndex(final String s) {
        this.index.set((Object)s);
    }
    
    public String getSequenceNo() {
        return (String)this.sequenceNo.get();
    }
    
    public void setSequenceNo(final String s) {
        this.sequenceNo.set((Object)s);
    }
    
    public String getTicketNo() {
        return (String)this.ticketNo.get();
    }
    
    public void setTicketNo(final String s) {
        this.ticketNo.set((Object)s);
    }
    
    public String getTrainInfo() {
        return (String)this.trainInfo.get();
    }
    
    public void setTrainInfo(final String s) {
        this.trainInfo.set((Object)s);
    }
    
    public String getSeatInfo() {
        return (String)this.seatInfo.get();
    }
    
    public void setSeatInfo(final String s) {
        this.seatInfo.set((Object)s);
    }
    
    public String getPassengerInfo() {
        return (String)this.passengerInfo.get();
    }
    
    public void setPassengerInfo(final String s) {
        this.passengerInfo.set((Object)s);
    }
    
    public String getTicketInfo() {
        return (String)this.ticketInfo.get();
    }
    
    public void setTicketInfo(final String s) {
        this.ticketInfo.set((Object)s);
    }
    
    public String getStatus() {
        return (String)this.status.get();
    }
    
    public void setStatus(final String s) {
        this.status.set((Object)s);
    }
    
    public Boolean getResignFlag() {
        return this.resignFlag.get();
    }
    
    public void setResignFlag(final Boolean b) {
        this.resignFlag.set((boolean)b);
    }
    
    public Boolean getReturnFlag() {
        return this.returnFlag.get();
    }
    
    public void setReturnFlag(final Boolean b) {
        this.returnFlag.set((boolean)b);
    }
    
    public String getTicketkey() {
        return (String)this.ticketkey.get();
    }
    
    public void setTicketkey(final String s) {
        this.ticketkey.set((Object)s);
    }
    
    public String getName() {
        return (String)this.name.get();
    }
    
    public void setName(final String s) {
        this.name.set((Object)s);
    }
    
    public String getCardType() {
        return (String)this.cardType.get();
    }
    
    public void setCardType(final String s) {
        this.cardType.set((Object)s);
    }
    
    public String getCardCode() {
        return (String)this.cardCode.get();
    }
    
    public void setCardCode(final String s) {
        this.cardCode.set((Object)s);
    }
    
    public String getPassengerType() {
        return (String)this.passengerType.get();
    }
    
    public void setPassengerType(final String s) {
        this.passengerType.set((Object)s);
    }
    
    public String getStationTrainCode() {
        return (String)this.stationTrainCode.get();
    }
    
    public void setStationTrainCode(final String s) {
        this.stationTrainCode.set((Object)s);
    }
    
    public String getTrainDate() {
        return (String)this.trainDate.get();
    }
    
    public void setTrainDate(final String s) {
        this.trainDate.set((Object)s);
    }
    
    public String getFromStationName() {
        return (String)this.fromStationName.get();
    }
    
    public void setFromStationName(final String s) {
        this.fromStationName.set((Object)s);
    }
    
    public String getFromStationTelecode() {
        return (String)this.fromStationTelecode.get();
    }
    
    public void setFromStationTelecode(final String s) {
        this.fromStationTelecode.set((Object)s);
    }
    
    public String getToStationName() {
        return (String)this.toStationName.get();
    }
    
    public void setToStationName(final String s) {
        this.toStationName.set((Object)s);
    }
    
    public String getToStationTelecode() {
        return (String)this.toStationTelecode.get();
    }
    
    public void setToStationTelecode(final String s) {
        this.toStationTelecode.set((Object)s);
    }
    
    @Override
    public String getItemValue() {
        return this.getTicketNo();
    }
}
