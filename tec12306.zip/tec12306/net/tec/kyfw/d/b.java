// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import java.util.ArrayList;
import net.tec.kyfw.util.p;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class b extends SelectedProperty
{
    public StringProperty userName;
    public StringProperty password;
    
    public b() {
        this.userName = (StringProperty)new SimpleStringProperty();
        this.password = (StringProperty)new SimpleStringProperty();
    }
    
    public b(final String s) {
        this.userName = (StringProperty)new SimpleStringProperty();
        this.password = (StringProperty)new SimpleStringProperty();
        this.userName.set((Object)s);
    }
    
    public b(final String s, final String s2) {
        this.userName = (StringProperty)new SimpleStringProperty();
        this.password = (StringProperty)new SimpleStringProperty();
        this.userName.set((Object)s);
        this.password.set((Object)s2);
    }
    
    public String getUserName() {
        return (String)this.userName.get();
    }
    
    public void setUserName(final String s) {
        this.userName.set((Object)s);
    }
    
    public String getPassword() {
        return (String)this.password.get();
    }
    
    public void setPassword(final String s) {
        this.password.set((Object)s);
    }
    
    @Override
    public boolean equals(final Object o) {
        return this.getUserName() == o || (o != null && this.getUserName().equals(((b)o).getUserName()));
    }
    
    @Override
    public String toString() {
        return this.getUserName() + "," + this.getPassword();
    }
    
    @Override
    public String getItemValue() {
        return this.getUserName();
    }
    
    public static List<b> stringToList(final String s) {
        List<b> list = null;
        if (p.b((Object)s)) {
            list = new ArrayList<b>();
            final String[] split = s.split("\\|");
            for (int i = 0; i < split.length; ++i) {
                final String[] split2 = split[i].split(",");
                list.add(new b(split2[0], split2[1]));
            }
        }
        return list;
    }
}
