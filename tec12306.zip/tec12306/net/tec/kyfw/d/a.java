// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import java.util.Collection;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import net.tec.kyfw.util.r;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import net.tec.kyfw.util.p;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.LongProperty;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class a extends SelectedProperty
{
    public static final String WAIT_RUN = "\u7b49\u5f85\u8fd0\u884c";
    public static final String LOGIN = "\u9700\u8981\u767b\u5f55";
    public static final String RUNNING = "\u6b63\u5728\u8fd0\u884c";
    public static final String SUCCESS = "\u8ba2\u7968\u6210\u529f";
    public static final String FAIL = "\u8ba2\u7968\u5931\u8d25";
    public static final String EXCEPTION = "\u5f02\u5e38\u7ec8\u6b62";
    public static final String TIMING = "\u5b9a\u65f6\u5237\u65b0";
    public StringProperty account;
    public StringProperty password;
    public StringProperty trainDate;
    public StringProperty fromStation;
    public StringProperty toStation;
    public StringProperty fromStationTelecode;
    public StringProperty toStationTelecode;
    public StringProperty startTime;
    public StringProperty seats;
    public StringProperty riders;
    public BooleanProperty timingBuy;
    public LongProperty timingDate;
    public StringProperty orderId;
    public StringProperty priorOption;
    public BooleanProperty submitOption;
    public BooleanProperty trainLimit;
    public StringProperty startTimeShow;
    public StringProperty stationShow;
    public StringProperty taskState;
    public ObservableList<g> trainList;
    public ObservableList<e> seatTypeList;
    public ObservableList<dProperty> passengerList;
    public ObservableList<j> priorDatesList;
    public ObservableList<g> blackList;
    private String flag;
    private String sequenceNo;
    private String ticketkey;
    private String changeTSFlag;
    
    public a(final String s, final String s2, final String trainDate, final String fromStation, final String toStation, final String s3, final String s4, final String startTime, final String s5, final Boolean b, final Boolean b2, final ObservableList<g> trainList, final ObservableList<e> seatTypeList, final ObservableList<dProperty> passengerList, final ObservableList<j> priorDatesList, final ObservableList<g> blackList, final Boolean b3, final Long n) {
        this.account = (StringProperty)new SimpleStringProperty();
        this.password = (StringProperty)new SimpleStringProperty();
        this.trainDate = (StringProperty)new SimpleStringProperty();
        this.fromStation = (StringProperty)new SimpleStringProperty();
        this.toStation = (StringProperty)new SimpleStringProperty();
        this.fromStationTelecode = (StringProperty)new SimpleStringProperty();
        this.toStationTelecode = (StringProperty)new SimpleStringProperty();
        this.startTime = (StringProperty)new SimpleStringProperty();
        this.seats = (StringProperty)new SimpleStringProperty();
        this.riders = (StringProperty)new SimpleStringProperty();
        this.timingBuy = (BooleanProperty)new SimpleBooleanProperty();
        this.timingDate = (LongProperty)new SimpleLongProperty();
        this.orderId = (StringProperty)new SimpleStringProperty();
        this.priorOption = (StringProperty)new SimpleStringProperty();
        this.submitOption = (BooleanProperty)new SimpleBooleanProperty();
        this.trainLimit = (BooleanProperty)new SimpleBooleanProperty();
        this.startTimeShow = (StringProperty)new SimpleStringProperty();
        this.stationShow = (StringProperty)new SimpleStringProperty();
        this.taskState = (StringProperty)new SimpleStringProperty();
        this.blackList = null;
        this.flag = "buy";
        this.sequenceNo = null;
        this.ticketkey = null;
        this.changeTSFlag = null;
        this.account.set((Object)s);
        this.password.set((Object)s2);
        this.setTrainDate(trainDate);
        this.setFromStation(fromStation);
        this.setToStation(toStation);
        this.fromStationTelecode.set((Object)s3);
        this.toStationTelecode.set((Object)s4);
        this.setStartTime(startTime);
        this.priorOption.set((Object)s5);
        this.submitOption.set((boolean)b);
        this.trainLimit.set((boolean)b2);
        this.setTrainList(trainList);
        this.setSeatTypeList(seatTypeList);
        this.setPriorDatesList(priorDatesList);
        this.setPassengerList(passengerList);
        this.setBlackList(blackList);
        this.timingBuy.set((boolean)b3);
        this.timingDate.set((long)n);
        this.setTaskState("\u7b49\u5f85\u8fd0\u884c");
    }
    
    public String getAccount() {
        return (String)this.account.get();
    }
    
    public void setAccount(final String s) {
        this.account.set((Object)s);
    }
    
    public String getTrainDate() {
        return (String)this.trainDate.get();
    }
    
    public void setTrainDate(final String s) {
        this.trainDate.set((Object)s);
        this.setStartTimeShow();
    }
    
    public String getFromStation() {
        return (String)this.fromStation.get();
    }
    
    public void setFromStation(final String s) {
        this.fromStation.set((Object)s);
        this.setStationShow();
    }
    
    public String getToStation() {
        return (String)this.toStation.get();
    }
    
    public void setToStation(final String s) {
        this.toStation.set((Object)s);
        this.setStationShow();
    }
    
    public String getFromStationTelecode() {
        return (String)this.fromStationTelecode.get();
    }
    
    public void setFromStationTelecode(final String s) {
        this.fromStationTelecode.set((Object)s);
    }
    
    public String getToStationTelecode() {
        return (String)this.toStationTelecode.get();
    }
    
    public void setToStationTelecode(final String s) {
        this.toStationTelecode.set((Object)s);
    }
    
    public String getStartTime() {
        return (String)this.startTime.get();
    }
    
    public void setStartTime(final String s) {
        this.startTime.set((Object)s);
        this.setStartTimeShow();
    }
    
    public String getPriorOption() {
        return (String)this.priorOption.get();
    }
    
    public void setPriorOption(final String s) {
        this.priorOption.set((Object)s);
    }
    
    public Boolean getSubmitOption() {
        return this.submitOption.get();
    }
    
    public void setSubmitOption(final Boolean b) {
        this.submitOption.set((boolean)b);
    }
    
    public Boolean getTrainLimit() {
        return this.trainLimit.getValue();
    }
    
    public void setTrainLimit(final Boolean b) {
        this.trainLimit.set((boolean)b);
    }
    
    public String getSeats() {
        return (String)this.seats.get();
    }
    
    public void setSeats(final String s) {
        this.seats.set((Object)s);
    }
    
    public String getRiders() {
        return (String)this.riders.get();
    }
    
    public void setRiders(final String s) {
        this.riders.set((Object)s);
    }
    
    public Boolean getTimingBuy() {
        return this.timingBuy.get();
    }
    
    public void setTimingBuy(final Boolean b) {
        this.timingBuy.set((boolean)b);
    }
    
    public Long getTimingDate() {
        return this.timingDate.get();
    }
    
    public void setTimingDate(final Long n) {
        this.timingDate.set((long)n);
    }
    
    private void setStationShow() {
        if (p.b(this.toStation.get()) && p.b(this.fromStation.get())) {
            this.stationShow.set((Object)((String)this.fromStation.get() + "\u2192" + (String)this.toStation.get()));
        }
        else {
            this.stationShow.set((Object)null);
        }
    }
    
    public String getStationShow() {
        return (String)this.stationShow.get();
    }
    
    public String getOrderId() {
        return (String)((this.orderId != null) ? this.orderId.get() : "");
    }
    
    public void setOrderId(final String s) {
        this.orderId.set((Object)s);
    }
    
    public String getTaskState() {
        return (String)this.taskState.get();
    }
    
    private void setStartTimeShow() {
        final StringBuffer sb = new StringBuffer();
        if (this.getPriorDatesList() == null || this.getPriorDatesList().isEmpty()) {
            sb.append(this.getTrainDate()).append("  ").append(this.getStartTime());
        }
        else {
            final j j = new j(LocalDate.parse(this.getTrainDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd")).format(DateTimeFormatter.ofPattern("MM.dd")), this.getTrainDate());
            if (this.getPriorDatesList().contains((Object)j)) {
                this.getPriorDatesList().remove(this.getPriorDatesList().indexOf((Object)j));
            }
            sb.append(j.getItemValue());
            sb.append("\uff0c");
            for (int i = 0; i < this.getPriorDatesList().size(); ++i) {
                sb.append(((j)this.getPriorDatesList().get(i)).getItemValue());
                if (i != this.getPriorDatesList().size() - 1) {
                    sb.append("\uff0c");
                }
            }
            sb.append("  ").append(this.getStartTime());
        }
        this.startTimeShow.set((Object)sb.toString().trim());
    }
    
    public String getStartTimeShow() {
        return (String)this.startTimeShow.get();
    }
    
    public String getTimingDateString() {
        return LocalTime.ofSecondOfDay(this.timingDate.get()).format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }
    
    public void setTaskState(final String s) {
        this.taskState.set((Object)s);
    }
    
    public String getStateString() {
        return (String)this.taskState.get();
    }
    
    public ObservableList<g> getTrainList() {
        return this.trainList;
    }
    
    public void setTrainList(final ObservableList<g> list) {
        if (list != null) {
            this.trainList = r.a(list);
        }
        else {
            this.trainList = (ObservableList<g>)FXCollections.observableArrayList();
        }
    }
    
    public ObservableList<e> getSeatTypeList() {
        return this.seatTypeList;
    }
    
    public void setSeatTypeList(final ObservableList<e> list) {
        if (list != null) {
            this.seatTypeList = r.a(list);
        }
        else {
            this.seatTypeList = (ObservableList<e>)FXCollections.observableArrayList();
        }
        this.seats.set((Object)arrayToString(this.getSeatTypeList()));
    }
    
    public ObservableList<d> getPassengerList() {
        return this.passengerList;
    }
    
    public void setPassengerList(final ObservableList<dProperty> list) {
        if (list != null) {
            this.passengerList = r.a(list);
        }
        else {
            this.passengerList = (ObservableList<dProperty>)FXCollections.observableArrayList();
        }
        for (int i = 0; i < this.getPassengerList().size(); ++i) {
            if (((dProperty)this.getPassengerList().get(i)).isCopy()) {
                ((dProperty)this.getPassengerList().get(i)).setPassengerType(d.a.CHILD.getName());
            }
        }
        this.riders.set((Object)passengerArrayToString(this.getPassengerList()));
    }
    
    public ObservableList<j> getPriorDatesList() {
        return this.priorDatesList;
    }
    
    public void setPriorDatesList(final ObservableList<j> list) {
        if (list != null) {
            this.priorDatesList = r.a(list);
        }
        else {
            this.priorDatesList = (ObservableList<j>)FXCollections.observableArrayList();
        }
        this.setStartTimeShow();
    }
    
    public ObservableList<g> getBlackList() {
        return this.blackList;
    }
    
    public void setBlackList(final ObservableList<g> list) {
        if (list != null) {
            this.blackList = r.a(list);
        }
        else {
            this.blackList = (ObservableList<g>)FXCollections.observableArrayList();
        }
    }
    
    public String getPassword() {
        return (String)this.password.get();
    }
    
    public void setPassword(final String s) {
        this.password.set((Object)s);
    }
    
    public static String arrayToString(final ObservableList<? extends SelectedProperty> list) {
        final StringBuffer sb = new StringBuffer();
        if (list != null && !list.isEmpty()) {
            for (int i = 0; i < list.size(); ++i) {
                sb.append(((SelectedProperty)list.get(i)).getItemValue());
                if (i != list.size() - 1) {
                    sb.append("\r\n");
                }
            }
        }
        return sb.toString();
    }
    
    public static String passengerArrayToString(final ObservableList<d> list) {
        final StringBuffer sb = new StringBuffer();
        if (list != null && !list.isEmpty()) {
            Object o = null;
            for (int i = 0; i < list.size(); ++i) {
                sb.append(((d)list.get(i)).getItemValue());
                if (((d)list.get(i)).equals(o) && ((d)list.get(i)).getPassengerType().equals(d.a.CHILD.getName())) {
                    sb.append("(\u7ae5)");
                }
                if (i != list.size() - 1) {
                    sb.append("\uff0c");
                }
                o = list.get(i);
            }
        }
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof a && this.getAccount().equals(((a)o).getAccount());
    }
    
    @Override
    public String toString() {
        return (String)this.account.get() + "#" + this.getPassword() + "#" + (String)this.trainDate.get() + "#" + (String)this.fromStation.get() + "#" + (String)this.toStation.get() + "#" + (String)this.fromStationTelecode.get() + "#" + (String)this.toStationTelecode.get() + "#" + (String)this.startTime.get() + "#" + (String)this.priorOption.get() + "#" + this.submitOption.get() + "#" + this.trainLimit.get() + "#" + p.a((List<?>)this.getTrainList()) + "#" + p.a((List<?>)this.getSeatTypeList()) + "#" + p.a((List<?>)this.getPassengerList()) + "#" + p.a((List<?>)this.getPriorDatesList()) + "#" + p.a((List<?>)this.getBlackList()) + "#" + this.timingBuy.get() + "#" + this.timingDate.get();
    }
    
    public static List<a> stringToList(final String s) {
        List<a> list = null;
        if (p.b((Object)s)) {
            try {
                final LocalDate now = LocalDate.now();
                list = new ArrayList<a>();
                final String[] split = s.split(";");
                for (int i = 0; i < split.length; ++i) {
                    final String[] split2 = split[i].split("#");
                    final LocalDate parse = LocalDate.parse(split2[2], DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    if (parse.isAfter(now) || parse.equals(now)) {
                        final ObservableList observableArrayList = FXCollections.observableArrayList();
                        final ObservableList observableArrayList2 = FXCollections.observableArrayList();
                        final ObservableList observableArrayList3 = FXCollections.observableArrayList();
                        final ObservableList observableArrayList4 = FXCollections.observableArrayList();
                        final ObservableList observableArrayList5 = FXCollections.observableArrayList();
                        if (!"".equals(split2[11])) {
                            observableArrayList.addAll((Collection)g.stringToList(split2[11]));
                        }
                        if (!"".equals(split2[12])) {
                            observableArrayList2.addAll((Collection)e.stringToList(split2[12]));
                        }
                        if (!"".equals(split2[13])) {
                            observableArrayList3.addAll((Collection)d.stringToList(split2[13]));
                        }
                        if (!"".equals(split2[14])) {
                            observableArrayList4.addAll((Collection)j.stringToList(split2[14]));
                        }
                        if (!"".equals(split2[15])) {
                            observableArrayList5.addAll((Collection)g.stringToList(split2[15]));
                        }
                        list.add(new a(split2[0], split2[1], split2[2], split2[3], split2[4], split2[5], split2[6], split2[7], split2[8], "true".equals(split2[9]), "true".equals(split2[10]), (ObservableList<g>)observableArrayList, (ObservableList<e>)observableArrayList2, (ObservableList<d>)observableArrayList3, (ObservableList<j>)observableArrayList4, (ObservableList<g>)observableArrayList5, "true".equals(split2[16]), Long.parseLong(split2[17])));
                    }
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return list;
    }
    
    @Override
    public String getItemValue() {
        return this.getAccount();
    }
    
    public String getFlag() {
        return this.flag;
    }
    
    public void setFlag(final String flag) {
        this.flag = flag;
    }
    
    public String getSequenceNo() {
        return this.sequenceNo;
    }
    
    public void setSequenceNo(final String sequenceNo) {
        this.sequenceNo = sequenceNo;
    }
    
    public String getTicketkey() {
        return this.ticketkey;
    }
    
    public void setTicketkey(final String ticketkey) {
        this.ticketkey = ticketkey;
    }
    
    public String getChangeTSFlag() {
        return this.changeTSFlag;
    }
    
    public void setChangeTSFlag(final String changeTSFlag) {
        this.changeTSFlag = changeTSFlag;
    }
}
