// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import net.tec.kyfw.util.p;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class fProperty extends SelectedProperty
{
    private StringProperty acronym;
    private StringProperty phoneticize;
    private StringProperty stationName;
    private StringProperty stationTelecode;
    private IntegerProperty serialnum;
    
    public fProperty(final String s, final String s2, final String s3, final String s4, final Integer n) {
        this.acronym = (StringProperty)new SimpleStringProperty();
        this.phoneticize = (StringProperty)new SimpleStringProperty();
        this.stationName = (StringProperty)new SimpleStringProperty();
        this.stationTelecode = (StringProperty)new SimpleStringProperty();
        this.serialnum = (IntegerProperty)new SimpleIntegerProperty();
        this.acronym.set(s);
        this.phoneticize.set(s2);
        this.stationName.set(s3);
        this.stationTelecode.set(s4);
        this.serialnum.set(n);
    }
    
    public String getAcronym() {
        return (String)this.acronym.get();
    }
    
    public void setAcronym(final String s) {
        this.acronym.set(s);
    }
    
    public String getPhoneticize() {
        return (String)this.phoneticize.get();
    }
    
    public void setPhoneticize(final String s) {
        this.phoneticize.set(s);
    }
    
    public String getStationName() {
        return (String)this.stationName.get();
    }
    
    public void setStationName(final String s) {
        this.stationName.set(s);
    }
    
    public String getStationTelecode() {
        return (String)this.stationTelecode.get();
    }
    
    public void setStationTelecode(final String s) {
        this.stationTelecode.set(s);
    }
    
    public Integer getSerialnum() {
        return this.serialnum.get();
    }
    
    public void setSerialnum(final Integer n) {
        this.serialnum.set((int)n);
    }
    
    @Override
    public String toString() {
        return this.getStationName() + "," + this.getStationTelecode() + "," + this.getAcronym() + "," + this.getPhoneticize() + "," + this.getSerialnum();
    }
    
    public static fProperty stringToObject(final String s) {
        fProperty fp = null;
        if (p.b((Object)s)) {
            final String[] split = s.split(",");
            fp = new fProperty(split[2], null, split[0], split[1], Integer.parseInt(split[4]));
        }
        return fp;
    }
    
    @Override
    public String getItemValue() {
        return this.getStationName();
    }
    
    @Override
    public String getRegex() {
        return this.getStationName() + "|" + this.getAcronym() + "|" + this.getPhoneticize();
    }
}
