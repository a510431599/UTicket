// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

public class k
{
    public int firstSeat;
    public int secondSeat;
    public String secondSeatName;
    private boolean exsitSecondSeat;
    
    public k() {
        this.firstSeat = 0;
        this.secondSeat = 0;
        this.secondSeatName = "";
        this.exsitSecondSeat = false;
    }
    
    public boolean isExsitSecondSeat() {
        return this.exsitSecondSeat;
    }
    
    public void setExsitSecondSeat(final boolean exsitSecondSeat) {
        this.exsitSecondSeat = exsitSecondSeat;
    }
    
    public int sumSeatNum() {
        return this.isExsitSecondSeat() ? (this.firstSeat + this.secondSeat) : this.firstSeat;
    }
}
