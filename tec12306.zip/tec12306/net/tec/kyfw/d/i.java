// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import java.util.HashMap;

final class i extends HashMap<String, String>
{
    private static final long serialVersionUID = -580949055004882783L;
    
    i() {
        this.put("\u4e8c\u7b49\u5ea7", "isZeDisc");
        this.put("\u4e00\u7b49\u5ea7", "isZyDisc");
        this.put("\u7279\u7b49\u5ea7", "isTzDisc");
        this.put("\u786c\u5367", "isYwDisc");
        this.put("\u786c\u5ea7", "isYzDisc");
        this.put("\u8f6f\u5367", "isRwDisc");
        this.put("\u8f6f\u5ea7", "isRzDisc");
        this.put("\u9ad8\u7ea7\u8f6f\u5367", "isGrDisc");
        this.put("\u5546\u52a1\u5ea7", "isSwzDisc");
        this.put("\u65e0\u5ea7", "isWzDisc");
        this.put("\u5176\u4ed6", "isQtDisc");
    }
}
