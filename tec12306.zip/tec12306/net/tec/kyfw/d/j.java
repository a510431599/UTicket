// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.time.LocalDate;
import net.tec.kyfw.util.p;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class j extends SelectedProperty
{
    private StringProperty simpleDate;
    private StringProperty date;
    
    public j(final String s, final String s2) {
        this.simpleDate = (StringProperty)new SimpleStringProperty();
        this.date = (StringProperty)new SimpleStringProperty();
        this.simpleDate.set((Object)s);
        this.date.set((Object)s2);
    }
    
    public String getSimpleDate() {
        return (String)((this.simpleDate != null) ? this.simpleDate.get() : "");
    }
    
    public void setSimpleDate(final String s) {
        this.simpleDate.set((Object)s);
    }
    
    public String getDate() {
        return (String)((this.date != null) ? this.date.get() : "");
    }
    
    public void setDate(final String s) {
        this.date.set((Object)s);
    }
    
    @Override
    public String toString() {
        return this.getSimpleDate() + "," + this.getDate();
    }
    
    public static List<j> stringToList(final String s) {
        List<j> list = null;
        if (p.b((Object)s)) {
            final LocalDate now = LocalDate.now();
            list = new ArrayList<j>();
            final String[] split = s.split("\\|");
            for (int i = 0; i < split.length; ++i) {
                final String[] split2 = split[i].split(",");
                final LocalDate parse = LocalDate.parse(split2[1], DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                if (parse.isAfter(now) || parse.equals(now)) {
                    list.add(new j(split2[0], split2[1]));
                }
            }
        }
        return list;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof j && this.getSimpleDate().equals(((j)o).getSimpleDate());
    }
    
    @Override
    public String getItemValue() {
        return this.getSimpleDate();
    }
    
    @Override
    public String getRegex() {
        return this.getSimpleDate() + "|" + this.getDate();
    }
}
