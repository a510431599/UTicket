// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.InvocationTargetException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.tec.kyfw.util.p;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import java.util.Map;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class g extends SelectedProperty
{
    private StringProperty buttonTextInfo;
    private StringProperty stationTrainCode;
    private StringProperty trainNo;
    private StringProperty startStationTelecode;
    private StringProperty startTrainDate;
    private StringProperty trainDate;
    private StringProperty endStationTelecode;
    private StringProperty fromStationName;
    private StringProperty fromStationTelecode;
    private StringProperty fromStationNo;
    private StringProperty startTime;
    private StringProperty toStationName;
    private StringProperty toStationTelecode;
    private StringProperty toStationNo;
    private StringProperty arriveTime;
    private StringProperty lishi;
    private StringProperty swz;
    private StringProperty tz;
    private StringProperty zy;
    private StringProperty ze;
    private StringProperty gr;
    private StringProperty rw;
    private StringProperty yw;
    private StringProperty rz;
    private StringProperty yz;
    private StringProperty wz;
    private StringProperty qt;
    private StringProperty gg;
    private StringProperty yb;
    private StringProperty canWebBuy;
    private StringProperty isSupportCard;
    private StringProperty locationCode;
    private StringProperty seatTypes;
    private StringProperty trainSeatFeature;
    private StringProperty ypEx;
    private StringProperty ypInfo;
    private StringProperty secretStr;
    private BooleanProperty priorTrain;
    private BooleanProperty visible;
    private BooleanProperty canTimingBuy;
    private StringProperty dayDifference;
    private StringProperty saleTime;
    public static Map<String, String> methods;
    public static Map<String, String> methods_disc;
    private String submitFlag;
    private String ticket;
    private String passengerTicketStr;
    private String oldPassengerStr;
    
    public g(final String stationTrainCode) {
        this.buttonTextInfo = (StringProperty)new SimpleStringProperty();
        this.stationTrainCode = (StringProperty)new SimpleStringProperty();
        this.trainNo = (StringProperty)new SimpleStringProperty();
        this.startStationTelecode = (StringProperty)new SimpleStringProperty();
        this.startTrainDate = (StringProperty)new SimpleStringProperty();
        this.trainDate = (StringProperty)new SimpleStringProperty();
        this.endStationTelecode = (StringProperty)new SimpleStringProperty();
        this.fromStationName = (StringProperty)new SimpleStringProperty();
        this.fromStationTelecode = (StringProperty)new SimpleStringProperty();
        this.fromStationNo = (StringProperty)new SimpleStringProperty();
        this.startTime = (StringProperty)new SimpleStringProperty();
        this.toStationName = (StringProperty)new SimpleStringProperty();
        this.toStationTelecode = (StringProperty)new SimpleStringProperty();
        this.toStationNo = (StringProperty)new SimpleStringProperty();
        this.arriveTime = (StringProperty)new SimpleStringProperty();
        this.lishi = (StringProperty)new SimpleStringProperty();
        this.swz = (StringProperty)new SimpleStringProperty();
        this.tz = (StringProperty)new SimpleStringProperty();
        this.zy = (StringProperty)new SimpleStringProperty();
        this.ze = (StringProperty)new SimpleStringProperty();
        this.gr = (StringProperty)new SimpleStringProperty();
        this.rw = (StringProperty)new SimpleStringProperty();
        this.yw = (StringProperty)new SimpleStringProperty();
        this.rz = (StringProperty)new SimpleStringProperty();
        this.yz = (StringProperty)new SimpleStringProperty();
        this.wz = (StringProperty)new SimpleStringProperty();
        this.qt = (StringProperty)new SimpleStringProperty();
        this.gg = (StringProperty)new SimpleStringProperty();
        this.yb = (StringProperty)new SimpleStringProperty();
        this.canWebBuy = (StringProperty)new SimpleStringProperty();
        this.isSupportCard = (StringProperty)new SimpleStringProperty();
        this.locationCode = (StringProperty)new SimpleStringProperty();
        this.seatTypes = (StringProperty)new SimpleStringProperty();
        this.trainSeatFeature = (StringProperty)new SimpleStringProperty();
        this.ypEx = (StringProperty)new SimpleStringProperty();
        this.ypInfo = (StringProperty)new SimpleStringProperty();
        this.secretStr = (StringProperty)new SimpleStringProperty();
        this.priorTrain = (BooleanProperty)new SimpleBooleanProperty(false);
        this.visible = (BooleanProperty)new SimpleBooleanProperty(true);
        this.canTimingBuy = (BooleanProperty)new SimpleBooleanProperty(false);
        this.dayDifference = (StringProperty)new SimpleStringProperty();
        this.saleTime = (StringProperty)new SimpleStringProperty();
        this.setStationTrainCode(stationTrainCode);
    }
    
    public g(final String buttonTextInfo, final String stationTrainCode, final String trainNo, final String startStationTelecode, final String startTrainDate, final String trainDate, final String endStationTelecode, final String fromStationName, final String fromStationTelecode, final String fromStationNo, final String startTime, final String toStationName, final String toStationTelecode, final String toStationNo, final String arriveTime, final String lishi, final String swz, final String tz, final String zy, final String ze, final String gr, final String rw, final String yw, final String rz, final String yz, final String wz, final String qt, final String gg, final String yb, final String canWebBuy, final String isSupportCard, final String locationCode, final String seatTypes, final String trainSeatFeature, final String ypEx, final String ypInfo, final String secretStr) {
        this.buttonTextInfo = (StringProperty)new SimpleStringProperty();
        this.stationTrainCode = (StringProperty)new SimpleStringProperty();
        this.trainNo = (StringProperty)new SimpleStringProperty();
        this.startStationTelecode = (StringProperty)new SimpleStringProperty();
        this.startTrainDate = (StringProperty)new SimpleStringProperty();
        this.trainDate = (StringProperty)new SimpleStringProperty();
        this.endStationTelecode = (StringProperty)new SimpleStringProperty();
        this.fromStationName = (StringProperty)new SimpleStringProperty();
        this.fromStationTelecode = (StringProperty)new SimpleStringProperty();
        this.fromStationNo = (StringProperty)new SimpleStringProperty();
        this.startTime = (StringProperty)new SimpleStringProperty();
        this.toStationName = (StringProperty)new SimpleStringProperty();
        this.toStationTelecode = (StringProperty)new SimpleStringProperty();
        this.toStationNo = (StringProperty)new SimpleStringProperty();
        this.arriveTime = (StringProperty)new SimpleStringProperty();
        this.lishi = (StringProperty)new SimpleStringProperty();
        this.swz = (StringProperty)new SimpleStringProperty();
        this.tz = (StringProperty)new SimpleStringProperty();
        this.zy = (StringProperty)new SimpleStringProperty();
        this.ze = (StringProperty)new SimpleStringProperty();
        this.gr = (StringProperty)new SimpleStringProperty();
        this.rw = (StringProperty)new SimpleStringProperty();
        this.yw = (StringProperty)new SimpleStringProperty();
        this.rz = (StringProperty)new SimpleStringProperty();
        this.yz = (StringProperty)new SimpleStringProperty();
        this.wz = (StringProperty)new SimpleStringProperty();
        this.qt = (StringProperty)new SimpleStringProperty();
        this.gg = (StringProperty)new SimpleStringProperty();
        this.yb = (StringProperty)new SimpleStringProperty();
        this.canWebBuy = (StringProperty)new SimpleStringProperty();
        this.isSupportCard = (StringProperty)new SimpleStringProperty();
        this.locationCode = (StringProperty)new SimpleStringProperty();
        this.seatTypes = (StringProperty)new SimpleStringProperty();
        this.trainSeatFeature = (StringProperty)new SimpleStringProperty();
        this.ypEx = (StringProperty)new SimpleStringProperty();
        this.ypInfo = (StringProperty)new SimpleStringProperty();
        this.secretStr = (StringProperty)new SimpleStringProperty();
        this.priorTrain = (BooleanProperty)new SimpleBooleanProperty(false);
        this.visible = (BooleanProperty)new SimpleBooleanProperty(true);
        this.canTimingBuy = (BooleanProperty)new SimpleBooleanProperty(false);
        this.dayDifference = (StringProperty)new SimpleStringProperty();
        this.saleTime = (StringProperty)new SimpleStringProperty();
        this.setStationTrainCode(stationTrainCode);
        this.setTrainNo(trainNo);
        this.setStartStationTelecode(startStationTelecode);
        this.setStartTrainDate(startTrainDate);
        this.setTrainDate(trainDate);
        this.setEndStationTelecode(endStationTelecode);
        this.setFromStationName(fromStationName);
        this.setFromStationTelecode(fromStationTelecode);
        this.setFromStationNo(fromStationNo);
        this.setStartTime(startTime);
        this.setToStationName(toStationName);
        this.setToStationTelecode(toStationTelecode);
        this.setToStationNo(toStationNo);
        this.setArriveTime(arriveTime);
        this.setLishi(lishi);
        this.setSwz(swz);
        this.setTz(tz);
        this.setZy(zy);
        this.setZe(ze);
        this.setGr(gr);
        this.setRw(rw);
        this.setYw(yw);
        this.setRz(rz);
        this.setYz(yz);
        this.setWz(wz);
        this.setQt(qt);
        this.setGg(gg);
        this.setYb(yb);
        this.setCanWebBuy(canWebBuy);
        this.setIsSupportCard(isSupportCard);
        this.setLocationCode(locationCode);
        this.setSeatTypes(seatTypes);
        this.setTrainSeatFeature(trainSeatFeature);
        this.setYpEx(ypEx);
        this.setYpInfo(ypInfo);
        this.setSecretStr(secretStr);
        this.DW2GCD();
        this.setButtonTextInfo(buttonTextInfo);
        if (("IS_TIME_NOT_BUY".equals(canWebBuy) || "N".equals(canWebBuy)) && !buttonTextInfo.contains("\u8d77\u552e")) {
            this.setVisible(false);
        }
        else if (buttonTextInfo.contains("\u8d77\u552e") && !this.isCanTimingBuy()) {
            this.setVisible(false);
        }
        String dayDifference = "0";
        final String replace = this.getLishi().replace(":", "");
        final String replace2 = this.getStartTime().replace(":", "");
        int n = Integer.parseInt(replace.substring(0, 2)) + Integer.parseInt(replace2.substring(0, 2));
        if (Integer.parseInt(replace.substring(2, 4)) + Integer.parseInt(replace2.substring(2, 4)) >= 60) {
            ++n;
        }
        if (n >= 24 && n < 48) {
            dayDifference = "1";
        }
        else if (n >= 48 && n < 72) {
            dayDifference = "2";
        }
        else if (n >= 72 && n < 96) {
            dayDifference = "3";
        }
        else if (n >= 96 && n < 120) {
            dayDifference = "4";
        }
        else if (n >= 120 && n < 144) {
            dayDifference = "5";
        }
        this.setDayDifference(dayDifference);
    }
    
    public g(final String stationTrainCode, final String fromStationName, final String toStationName, final String lishi, final String startTime, final String arriveTime) {
        this.buttonTextInfo = (StringProperty)new SimpleStringProperty();
        this.stationTrainCode = (StringProperty)new SimpleStringProperty();
        this.trainNo = (StringProperty)new SimpleStringProperty();
        this.startStationTelecode = (StringProperty)new SimpleStringProperty();
        this.startTrainDate = (StringProperty)new SimpleStringProperty();
        this.trainDate = (StringProperty)new SimpleStringProperty();
        this.endStationTelecode = (StringProperty)new SimpleStringProperty();
        this.fromStationName = (StringProperty)new SimpleStringProperty();
        this.fromStationTelecode = (StringProperty)new SimpleStringProperty();
        this.fromStationNo = (StringProperty)new SimpleStringProperty();
        this.startTime = (StringProperty)new SimpleStringProperty();
        this.toStationName = (StringProperty)new SimpleStringProperty();
        this.toStationTelecode = (StringProperty)new SimpleStringProperty();
        this.toStationNo = (StringProperty)new SimpleStringProperty();
        this.arriveTime = (StringProperty)new SimpleStringProperty();
        this.lishi = (StringProperty)new SimpleStringProperty();
        this.swz = (StringProperty)new SimpleStringProperty();
        this.tz = (StringProperty)new SimpleStringProperty();
        this.zy = (StringProperty)new SimpleStringProperty();
        this.ze = (StringProperty)new SimpleStringProperty();
        this.gr = (StringProperty)new SimpleStringProperty();
        this.rw = (StringProperty)new SimpleStringProperty();
        this.yw = (StringProperty)new SimpleStringProperty();
        this.rz = (StringProperty)new SimpleStringProperty();
        this.yz = (StringProperty)new SimpleStringProperty();
        this.wz = (StringProperty)new SimpleStringProperty();
        this.qt = (StringProperty)new SimpleStringProperty();
        this.gg = (StringProperty)new SimpleStringProperty();
        this.yb = (StringProperty)new SimpleStringProperty();
        this.canWebBuy = (StringProperty)new SimpleStringProperty();
        this.isSupportCard = (StringProperty)new SimpleStringProperty();
        this.locationCode = (StringProperty)new SimpleStringProperty();
        this.seatTypes = (StringProperty)new SimpleStringProperty();
        this.trainSeatFeature = (StringProperty)new SimpleStringProperty();
        this.ypEx = (StringProperty)new SimpleStringProperty();
        this.ypInfo = (StringProperty)new SimpleStringProperty();
        this.secretStr = (StringProperty)new SimpleStringProperty();
        this.priorTrain = (BooleanProperty)new SimpleBooleanProperty(false);
        this.visible = (BooleanProperty)new SimpleBooleanProperty(true);
        this.canTimingBuy = (BooleanProperty)new SimpleBooleanProperty(false);
        this.dayDifference = (StringProperty)new SimpleStringProperty();
        this.saleTime = (StringProperty)new SimpleStringProperty();
        this.setStationTrainCode(stationTrainCode);
        this.setFromStationName(fromStationName);
        this.setToStationName(toStationName);
        this.setLishi(lishi);
        this.setStartTime(startTime);
        this.setArriveTime(arriveTime);
    }
    
    public String getTrainInfo() {
        return p.b(this.getFromStationName()) + "\r\n" + p.b(this.getToStationName()) + "\r\n" + this.getStartStationTelecode().equals(this.getFromStationTelecode()) + "\r\n" + this.getEndStationTelecode().equals(this.getToStationTelecode());
    }
    
    public String getTimeTable() {
        return p.b(this.getStartTime()) + "\r\n" + p.b(this.getArriveTime());
    }
    
    public String getTrainType() {
        String s;
        if (this.getStationTrainCode().startsWith("G")) {
            s = "\u9ad8\u901f\u5217\u8f66";
        }
        else if (this.getStationTrainCode().startsWith("D")) {
            s = "\u52a8\u8f66\u7ec4";
        }
        else if (this.getStationTrainCode().startsWith("K")) {
            s = "\u5feb\u901f\u5217\u8f66";
        }
        else if (this.getStationTrainCode().startsWith("T")) {
            s = "\u7279\u5feb\u5217\u8f66";
        }
        else if (this.getStationTrainCode().startsWith("Z")) {
            s = "\u76f4\u8fbe\u5217\u8f66";
        }
        else if (this.getStationTrainCode().startsWith("C")) {
            s = "\u57ce\u9645\u5217\u8f66";
        }
        else if (this.getStationTrainCode().startsWith("L")) {
            s = "\u4e34\u5ba2\u5217\u8f66";
        }
        else {
            s = "\u666e\u901f\u5217\u8f66";
        }
        return s;
    }
    
    public String getLishiShow() {
        String s = "\u5f53\u65e5\u5230\u8fbe";
        final int int1 = Integer.parseInt(this.getDayDifference());
        if (int1 == 1) {
            s = "\u6b21\u65e5\u5230\u8fbe";
        }
        else if (int1 == 2) {
            s = "\u4e24\u65e5\u5230\u8fbe";
        }
        else if (int1 == 3) {
            s = "\u4e09\u65e5\u5230\u8fbe";
        }
        else if (int1 == 4) {
            s = "\u56db\u65e5\u5230\u8fbe";
        }
        else if (int1 == 4) {
            s = "\u4e94\u65e5\u5230\u8fbe";
        }
        return this.getLishi() + "\n" + s;
    }
    
    public boolean isCRHDW() {
        return Pattern.compile("[78FA]+").matcher(this.getSeatTypes()).find();
    }
    
    public boolean isCRHGCD() {
        return Pattern.compile("[OMP9]+").matcher(this.getSeatTypes()).find();
    }
    
    public void DW2GCD() {
        if (this.isCRHDW()) {
            final StringBuffer sb = new StringBuffer(this.getYpEx());
            int i = 0;
            final boolean b = false;
            while (i < sb.length()) {
                final int n = i + 1;
                final String substring = sb.substring(i, n);
                if (substring.equals("8")) {
                    if ((b ? 1 : 0) == i) {
                        sb.replace(i, n, "1");
                    }
                    else {
                        sb.replace(i, n, "O");
                    }
                }
                else if (substring.equals("7")) {
                    sb.replace(i, n, "M");
                }
                else if (substring.equals("F")) {
                    sb.replace(i, n, "4");
                }
                else if (substring.equals("A")) {
                    sb.replace(i, n, "6");
                }
                ++i;
            }
            this.setYpEx(sb.toString());
        }
    }
    
    public String getButtonTextInfo() {
        return (String)this.buttonTextInfo.get();
    }
    
    public void setButtonTextInfo(String replace) {
        if (replace.contains("\u7cfb\u7edf\u7ef4\u62a4\u65f6\u95f4")) {
            replace = "\u7ef4\u62a4\u65f6\u6bb5";
        }
        else if (replace.contains("\u8d77\u552e")) {
            if ("Y".equals(this.canWebBuy.get())) {
                replace = "\u9884\u8ba2";
            }
            else {
                if (replace.contains("\u5206")) {
                    final Matcher matcher = Pattern.compile("(?s)(?i)(\\d{1,2})(?:\u70b9)(\\d{1,2})(?:\u5206)").matcher(replace);
                    if (matcher.find()) {
                        this.setSaleTime(p.a(matcher.group(1), 2) + p.a(matcher.group(2), 2));
                    }
                    replace = replace.replace("\u5206", "").replace("\u70b9", ":");
                    this.setCanTimingBuy(true);
                }
                else if (replace.contains("\u70b9")) {
                    this.setCanTimingBuy(true);
                    final Matcher matcher2 = Pattern.compile("(?s)(?i)(\\d{1,2})(?:\u70b9)").matcher(replace);
                    if (matcher2.find()) {
                        this.setSaleTime(p.a(matcher2.group(1), 2) + "00");
                    }
                }
                if (replace.contains("\u65e5")) {
                    this.setCanTimingBuy(false);
                }
            }
        }
        else if (replace.contains("\u5217\u8f66\u8fd0\u884c\u56fe\u8c03\u6574")) {
            replace = "\u5217\u8f66\u8fd0\u884c\u56fe\u8c03\r\n\u6574\uff0c\u6682\u505c\u53d1\u552e";
        }
        this.buttonTextInfo.set((Object)replace);
    }
    
    public String getStationTrainCode() {
        return (String)this.stationTrainCode.get();
    }
    
    public void setStationTrainCode(final String s) {
        this.stationTrainCode.set((Object)s);
    }
    
    public String getTrainNo() {
        return (String)this.trainNo.get();
    }
    
    public void setTrainNo(final String s) {
        this.trainNo.set((Object)s);
    }
    
    public String getStartStationTelecode() {
        return (String)this.startStationTelecode.get();
    }
    
    public void setStartStationTelecode(final String s) {
        this.startStationTelecode.set((Object)s);
    }
    
    public String getStartTrainDate() {
        return (String)this.startTrainDate.get();
    }
    
    public void setStartTrainDate(final String s) {
        this.startTrainDate.set((Object)s);
    }
    
    public String getTrainDate() {
        return (String)this.trainDate.get();
    }
    
    public void setTrainDate(final String s) {
        this.trainDate.set((Object)s);
    }
    
    public String getEndStationTelecode() {
        return (String)this.endStationTelecode.get();
    }
    
    public void setEndStationTelecode(final String s) {
        this.endStationTelecode.set((Object)s);
    }
    
    public String getFromStationName() {
        return (String)this.fromStationName.get();
    }
    
    public void setFromStationName(final String s) {
        this.fromStationName.set((Object)s);
    }
    
    public String getFromStationTelecode() {
        return (String)this.fromStationTelecode.get();
    }
    
    public void setFromStationTelecode(final String s) {
        this.fromStationTelecode.set((Object)s);
    }
    
    public String getFromStationNo() {
        return (String)this.fromStationNo.get();
    }
    
    public void setFromStationNo(final String s) {
        this.fromStationNo.set((Object)s);
    }
    
    public String getStartTime() {
        return (String)this.startTime.get();
    }
    
    public void setStartTime(final String s) {
        this.startTime.set((Object)s);
    }
    
    public String getToStationName() {
        return (String)this.toStationName.get();
    }
    
    public void setToStationName(final String s) {
        this.toStationName.set((Object)s);
    }
    
    public String getToStationTelecode() {
        return (String)this.toStationTelecode.get();
    }
    
    public void setToStationTelecode(final String s) {
        this.toStationTelecode.set((Object)s);
    }
    
    public String getToStationNo() {
        return (String)this.toStationNo.get();
    }
    
    public void setToStationNo(final String s) {
        this.toStationNo.set((Object)s);
    }
    
    public String getArriveTime() {
        return (String)this.arriveTime.get();
    }
    
    public void setArriveTime(final String s) {
        this.arriveTime.set((Object)s);
    }
    
    public String getLishi() {
        return (String)this.lishi.get();
    }
    
    public void setLishi(final String s) {
        this.lishi.set((Object)s);
    }
    
    public String getSaleTime() {
        return (String)this.saleTime.get();
    }
    
    public void setSaleTime(final String s) {
        this.saleTime.set((Object)s);
    }
    
    public String getSwz() {
        return (String)this.swz.get();
    }
    
    public void setSwz(final String s) {
        this.swz.set((Object)s);
    }
    
    public String getTz() {
        return (String)this.tz.get();
    }
    
    public void setTz(final String s) {
        this.tz.set((Object)s);
    }
    
    public String getZy() {
        return (String)this.zy.get();
    }
    
    public void setZy(final String s) {
        this.zy.set((Object)s);
    }
    
    public String getZe() {
        return (String)this.ze.get();
    }
    
    public void setZe(final String s) {
        this.ze.set((Object)s);
    }
    
    public String getGr() {
        return (String)this.gr.get();
    }
    
    public void setGr(final String s) {
        this.gr.set((Object)s);
    }
    
    public String getRw() {
        return (String)this.rw.get();
    }
    
    public void setRw(final String s) {
        this.rw.set((Object)s);
    }
    
    public String getYw() {
        return (String)this.yw.get();
    }
    
    public void setYw(final String s) {
        this.yw.set((Object)s);
    }
    
    public String getRz() {
        return (String)this.rz.get();
    }
    
    public void setRz(final String s) {
        this.rz.set((Object)s);
    }
    
    public String getYz() {
        return (String)this.yz.get();
    }
    
    public void setYz(final String s) {
        this.yz.set((Object)s);
    }
    
    public String getWz() {
        return (String)this.wz.get();
    }
    
    public void setWz(final String s) {
        this.wz.set((Object)s);
    }
    
    public String getQt() {
        return (String)this.qt.get();
    }
    
    public void setQt(final String s) {
        this.qt.set((Object)s);
    }
    
    public String getGg() {
        return (String)this.gg.get();
    }
    
    public void setGg(final String s) {
        this.gg.set((Object)s);
    }
    
    public String getYb() {
        return (String)this.yb.get();
    }
    
    public void setYb(final String s) {
        this.yb.set((Object)s);
    }
    
    public String getCanWebBuy() {
        return (String)this.canWebBuy.get();
    }
    
    public void setCanWebBuy(final String s) {
        this.canWebBuy.set((Object)s);
    }
    
    public String getDayDifference() {
        return (String)this.dayDifference.get();
    }
    
    public void setDayDifference(final String s) {
        this.dayDifference.set((Object)s);
    }
    
    public String getIsSupportCard() {
        return (String)this.isSupportCard.get();
    }
    
    public void setIsSupportCard(final String s) {
        this.isSupportCard.set((Object)s);
    }
    
    public String getLocationCode() {
        return (String)this.locationCode.get();
    }
    
    public void setLocationCode(final String s) {
        this.locationCode.set((Object)s);
    }
    
    public String getSeatTypes() {
        return (String)this.seatTypes.get();
    }
    
    public void setSeatTypes(final String s) {
        this.seatTypes.set((Object)s);
    }
    
    public String getTrainSeatFeature() {
        return (String)this.trainSeatFeature.get();
    }
    
    public void setTrainSeatFeature(final String s) {
        this.trainSeatFeature.set((Object)s);
    }
    
    public String getYpEx() {
        return (String)this.ypEx.get();
    }
    
    public void setYpEx(final String s) {
        this.ypEx.set((Object)s);
    }
    
    public String getYpInfo() {
        return (String)this.ypInfo.get();
    }
    
    public void setYpInfo(final String s) {
        this.ypInfo.set((Object)s);
    }
    
    public String getSecretStr() {
        try {
            return (this.secretStr.get() != null) ? URLDecoder.decode((String)this.secretStr.get(), "UTF-8") : "";
        }
        catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
            return (String)this.secretStr.get();
        }
    }
    
    public void setSecretStr(final String s) {
        this.secretStr.set((Object)s);
    }
    
    public void setCanTimingBuy(final Boolean b) {
        this.canTimingBuy.set((boolean)b);
    }
    
    public Boolean isCanTimingBuy() {
        return this.canTimingBuy.get();
    }
    
    public void setVisible(final Boolean b) {
        this.visible.set((boolean)b);
    }
    
    public Boolean isVisible() {
        return this.visible.get();
    }
    
    public void setPriorTrain(final Boolean b) {
        this.priorTrain.set((boolean)b);
    }
    
    public Boolean getPriorTrain() {
        return this.priorTrain.get();
    }
    
    @Override
    public String getItemValue() {
        return this.getStationTrainCode();
    }
    
    @Override
    public String getItemDisplayText() {
        return this.getStationTrainCode() + "  " + this.getFromStationName() + "[" + this.getStartTime() + "] -> " + this.getToStationName() + "[" + this.getArriveTime() + "]";
    }
    
    public Boolean isSwzDisc() {
        return this.getYpEx().contains("91");
    }
    
    public Boolean isTzDisc() {
        return this.getYpEx().contains("P1");
    }
    
    public Boolean isZyDisc() {
        return this.getYpEx().contains("M1");
    }
    
    public Boolean isZeDisc() {
        return this.getYpEx().contains("O1") && this.getYpEx().indexOf("O1") != 0;
    }
    
    public Boolean isGrDisc() {
        return this.getYpEx().contains("61");
    }
    
    public Boolean isRwDisc() {
        return this.getYpEx().contains("41");
    }
    
    public Boolean isYwDisc() {
        return this.getYpEx().contains("31");
    }
    
    public Boolean isRzDisc() {
        return this.getYpEx().contains("21");
    }
    
    public Boolean isYzDisc() {
        return this.getYpEx().contains("11") && this.getYpEx().indexOf("11") != 0;
    }
    
    public Boolean isWzDisc() {
        return this.getYpEx().startsWith("11") || this.getYpEx().startsWith("O1");
    }
    
    public Boolean isQtDisc() {
        return Boolean.TRUE;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof g && this.getStationTrainCode().equals(((g)o).getStationTrainCode());
    }
    
    @Override
    public String toString() {
        return this.getStationTrainCode();
    }
    
    public <T> T invoke(final String s) {
        Object invoke = null;
        try {
            invoke = this.getClass().getMethod(s, (Class<?>[])new Class[0]).invoke(this, new Object[0]);
        }
        catch (NoSuchMethodException | SecurityException ex4) {
            final Throwable t;
            t.printStackTrace();
        }
        catch (IllegalAccessException ex) {
            ex.printStackTrace();
        }
        catch (IllegalArgumentException ex2) {
            ex2.printStackTrace();
        }
        catch (InvocationTargetException ex3) {
            ex3.printStackTrace();
        }
        return (T)invoke;
    }
    
    public static List<g> stringToList(final String s) {
        List<g> list = null;
        if (p.b((Object)s)) {
            list = new ArrayList<g>();
            final String[] split = s.split("\\|");
            for (int i = 0; i < split.length; ++i) {
                list.add(new g(split[i].split(",")[0]));
            }
        }
        return list;
    }
    
    public String getSubmitFlag() {
        return this.submitFlag;
    }
    
    public void setSubmitFlag(final String submitFlag) {
        this.submitFlag = submitFlag;
    }
    
    public String getTicket() {
        return this.ticket;
    }
    
    public void setTicket(final String ticket) {
        this.ticket = ticket;
    }
    
    public String getPassengerTicketStr() {
        return this.passengerTicketStr;
    }
    
    public void setPassengerTicketStr(final String passengerTicketStr) {
        this.passengerTicketStr = passengerTicketStr;
    }
    
    public String getOldPassengerStr() {
        return this.oldPassengerStr;
    }
    
    public void setOldPassengerStr(final String oldPassengerStr) {
        this.oldPassengerStr = oldPassengerStr;
    }
    
    static {
        g.methods = new h();
        g.methods_disc = new i();
    }
}
