// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import java.util.ArrayList;
import net.tec.kyfw.util.p;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.control.bean.SelectedProperty;

public class e extends SelectedProperty
{
    private StringProperty seatName;
    private StringProperty seatNo;
    private StringProperty ticketNum;
    
    public e(final String s, final String s2) {
        this.seatName = (StringProperty)new SimpleStringProperty();
        this.seatNo = (StringProperty)new SimpleStringProperty();
        this.ticketNum = (StringProperty)new SimpleStringProperty();
        this.seatName.set((Object)s);
        this.seatNo.set((Object)s2);
    }
    
    public e(final String s, final String s2, final String s3) {
        this.seatName = (StringProperty)new SimpleStringProperty();
        this.seatNo = (StringProperty)new SimpleStringProperty();
        this.ticketNum = (StringProperty)new SimpleStringProperty();
        this.seatName.set((Object)s);
        this.seatNo.set((Object)s2);
        this.ticketNum.set((Object)s3);
    }
    
    public String getTicketNum() {
        return (String)((this.ticketNum != null) ? this.ticketNum.get() : "0");
    }
    
    public void setTicketNum(final String s) {
        this.ticketNum.set((Object)s);
    }
    
    public String getSeatName() {
        return (String)((this.seatName != null) ? this.seatName.get() : "");
    }
    
    public void setSeatName(final String s) {
        this.seatName.set((Object)s);
    }
    
    public String getSeatNo() {
        return (String)((this.seatNo != null) ? this.seatNo.get() : "");
    }
    
    public void setSeatNo(final String s) {
        this.seatNo.set((Object)s);
    }
    
    @Override
    public String toString() {
        return this.getSeatName() + "," + this.getSeatNo();
    }
    
    public static List<e> stringToList(final String s) {
        List<e> list = null;
        if (p.b((Object)s)) {
            list = new ArrayList<e>();
            final String[] split = s.split("\\|");
            for (int i = 0; i < split.length; ++i) {
                final String[] split2 = split[i].split(",");
                list.add(new e(split2[0], split2[1]));
            }
        }
        return list;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof e && this.getSeatName().equals(((e)o).getSeatName());
    }
    
    @Override
    public String getItemValue() {
        return this.getSeatName();
    }
}
