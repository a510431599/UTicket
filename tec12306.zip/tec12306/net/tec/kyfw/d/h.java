// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.d;

import java.util.HashMap;

final class h extends HashMap<String, String>
{
    private static final long serialVersionUID = -580949055004882783L;
    
    h() {
        this.put("\u4e8c\u7b49\u5ea7", "getZe");
        this.put("\u4e00\u7b49\u5ea7", "getZy");
        this.put("\u7279\u7b49\u5ea7", "getTz");
        this.put("\u786c\u5367", "getYw");
        this.put("\u786c\u5ea7", "getYz");
        this.put("\u8f6f\u5367", "getRw");
        this.put("\u8f6f\u5ea7", "getRz");
        this.put("\u9ad8\u7ea7\u8f6f\u5367", "getGr");
        this.put("\u5546\u52a1\u5ea7", "getSwz");
        this.put("\u65e0\u5ea7", "getWz");
        this.put("\u5176\u4ed6", "getQt");
        this.put("O", "getZe");
        this.put("M", "getZy");
        this.put("P", "getTz");
        this.put("3", "getYw");
        this.put("1", "getYz");
        this.put("F", "getRw");
        this.put("4", "getRw");
        this.put("2", "getRz");
        this.put("6", "getGr");
        this.put("9", "getSwz");
        this.put("W", "getWz");
        this.put("H", "getQt");
    }
}
