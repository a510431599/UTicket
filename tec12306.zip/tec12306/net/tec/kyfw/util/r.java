// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.ArrayList;
import java.util.List;
import net.tec.kyfw.d.k;
import java.util.HashMap;
import net.tec.kyfw.d.d;
import java.util.Iterator;
import javafx.control.bean.SelectedProperty;
import java.util.Comparator;
import javafx.collections.ObservableList;
import java.util.Collection;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import net.tec.kyfw.d.g;
import net.tec.kyfw.d.a;
import net.tec.kyfw.e;
import java.util.HashSet;
import java.util.Map;

public class r
{
    public static Map<String, Integer> a;
    
    public static String a(final String s) {
        final String[] split = s.split("_");
        final HashSet<Character> set = new HashSet<Character>();
        for (int i = 0; i < split.length; ++i) {
            set.add(split[i].charAt(0));
        }
        if (set.size() > 1) {
            return "";
        }
        final Character c = set.iterator().next();
        final int length = split.length;
        String[] array = null;
        if (e.a(e.a.GT_CHOOSE_SEAT).equals("\u4f18\u5148\u9760\u7a97")) {
            if (length < 3) {
                switch ((char)c) {
                    case '9':
                    case 'P': {
                        array = new String[] { "A", "C" };
                        break;
                    }
                    case '7':
                    case 'M': {
                        array = new String[] { "A", "C" };
                        break;
                    }
                    case '8':
                    case 'O': {
                        array = new String[] { "F", "D" };
                        break;
                    }
                }
            }
            else {
                switch ((char)c) {
                    case '9':
                    case 'P': {
                        array = new String[] { "A", "C", "F", "A", "C" };
                        break;
                    }
                    case '7':
                    case 'M': {
                        array = new String[] { "A", "C", "D", "F", "A" };
                        break;
                    }
                    case '8':
                    case 'O': {
                        array = new String[] { "A", "B", "C", "D", "F" };
                        break;
                    }
                }
            }
        }
        else if (e.a(e.a.GT_CHOOSE_SEAT).equals("\u4f18\u5148\u8fc7\u9053")) {
            if (length < 3) {
                switch ((char)c) {
                    case '9':
                    case 'P': {
                        array = new String[] { "C", "A" };
                        break;
                    }
                    case '7':
                    case 'M': {
                        array = new String[] { "C", "A" };
                        break;
                    }
                    case '8':
                    case 'O': {
                        array = new String[] { "D", "F" };
                        break;
                    }
                }
            }
            else {
                switch ((char)c) {
                    case '9':
                    case 'P': {
                        array = new String[] { "C", "A", "F", "C", "A" };
                        break;
                    }
                    case '7':
                    case 'M': {
                        array = new String[] { "C", "A", "D", "F", "C" };
                        break;
                    }
                    case '8':
                    case 'O': {
                        array = new String[] { "C", "B", "A", "D", "F" };
                        break;
                    }
                }
            }
        }
        if (array == null) {
            return "";
        }
        final StringBuffer sb = new StringBuffer();
        final int n = 1;
        for (int j = 0; j < length; ++j) {
            sb.append(n).append(array[j]);
        }
        return sb.toString();
    }
    
    public static d a(final d d, final net.tec.kyfw.d.a a) {
        d d2 = null;
        if (a.getPriorOption().equals("\u5e2d\u522b\u4f18\u5148")) {
            final int index = a.getSeatTypeList().indexOf((Object)d.a);
            for (int size = a.getSeatTypeList().size(), i = index; i < size; ++i) {
                for (int size2 = d.c.size(), j = 0; j < size2; ++j) {
                    if (i != index || j > d.c.indexOf((Object)d.b)) {
                        final g b = (g)d.c.get(j);
                        final net.tec.kyfw.d.e a2 = (net.tec.kyfw.d.e)a.getSeatTypeList().get(i);
                        if (c(b, a2.getSeatName()) >= (a.getSubmitOption() ? 1 : a.getPassengerList().size())) {
                            d2 = d;
                            d2.b = b;
                            d2.a = a2;
                            break;
                        }
                    }
                }
                if (d2 != null) {
                    break;
                }
            }
        }
        else {
            final int index2 = d.c.indexOf((Object)d.b);
            for (int size3 = d.c.size(), k = index2; k < size3; ++k) {
                for (int size4 = a.getSeatTypeList().size(), l = 0; l < size4; ++l) {
                    if (k != index2 || l > a.getSeatTypeList().indexOf((Object)d.a)) {
                        final g b2 = (g)d.c.get(k);
                        final net.tec.kyfw.d.e a3 = (net.tec.kyfw.d.e)a.getSeatTypeList().get(l);
                        if (c(b2, a3.getSeatName()) >= (a.getSubmitOption() ? 1 : a.getPassengerList().size())) {
                            d2 = d;
                            d2.b = b2;
                            d2.a = a3;
                            break;
                        }
                    }
                }
                if (d2 != null) {
                    break;
                }
            }
        }
        return d2;
    }
    
    public static d a(final FilteredList<g> list, final net.tec.kyfw.d.a a, final Map<String, String> map) {
        net.tec.kyfw.d.e a2 = null;
        final boolean booleanValue = a.getSubmitOption();
        final int size = a.getPassengerList().size();
        final ObservableList observableArrayList = FXCollections.observableArrayList((Collection)list);
        g b = null;
        try {
            ObservableList list2;
            if (a.getTrainLimit()) {
                list2 = FXCollections.observableArrayList();
            }
            else {
                list2 = a.getTrainList();
            }
            final ObservableList<net.tec.kyfw.d.e> seatTypeList = a.getSeatTypeList();
            final String priorOption = a.getPriorOption();
            if (!list2.isEmpty()) {
                FXCollections.sort(observableArrayList, (Comparator)new c((javafx.collections.ObservableList<Object>)list2));
            }
            if (seatTypeList.isEmpty()) {
                boolean b2 = false;
                for (final SelectedProperty selectedProperty : list2) {
                    for (final g g : observableArrayList) {
                        if (selectedProperty.getItemValue().endsWith(g.getStationTrainCode())) {
                            a2 = a(b, a.getSubmitOption(), a.getPassengerList().size(), map.get(g.getStationTrainCode()));
                            if (a2 != null) {
                                b = g;
                                b2 = true;
                                break;
                            }
                            continue;
                        }
                    }
                    if (b2) {
                        break;
                    }
                }
            }
            else if (list2.isEmpty()) {
                boolean b3 = false;
                for (final SelectedProperty selectedProperty2 : seatTypeList) {
                    for (final g g2 : observableArrayList) {
                        if (map.containsKey(g2.getStationTrainCode()) && map.get(g2.getStationTrainCode()).contains(c(selectedProperty2.getItemValue()))) {
                            continue;
                        }
                        final String s = (String)g2.getClass().getMethod(g.methods.get(selectedProperty2.getItemValue()), (Class<?>[])new Class[0]).invoke(g2, new Object[0]);
                        if (!p.b((Object)s) || s.equals("--") || s.equals("\u65e0") || s.equals("*")) {
                            continue;
                        }
                        if (!s.equals("\u6709") && !booleanValue && Integer.valueOf(s) < size) {
                            continue;
                        }
                        a2 = (net.tec.kyfw.d.e)selectedProperty2;
                        b = g2;
                        b3 = true;
                        break;
                    }
                    if (b3) {
                        break;
                    }
                }
            }
            else if (priorOption.equals("\u5e2d\u522b\u4f18\u5148")) {
                boolean b4 = false;
                for (final SelectedProperty selectedProperty3 : seatTypeList) {
                    for (final SelectedProperty selectedProperty4 : list2) {
                        for (final g g3 : observableArrayList) {
                            if (selectedProperty4.getItemValue().endsWith(g3.getStationTrainCode())) {
                                if (map.containsKey(g3.getStationTrainCode()) && map.get(g3.getStationTrainCode()).contains(c(selectedProperty3.getItemValue()))) {
                                    continue;
                                }
                                final String s2 = (String)g3.getClass().getMethod(g.methods.get(selectedProperty3.getItemValue()), (Class<?>[])new Class[0]).invoke(g3, new Object[0]);
                                if (p.b((Object)s2) && !s2.equals("--") && !s2.equals("\u65e0") && !s2.equals("*")) {
                                    if (!s2.equals("\u6709") && !booleanValue && Integer.valueOf(s2) < size) {
                                        continue;
                                    }
                                    a2 = (net.tec.kyfw.d.e)selectedProperty3;
                                    b = g3;
                                    b4 = true;
                                    break;
                                }
                                else {
                                    if (b4) {
                                        break;
                                    }
                                    continue;
                                }
                            }
                        }
                        if (b4) {
                            break;
                        }
                    }
                    if (b4) {
                        break;
                    }
                }
            }
            else {
                boolean b5 = false;
                for (final SelectedProperty selectedProperty5 : list2) {
                    for (final g g4 : observableArrayList) {
                        if (selectedProperty5.getItemValue().endsWith(g4.getStationTrainCode())) {
                            for (final SelectedProperty selectedProperty6 : seatTypeList) {
                                if (map.containsKey(g4.getStationTrainCode()) && map.get(g4.getStationTrainCode()).contains(c(selectedProperty6.getItemValue()))) {
                                    continue;
                                }
                                final String s3 = (String)g4.getClass().getMethod(g.methods.get(selectedProperty6.getItemValue()), (Class<?>[])new Class[0]).invoke(g4, new Object[0]);
                                if (!p.b((Object)s3) || s3.equals("--") || s3.equals("\u65e0") || s3.equals("*")) {
                                    continue;
                                }
                                if (!s3.equals("\u6709") && !booleanValue && Integer.valueOf(s3) < size) {
                                    continue;
                                }
                                a2 = (net.tec.kyfw.d.e)selectedProperty6;
                                b = g4;
                                b5 = true;
                                break;
                            }
                            break;
                        }
                    }
                    if (b5) {
                        break;
                    }
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        d d = null;
        if (a2 != null) {
            d = new d();
            d.a = a2;
            d.b = b;
            d.c = (ObservableList<g>)observableArrayList;
        }
        return d;
    }
    
    public static net.tec.kyfw.d.e a(final g g, final boolean b, final int n, final String s) {
        String s2 = "";
        String s3 = "";
        final String[] split = g.getYpEx().split("|");
        final String[] array = new String[11];
        final String[] array2 = new String[11];
        for (int i = 0; i < split.length; i += 2) {
            String s4 = split[i];
            if (i == 0 && (s4.equals("1") || (s4.equals("O") && g.getYpEx().lastIndexOf("O") != i))) {
                s4 = "W";
            }
            final String b2 = b(s4);
            array2[r.a.get(b2)] = s4;
            array[r.a.get(b2)] = b2;
        }
        for (int j = 0; j < array.length; ++j) {
            if (array[j] != null) {
                if (!p.b((Object)s) || !s.contains(array2[j])) {
                    final String s5 = g.invoke(g.methods.get(array[j]));
                    if (p.b((Object)s5) && !s5.equals("\u65e0") && !s5.equals("*")) {
                        if (s5.equals("\u6709") || b || Integer.valueOf(s5) >= n) {
                            s2 = array[j];
                            s3 = array2[j];
                            break;
                        }
                    }
                }
            }
        }
        net.tec.kyfw.d.e e = null;
        if (p.b((Object)s2)) {
            e = new net.tec.kyfw.d.e(s2, s3);
        }
        return e;
    }
    
    public static <T extends SelectedProperty> ObservableList<T> a(final ObservableList<T> list) {
        if (list == null) {
            return null;
        }
        final ObservableList observableArrayList = FXCollections.observableArrayList();
        for (int i = 0; i < list.size(); ++i) {
            observableArrayList.add((Object)((SelectedProperty)list.get(i)).cloneNewInstance());
        }
        return (ObservableList<T>)observableArrayList;
    }
    
    public static String a(final Integer n, final Integer n2) {
        Integer n3 = n2;
        String s = "";
        final Integer value = n3 / 3600;
        if (value > 0) {
            s = value + "\u5c0f\u65f6";
            n3 %= 3600;
        }
        final Integer value2 = n3 / 60;
        if (value2 >= 1) {
            s = s + value2 + "\u5206";
            n3 %= 60;
        }
        else if (value >= 1 && n3 > 0) {
            s += "0\u5206";
        }
        if (n3 > 0) {
            s = s + n3 + "\u79d2";
        }
        String s2;
        if (n2 <= 5) {
            s2 = "\u6392\u961f\u4e2d,\u6b63\u5728\u5904\u7406...";
        }
        else if (n2 > 1800) {
            s2 = "\u6392\u961f\u4e2d,\u60a8\u524d\u9762\u8fd8\u6709" + n + "\u4eba,\u7b49\u5f85\u65f6\u95f4\u5927\u4e8e30\u5206\u949f";
        }
        else {
            s2 = "\u6392\u961f\u4e2d,\u60a8\u524d\u9762\u8fd8\u6709" + n + "\u4eba,\u7b49\u5f85\u7ea6" + s;
        }
        if (s2.endsWith("\u5206")) {
            s2 += "\u949f";
        }
        return s2;
    }
    
    public static String a(final Integer n) {
        Integer n2 = n;
        String s = "";
        final Integer value = n2 / 3600;
        if (value > 0) {
            s = value + "\u5c0f\u65f6";
            n2 %= 3600;
        }
        final Integer value2 = n2 / 60;
        if (value2 >= 1) {
            s = s + value2 + "\u5206";
            n2 %= 60;
        }
        else if (value >= 1 && n2 > 0) {
            s += "0\u5206";
        }
        if (n2 > 0) {
            s = s + n2 + "\u79d2";
        }
        String s2;
        if (n <= 5) {
            s2 = "\u6392\u961f\u4e2d,\u6b63\u5728\u5904\u7406...";
        }
        else {
            s2 = "\u6392\u961f\u4e2d,\u7b49\u5f85\u7ea6" + s;
        }
        if (s2.endsWith("\u5206")) {
            s2 += "\u949f";
        }
        return s2;
    }
    
    public static String[] a(final g g, final ObservableList<net.tec.kyfw.d.d> list, final Boolean b) {
        final StringBuffer sb = new StringBuffer();
        final StringBuffer sb2 = new StringBuffer();
        if (list != null && !list.isEmpty()) {
            final HashMap<Object, Integer> hashMap = new HashMap<Object, Integer>();
            for (int i = 0; i < list.size(); ++i) {
                final int sumSeatNum = b(g, c(((net.tec.kyfw.d.d)list.get(i)).getSeatType())).sumSeatNum();
                if (b) {
                    if (sumSeatNum <= 0) {
                        continue;
                    }
                    if (hashMap.containsKey(((net.tec.kyfw.d.d)list.get(i)).getSeatType()) && sumSeatNum <= hashMap.get(((net.tec.kyfw.d.d)list.get(i)).getSeatType())) {
                        continue;
                    }
                }
                a(g, (net.tec.kyfw.d.d)list.get(i), sb, sb2);
                if (hashMap.containsKey(((net.tec.kyfw.d.d)list.get(i)).getSeatType())) {
                    hashMap.put(((net.tec.kyfw.d.d)list.get(i)).getSeatType(), hashMap.get(((net.tec.kyfw.d.d)list.get(i)).getSeatType()) + 1);
                }
                else {
                    hashMap.put(((net.tec.kyfw.d.d)list.get(i)).getSeatType(), 1);
                }
            }
            if (sb.toString().equals("")) {
                for (int j = 0; j < list.size(); ++j) {
                    a(g, (net.tec.kyfw.d.d)list.get(j), sb, sb2);
                }
            }
            sb.deleteCharAt(sb.lastIndexOf("_"));
        }
        return new String[] { sb.toString(), sb2.toString() };
    }
    
    private static void a(final g g, final net.tec.kyfw.d.d d, final StringBuffer sb, final StringBuffer sb2) {
        sb.append(String.format("%s,0,%s,%s,%s,%s,%s," + ("resign".equals(g.getSubmitFlag()) ? "Y" : "N") + "_", e(g, d.getSeatType()), r.a.getValue(d.getPassengerType()), d.getName(), r.a.getValue(d.getCardType()), d.getCardCode(), d.getMobileNo()));
        sb2.append(String.format("%s,%s,%s,%s_", d.getName(), r.a.getValue(d.getCardType()), d.getCardCode(), r.a.getValue(d.getPassengerType())));
    }
    
    public static Map<String, Integer> a(final g g) {
        final HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
        final String[] split = g.getYpEx().split("|");
        for (int i = 0; i < split.length; i += 2) {
            String s = split[i];
            if (i == 0 && (s.equals("1") || (s.equals("O") && g.getYpEx().lastIndexOf("O") != i))) {
                s = "W";
            }
            hashMap.put(s, a(g, s));
        }
        return hashMap;
    }
    
    public static int a(final g g, final String s) {
        final Object invoke = g.invoke(g.methods.get(s));
        if ("\u65e0".equals(invoke) || "--".equals(invoke) || "*".equals(invoke)) {
            return 0;
        }
        if ("\u6709".equals(invoke)) {
            return Integer.MAX_VALUE;
        }
        return Integer.parseInt(invoke.toString());
    }
    
    public static k b(final g g, final String s) {
        final k k = new k();
        if (s.equals(b.YZ.getValue()) || s.equals(b.ZE.getValue()) || s.equals("W")) {
            final Map<String, Integer> a = a(g);
            if (a.keySet().contains(s)) {
                k.firstSeat = a.get(s);
                if (s.equals("W")) {
                    if (a.containsKey(b.YZ.getValue())) {
                        k.secondSeat = a.get(b.YZ.getValue());
                        k.secondSeatName = b.YZ.getName();
                    }
                    else {
                        k.secondSeat = a.get(b.ZE.getValue());
                        k.secondSeatName = b.ZE.getName();
                    }
                    k.setExsitSecondSeat(true);
                }
                else if (a.containsKey("W")) {
                    k.secondSeat = a.get("W");
                    k.secondSeatName = b.WZ.getName();
                    k.setExsitSecondSeat(true);
                }
            }
        }
        else {
            k.firstSeat = a(g, s);
        }
        return k;
    }
    
    public static k a(final g g, final String s, final String s2) {
        final k k = new k();
        final String[] split = s.split(",");
        if (split.length == 1) {
            k.firstSeat = Integer.parseInt(split[0]);
        }
        else if (split.length == 2) {
            final Map<String, Integer> a = a(g);
            if (s2.equals("W")) {
                k.firstSeat = Integer.parseInt(split[1]);
                k.secondSeat = Integer.parseInt(split[0]);
                if (a.containsKey(b.YZ.getValue())) {
                    k.secondSeatName = b.YZ.getName();
                }
                else {
                    k.secondSeatName = b.ZE.getName();
                }
                k.setExsitSecondSeat(true);
            }
            else if (a.containsKey("W")) {
                k.firstSeat = Integer.parseInt(split[0]);
                k.secondSeat = Integer.parseInt(split[1]);
                k.secondSeatName = b.WZ.getName();
                k.setExsitSecondSeat(true);
            }
        }
        return k;
    }
    
    public static int c(final g g, final String s) {
        final String c = c(s);
        return a(g, String.valueOf(a(g, c)), c).sumSeatNum();
    }
    
    public static int d(final g g, final String s) {
        return a(g, String.valueOf(a(g, s)), s).sumSeatNum();
    }
    
    public static List<String> b(final g g) {
        final String[] split = g.getYpEx().split("|");
        final ArrayList<String> list = new ArrayList<String>();
        final String[] array = new String[11];
        for (int i = 0; i < split.length; i += 2) {
            String s = split[i];
            if (i == 0 && (s.equals("1") || (s.equals("O") && g.getYpEx().lastIndexOf("O") != i))) {
                s = "W";
            }
            final String b = b(s);
            array[r.a.get(b)] = b;
        }
        for (int j = 0; j < array.length; ++j) {
            if (array[j] != null) {
                list.add(array[j]);
            }
        }
        return list;
    }
    
    public static List<net.tec.kyfw.d.e> a() {
        final ArrayList<net.tec.kyfw.d.e> list = new ArrayList<net.tec.kyfw.d.e>();
        list.add(new net.tec.kyfw.d.e("\u4e8c\u7b49\u5ea7", "O"));
        list.add(new net.tec.kyfw.d.e("\u4e00\u7b49\u5ea7", "M"));
        list.add(new net.tec.kyfw.d.e("\u7279\u7b49\u5ea7", "P"));
        list.add(new net.tec.kyfw.d.e("\u786c\u5367", "3"));
        list.add(new net.tec.kyfw.d.e("\u786c\u5ea7", "1"));
        list.add(new net.tec.kyfw.d.e("\u8f6f\u5367", "4"));
        list.add(new net.tec.kyfw.d.e("\u8f6f\u5ea7", "2"));
        list.add(new net.tec.kyfw.d.e("\u9ad8\u7ea7\u8f6f\u5367", "6"));
        list.add(new net.tec.kyfw.d.e("\u5546\u52a1\u5ea7", "9"));
        list.add(new net.tec.kyfw.d.e("\u65e0\u5ea7", "W"));
        return list;
    }
    
    public static String e(final g g, final String s) {
        String access$100 = "";
        for (final b b : b.values()) {
            Label_0083: {
                if (g.isCRHGCD()) {
                    if (b.equals(b.WZ)) {
                        break Label_0083;
                    }
                }
                else if (b.equals(b.WZ_D)) {
                    break Label_0083;
                }
                if (b.name.equals(s)) {
                    access$100 = b.value;
                    break;
                }
            }
        }
        if (g.isCRHDW()) {
            final String s2 = access$100;
            switch (s2) {
                case "O": {
                    access$100 = "8";
                    break;
                }
                case "M": {
                    access$100 = "7";
                    break;
                }
                case "4": {
                    access$100 = "F";
                    break;
                }
                case "1": {
                    access$100 = "8";
                    break;
                }
                case "6": {
                    access$100 = "A";
                    break;
                }
            }
        }
        return access$100;
    }
    
    public static String b(final String s) {
        String s2 = "";
        switch (s) {
            case "9": {
                s2 = "\u5546\u52a1\u5ea7";
                break;
            }
            case "P": {
                s2 = "\u7279\u7b49\u5ea7";
                break;
            }
            case "M": {
                s2 = "\u4e00\u7b49\u5ea7";
                break;
            }
            case "O": {
                s2 = "\u4e8c\u7b49\u5ea7";
                break;
            }
            case "6": {
                s2 = "\u9ad8\u7ea7\u8f6f\u5367";
                break;
            }
            case "F": {
                s2 = "\u8f6f\u5367";
                break;
            }
            case "4": {
                s2 = "\u8f6f\u5367";
                break;
            }
            case "3": {
                s2 = "\u786c\u5367";
                break;
            }
            case "2": {
                s2 = "\u8f6f\u5ea7";
                break;
            }
            case "1": {
                s2 = "\u786c\u5ea7";
                break;
            }
            case "W": {
                s2 = "\u65e0\u5ea7";
                break;
            }
            case "H": {
                s2 = "\u5176\u4ed6";
                break;
            }
        }
        return s2;
    }
    
    public static String c(final String s) {
        String s2 = "";
        switch (s) {
            case "\u5546\u52a1\u5ea7": {
                s2 = "9";
                break;
            }
            case "\u7279\u7b49\u5ea7": {
                s2 = "P";
                break;
            }
            case "\u4e00\u7b49\u5ea7": {
                s2 = "M";
                break;
            }
            case "\u4e8c\u7b49\u5ea7": {
                s2 = "O";
                break;
            }
            case "\u9ad8\u7ea7\u8f6f\u5367": {
                s2 = "6";
                break;
            }
            case "\u52a8\u5367": {
                s2 = "4";
                break;
            }
            case "\u8f6f\u5367": {
                s2 = "4";
                break;
            }
            case "\u786c\u5367": {
                s2 = "3";
                break;
            }
            case "\u8f6f\u5ea7": {
                s2 = "2";
                break;
            }
            case "\u786c\u5ea7": {
                s2 = "1";
                break;
            }
            case "\u65e0\u5ea7": {
                s2 = "W";
                break;
            }
            case "\u5176\u4ed6": {
                s2 = "H";
                break;
            }
        }
        return s2;
    }
    
    static {
        r.a = new s();
    }
    
    public static class c<E> implements Comparator<E>
    {
        ObservableList<E> a;
        
        c(final ObservableList<E> a) {
            this.a = a;
        }
        
        @Override
        public int compare(final E e, final E e2) {
            final int index = this.a.indexOf((Object)e);
            final int index2 = this.a.indexOf((Object)e2);
            return (index > index2) ? 1 : ((index != index2) ? -1 : 0);
        }
    }
    
    public static class d
    {
        public net.tec.kyfw.d.e a;
        public g b;
        public ObservableList<g> c;
    }
    
    public enum a
    {
        IDCARD("\u4e8c\u4ee3\u8eab\u4efd\u8bc1", "1"), 
        HKPASS("\u6e2f\u6fb3\u901a\u884c\u8bc1", "C"), 
        TWPASS("\u53f0\u6e7e\u901a\u884c\u8bc1", "G"), 
        PASSPORT("\u62a4\u7167", "B"), 
        ADULT("\u6210\u4eba", "1"), 
        CHILD("\u513f\u7ae5", "2"), 
        STUDENT("\u5b66\u751f", "3"), 
        POLICE("\u6b8b\u519b", "4"), 
        ADULT_T("\u6210\u4eba\u7968", "1"), 
        CHILD_T("\u513f\u7ae5\u7968", "2"), 
        STUDENT_T("\u5b66\u751f\u7968", "3"), 
        POLICE_T("\u6b8b\u519b\u7968", "4");
        
        private String value;
        private String name;
        
        private a(final String name, final String value) {
            this.value = value;
            this.name = name;
        }
        
        public String getName() {
            return this.name;
        }
        
        public void setName(final String name) {
            this.name = name;
        }
        
        public String getValue() {
            return this.value;
        }
        
        public void setValue(final String value) {
            this.value = value;
        }
        
        public static String getValue(final String s) {
            String value = "";
            for (final a a : values()) {
                if (a.name.equals(s)) {
                    value = a.value;
                    break;
                }
            }
            return value;
        }
        
        public static String getName(final String s) {
            String s2 = a.ADULT.name;
            for (final a a : values()) {
                if (a.value.equals(s)) {
                    s2 = a.name;
                    break;
                }
            }
            return s2;
        }
        
        public static String getPassengerType(final String s) {
            if (s.equals(a.CHILD.value)) {
                return a.CHILD.name;
            }
            if (s.equals(a.STUDENT.value)) {
                return a.STUDENT.name;
            }
            if (s.equals(a.POLICE.value)) {
                return a.POLICE.name;
            }
            return a.ADULT.name;
        }
    }
    
    public enum b
    {
        SWZ("\u5546\u52a1\u5ea7", "9"), 
        TZ("\u7279\u7b49\u5ea7", "P"), 
        ZY("\u4e00\u7b49\u5ea7", "M"), 
        ZE("\u4e8c\u7b49\u5ea7", "O"), 
        GR("\u9ad8\u7ea7\u8f6f\u5367", "6"), 
        RW("\u8f6f\u5367", "4"), 
        YW("\u786c\u5367", "3"), 
        RZ("\u8f6f\u5ea7", "2"), 
        YZ("\u786c\u5ea7", "1"), 
        WZ("\u65e0\u5ea7", "1"), 
        WZ_D("\u65e0\u5ea7", "O"), 
        QT("\u5176\u4ed6", "H");
        
        private String value;
        private String name;
        
        private b(final String name, final String value) {
            this.name = name;
            this.value = value;
        }
        
        public String getName() {
            return this.name;
        }
        
        public void setName(final String name) {
            this.name = name;
        }
        
        public String getValue() {
            return this.value;
        }
        
        public void setValue(final String value) {
            this.value = value;
        }
    }
}
