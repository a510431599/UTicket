// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

final class m extends Thread
{
    final /* synthetic */ String a;
    
    m(final String a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        g.a(k.b, k.c).b(this.a);
    }
}
