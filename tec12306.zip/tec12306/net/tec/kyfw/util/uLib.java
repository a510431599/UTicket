// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import com.sun.jna.FromNativeContext;
import com.sun.jna.PointerType;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByReference;
import com.sun.jna.Native;
import com.sun.jna.win32.W32APIOptions;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.Library;

public interface uLib extends Library
{
    public static final uLib aLib = (uLib)Native.loadLibrary("Advapi32.dll", uLib.class, W32APIOptions.ASCII_OPTIONS);
    public static final aPoint bPoint = new aPoint(-2147483648L);
    public static final aPoint cPoint = new aPoint(-2147483647L);
    public static final aPoint dPoint = new aPoint(-2147483646L);
    public static final aPoint ePoint = new aPoint(-2147483645L);
    public static final aPoint fPoint = new aPoint(-2147483644L);
    public static final aPoint gPoint = new aPoint(-2147483568L);
    public static final aPoint hPoint = new aPoint(-2147483552L);
    public static final aPoint iPoint = new aPoint(-2147483643L);
    public static final aPoint jPoint = new aPoint(-2147483642L);
    
    int RegOpenKeyEx(final aPoint p0, final String p1, final int p2, final int p3, final bByRef p4);
    
    int RegOpenKey(final aPoint p0, final String p1, final b p2);
    
    int RegCloseKey(final aPoint p0);
    
    int RegQueryValueEx(final aPoint p0, final String p1, final Integer p2, final IntByReference p3, final byte[] p4, final IntByReference p5);
    
    int RegGetValue(final aPoint p0, final String p1, final String p2, final int p3, final IntByReference p4, final byte[] p5, final IntByReference p6);
    
    int RegCreateKey(final aPoint p0, final String p1, final bByRef p2);
    
    int RegSetKeyValue(final aPoint p0, final String p1, final String p2, final int p3, final byte[] p4, final int p5);
    
    int RegSetValue(final aPoint p0, final String p1, final int p2, final byte[] p3, final int p4);
    
    int RegSetValueEx(final aPoint p0, final String p1, final int p2, final int p3, final byte[] p4, final int p5);
    
    int RegDeleteKey(final aPoint p0, final String p1);
    
    public static class bByRef extends ByReference
    {
        public bByRef() {
            this((aPoint)null);
        }
        
        public bByRef(final aPoint value) {
            super(Pointer.SIZE);
            this.setValue(value);
        }
        
        public void setValue(final aPoint a) {
            this.getPointer().setPointer(0L, (a != null) ? a.getPointer() : null);
        }
        
        public aPoint getValue() {
            final Pointer pointer = this.getPointer().getPointer(0L);
            if (pointer == null) {
                return null;
            }
            final Pointer constant = Pointer.createConstant((Pointer.SIZE == 8) ? -1L : 4294967295L);
            if (constant.equals(pointer)) {
                return new aPoint(constant);
            }
            return new aPoint(pointer);
        }
    }
    
    public static class aPoint extends PointerType
    {
        private boolean immutable;
        
        public aPoint() {
        }
        
        public aPoint(final Pointer pointer) {
            this.setPointer(pointer);
            this.immutable = true;
        }
        
        public aPoint(final long n) {
            this.setPointer(new Pointer(n));
            this.immutable = true;
        }
        
        @Override
        public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
            final Object fromNative = super.fromNative(o, fromNativeContext);
            final Pointer constant = Pointer.createConstant((Pointer.SIZE == 8) ? -1L : 4294967295L);
            if (constant.equals(fromNative)) {
                return constant;
            }
            return fromNative;
        }
        
        @Override
        public void setPointer(final Pointer pointer) {
            if (this.immutable) {
                throw new UnsupportedOperationException("immutable reference");
            }
            super.setPointer(pointer);
        }
    }
    
    public static class cAuth
    {
        public static String aAuth(final aPoint aPoint, final String s, final String s2) {
            String string = null;
            final IntByReference intByReference = new IntByReference();
            final IntByReference intByReference2 = new IntByReference();
            final bByRef bRef = new bByRef();
            if (uLib.aLib.RegOpenKeyEx(aPoint, s, 0, 131097, bRef) == 0 && uLib.aLib.RegQueryValueEx(bRef.getValue(), s2, 0, intByReference2, null, intByReference) == 0) {
                final byte[] array = new byte[intByReference.getValue()];
                int n;
                if (net.tec.kyfw.util.n.a()) {
                    n = uLib.aLib.RegGetValue(bRef.getValue(), null, s2, 65535, new IntByReference(), array, new IntByReference(array.length));
                }
                else {
                    n = uLib.aLib.RegQueryValueEx(bRef.getValue(), s2, 0, intByReference2, array, intByReference);
                }
                if (n == 0) {
                    string = Native.toString(array);
                }
            }
            uLib.aLib.RegCloseKey(bRef.getValue());
            return string;
        }
        
        public static boolean aDecode(final aPoint aPoint, final String s, final String s2, final String s3) {
            final byte[] byteArray = Native.toByteArray(s3);
            int n;
            if (net.tec.kyfw.util.n.a()) {
                n = uLib.aLib.RegSetKeyValue(aPoint, s, s2, 1, byteArray, byteArray.length);
            }
            else {
                final bByRef bRef = new bByRef();
                if (uLib.aLib.RegOpenKeyEx(aPoint, s, 0, 131103, bRef) == 2) {
                    uLib.aLib.RegCreateKey(aPoint, s, bRef);
                }
                n = uLib.aLib.RegSetValueEx(bRef.getValue(), s2, 0, 1, byteArray, byteArray.length);
                uLib.aLib.RegCloseKey(bRef.getValue());
            }
            return n == 0;
        }
    }
}
