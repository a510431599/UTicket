// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.time.LocalTime;
import javafx.collections.ObservableList;
import net.tec.kyfw.d.g;
import java.util.function.Predicate;

final class c implements Predicate<g>
{
    final /* synthetic */ ObservableList a;
    final /* synthetic */ String b;
    
    c(final ObservableList a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    public boolean a(final g g) {
        int booleanValue = ((boolean)g.isVisible()) ? 1 : 0;
        if (booleanValue != 0 && this.a != null && !this.a.isEmpty()) {
            booleanValue = (this.a.contains((Object)g) ? 0 : 1);
        }
        if (booleanValue != 0 && !this.b.equals("00:00--24:00")) {
            final String[] split = this.b.split("--");
            final LocalTime parse = LocalTime.parse(split[0] + ":00");
            final LocalTime parse2 = LocalTime.parse((split[1].equals("24:00") ? "23:59" : split[1]) + ":00");
            final LocalTime parse3 = LocalTime.parse((g.getStartTime().equals("24:00") ? "23:59" : g.getStartTime()) + ":00");
            if (parse3.isAfter(parse2) || parse3.isBefore(parse)) {
                booleanValue = 0;
            }
        }
        return booleanValue != 0 && g.getPriorTrain();
    }
}
