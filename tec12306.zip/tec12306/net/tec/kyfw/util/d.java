// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.regex.Pattern;
import java.time.LocalTime;
import net.tec.kyfw.d.g;
import java.util.function.Predicate;

final class d implements Predicate<g>
{
    final /* synthetic */ String a;
    final /* synthetic */ String b;
    final /* synthetic */ Boolean c;
    
    d(final String a, final String b, final Boolean c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public boolean a(final g g) {
        boolean b = true;
        if (!this.a.equals("00:00--24:00")) {
            final String[] split = this.a.split("--");
            final LocalTime parse = LocalTime.parse(split[0] + ":00");
            final LocalTime parse2 = LocalTime.parse((split[1].equals("24:00") ? "23:59" : split[1]) + ":00");
            final LocalTime parse3 = LocalTime.parse((g.getStartTime().equals("24:00") ? "23:59" : g.getStartTime()) + ":00");
            if (parse3.isAfter(parse2) || parse3.isBefore(parse)) {
                b = false;
            }
        }
        if (b) {
            b = false;
            if (!this.b.equalsIgnoreCase("ALL")) {
                if (this.b.contains("O")) {
                    b = Pattern.compile("^[^GCDZTK]+").matcher(g.getStationTrainCode()).find();
                }
                String s = this.b;
                if (this.b.equals("O")) {
                    return b;
                }
                if (this.b.contains("O") && s.length() > 1) {
                    s = new StringBuffer(this.b).delete(this.b.length() - 2, this.b.length()).toString();
                }
                final String[] split2 = s.split(",");
                for (int i = 0; i < split2.length; ++i) {
                    if (g.getStationTrainCode().startsWith(split2[i])) {
                        b = true;
                        break;
                    }
                }
            }
            else {
                b = true;
            }
        }
        if (b && this.c) {
            b = g.isVisible();
        }
        return b;
    }
}
