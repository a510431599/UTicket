// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import sun.misc.BASE64Encoder;
import javax.crypto.SecretKey;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import javax.crypto.KeyGenerator;
import java.io.UnsupportedEncodingException;

public class e
{
    public static String a(final String s) {
        final StringBuffer sb = new StringBuffer();
        sb.ensureCapacity(s.length() * 6);
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            if (Character.isDigit(char1) || Character.isLowerCase(char1) || Character.isUpperCase(char1)) {
                sb.append(char1);
            }
            else if (char1 < '\u0100') {
                sb.append("%");
                if (char1 < '\u0010') {
                    sb.append("0");
                }
                sb.append(Integer.toString(char1, 16));
            }
            else {
                sb.append("%u");
                sb.append(Integer.toString(char1, 16));
            }
        }
        return sb.toString();
    }
    
    public static String b(final String s) {
        try {
            return new String(b(c(s)), "utf-8");
        }
        catch (UnsupportedEncodingException ex) {
            return null;
        }
    }
    
    public static byte[] a(final byte[] array) {
        try {
            final KeyGenerator instance = KeyGenerator.getInstance("AES");
            final SecureRandom instance2 = SecureRandom.getInstance("SHA1PRNG");
            instance2.setSeed("25MwHtwDQ+CX1zGFOLZhUqbTM9CrepJjI0gYYRVVx+Q=".getBytes());
            instance.init(128, instance2);
            final SecretKeySpec secretKeySpec = new SecretKeySpec(instance.generateKey().getEncoded(), "AES");
            final Cipher instance3 = Cipher.getInstance("AES");
            instance3.init(1, secretKeySpec);
            return instance3.doFinal(array);
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public static byte[] b(final byte[] array) {
        try {
            final KeyGenerator instance = KeyGenerator.getInstance("AES");
            final SecureRandom instance2 = SecureRandom.getInstance("SHA1PRNG");
            instance2.setSeed("25MwHtwDQ+CX1zGFOLZhUqbTM9CrepJjI0gYYRVVx+Q=".getBytes());
            instance.init(128, instance2);
            final SecretKey generateKey = instance.generateKey();
            final Cipher instance3 = Cipher.getInstance("AES");
            instance3.init(2, generateKey);
            return instance3.doFinal(array);
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public static byte[] c(final String s) {
        final int n = s.length() / 2;
        final byte[] array = new byte[n];
        final char[] charArray = s.toCharArray();
        for (int i = 0; i < n; ++i) {
            final int n2 = i * 2;
            array[i] = (byte)(a(charArray[n2]) << 4 | a(charArray[n2 + 1]));
        }
        return array;
    }
    
    private static int a(final char c) {
        return (byte)"0123456789ABCDEF".indexOf(c);
    }
    
    public static String d(final String s) {
        try {
            return c(s.getBytes("utf-8"));
        }
        catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static String c(final byte[] array) {
        return new BASE64Encoder().encodeBuffer(array).replaceAll("\\s", "");
    }
}
