// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.List;

public class pUtil
{
    public static boolean aMethod(final Object o) {
        return o == null || o.equals("");
    }
    
    public static boolean bMethod(final Object o) {
        return !a(o);
    }
    
    public static boolean aMethod(final String s) {
        return s == null;
    }
    
    public static String bMethod(final String s) {
        if (null == s) {
            return "";
        }
        return String.valueOf(s);
    }
    
    public static String aMethod(final List<?> list) {
        final StringBuffer sb = new StringBuffer();
        if (list != null) {
            for (int i = 0; i < list.size(); ++i) {
                sb.append(list.get(i).toString()).append("|");
            }
        }
        return sb.toString();
    }
    
    public static String aMethod(final String s, final int n) {
        final StringBuffer sb = new StringBuffer();
        for (int i = s.length(); i < n; ++i) {
            sb.append("0");
        }
        sb.append(s);
        return sb.toString();
    }
    
    public static String cMethod(final Object o) {
        if (o == null) {
            return null;
        }
        return o.toString();
    }
}
