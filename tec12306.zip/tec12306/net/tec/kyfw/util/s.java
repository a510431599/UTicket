// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.HashMap;

final class s extends HashMap<String, Integer>
{
    s() {
        this.put("\u4e8c\u7b49\u5ea7", 0);
        this.put("\u4e00\u7b49\u5ea7", 1);
        this.put("\u7279\u7b49\u5ea7", 2);
        this.put("\u786c\u5367", 3);
        this.put("\u786c\u5ea7", 4);
        this.put("\u8f6f\u5367", 5);
        this.put("\u8f6f\u5ea7", 6);
        this.put("\u9ad8\u7ea7\u8f6f\u5367", 7);
        this.put("\u5546\u52a1\u5ea7", 8);
        this.put("\u65e0\u5ea7", 9);
        this.put("\u5176\u4ed6", 10);
    }
}
