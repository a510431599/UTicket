// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.security.MessageDigest;
import java.util.Scanner;
import java.net.MalformedURLException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.File;
import java.net.URL;
import java.io.InputStream;

public final class o
{
    public static String a;
    
    public static InputStream a(final String s) {
        return o.class.getResourceAsStream(s);
    }
    
    public static String b(final String s) {
        return (o.class.getResource(s) != null) ? o.class.getResource(s).toExternalForm() : "";
    }
    
    public static URL c(final String s) {
        return o.class.getResource(s);
    }
    
    public static byte[] a(final File file) {
        FileInputStream fileInputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        byte[] byteArray = null;
        try {
            fileInputStream = new FileInputStream(file);
            byteArrayOutputStream = new ByteArrayOutputStream();
            final byte[] array = new byte[1024];
            int read;
            while ((read = fileInputStream.read(array)) != -1) {
                byteArrayOutputStream.write(array, 0, read);
            }
            byteArray = byteArrayOutputStream.toByteArray();
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
        finally {
            a(byteArrayOutputStream);
            b(fileInputStream);
        }
        return byteArray;
    }
    
    public static boolean a(final byte[] array, final File file) {
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(array, 0, array.length);
            return true;
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
        finally {
            a(fileOutputStream);
        }
        return false;
    }
    
    public static String d(final String s) {
        final File file = new File(s);
        if (file.exists() && file.isFile()) {
            try {
                return file.toURI().toURL().toExternalForm();
            }
            catch (MalformedURLException ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }
    
    public static byte[] a(final InputStream inputStream) {
        byte[] byteArray = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            final byte[] array = new byte[1024];
            int read;
            while ((read = inputStream.read(array)) != -1) {
                byteArrayOutputStream.write(array, 0, read);
            }
            byteArray = byteArrayOutputStream.toByteArray();
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
        finally {
            a(byteArrayOutputStream);
            b(inputStream);
        }
        return byteArray;
    }
    
    public static String a() {
        if (o.a != null) {
            return o.a;
        }
        final String[] array = { "wmic", "cpu", "get", "ProcessorId" };
        final String[] array2 = { "wmic", "bios", "get", "serialnumber" };
        final StringBuffer sb = new StringBuffer();
        final Runtime runtime = Runtime.getRuntime();
        try {
            final Process exec = runtime.exec(array);
            exec.getOutputStream().close();
            final Scanner scanner = new Scanner(exec.getInputStream());
            final String next = scanner.next();
            final String next2 = scanner.next();
            exec.waitFor();
            exec.destroy();
            final Process exec2 = runtime.exec(array2);
            exec2.getOutputStream().close();
            final Scanner scanner2 = new Scanner(exec2.getInputStream());
            final String next3 = scanner2.next();
            final String next4 = scanner2.next();
            exec2.waitFor();
            exec2.destroy();
            sb.append(next).append(":").append(next2).append(",").append(next3).append(":").append(next4);
        }
        catch (Exception ex) {}
        return o.a = a(sb.toString().getBytes()).toUpperCase();
    }
    
    public static final String a(final byte[] array) {
        final char[] array2 = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
        try {
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(array);
            final byte[] digest = instance.digest();
            final int length = digest.length;
            final char[] array3 = new char[length * 2];
            int n = 0;
            for (final byte b : digest) {
                array3[n++] = array2[b >>> 4 & 0xF];
                array3[n++] = array2[b & 0xF];
            }
            return new String(array3);
        }
        catch (Exception ex) {
            return "";
        }
    }
    
    public static void b(final InputStream inputStream) {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        catch (Exception ex) {}
    }
    
    public static void a(final OutputStream outputStream) {
        try {
            if (outputStream != null) {
                outputStream.close();
            }
        }
        catch (Exception ex) {}
    }
    
    static {
        o.a = null;
    }
}
