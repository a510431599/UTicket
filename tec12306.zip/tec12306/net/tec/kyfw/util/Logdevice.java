// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.util.Iterator;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.LinkedHashMap;

public class Logdevice
{
    private static Integer a;
    
    public static void main(final String[] array) {
        new Logdevice().a();
    }
    
    public String a() {
        final String[] split = this.b().split("\\.");
        long n = 0L;
        for (int i = 0; i < split.length; ++i) {
            n = (n | Long.parseLong(split[i]) << 8 * (split.length - i - 1)) >>> 0;
        }
        final LinkedHashMap<String, String> linkedHashMap = (LinkedHashMap<String, String>)new LinkedHashMap<Object, String>();
        linkedHashMap.put("algID", "ljMMnNoh9U");
        linkedHashMap.put("hashCode", this.a(n));
        linkedHashMap.put("FMQw", "0");
        linkedHashMap.put("q4f3", "zh-CN");
        linkedHashMap.put("VySQ", "FFEKVLnY33fx12eF3fTk8aIr_Tru12Ap");
        linkedHashMap.put("VPIf", "1");
        linkedHashMap.put("custID", "133");
        linkedHashMap.put("VEek", "unknown");
        linkedHashMap.put("dzuS", "26.0 r0");
        linkedHashMap.put("yD16", "0");
        linkedHashMap.put("EOQP", "0e979e90eba67870844973a8b69a4a29");
        linkedHashMap.put("lEnu", String.valueOf(n));
        linkedHashMap.put("jp76", "e8eea307be405778bd87bbc8fa97b889");
        linkedHashMap.put("hAqN", "Win32");
        linkedHashMap.put("platform", "WEB");
        linkedHashMap.put("ks0Q", "2955119c83077df58dd8bb7832898892");
        linkedHashMap.put("TeRS", "728x1366");
        linkedHashMap.put("tOHY", "24xx768x1366");
        linkedHashMap.put("Fvje", "i1l1o1s1");
        linkedHashMap.put("q5aJ", "-8");
        linkedHashMap.put("wNLf", "99115dfb07133750ba677d055874de87");
        linkedHashMap.put("0aew", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36");
        linkedHashMap.put("E3gR", "ff93b35f3be1cbaf021f923569188897");
        linkedHashMap.put("timestamp", "1504601289149");
        final StringBuffer sb = new StringBuffer();
        sb.append("/otn/HttpZF/logdevice?");
        for (final String s : linkedHashMap.keySet()) {
            try {
                sb.append(s).append("=").append(URLEncoder.encode(linkedHashMap.get(s), "utf-8")).append("&");
            }
            catch (UnsupportedEncodingException ex) {
                ex.printStackTrace();
            }
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }
    
    private String b() {
        String s = "192.168.1.1";
        try {
            s = InetAddress.getLocalHost().getHostAddress().toString();
            final String[] split = s.split("\\.");
            split[2] = String.valueOf(Logdevice.a);
            final Integer a = Logdevice.a;
            ++Logdevice.a;
            if (Logdevice.a > 254) {
                Logdevice.a = 1;
            }
            s = split[0] + "." + split[1] + "." + split[2] + "." + split[3];
        }
        catch (UnknownHostException ex) {
            ex.printStackTrace();
        }
        return s;
    }
    
    private String a(final long n) {
        return this.a(this.d(this.a(this.b(this.c(this.b(this.a("adblock0browserLanguagezh-CNcookieCodeFFEKVLnY33fx12eF3fTk8aIr_Tru12ApcookieEnabled1custID133doNotTrackunknownflashVersion26.0 r0javaEnabled0jsFonts0e979e90eba67870844973a8b69a4a29localCode" + n + "mimeTypese8eea307be405778bd87bbc8fa97b889osWin32platformWEBplugins2955119c83077df58dd8bb7832898892scrAvailSize728x1366srcScreenSize24xx768x1366storeDbi1l1o1s1timeZone-8touchSupport99115dfb07133750ba677d055874de87userAgentMozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36webSmartIDff93b35f3be1cbaf021f923569188897"))))))).replaceAll("=", "");
    }
    
    private String a(String s) {
        s = ((0 == s.length() % 2) ? (s.substring(s.length() / 2, s.length()) + s.substring(0, s.length() / 2)) : (s.substring(s.length() / 2 + 1, s.length()) + s.charAt(s.length() / 2) + s.substring(0, s.length() / 2)));
        return s;
    }
    
    private String b(final String s) {
        String string = "";
        for (int n = s.length() - 1; 0 <= n; --n) {
            string += s.charAt(n);
        }
        return string;
    }
    
    private String c(final String s) {
        final char[] charArray = s.toCharArray();
        for (int length = s.length(), i = 0; i < length / 2; ++i) {
            if (0 == i % 2) {
                final char char1 = s.charAt(i);
                charArray[i] = charArray[length - 1 - i];
                charArray[length - 1 - i] = char1;
            }
        }
        return new String(charArray);
    }
    
    private String a(final byte[] array) {
        final char[] charArray = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=".toCharArray();
        final char[] array2 = new char[(array.length + 2) / 3 * 4];
        for (int i = 0, n = 0; i < array.length; i += 3, n += 4) {
            boolean b = false;
            boolean b2 = false;
            int n2 = (0xFF & array[i]) << 8;
            if (i + 1 < array.length) {
                n2 |= (0xFF & array[i + 1]);
                b2 = true;
            }
            int n3 = n2 << 8;
            if (i + 2 < array.length) {
                n3 |= (0xFF & array[i + 2]);
                b = true;
            }
            array2[n + 3] = charArray[b ? (n3 & 0x3F) : 64];
            final int n4 = n3 >> 6;
            array2[n + 2] = charArray[b2 ? (n4 & 0x3F) : 64];
            final int n5 = n4 >> 6;
            array2[n + 1] = charArray[n5 & 0x3F];
            array2[n + 0] = charArray[n5 >> 6 & 0x3F];
        }
        return new String(array2);
    }
    
    private byte[] d(final String s) {
        return this.a(s, "SHA-256");
    }
    
    private byte[] a(final String s, final String s2) {
        byte[] digest = null;
        if (s != null && s.length() > 0) {
            try {
                final MessageDigest instance = MessageDigest.getInstance(s2);
                instance.update(s.getBytes());
                digest = instance.digest();
            }
            catch (NoSuchAlgorithmException ex) {
                ex.printStackTrace();
            }
        }
        return digest;
    }
    
    static {
        Logdevice.a = 1;
    }
}
