// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.net.URI;
import java.awt.Desktop;
import net.tec.kyfw.e;
import org.apache.http.cookie.Cookie;
import net.tec.kyfw.f;
import com.sun.jna.ptr.ByteByReference;
import java.util.Arrays;
import java.util.List;
import com.sun.jna.FromNativeContext;
import com.sun.jna.IntegerType;
import com.sun.jna.Native;
import com.sun.jna.win32.W32APIOptions;
import com.sun.jna.PointerType;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.Library;

public interface i extends Library
{
    public static final i a = (i)Native.loadLibrary("Kernel32.dll", i.class, W32APIOptions.UNICODE_OPTIONS);
    
    int GetCurrentProcessId();
    
    boolean CreateProcess(final String p0, final String p1, final Structure p2, final Structure p3, final boolean p4, final a p5, final Pointer p6, final String p7, final d p8, final c p9);
    
    boolean TerminateProcess(final PointerType p0, final a p1);
    
    boolean GetExitCodeProcess(final PointerType p0, final a p1);
    
    b OpenProcess(final int p0, final boolean p1, final int p2);
    
    int WaitForSingleObject(final b p0, final int p1);
    
    boolean CloseHandle(final b p0);
    
    long GetModuleFileName(final b p0, final char[] p1, final int p2);
    
    public static class a extends IntegerType
    {
        private static final long serialVersionUID = 1098865105158080121L;
        public static final int SIZE = 4;
        
        public a() {
            this(0L);
        }
        
        public a(final long n) {
            super(4, n, true);
        }
        
        public f getLow() {
            return new f(this.longValue() & 0xFFL);
        }
        
        public f getHigh() {
            return new f(this.longValue() >> 16 & 0xFFL);
        }
    }
    
    public static class f extends IntegerType
    {
        private static final long serialVersionUID = 7585975014139110979L;
        public static final int SIZE = 2;
        
        public f() {
            this(0L);
        }
        
        public f(final long n) {
            super(2, n, true);
        }
    }
    
    public static class b extends PointerType
    {
        private boolean immutable;
        
        public b() {
        }
        
        public b(final Pointer pointer) {
            this.setPointer(pointer);
            this.immutable = true;
        }
        
        @Override
        public Object fromNative(final Object o, final FromNativeContext fromNativeContext) {
            final Object fromNative = super.fromNative(o, fromNativeContext);
            final Pointer constant = Pointer.createConstant((Pointer.SIZE == 8) ? -1L : 4294967295L);
            if (constant.equals(fromNative)) {
                return constant;
            }
            return fromNative;
        }
        
        @Override
        public void setPointer(final Pointer pointer) {
            if (this.immutable) {
                throw new UnsupportedOperationException("immutable reference");
            }
            super.setPointer(pointer);
        }
    }
    
    public static class c extends Structure
    {
        public b hProcess;
        public b hThread;
        public a dwProcessId;
        public a dwThreadId;
        
        @Override
        protected List<String> getFieldOrder() {
            return Arrays.asList("hProcess", "hThread", "dwProcessId", "dwThreadId");
        }
        
        public c() {
        }
        
        public c(final Pointer pointer) {
            this.read();
        }
    }
    
    public static class d extends Structure
    {
        public a cb;
        public String lpReserved;
        public String lpDesktop;
        public String lpTitle;
        public a dwX;
        public a dwY;
        public a dwXSize;
        public a dwYSize;
        public a dwXCountChars;
        public a dwYCountChars;
        public a dwFillAttribute;
        public int dwFlags;
        public f wShowWindow;
        public f cbReserved2;
        public ByteByReference lpReserved2;
        public b hStdInput;
        public b hStdOutput;
        public b hStdError;
        
        @Override
        protected List<String> getFieldOrder() {
            return Arrays.asList("cb", "lpReserved", "lpDesktop", "lpTitle", "dwX", "dwY", "dwXSize", "dwYSize", "dwXCountChars", "dwYCountChars", "dwFillAttribute", "dwFlags", "wShowWindow", "cbReserved2", "lpReserved2", "hStdInput", "hStdOutput", "hStdError");
        }
        
        public d() {
            this.cb = new a((long)this.size());
        }
    }
    
    public static class e
    {
        public static boolean a(final String s, final String s2) {
            return i.a.CreateProcess(s, s2, null, null, false, new a(0L), null, null, new d(), new c());
        }
        
        public static boolean a(final int n) {
            return i.a.OpenProcess(1, false, n) != null;
        }
        
        public static boolean b(final int n) {
            final b openProcess = i.a.OpenProcess(1, false, n);
            if (openProcess != null) {
                final a a = new a();
                i.a.GetExitCodeProcess(openProcess, a);
                return i.a.TerminateProcess(openProcess, a);
            }
            return true;
        }
        
        public static String a() {
            final char[] array = new char[1024];
            i.a.GetModuleFileName(null, array, array.length);
            return Native.toString(array);
        }
        
        public static void a(final net.tec.kyfw.f f, final String s) {
            if (f.i()) {
                final List<Cookie> cookies = f.t().getCookies();
                if (cookies != null) {
                    for (int i = 0; i < cookies.size(); ++i) {
                        v.a.InternetSetCookieA("https://" + cookies.get(i).getDomain() + cookies.get(i).getPath(), cookies.get(i).getName(), cookies.get(i).getValue() + ";expires=" + DateUtil.e());
                    }
                }
            }
            a(net.tec.kyfw.e.e(), "open " + s);
        }
        
        public static void a(final String s) {
            if (Desktop.isDesktopSupported()) {
                try {
                    final URI create = URI.create(s);
                    final Desktop desktop = Desktop.getDesktop();
                    if (desktop.isSupported(Desktop.Action.BROWSE)) {
                        desktop.browse(create);
                    }
                }
                catch (Exception ex) {}
            }
        }
    }
}
