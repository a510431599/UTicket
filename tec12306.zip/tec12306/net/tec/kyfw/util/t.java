// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class t
{
    static int a;
    static String b;
    
    public static String a(final String s) {
        return c(b(a("1111", s)));
    }
    
    public static String a(final String s, final String s2) {
        if (p.a((Object)s)) {
            return "";
        }
        final int[] a = a(s, true);
        int[] array = a(s2, false);
        if (array.length < 4) {
            array = a(array, 4);
        }
        final int n = a.length - 1;
        int n2 = a[n];
        final int n3 = a[0];
        int n4 = (int)Math.floor(6 + 52 / (n + 1));
        int n5 = 0;
        while (0 < n4--) {
            n5 = (n5 + t.a & -1);
            final int n6 = n5 >>> 2 & 0x3;
            int i;
            for (i = 0; i < n; ++i) {
                final int n7 = a[i + 1];
                final int n8 = (n2 >>> 5 ^ n7 << 2) + (n7 >>> 3 ^ n2 << 4) ^ (n5 ^ n7) + (array[(i & 0x3) ^ n6] ^ n2);
                final int[] array2 = a;
                final int n9 = i;
                final int n10 = a[i] + n8 & -1;
                array2[n9] = n10;
                n2 = n10;
            }
            final int n11 = a[0];
            final int n12 = (n2 >>> 5 ^ n11 << 2) + (n11 >>> 3 ^ n2 << 4) ^ (n5 ^ n11) + (array[(i & 0x3) ^ n6] ^ n2);
            final int[] array3 = a;
            final int n13 = n;
            final int n14 = a[n] + n12 & -1;
            array3[n13] = n14;
            n2 = n14;
        }
        return a(a, false);
    }
    
    public static String b(final String s) {
        String string = "";
        for (int i = 0; i < s.length(); ++i) {
            final String hexString = Integer.toHexString(s.charAt(i));
            string += ((hexString.length() < 2) ? ("0" + hexString) : hexString);
        }
        return string;
    }
    
    public static String c(String encode) {
        String d = "";
        try {
            encode = URLEncoder.encode(encode, "UTF-8");
            d = e.d(encode);
        }
        catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
        }
        return d;
    }
    
    public static int[] a(final String s, final boolean b) {
        final int length = s.length();
        final int[] array = new int[((length / 4 == 0) ? 1 : (length / 4)) + (b ? 1 : 0)];
        for (int i = 0; i < length; i += 4) {
            array[i >> 2] = (s.charAt(i) | s.charAt(i + 1) << 8 | s.charAt(i + 2) << 16 | s.charAt(i + 3) << 24);
        }
        if (b) {
            array[array.length - 1] = length;
        }
        return array;
    }
    
    public static String a(final int[] array, final boolean b) {
        final int length = array.length;
        int n = length - 1 << 2;
        if (b) {
            final int n2 = array[length - 1];
            if (n2 < n - 3 || n2 > n) {
                return null;
            }
            n = n2;
        }
        final String[] array2 = new String[array.length];
        for (int i = 0; i < length; ++i) {
            array2[i] = a(array[i] & 0xFF, array[i] >>> 8 & 0xFF, array[i] >>> 16 & 0xFF, array[i] >>> 24 & 0xFF);
        }
        if (b) {
            return a(array2, "").substring(0, n);
        }
        return a(array2, "");
    }
    
    public static String a(final String[] array, final String s) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < array.length; ++i) {
            sb.append(array[i]);
            if (i != array.length - 1) {
                sb.append(s);
            }
        }
        return sb.toString();
    }
    
    public static String a(final int... array) {
        return new String(array, 0, array.length);
    }
    
    public static int[] a(final int[] array, final int n) {
        final int[] array2 = new int[n];
        for (int i = 0; i < array.length; ++i) {
            array2[i] = array[i];
        }
        return array2;
    }
    
    public static String d(final String s) {
        String group = "";
        if (p.b((Object)s)) {
            final Matcher matcher = Pattern.compile("(?s)(?i)\\<script\\s*src\\s*\\=\\s*(['\"]+)(\\/otn\\/dynamicJs\\/[^'\"]*)").matcher(s);
            if (matcher.find()) {
                group = matcher.group(2);
            }
        }
        return group;
    }
    
    public static String e(final String s) {
        String group = "";
        if (p.b((Object)s)) {
            final Matcher matcher = Pattern.compile("(?s)(?i)function\\s*gc\\s*\\(\\s*\\)\\s*\\{\\s*var\\s*\\w+\\s*\\=\\s*(['\"]+)([^'\"]*)").matcher(s);
            if (matcher.find()) {
                group = matcher.group(2);
            }
        }
        return group;
    }
    
    static {
        t.a = -1640531528;
        t.b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    }
}
