// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import net.tec.kyfw.c.g;

public class a
{
    public static a a;
    
    public boolean a() {
        net.tec.kyfw.util.a.a = g.a();
        return net.tec.kyfw.util.a.a == null || this.a(net.tec.kyfw.util.a.a.b);
    }
    
    private boolean a(final String s) {
        final String s2 = "3.0.0.1014";
        if (!s.equals(s2)) {
            final String[] split = s.split("\\.");
            final String[] split2 = s2.split("\\.");
            if (split.length != split2.length) {
                return false;
            }
            for (int i = 0; i < split2.length; ++i) {
                final int int1 = Integer.parseInt(split[i]);
                final int int2 = Integer.parseInt(split2[i]);
                if (int1 > int2) {
                    return false;
                }
                if (int2 > int1) {
                    return true;
                }
            }
        }
        return true;
    }
    
    static {
        net.tec.kyfw.util.a.a = null;
    }
    
    public static class a
    {
        public String a;
        public String b;
        public Long c;
        public String d;
        public String e;
        public String f;
        public String g;
        public String h;
        public Boolean i;
        
        public a(final String a, final String b, final Long c, final String d, final String e, final String f, final String g, final String h) {
            this.i = Boolean.FALSE;
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
            this.f = f;
            this.g = g;
            this.h = h;
        }
    }
}
