// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.ArrayList;
import java.util.Iterator;
import javafx.control.bean.SelectedProperty;
import javafx.collections.FXCollections;
import net.tec.kyfw.d.e;
import java.util.function.Predicate;
import javafx.collections.transformation.FilteredList;
import net.tec.kyfw.d.g;
import javafx.collections.ObservableList;

public class b
{
    public static FilteredList<g> a(final ObservableList<g> list, final ObservableList<g> list2, final String s) {
        return (FilteredList<g>)list.filtered((Predicate)new c(list2, s));
    }
    
    public static FilteredList<g> a(final ObservableList<g> list, final String s, final String s2, final Boolean b) {
        return (FilteredList<g>)list.filtered((Predicate)new d(s2, s, b));
    }
    
    public static ObservableList<g> a(final ObservableList<g> list, final ObservableList<g> list2, final ObservableList<e> list3, final Boolean b, final Integer n) {
        if (list == null) {
            return list;
        }
        final ObservableList observableArrayList = FXCollections.observableArrayList();
        try {
            int n2 = 0;
            for (int i = 0; i < list.size(); ++i) {
                final g g = (g)list.get(i);
                if (list2.contains((Object)g)) {
                    if (!list3.isEmpty()) {
                        final Iterator iterator = list3.iterator();
                        while (iterator.hasNext()) {
                            final String s = (String)g.getClass().getMethod(net.tec.kyfw.d.g.methods.get(iterator.next().getItemValue()), (Class<?>[])new Class[0]).invoke(g, new Object[0]);
                            if (p.b((Object)s) && !s.equals("--") && !s.equals("\u65e0") && !s.equals("*")) {
                                if (!s.equals("\u6709") && !b && Integer.valueOf(s) < n) {
                                    continue;
                                }
                                g.setPriorTrain(true);
                                break;
                            }
                        }
                    }
                    else {
                        final String[] split = g.getYpEx().split("|");
                        for (int j = 0; j < split.length; j += 2) {
                            String s2 = split[j];
                            if (j == 0 && (s2.equals("1") || (s2.equals("O") && g.getYpEx().lastIndexOf("O") != j))) {
                                s2 = "W";
                            }
                            final String s3 = (String)g.getClass().getMethod(net.tec.kyfw.d.g.methods.get(s2), (Class<?>[])new Class[0]).invoke(g, new Object[0]);
                            if (p.b((Object)s3) && !s3.equals("--") && !s3.equals("\u65e0") && !s3.equals("*") && (s3.equals("\u6709") || b || Integer.valueOf(s3) >= n)) {
                                g.setPriorTrain(true);
                                break;
                            }
                        }
                    }
                }
                else if (list2.isEmpty() && !list3.isEmpty()) {
                    final Iterator iterator2 = list3.iterator();
                    while (iterator2.hasNext()) {
                        final String s4 = (String)g.getClass().getMethod(net.tec.kyfw.d.g.methods.get(iterator2.next().getItemValue()), (Class<?>[])new Class[0]).invoke(g, new Object[0]);
                        if (p.b((Object)s4) && !s4.equals("--") && !s4.equals("\u65e0") && !s4.equals("*")) {
                            if (!s4.equals("\u6709") && !b && Integer.valueOf(s4) < n) {
                                continue;
                            }
                            g.setPriorTrain(true);
                            break;
                        }
                    }
                }
                if (g.getPriorTrain()) {
                    observableArrayList.add(n2, (Object)g);
                    ++n2;
                }
                else {
                    observableArrayList.add((Object)g);
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return (ObservableList<g>)observableArrayList;
    }
    
    public static ObservableList<g> a(final ObservableList<g> list, final ObservableList<g> list2, final ObservableList<e> list3, final Boolean b, final Boolean b2, final Integer n) {
        if (list == null) {
            return list;
        }
        if (b2) {
            return a(list, list2, list3, b, n);
        }
        final ArrayList<g> list4 = new ArrayList<g>();
        final ObservableList observableArrayList = FXCollections.observableArrayList();
        try {
            int n2 = 0;
            for (int i = 0; i < list.size(); ++i) {
                final g g = (g)list.get(i);
                if (!list3.isEmpty()) {
                    final Iterator iterator = list3.iterator();
                    while (iterator.hasNext()) {
                        final String s = (String)g.getClass().getMethod(net.tec.kyfw.d.g.methods.get(iterator.next().getItemValue()), (Class<?>[])new Class[0]).invoke(g, new Object[0]);
                        if (p.b((Object)s) && !s.equals("--") && !s.equals("\u65e0") && !s.equals("*")) {
                            if (!s.equals("\u6709") && !b && Integer.valueOf(s) < n) {
                                continue;
                            }
                            g.setPriorTrain(true);
                            break;
                        }
                    }
                }
                if (g.getPriorTrain()) {
                    if (list2.isEmpty()) {
                        observableArrayList.add(n2, (Object)g);
                        ++n2;
                    }
                    else {
                        list4.add(g);
                    }
                }
                else {
                    observableArrayList.add((Object)g);
                }
            }
            if (!list2.isEmpty()) {
                int n3 = 0;
                for (int j = 0; j < list2.size(); ++j) {
                    final int index = list4.indexOf(list2.get(j));
                    if (index != -1) {
                        observableArrayList.add(n3, list4.get(index));
                        ++n3;
                    }
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return (ObservableList<g>)observableArrayList;
    }
}
