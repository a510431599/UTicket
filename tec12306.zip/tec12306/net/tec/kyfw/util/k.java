// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.tec.kyfw.c.e;

public class k
{
    public static String a;
    public static String b;
    public static String c;
    
    public static String a(final String s) {
        return a(k.b, k.c, s);
    }
    
    public static String a(final String s, final String s2, final String s3) {
        final String a = e.a(s, c(s2));
        if (a == null) {
            return "\u8d26\u6237\u540d\u6216\u5bc6\u7801\u9519\u8bef\uff01";
        }
        final Matcher matcher = Pattern.compile("sid\\=([^&]*).*?cguid\\=([^&]*)").matcher(a);
        if (!matcher.find()) {
            return "\u8d26\u6237\u540d\u6216\u5bc6\u7801\u9519\u8bef\uff01";
        }
        final String a2 = e.a(matcher.group(1), matcher.group(2), s3, s);
        if (a2 != null) {
            return a2.contains("\u77ed\u4fe1\u53d1\u9001\u6210\u529f") ? "\u77ed\u4fe1\u53d1\u9001\u6210\u529f\u3002" : "\u77ed\u4fe1\u53d1\u9001\u5931\u8d25\uff01";
        }
        return "\u77ed\u4fe1\u53d1\u9001\u5931\u8d25\uff01";
    }
    
    public static void b(final String s) {
        if (a()) {
            if (!a()) {
                return;
            }
            new l(s).start();
        }
        else if (b()) {
            new m(s).start();
        }
    }
    
    public static void a(final String s, final String s2, final String s3, final String s4, final String s5, final String s6) {
        if (a() || b()) {
            final StringBuffer sb = new StringBuffer();
            sb.append("\r\n\u60a8\u6709\u4e00\u7b14\u672a\u5904\u7406\u7684\u8ba2\u5355\uff0c\u5df2\u6210\u529f\u9884\u8ba2").append(s2).append("\u4ece").append(s4).append("\u5f00\u5f80").append(s5).append("\u7684").append(s3).append("\u6b21\u5217\u8f66").append(s6).append("\u8f66\u7968\uff0c");
            if (p.b((Object)s)) {
                sb.append("\u8ba2\u5355\u53f7\uff1a").append(s);
            }
            sb.append("\uff0c\u8bf7\u53ca\u65f6\u652f\u4ed8\uff01");
            if (a()) {
                sb.append("[\u94c1\u5ba2\u7f51\u7edc\u8ba2\u7968\u7cfb\u7edf]");
            }
            b(sb.toString());
        }
    }
    
    public static String a(final int n, final String s, final String s2) {
        if (n == 1) {
            return a(s, s2, "\u8fd9\u662f\u4e00\u6761\u6d4b\u8bd5\u77ed\u4fe1\u3002[\u94c1\u5ba2\u7f51\u7edc\u8ba2\u7968\u7cfb\u7edf]");
        }
        if (n == 2) {
            return g.a(s, s2).a("\u8fd9\u662f\u4e00\u5c01\u6d4b\u8bd5\u90ae\u4ef6\u3002");
        }
        return "\u975e\u6cd5\u64cd\u4f5c\u3002";
    }
    
    public static boolean a() {
        return "1".equals(k.a) && p.b((Object)k.b) && p.b((Object)k.c);
    }
    
    public static boolean b() {
        return "2".equals(k.a) && p.b((Object)k.b) && p.b((Object)k.c);
    }
    
    private static int a(final int n, final int n2) {
        final int n3 = (n & 0xFFFF) + (n2 & 0xFFFF);
        return (n >> 16) + (n2 >> 16) + (n3 >> 16) << 16 | (n3 & 0xFFFF);
    }
    
    private static String c(String string) {
        string = "fetion.com.cn:" + string;
        final int n = (string.length() + 8 >> 6) + 1;
        final int[] array = new int[16 * n];
        for (int i = 0; i < array.length; ++i) {
            array[i] = 0;
        }
        int j;
        for (j = 0; j < string.length(); ++j) {
            final int[] array2 = array;
            final int n2 = j >> 2;
            array2[n2] |= string.charAt(j) << 24 - 8 * (j & 0x3);
        }
        final int[] array3 = array;
        final int n3 = j >> 2;
        array3[n3] |= 128 << 24 - 8 * (j & 0x3);
        array[16 * n - 1] = 8 * string.length();
        final int[] array4 = new int[80];
        int a = -271733879;
        int a2 = 1732584193;
        int a3 = -1732584194;
        int a4 = 271733878;
        int a5 = -1009589776;
        for (int k = 0; k < array.length; k += 16) {
            final int n4 = a2;
            final int n5 = a;
            final int n6 = a3;
            final int n7 = a4;
            final int n8 = a5;
            for (int n9 = 0; 80 > n9; ++n9) {
                array4[n9] = ((16 > n9) ? array[k + n9] : ((array4[n9 - 3] ^ array4[n9 - 8] ^ array4[n9 - 14] ^ array4[n9 - 16]) << 1 | (array4[n9 - 3] ^ array4[n9 - 8] ^ array4[n9 - 14] ^ array4[n9 - 16]) >>> 31));
                final int a6 = a(a(a2 << 5 | a2 >>> 27, (20 > n9) ? ((a & a3) | (~a & a4)) : ((40 > n9) ? (a ^ a3 ^ a4) : ((60 > n9) ? ((a & a3) | (a & a4) | (a3 & a4)) : (a ^ a3 ^ a4)))), a(a(a5, array4[n9]), (20 > n9) ? 1518500249 : ((40 > n9) ? 1859775393 : ((60 > n9) ? -1894007588 : -899497514))));
                a5 = a4;
                a4 = a3;
                a3 = (a << 30 | a >>> 2);
                a = a2;
                a2 = a6;
            }
            a2 = a(a2, n4);
            a = a(a, n5);
            a3 = a(a3, n6);
            a4 = a(a4, n7);
            a5 = a(a5, n8);
        }
        final int[] array5 = { a2, a, a3, a4, a5 };
        String string2 = "";
        for (int l = 0; l < 4 * array5.length; ++l) {
            string2 = string2 + String.valueOf("0123456789abcdef".charAt(array5[l >> 2] >> 8 * (3 - l % 4) + 4 & 0xF)) + String.valueOf("0123456789abcdef".charAt(array5[l >> 2] >> 8 * (3 - l % 4) & 0xF));
        }
        return string2;
    }
    
    static {
        final String a = net.tec.kyfw.e.a(net.tec.kyfw.e.a.MSGAPI);
        if (p.b((Object)a)) {
            final String[] split = a.split(",");
            if (split.length == 3) {
                k.a = split[0];
                k.b = split[1];
                k.c = split[2];
            }
        }
    }
}
