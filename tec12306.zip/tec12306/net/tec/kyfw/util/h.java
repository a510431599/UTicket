// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import javafx.control.dialog.Tooltips;
import javafx.application.Platform;
import net.tec.kyfw.b.e;
import javafx.controller.AbstractController;
import javafx.controller.a;
import net.tec.kyfw.controller.TicketController;
import net.tec.kyfw.c.g;
import java.util.concurrent.CountDownLatch;
import net.tec.kyfw.fClient;
import org.apache.log4j.Logger;

public class h implements Runnable
{
    private Logger c;
    private fClient d;
    String a;
    CountDownLatch b;
    
    public h(final fClient d) {
        this.c = j.a(h.class);
        this.d = d;
    }
    
    @Override
    public void run() {
        if (g.j(this.d) == 302) {
            this.b();
        }
    }
    
    private String a() {
        this.a = null;
        do {
            final TicketController ticketController = javafx.controller.a.a(TicketController.class);
            if (net.tec.kyfw.a.a.a() && ticketController.autoVerifyCode.isSelected()) {
                if (g.a(this.d, Boolean.valueOf(true)) != null) {
                    this.a = net.tec.kyfw.a.a.a(this.d, true);
                }
            }
            else {
                this.b = new CountDownLatch(1);
                Platform.runLater(() -> this.d.b = e.a(this.d, true, this.b).a(ticketController.getWindow()).a(this.d.g() + "\u8eab\u4efd\u4fe1\u606f\u5931\u6548\uff0c\u8bf7\u91cd\u65b0\u767b\u5f55\uff1a").b());
                try {
                    this.b.await();
                    if (this.d.a != null && this.d.a.isCancelled()) {
                        break;
                    }
                    this.a = new String(this.d.b.c());
                }
                catch (InterruptedException ex) {
                    this.c.warn("\u4fdd\u6301\u767b\u5f55\u72b6\u6001\u81ea\u52a8\u767b\u5f55\u65f6\u83b7\u53d6\u9a8c\u8bc1\u7801\u8f93\u5165\u5f02\u5e38", ex);
                }
                if ("#CANCEL#".equals(this.a)) {
                    break;
                }
            }
        } while (!p.b((Object)this.a));
        return this.a;
    }
    
    private void b() {
        g.k(this.d);
        g.h(this.d);
        int n = 1;
        boolean b;
        do {
            if (n != 0) {
                this.a();
                if (this.d.a != null && this.d.a.isCancelled()) {
                    return;
                }
                if ("#CANCEL#".equals(this.a)) {
                    return;
                }
            }
            final net.tec.kyfw.c.h b2 = g.b(this.d, this.d.g(), this.d.h());
            b = !b2.b();
            if (!b) {
                this.d.a(Boolean.valueOf(false));
                g.h(this.d);
            }
            else if (b2.c().contains("\u975e\u6cd5\u8bf7\u6c42") || b2.c().contains("\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6")) {
                n = 0;
            }
            else if (b2.c().contains("\u9a8c\u8bc1\u7801")) {
                n = 1;
            }
            else {
                Platform.runLater(() -> Tooltips.show(javafx.controller.a.a(TicketController.class).getWindow(), b2.c()));
            }
        } while (b);
    }
}
