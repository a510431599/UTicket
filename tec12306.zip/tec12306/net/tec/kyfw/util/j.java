// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.io.InputStream;
import java.io.IOException;
import org.apache.log4j.PropertyConfigurator;
import java.io.FileInputStream;
import java.io.File;
import org.apache.log4j.Logger;

public class j
{
    public static Logger a(final Class<?> clazz) {
        return Logger.getLogger(clazz);
    }
    
    static {
        InputStream a = null;
        try {
            System.setProperty("log4j.home", o.b("/"));
            final File file = new File("log4j.properties");
            if (file.exists()) {
                a = new FileInputStream(file);
            }
            else {
                a = o.a("/res/conf/log4j.properties");
            }
            PropertyConfigurator.configure(a);
        }
        catch (Exception ex) {}
        finally {
            if (a != null) {
                try {
                    a.close();
                }
                catch (IOException ex2) {}
            }
        }
    }
}
