// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import sun.misc.BASE64Decoder;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.KeySpec;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.time.LocalDate;

public abstract class f
{
    private static String c;
    public static long a;
    public static String b;
    
    public static void a() {
        f.c = "MIIBuDCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2USZpRV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4O1fnxqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmCouuEC/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCBgLRJFnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhRkImog9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoDgYUAAoGBAI+EVQrOLu9AhWZvfkQ4YtKfZapPjJNWYTvVDmu6hDuMfnl+zoAxOTlPY1Lsf3A9Kk3IuiKengr+OiuaZWNKS2H7N2sEulm2/fdOkF2GcO5LMYiBtwIOWCSv6IfiP8xOgNeQ1TGux1vAOfpQfBlErzhQJY+NYXr5+Wfo+Cibu3JP";
        final String a = u.c.a(u.c, "Software\\12306", "license3");
        if (p.b((Object)a)) {
            try {
                final String[] a2 = a(a);
                if (a2 != null && a(a2[0], a2[1])) {
                    f.a = Long.parseLong(a2[0]);
                    f.b = a;
                }
            }
            catch (Exception ex) {}
        }
    }
    
    public static final String[] a(final String s) {
        final String b = e.b(s);
        if (p.b((Object)b)) {
            final String[] split = b.split("\\|");
            if (split.length == 2) {
                try {
                    return new String[] { split[0], split[1] };
                }
                catch (Exception ex) {}
            }
        }
        return null;
    }
    
    public static final boolean b() {
        final String b = f.b;
        try {
            if (b != null && !b.equals("")) {
                final String[] a = a(b);
                return a != null && a(a[0], a[1]);
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    public static final boolean a(final String b, final boolean b2) {
        try {
            if (b != null && !b.equals("")) {
                final String[] a = a(b);
                final boolean b3 = a != null && a(a[0], a[1]);
                if (b2 && b3) {
                    f.a = Long.parseLong(a[0]);
                    f.b = b;
                    u.c.a(u.c, "Software\\12306", "license3", b);
                }
                return b3;
            }
        }
        catch (Exception ex) {}
        return false;
    }
    
    private static final boolean a(String string, final String s) {
        try {
            if (!string.equals("1") && Long.parseLong(string) <= LocalDate.now().toEpochDay()) {
                return false;
            }
            string = string + "|" + o.a();
            return a(string.getBytes(), f.c, s);
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    private static boolean a(final byte[] array, final String s, final String s2) {
        final X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(b(s));
        final KeyFactory instance = KeyFactory.getInstance("DSA");
        final PublicKey generatePublic = instance.generatePublic(x509EncodedKeySpec);
        final Signature instance2 = Signature.getInstance(instance.getAlgorithm());
        instance2.initVerify(generatePublic);
        instance2.update(array);
        return instance2.verify(b(s2));
    }
    
    public static byte[] b(final String s) {
        return new BASE64Decoder().decodeBuffer(s);
    }
    
    static {
        f.c = null;
        f.a = 0L;
        f.b = null;
    }
}
