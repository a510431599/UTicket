// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.io.IOException;
import java.util.TimeZone;
import java.util.Locale;
import net.tec.kyfw.d.j;
import java.util.ArrayList;
import java.util.List;
import java.time.chrono.ChronoLocalDateTime;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.text.ParseException;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import org.apache.log4j.Logger;

public class DateUtil
{
    private static Logger b;
    public static String[] a;
    
    public static String a(final String s) {
        return new SimpleDateFormat(s).format(Calendar.getInstance().getTime());
    }
    
    public static String a(final Date date, final String s) {
        return new SimpleDateFormat(s).format(date);
    }
    
    public static String a(final LocalDate localDate, final String s) {
        return localDate.format(DateTimeFormatter.ofPattern(s));
    }
    
    public static Date a(final String s, final String s2) {
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(s2);
        try {
            return simpleDateFormat.parse(s);
        }
        catch (ParseException ex) {
            DateUtil.b.error("\u65e5\u671f\u89e3\u6790\u51fa\u9519!");
            return null;
        }
    }
    
    public static LocalDateTime a() {
        return LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
    }
    
    public static LocalDateTime b() {
        return LocalDateTime.of(LocalDate.parse(a("yyyy-MM-dd")).plusDays(29L), LocalTime.MAX);
    }
    
    public static boolean a(final LocalDate localDate) {
        final LocalDateTime a = a();
        final LocalDateTime of = LocalDateTime.of(localDate, LocalTime.MAX);
        final LocalDateTime b = b();
        return (of.isAfter(a) || of.toLocalDate().equals(a.toLocalDate())) && (of.isBefore(b) || of.toLocalDate().equals(b.toLocalDate()));
    }
    
    public static List<LocalDate> c() {
        final ArrayList<LocalDate> list = new ArrayList<LocalDate>();
        LocalDateTime localDateTime = a();
        for (int i = 0; i < 30; ++i) {
            list.add(localDateTime.toLocalDate());
            localDateTime = localDateTime.plusDays(1L);
        }
        return list;
    }
    
    public static String b(final LocalDate localDate) {
        return localDate.format(DateTimeFormatter.ofPattern("MM-dd")) + " " + DateUtil.a[localDate.getDayOfWeek().getValue()];
    }
    
    public static List<j> d() {
        final ArrayList<j> list = new ArrayList<j>();
        LocalDateTime localDateTime = a();
        for (int i = 0; i < 30; ++i) {
            list.add(new j(localDateTime.format(DateTimeFormatter.ofPattern("MM.dd")), localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
            localDateTime = localDateTime.plusDays(1L);
        }
        return list;
    }
    
    public static String e() {
        return LocalDateTime.of(LocalDate.now(), LocalTime.MAX).plusDays(1L).format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy HH:mm:ss", Locale.ENGLISH)) + " GMT";
    }
    
    public static String a(final Date time) {
        final Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        final LocalTime now = LocalTime.now();
        instance.set(11, now.getHour());
        instance.set(12, now.getMinute());
        instance.set(13, now.getSecond());
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss", Locale.ENGLISH);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT+0800"));
        return simpleDateFormat.format(instance.getTime()) + " GMT+0800 (\u4e2d\u56fd\u6807\u51c6\u65f6\u95f4)";
    }
    
    public static void main(final String[] array) {
        System.out.println(a(new Date()));
    }
    
    public static boolean f() {
        final int hour = LocalTime.now().getHour();
        return hour < 6 || hour == 23;
    }
    
    public static void a(final Calendar calendar) {
        final int value = calendar.get(1);
        final int n = calendar.get(2) + 1;
        final int value2 = calendar.get(5);
        final int value3 = calendar.get(11);
        final int value4 = calendar.get(12);
        final int value5 = calendar.get(13);
        calendar.setTime(new Date());
        final int value6 = calendar.get(1);
        final int n2 = calendar.get(2) + 1;
        final int value7 = calendar.get(5);
        final String string = value + "-" + n + "-" + value2;
        final String string2 = value3 + ":" + value4 + ":" + value5;
        try {
            Runtime.getRuntime().exec("cmd  /c  time " + string2).waitFor();
            if (value != value6 || n != n2 || value2 != value7) {
                Runtime.getRuntime().exec("cmd /c date " + string).waitFor();
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        catch (InterruptedException ex2) {
            ex2.printStackTrace();
        }
    }
    
    public static Long b(final String s) {
        return (long)LocalTime.parse(s + "00", DateTimeFormatter.ofPattern("HHmmss")).toSecondOfDay();
    }
    
    static {
        DateUtil.b = net.tec.kyfw.util.j.a(DateUtil.class);
        DateUtil.a = new String[] { "", "\u5468\u4e00", "\u5468\u4e8c", "\u5468\u4e09", "\u5468\u56db", "\u5468\u4e94", "\u5468\u516d", "\u5468\u65e5" };
    }
}
