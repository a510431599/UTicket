// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.Hashtable;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.mail.PasswordAuthentication;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.AuthenticationFailedException;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.Address;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.Authenticator;
import javax.mail.Session;
import java.util.Properties;
import org.apache.log4j.Logger;

public class g
{
    private static Logger a;
    private final transient Properties b;
    private transient a c;
    private transient Session d;
    
    public static g a(final String s, final String s2) {
        return new g(s, s2);
    }
    
    public g(final String s, final String s2) {
        this.b = System.getProperties();
        String string = "smtp.";
        if (s.indexOf("@") != -1 && !s.startsWith("@") && !s.endsWith("@")) {
            string += s.split("@")[1];
        }
        this.b(s, s2, string);
    }
    
    private void b(final String s, final String s2, final String s3) {
        ((Hashtable<String, String>)this.b).put("mail.smtp.auth", "true");
        ((Hashtable<String, String>)this.b).put("mail.smtp.host", s3);
        if (s3.endsWith("qq.com") || s3.endsWith("163.com") || s3.endsWith("126.com")) {
            ((Hashtable<String, String>)this.b).put("mail.smtp.starttls.enable", "true");
            ((Hashtable<String, String>)this.b).put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            ((Hashtable<String, String>)this.b).put("mail.smtp.socketFactory.port", "465");
            ((Hashtable<String, String>)this.b).put("mail.smtp.socketFactory.fallback", "false");
        }
        this.c = new a(s, s2);
        this.d = Session.getInstance(this.b, this.c);
    }
    
    public void a(final String s, final String subject, final String s2) {
        final MimeMessage mimeMessage = new MimeMessage(this.d);
        mimeMessage.setFrom(new InternetAddress(this.c.a()));
        mimeMessage.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(s));
        mimeMessage.setSubject(subject);
        mimeMessage.setContent(s2, "text/html;charset=utf-8");
        Transport.send(mimeMessage);
    }
    
    public void a(final String s, final b b) {
        this.a(s, b.a(), b.b());
    }
    
    public String a(final String s) {
        String s2;
        try {
            this.a(this.c.a(), g.b.a(s));
            s2 = "\u53d1\u9001\u6210\u529f\uff01\u8bf7\u767b\u5f55\u60a8\u7684\u90ae\u7bb1\u67e5\u770b\u662f\u5426\u6536\u5230\u6b64\u90ae\u4ef6\u3002";
        }
        catch (AuthenticationFailedException ex) {
            s2 = "\u8d26\u53f7\u548c\u5bc6\u7801\u4e0d\u5339\u914d\u6216\u4e0d\u652f\u6301\u7684\u90ae\u7bb1\u7c7b\u578b\u3002";
        }
        catch (AddressException ex2) {
            s2 = "\u90ae\u7bb1\u5730\u5740\u6709\u8bef\uff0c\u8bf7\u8f93\u5165\u6b63\u786e\u7684\u90ae\u7bb1\u8d26\u53f7\u3002";
        }
        catch (MessagingException ex3) {
            s2 = "\u90ae\u7bb1\u8d26\u53f7\u683c\u5f0f\u6709\u8bef\u6216\u4e0d\u652f\u6301\u7684\u90ae\u7bb1\u7c7b\u578b\u3002";
        }
        return s2;
    }
    
    public void b(final String s) {
        try {
            this.a(this.c.a(), g.b.a(s));
        }
        catch (MessagingException ex) {
            g.a.warn("\u53d1\u9001\u90ae\u4ef6\u5931\u8d25", ex);
        }
    }
    
    static {
        g.a = j.a(g.class);
    }
    
    public static class a extends Authenticator
    {
        private String a;
        private String b;
        
        public a(final String a, final String b) {
            this.a = a;
            this.b = b;
        }
        
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(this.a, this.b);
        }
        
        String a() {
            return this.a;
        }
    }
    
    public static class b
    {
        private String a;
        private String b;
        
        public b(final String a, final String b) {
            this.a = a;
            this.b = b;
        }
        
        public String a() {
            return this.a;
        }
        
        public String b() {
            return this.b;
        }
        
        public static b a(final String s) {
            final String format = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            final StringBuffer sb = new StringBuffer();
            sb.append("<div style='font-size:12px;'>").append("<div style='padding: 5px;'>\u60a8\u597d\uff1a</div>").append("<div style='padding: 0 0 0 5px;'>").append("<p style='line-height:130%;text-indent:2em;padding: 3px 0px;margin: 0px;'>").append(s).append("</p>").append("</div>").append("<div align='right'>\u53d1\u81ea\uff1a\u94c1\u5ba2\u7f51\u7edc\u8ba2\u7968\u7cfb\u7edf&nbsp;&nbsp;&nbsp;&nbsp;" + format + "</div>").append("</div>");
            sb.append("");
            return new b("\u3010\u8d2d\u7968\u63d0\u9192\u3011\u94c1\u5ba2\u7f51\u7edc\u8ba2\u7968\u7cfb\u7edf", sb.toString());
        }
    }
}
