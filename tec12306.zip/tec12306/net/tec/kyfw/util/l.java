// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

final class l extends Thread
{
    final /* synthetic */ String a;
    
    l(final String a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        k.a(this.a);
    }
}
