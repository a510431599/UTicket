// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import com.sun.jna.Native;
import com.sun.jna.Library;

public interface v extends Library
{
    public static final v a = (v)Native.loadLibrary("Wininet", v.class);
    
    boolean InternetSetCookieA(final Object p0, final Object p1, final Object p2);
}
