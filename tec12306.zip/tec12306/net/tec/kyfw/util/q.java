// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

import java.util.ArrayList;
import net.tec.kyfw.d.d;
import java.util.List;

public class q
{
    public static List<d> a(final byte[] array) {
        List<d> list = null;
        try {
            if (p.b(array)) {
                final String s = new String(array, "UTF-8");
                if (p.b((Object)s)) {
                    final String replaceAll = s.replaceAll("#", "#");
                    list = new ArrayList<d>();
                    final String[] split = replaceAll.split("\r\n");
                    for (int i = 0; i < split.length; ++i) {
                        if (!p.a((Object)split[i])) {
                            if (!split[i].trim().startsWith("#")) {
                                final String[] split2 = split[i].replaceAll("\uff0c", ",").split(",");
                                if (split2.length >= 2) {
                                    list.add(a(split2));
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex) {}
        return list;
    }
    
    public static d a(final String[] array) {
        final String trim = array[0].trim();
        final String trim2 = array[1].trim();
        String trim3 = "";
        String s = d.a.IDCARD.getName();
        String s2 = d.a.ADULT.getName();
        if (array.length >= 3) {
            trim3 = array[2].trim();
        }
        if (array.length >= 4) {
            s = d.a.getName(array[3].trim());
        }
        if (array.length >= 5) {
            s2 = d.a.getName(array[4].trim()).replace("\u7968", "");
        }
        return new d(trim, s, trim2, trim3, s2, "\u5f85\u6838\u9a8c");
    }
}
