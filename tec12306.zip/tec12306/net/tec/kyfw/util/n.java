// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.util;

public class n
{
    public static boolean a() {
        return Double.parseDouble(System.getProperty("os.version")) >= 6.1;
    }
}
