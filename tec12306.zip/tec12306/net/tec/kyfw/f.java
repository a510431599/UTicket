// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw;

import java.util.concurrent.Executors;
import java.util.HashMap;
import javafx.application.Platform;
import java.util.concurrent.TimeUnit;
import net.tec.kyfw.util.h;
import java.io.IOException;
import java.util.List;
import org.apache.http.cookie.Cookie;
import java.util.Iterator;
import net.tec.kyfw.b.e;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.Map;
import net.tec.kyfw.c.cClient;

public class fClient extends cClient
{
    private static Map<String, fClient> i;
    private String j;
    private String k;
    private String l;
    private Boolean m;
    private Boolean n;
    private static ScheduledExecutorService o;
    private static ScheduledFuture<?> p;
    public ScheduledFuture<?> a;
    public e b;
    
    public static void a() {
        fClient.i.put("D", new fClient("D", 5000, 10000));
        fClient.i.put("T", new fClient("T", 5000, 10000));
        fClient.i.put("Q", new fClient("Q", 3000, 5000));
    }
    
    public static fClient b() {
        return fClient.i.get("D");
    }
    
    public static fClient c() {
        return fClient.i.get("T");
    }
    
    public static fClient d() {
        return fClient.i.get("Q");
    }
    
    public static fClient a(final String s) {
        if (b().i() && b().k.equals(s)) {
            return b();
        }
        if (fClient.i.get(s) == null) {
            fClient.i.put(s, new fClient(s, 5000, 10000));
        }
        return fClient.i.get(s);
    }
    
    public static Boolean e() {
        return fClient.i.keySet().size() > 3;
    }
    
    public static Boolean b(final String s) {
        for (final String s2 : fClient.i.keySet()) {
            if (fClient.i.get(s2).i() && fClient.i.get(s2).g().equals(s)) {
                return true;
            }
        }
        return false;
    }
    
    public fClient(final String j, final int n, final int n2) {
        super(n, n2);
        this.m = Boolean.FALSE;
        this.n = Boolean.FALSE;
        this.a = null;
        this.j = j;
    }
    
    public String f() {
        return this.j;
    }
    
    public String g() {
        return this.k;
    }
    
    public String h() {
        return this.l;
    }
    
    public Boolean i() {
        return this.m && !this.n;
    }
    
    public Boolean j() {
        return this.j.equals("D");
    }
    
    public void k() {
        this.m = Boolean.FALSE;
        this.n = Boolean.FALSE;
        this.k = null;
        this.l = null;
        this.t().clear();
        this.o();
    }
    
    public void a(final String k, final String l) {
        this.m = Boolean.TRUE;
        this.n = Boolean.FALSE;
        this.k = k;
        this.l = l;
        this.n();
    }
    
    public void a(final Boolean n) {
        this.n = n;
    }
    
    public fClient c(final String s) {
        final fClient a = a(s);
        a.m = this.m;
        a.n = this.n;
        a.k = this.k;
        a.l = this.l;
        a.f = this.f;
        a.g = this.g;
        a.h = this.h;
        final List<Cookie> cookies = this.t().getCookies();
        for (int i = 0; i < cookies.size(); ++i) {
            a.t().addCookie(cookies.get(i));
        }
        this.l();
        return a;
    }
    
    public void l() {
        this.k();
        this.t().getCookies().clear();
        this.f = null;
        this.g = null;
        this.h = 0L;
    }
    
    public void m() {
        try {
            this.s().close();
        }
        catch (IOException ex) {}
        fClient.i.remove(this.j);
    }
    
    @Override
    public String toString() {
        return this.f();
    }
    
    public void n() {
        try {
            this.a = fClient.o.scheduleWithFixedDelay(new h(this), 300000L, 300000L, TimeUnit.MILLISECONDS);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void o() {
        if (this.a != null && !this.a.isCancelled()) {
            this.a.cancel(true);
        }
    }
    
    public void p() {
        if (this.a != null && !this.a.isCancelled()) {
            this.a.cancel(false);
        }
        Platform.runLater(() -> {
            if (this.b != null && this.b.isShowing()) {
                this.b.a();
            }
        });
    }
    
    public static void q() {
        try {
            fClient.p.cancel(true);
        }
        catch (Exception ex) {}
        final Iterator<String> iterator = f.i.keySet().iterator();
        while (iterator.hasNext()) {
            fClient.i.get(iterator.next()).o();
        }
        fClient.o.shutdown();
    }
    
    static {
        fClient.i = new HashMap<String, f>();
        fClient.p = null;
        try {
            fClient.o = Executors.newScheduledThreadPool(1);
            fClient.p = fClient.o.scheduleWithFixedDelay(() -> {
                System.gc();
                Runtime.getRuntime().freeMemory();
            }, 300000L, 300000L, TimeUnit.MILLISECONDS);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
