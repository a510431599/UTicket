// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw;

import net.tec.kyfw.util.j;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.BottomController;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javafx.stage.Window;
import javafx.control.dialog.Dialogs;
import javafx.collections.ObservableMap;
import net.tec.kyfw.e.i;
import javafx.event.Event;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;

import javax.imageio.ImageIO;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.Collection;
import javafx.beans.value.ObservableValue;
import javafx.a.a;
import javafx.a.d;
import net.tec.kyfw.e.c;
import javafx.stage.StageStyle;
import javafx.scene.image.Image;
import javafx.scene.paint.Paint;
import javafx.scene.paint.Color;
import javafx.scene.Scene;
import net.tec.kyfw.controller.LoadingController;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import net.tec.kyfw.util.o;
import javafx.stage.Stage;
import javafx.application.Platform;
import javax.swing.UIManager;

import org.apache.log4j.Logger;
import javafx.application.Application;

public class App extends Application
{
    private static Logger c;
    public static TrayIcon a;
    public static String[] b;
    
    public static void main(final String[] b) {
        App.b = b;
        UIManager.installLookAndFeel(new UIManager.LookAndFeelInfo("Windows", "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"));
        launch(b);
        Platform.exit();
    }
    
    public void start(final Stage stage) throws IOException {
        final FXMLLoader fxmlLoader = new FXMLLoader(o.c("/res/fxml/loading.fxml"));
        final Parent parent = (Parent)fxmlLoader.load();
        final LoadingController loadingController = (LoadingController)fxmlLoader.getController();
        final Scene scene = new Scene(parent);
        scene.setFill((Paint)Color.TRANSPARENT);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.setTitle("\u94c1\u5ba2\u7f51\u7edc\u8ba2\u7968\u7cfb\u7edf");
        stage.getIcons().add(new Image(o.a("/res/images/icon.png")));
        stage.initStyle(StageStyle.TRANSPARENT);
        final c c = d.a((Class<? extends a<Object>>)c.class);
        loadingController.progressBar.progressProperty().bind((ObservableValue)c.progressProperty());
        stage.setOnShown(windowEvent -> c.start());
        stage.show();
    }
    
    public static void a(final Stage stage) throws IOException, AWTException {
        final Stage stage2 = new Stage();
        final FXMLLoader fxmlLoader = new FXMLLoader(o.c("/res/fxml/main.fxml"));
        final Parent parent = (Parent)fxmlLoader.load();
        fxmlLoader.getController();
        final Scene scene = new Scene(parent);
        scene.setFill((Paint)Color.TRANSPARENT);
        stage2.setScene(scene);
        stage2.setResizable(stage.isResizable());
        stage2.setTitle(stage.getTitle());
        stage2.getIcons().addAll((Collection)stage.getIcons());
        stage2.initStyle(StageStyle.TRANSPARENT);
        stage2.setOnCloseRequest(windowEvent -> {
            if (!a((Event)windowEvent, stage2)) {
                return;
            }
            Platform.setImplicitExit(true);
        });
        stage.setOnHidden(windowEvent -> {
            try {
                Thread.sleep(80L);
                stage2.show();
                stage2.requestFocus();
            }
            catch (InterruptedException ex) {}
        });
        stage2.setOnShown(windowEvent -> new Thread((Runnable)new net.tec.kyfw.aTask(stage2)).start());
        stage.hide();
        stage2.addEventHandler(WindowEvent.WINDOW_SHOWN, windowEvent -> ((BottomController)javafx.controller.a.a(BottomController.class)).b.c());
        stage2.addEventHandler(WindowEvent.WINDOW_HIDING, windowEvent -> ((BottomController)javafx.controller.a.a(BottomController.class)).b.b());
        App.a = new TrayIcon(ImageIO.read(o.a("/res/images/icon_tray.png")), "\u94c1\u5ba2\u7f51\u7edc\u8ba2\u7968\u7cfb\u7edf", new PopupMenu());
        b(stage2);
        final KeyCodeCombination keyCodeCombination = new KeyCodeCombination(KeyCode.W, new KeyCombination.Modifier[] { KeyCombination.CONTROL_DOWN });
        final KeyCodeCombination keyCodeCombination2 = new KeyCodeCombination(KeyCode.ESCAPE, new KeyCombination.Modifier[0]);
        final ObservableMap accelerators = scene.getAccelerators();
        final Stage stage3 = null;
        final Runnable runnable = () -> {
            if (!a(null, stage3)) {
                return;
            }
            else {
                Platform.setImplicitExit((boolean)(1 != 0));
                stage3.hide();
                return;
            }
        };
        final Runnable runnable1 = () -> i.a();
        accelerators.put((Object)keyCodeCombination2, runnable1);
        accelerators.put((Object)keyCodeCombination, (Object)runnable);
    }
    
    public static boolean a(final Event event, final Stage stage) {
        if (f.b().i()) {
            if (Integer.valueOf(Dialogs.create().owner((Window)stage).title("\u786e\u8ba4\u63d0\u793a").message("\u60a8\u5df2\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u786e\u8ba4\u9000\u51fa\u6b64\u7a0b\u5e8f\uff1f").confirmAndWait()) != 1) {
                if (event != null) {
                    event.consume();
                }
                return false;
            }
        }
        else if (f.e() && Integer.valueOf(Dialogs.create().owner((Window)stage).title("\u786e\u8ba4\u63d0\u793a").message("\u7cfb\u7edf\u6b63\u5728\u62a2\u7968\u4e2d\uff0c\u786e\u8ba4\u9000\u51fa\u6b64\u7a0b\u5e8f\uff1f").confirmAndWait()) != 1) {
            if (event != null) {
                event.consume();
            }
            return false;
        }
        e.c();
        SystemTray.getSystemTray().remove(App.a);
        f.q();
        App.c.info("\u9000\u51fa\u7a0b\u5e8f!");
        return true;
    }
    
    private static void b(final Stage stage) throws AWTException {
        Platform.setImplicitExit(false);
        App.a.setImageAutoSize(true);
        App.a.addMouseListener(new net.tec.kyfw.c(stage));
        final MenuItem menuItem = new MenuItem("\u8f6f\u4ef6\u8bbe\u7f6e");
        final MenuItem menuItem2 = new MenuItem("\u8fdc\u7a0b\u6253\u7801");
        final MenuItem menuItem3 = new MenuItem("\u6253\u5f00\u4e3b\u9762\u677f");
        final MenuItem menuItem4 = new MenuItem("\u6700\u5c0f\u5316");
        final MenuItem menuItem5 = new MenuItem("\u9000\u51fa\u7a0b\u5e8f");
        menuItem.setFont(new Font("Microsoft YaHei", 0, 12));
        menuItem3.setFont(new Font("Microsoft YaHei", 0, 12));
        menuItem2.setFont(new Font("Microsoft YaHei", 0, 12));
        menuItem4.setFont(new Font("Microsoft YaHei", 0, 12));
        menuItem5.setFont(new Font("Microsoft YaHei", 1, 12));
        menuItem.setActionCommand("3");
        menuItem2.setActionCommand("4");
        menuItem5.setActionCommand("0");
        menuItem3.setActionCommand("1");
        menuItem4.setActionCommand("2");
        final net.tec.kyfw.d d = new net.tec.kyfw.d(stage);
        menuItem.addActionListener(d);
        menuItem3.addActionListener(d);
        menuItem5.addActionListener(d);
        menuItem4.addActionListener(d);
        menuItem2.addActionListener(d);
        final PopupMenu popupMenu = App.a.getPopupMenu();
        popupMenu.add(menuItem3);
        popupMenu.add(menuItem4);
        popupMenu.add(menuItem);
        popupMenu.add(menuItem2);
        popupMenu.addSeparator();
        popupMenu.add(menuItem5);
        SystemTray.getSystemTray().add(App.a);
    }
    
    static {
        App.c = j.a(App.class);
        App.a = null;
        App.b = null;
    }
}
