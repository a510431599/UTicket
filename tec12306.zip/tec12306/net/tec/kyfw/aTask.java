// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw;

import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.concurrent.Task;

final class aTask extends Task<Void>
{
    final /* synthetic */ Stage aStage;

    aTask(final Stage a) {
        this.aStage = a;
    }
    
    protected Void call() throws InterruptedException {
        Thread.sleep(800L);
        Platform.runLater((Runnable)new bRun(this));
        return null;
    }
}
