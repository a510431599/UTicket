// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

import net.tec.kyfw.util.j;
import java.io.IOException;
import java.net.URL;
import java.net.HttpURLConnection;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import net.tec.kyfw.f;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import java.nio.charset.StandardCharsets;
import org.apache.http.message.BasicNameValuePair;
import java.util.ArrayList;
import org.apache.http.client.methods.HttpPost;
import org.apache.log4j.Logger;

public class e
{
    private static Logger a;
    
    public static String a(final String s, final String s2) {
        final String s3 = "https://mail.10086.cn/Login/Login.ashx?_fv=4&resource=indexLogin";
        HttpEntity entity = null;
        HttpResponse execute = null;
        final HttpPost httpPost = new HttpPost(s3);
        try {
            final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            list.add(new BasicNameValuePair("UserName", s));
            list.add(new BasicNameValuePair("Password", s2));
            list.add(new BasicNameValuePair("VerifyCode", ""));
            list.add(new BasicNameValuePair("auto", "on"));
            list.add(new BasicNameValuePair("webVersion", "25"));
            list.add(new BasicNameValuePair("authType", "2"));
            entity = new UrlEncodedFormEntity(list, StandardCharsets.UTF_8);
            httpPost.setEntity(entity);
            execute = f.c().s().execute((HttpUriRequest)httpPost);
            if (302 == execute.getStatusLine().getStatusCode()) {
                return execute.getFirstHeader("Location").getValue();
            }
        }
        catch (Exception ex) {
            e.a.warn("\u767b\u5f55139\u51fa\u9519!", ex);
        }
        finally {
            a(entity);
            a((CloseableHttpResponse)execute);
            httpPost.abort();
        }
        return null;
    }
    
    public static String a(final String s, final String s2, final String s3, final String s4) {
        final String string = "http://smsrebuild1.mail.10086.cn/sms/sms?func=sms:sendSms&cguid=" + s2 + "&sid=" + s;
        HttpEntity entity = null;
        HttpResponse execute = null;
        final HttpPost httpPost = new HttpPost(string);
        try {
            entity = new StringEntity("<object><int name=\"doubleMsg\">0</int><int name=\"submitType\">1</int><string name=\"smsContent\">" + s3 + "</string><string name=\"receiverNumber\">86" + s4 + "</string><string name=\"comeFrom\">104</string><int name=\"sendType\">0</int><int name=\"smsType\">1</int><int name=\"serialId\">-1</int><int name=\"isShareSms\">0</int><string name=\"sendTime\"></string><string name=\"validImg\"></string><int name=\"groupLength\">50</int><int name=\"isSaveRecord\">1</int><int name=\"smsIds\"></int></object>", StandardCharsets.UTF_8);
            httpPost.setEntity(entity);
            execute = f.c().s().execute((HttpUriRequest)httpPost);
            if (200 == execute.getStatusLine().getStatusCode()) {
                a(entity);
                entity = execute.getEntity();
                return EntityUtils.toString(entity);
            }
        }
        catch (Exception ex) {
            e.a.warn("\u53d1\u9001\u77ed\u4fe1\u51fa\u9519!", ex);
        }
        finally {
            a(entity);
            a((CloseableHttpResponse)execute);
            httpPost.abort();
        }
        return null;
    }
    
    public static long a() {
        long headerFieldDate = 0L;
        try {
            final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL("http://open.baidu.com/special/time/").openConnection();
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setUseCaches(false);
            headerFieldDate = httpURLConnection.getHeaderFieldDate("Date", 0L);
            httpURLConnection.disconnect();
        }
        catch (Exception ex) {
            e.a.warn("\u8bbf\u95ee\u51fa\u9519!", ex);
        }
        return headerFieldDate;
    }
    
    public static void a(final HttpEntity httpEntity) {
        try {
            if (httpEntity != null) {
                EntityUtils.consume(httpEntity);
            }
        }
        catch (IOException ex) {}
    }
    
    public static void a(final CloseableHttpResponse closeableHttpResponse) {
        try {
            if (closeableHttpResponse != null) {
                closeableHttpResponse.close();
            }
        }
        catch (IOException ex) {}
    }
    
    static {
        e.a = j.a(e.class);
    }
}
