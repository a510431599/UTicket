// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

import java.security.cert.X509Certificate;
import org.apache.http.conn.ssl.TrustStrategy;

class d implements TrustStrategy
{
    final /* synthetic */ c a;
    
    d(final c a) {
        this.a = a;
    }
    
    @Override
    public boolean isTrusted(final X509Certificate[] array, final String s) {
        return true;
    }
}
