// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

public enum a
{
    SUCCESS("200", "\u6210\u529f"), 
    CONNECTION_TIMEOUT("-1000", "\u8fde\u63a5\u8d85\u65f6"), 
    SO_TIMEOUT("-1001", "\u54cd\u5e94\u8d85\u65f6"), 
    UNKNOWN_HOST_EXCEPTION("-1002", "\u7f51\u7edc\u8fde\u63a5\u5f02\u5e38"), 
    UNKNOWN_EXCEPTION("-1003", "\u672a\u77e5\u9519\u8bef"), 
    INVALID_SESSION("0000", "\u7528\u6237\u8eab\u4efd\u4fe1\u606f\u5931\u6548\uff0c\u8bf7\u91cd\u65b0\u767b\u5f55\uff01");
    
    public String E;
    public String M;
    
    private a(final String e, final String m) {
        this.E = e;
        this.M = m;
    }
    
    public static String getErrorMessage(final String s) {
        String m = null;
        for (final a a : values()) {
            if (a.E.equals(s)) {
                m = a.M;
                break;
            }
        }
        return m;
    }
    
    public static String getErrorMessage(final String s, final String s2) {
        if (s == null || a.UNKNOWN_EXCEPTION.E.equals(s)) {
            return s2;
        }
        String errorMessage = getErrorMessage(s);
        if (errorMessage == null) {
            errorMessage = s2;
        }
        return errorMessage;
    }
    
    public static boolean contains(final String s) {
        for (final a a : values()) {
            if (!a.equals(a.SUCCESS) && a.E.equals(s)) {
                return true;
            }
        }
        return false;
    }
}
