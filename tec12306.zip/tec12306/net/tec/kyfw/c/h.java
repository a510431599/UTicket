// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

import java.util.HashMap;
import java.io.Serializable;

public class h implements Serializable
{
    private Boolean a;
    private String b;
    private String c;
    private Object d;
    
    public static h a() {
        return new h();
    }
    
    public static h a(final Boolean b, final String s) {
        final h h = new h();
        h.a(b);
        h.b(s);
        return h;
    }
    
    public static h a(final Boolean b, final String s, final String s2) {
        final h h = new h();
        h.a(b);
        h.b(s);
        h.c(s2);
        return h;
    }
    
    public static h a(final Boolean b, final String s, final String s2, final Object o) {
        final h h = new h();
        h.a(b);
        h.b(s);
        h.c(s2);
        h.a(o);
        return h;
    }
    
    public static h a(final Boolean b, final String s, final Object o) {
        final h h = new h();
        h.a(b);
        h.b(s);
        h.a(o);
        return h;
    }
    
    public static h a(final String s, final Object o) {
        final h h = new h();
        h.a(Boolean.valueOf(true));
        h.b(s);
        h.a(o);
        return h;
    }
    
    public static h a(final String s, final String s2, final Object o) {
        final h h = new h();
        h.a(Boolean.valueOf(true));
        h.b(s);
        h.c(s2);
        h.a(o);
        return h;
    }
    
    public static h a(final String s) {
        final h h = new h();
        h.a(Boolean.valueOf(false));
        h.b(s);
        return h;
    }
    
    public static h a(final String s, final String s2) {
        final h h = new h();
        h.a(Boolean.valueOf(false));
        h.b(s);
        h.c(s2);
        return h;
    }
    
    public Boolean b() {
        return this.a;
    }
    
    public void a(final Boolean a) {
        this.a = a;
    }
    
    public String c() {
        return this.b;
    }
    
    public void b(final String b) {
        this.b = b;
    }
    
    public String d() {
        return this.c;
    }
    
    public void c(final String c) {
        this.c = c;
    }
    
    public <T> T e() {
        return (T)this.d;
    }
    
    public void a(final Object d) {
        this.d = d;
    }
    
    public static class a extends HashMap<String, Object>
    {
        public String a(final String s) {
            String s2 = null;
            if (this.get(s) != null) {
                s2 = ((HashMap<K, String>)this).get(s);
            }
            return s2;
        }
        
        public Integer b(final String s) {
            Integer n = null;
            if (this.get(s) != null) {
                n = ((HashMap<K, Integer>)this).get(s);
            }
            return n;
        }
        
        public <T> T c(final String s) {
            Object value = null;
            if (this.get(s) != null) {
                value = ((HashMap<K, Object>)this).get(s);
            }
            return (T)value;
        }
        
        public boolean d(final String s) {
            return this.get(s) == null;
        }
        
        public boolean e(final String s) {
            return this.get(s) == null || "".equals(this.a(s));
        }
    }
}
