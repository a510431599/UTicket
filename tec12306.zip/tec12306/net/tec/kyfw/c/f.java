// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

public class f
{
    private b a;
    private String b;
    private byte[] c;
    
    public f(final b a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    public f(final b a, final String b, final byte[] c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public b a() {
        return this.a;
    }
    
    public String b() {
        return this.b;
    }
    
    public byte[] c() {
        return this.c;
    }
}
