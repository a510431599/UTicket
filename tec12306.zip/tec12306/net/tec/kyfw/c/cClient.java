// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

import net.tec.kyfw.util.j;
import java.io.IOException;
import net.tec.kyfw.util.p;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import java.net.UnknownHostException;
import java.net.SocketTimeoutException;
import java.net.SocketException;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.util.EntityUtils;
import org.apache.http.HttpRequest;
import org.apache.http.client.methods.HttpGet;
import javax.net.ssl.SSLContext;
import org.apache.http.Header;
import java.util.Collection;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.config.Registry;
import java.net.CookieHandler;
import java.net.CookiePolicy;
import java.net.CookieManager;
import javax.net.ssl.HttpsURLConnection;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.message.BasicHeader;
import java.util.ArrayList;
import net.tec.kyfw.e;
import org.apache.http.client.config.RequestConfig;
import javax.net.ssl.HostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.ssl.TrustStrategy;
import java.security.KeyStore;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.HttpHost;
import org.apache.http.client.CookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.log4j.Logger;

public class cClient
{
    private static Logger a;
    private PoolingHttpClientConnectionManager b;
    private CloseableHttpClient i;
    private CookieStore j;
    private HttpHost k;
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public Long h;
    
    public cClient(final int connectTimeout, final int socketTimeout) {
        this.c = "4.5.1";
        this.d = null;
        this.e = null;
        this.f = null;
        this.g = null;
        this.h = 0L;
        try {
            final SSLContext build = SSLContexts.custom().loadTrustMaterial(null, new d(this)).build();
            final SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(build, NoopHostnameVerifier.INSTANCE);
            final RequestConfig.Builder setSocketTimeout = RequestConfig.custom().setConnectTimeout(connectTimeout).setSocketTimeout(socketTimeout);
            if (net.tec.kyfw.eMap.dMethod()) {
                setSocketTimeout.setProxy(new HttpHost(net.tec.kyfw.e.a(net.tec.kyfw.e.a.PROXY_HOST), Integer.parseInt(net.tec.kyfw.e.a(net.tec.kyfw.e.a.PROXY_PORT))));
            }
            final RequestConfig build2 = setSocketTimeout.build();
            final ArrayList<BasicHeader> defaultHeaders = new ArrayList<BasicHeader>();
            defaultHeaders.add(new BasicHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"));
            defaultHeaders.add(new BasicHeader("Cache-Control", "no-cache"));
            defaultHeaders.add(new BasicHeader("Accept", "*/*"));
            defaultHeaders.add(new BasicHeader("Accept-Language", "zh-CN"));
            defaultHeaders.add(new BasicHeader("Accept-Encoding", "gzip, deflate"));
            defaultHeaders.add(new BasicHeader("Connection", "keep-alive"));
            final Registry<PlainConnectionSocketFactory> build3 = RegistryBuilder.create().register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", (PlainConnectionSocketFactory)sslConnectionSocketFactory).build();
            HttpsURLConnection.setDefaultSSLSocketFactory(build.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(NoopHostnameVerifier.INSTANCE);
            final CookieManager default1 = new CookieManager();
            default1.setCookiePolicy(CookiePolicy.ACCEPT_NONE);
            CookieHandler.setDefault(default1);
            this.k = new HttpHost("kyfw.12306.cn", 443, "https");
            (this.b = new PoolingHttpClientConnectionManager((Registry<ConnectionSocketFactory>)build3)).setMaxTotal(1000);
            this.b.setDefaultMaxPerRoute(1000);
            this.j = new BasicCookieStore();
            this.i = HttpClients.custom().setConnectionManager(this.b).setDefaultHeaders(defaultHeaders).setDefaultRequestConfig(build2).setDefaultCookieStore(this.j).build();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public f a(final HttpHost httpHost, final String s, final Header... array) {
        final HttpGet httpGet = new HttpGet(s);
        if (array != null && array.length > 0) {
            for (int i = 0; i < array.length; ++i) {
                httpGet.setHeader(array[i]);
            }
        }
        CloseableHttpResponse execute = null;
        HttpEntity entity = null;
        f f = null;
        try {
            execute = this.s().execute(httpHost, (HttpRequest)httpGet);
            if (200 == execute.getStatusLine().getStatusCode()) {
                entity = execute.getEntity();
                byte[] array2;
                if (entity.getContentType() != null && (entity.getContentType().getValue().toLowerCase().contains("image") || entity.getContentType().getValue().contains("application/octet-stream"))) {
                    array2 = EntityUtils.toByteArray(entity);
                }
                else {
                    array2 = EntityUtils.toString(entity, "UTF-8").getBytes("UTF-8");
                }
                f = new f(net.tec.kyfw.c.b.SUCCESS, net.tec.kyfw.c.a.SUCCESS.E, array2);
            }
            else {
                f = new f(net.tec.kyfw.c.b.ERR_RESP_CODE, "-" + execute.getStatusLine().getStatusCode());
            }
        }
        catch (ConnectTimeoutException | SocketException ex4) {
            final Throwable t;
            net.tec.kyfw.c.c.a.warn("\u8fde\u63a5\u8d85\u65f6.", t);
            f = new f(net.tec.kyfw.c.b.CONNECTION_TIMEOUT, net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E);
        }
        catch (SocketTimeoutException ex) {
            net.tec.kyfw.c.c.a.warn("\u8bfb\u53d6\u6570\u636e\u8d85\u65f6.", ex);
            f = new f(net.tec.kyfw.c.b.SO_TIMEOUT, net.tec.kyfw.c.a.SO_TIMEOUT.E);
        }
        catch (UnknownHostException ex2) {
            net.tec.kyfw.c.c.a.warn("\u7f51\u7edc\u8fde\u63a5\u5f02\u5e38.", ex2);
            f = new f(net.tec.kyfw.c.b.UNKNOWN_HOST_EXCEPTION, net.tec.kyfw.c.a.UNKNOWN_HOST_EXCEPTION.E);
        }
        catch (Exception ex3) {
            net.tec.kyfw.c.c.a.error("\u672a\u77e5\u9519\u8bef.", ex3);
            f = new f(net.tec.kyfw.c.b.UNKNOWN_EXCEPTION, net.tec.kyfw.c.a.UNKNOWN_EXCEPTION.E);
        }
        finally {
            this.a(entity);
            this.a(execute);
            httpGet.abort();
        }
        return f;
    }
    
    public f a(final String s, final Header... array) {
        final HttpGet httpGet = new HttpGet(s);
        if (array != null && array.length > 0) {
            for (int i = 0; i < array.length; ++i) {
                httpGet.setHeader(array[i]);
            }
        }
        CloseableHttpResponse closeableHttpResponse = null;
        HttpEntity entity = null;
        f f = null;
        try {
            if (s.startsWith("https") || s.startsWith("http")) {
                closeableHttpResponse = this.s().execute((HttpUriRequest)httpGet);
            }
            else {
                closeableHttpResponse = this.s().execute(this.u(), (HttpRequest)httpGet);
            }
            if (200 == closeableHttpResponse.getStatusLine().getStatusCode()) {
                entity = closeableHttpResponse.getEntity();
                byte[] array2;
                if (entity.getContentType() != null && (entity.getContentType().getValue().toLowerCase().contains("image") || entity.getContentType().getValue().contains("application/octet-stream"))) {
                    array2 = EntityUtils.toByteArray(entity);
                }
                else {
                    array2 = EntityUtils.toString(entity, "UTF-8").getBytes("UTF-8");
                }
                f = new f(net.tec.kyfw.c.b.SUCCESS, net.tec.kyfw.c.a.SUCCESS.E, array2);
            }
            else {
                f = new f(net.tec.kyfw.c.b.ERR_RESP_CODE, "-" + closeableHttpResponse.getStatusLine().getStatusCode());
            }
        }
        catch (ConnectTimeoutException | SocketException ex4) {
            final Throwable t;
            net.tec.kyfw.c.c.a.warn("\u8fde\u63a5\u8d85\u65f6.", t);
            f = new f(net.tec.kyfw.c.b.CONNECTION_TIMEOUT, net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E);
        }
        catch (SocketTimeoutException ex) {
            net.tec.kyfw.c.c.a.warn("\u8bfb\u53d6\u6570\u636e\u8d85\u65f6.", ex);
            f = new f(net.tec.kyfw.c.b.SO_TIMEOUT, net.tec.kyfw.c.a.SO_TIMEOUT.E);
        }
        catch (UnknownHostException ex2) {
            net.tec.kyfw.c.c.a.warn("\u7f51\u7edc\u8fde\u63a5\u5f02\u5e38.", ex2);
            f = new f(net.tec.kyfw.c.b.UNKNOWN_HOST_EXCEPTION, net.tec.kyfw.c.a.UNKNOWN_HOST_EXCEPTION.E);
        }
        catch (Exception ex3) {
            net.tec.kyfw.c.c.a.error("\u672a\u77e5\u9519\u8bef.", ex3);
            f = new f(net.tec.kyfw.c.b.UNKNOWN_EXCEPTION, net.tec.kyfw.c.a.UNKNOWN_EXCEPTION.E);
        }
        finally {
            this.a(entity);
            this.a(closeableHttpResponse);
            httpGet.abort();
        }
        return f;
    }
    
    public f d(final String s) {
        return this.a(s, (HttpEntity)null, new Header[0]);
    }
    
    public f a(final String s, HttpEntity entity, final Header... array) {
        final HttpPost httpPost = new HttpPost(s);
        if (array != null && array.length > 0) {
            for (int i = 0; i < array.length; ++i) {
                httpPost.setHeader(array[i]);
            }
        }
        CloseableHttpResponse closeableHttpResponse = null;
        f f = null;
        try {
            if (entity != null) {
                httpPost.setEntity(entity);
            }
            if (s.startsWith("https") || s.startsWith("http")) {
                closeableHttpResponse = this.s().execute((HttpUriRequest)httpPost);
            }
            else {
                closeableHttpResponse = this.s().execute(this.u(), (HttpRequest)httpPost);
            }
            if (200 == closeableHttpResponse.getStatusLine().getStatusCode()) {
                if (entity != null) {
                    this.a(entity);
                }
                entity = closeableHttpResponse.getEntity();
                byte[] array2;
                if (entity.getContentType() != null && (entity.getContentType().getValue().toLowerCase().contains("image") || entity.getContentType().getValue().contains("application/octet-stream"))) {
                    array2 = EntityUtils.toByteArray(entity);
                }
                else {
                    array2 = EntityUtils.toString(entity, "UTF-8").getBytes("UTF-8");
                }
                f = new f(net.tec.kyfw.c.b.SUCCESS, net.tec.kyfw.c.a.SUCCESS.E, array2);
            }
            else {
                f = new f(net.tec.kyfw.c.b.ERR_RESP_CODE, "-" + closeableHttpResponse.getStatusLine().getStatusCode());
            }
        }
        catch (ConnectTimeoutException | SocketException ex4) {
            final Throwable t;
            net.tec.kyfw.c.c.a.warn("\u8fde\u63a5\u8d85\u65f6.", t);
            f = new f(net.tec.kyfw.c.b.CONNECTION_TIMEOUT, net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E);
        }
        catch (SocketTimeoutException ex) {
            net.tec.kyfw.c.c.a.warn("\u8bfb\u53d6\u6570\u636e\u8d85\u65f6.", ex);
            f = new f(net.tec.kyfw.c.b.SO_TIMEOUT, net.tec.kyfw.c.a.SO_TIMEOUT.E);
        }
        catch (UnknownHostException ex2) {
            net.tec.kyfw.c.c.a.warn("\u7f51\u7edc\u8fde\u63a5\u5f02\u5e38.", ex2);
            f = new f(net.tec.kyfw.c.b.UNKNOWN_HOST_EXCEPTION, net.tec.kyfw.c.a.UNKNOWN_HOST_EXCEPTION.E);
        }
        catch (Exception ex3) {
            net.tec.kyfw.c.c.a.error("\u672a\u77e5\u9519\u8bef.", ex3);
            f = new f(net.tec.kyfw.c.b.UNKNOWN_EXCEPTION, net.tec.kyfw.c.a.UNKNOWN_EXCEPTION.E);
        }
        finally {
            this.a(entity);
            this.a(closeableHttpResponse);
            httpPost.abort();
        }
        return f;
    }
    
    public String e(final String s) {
        return this.b(s, null, new Header[0]);
    }
    
    public String b(final String s, final HttpEntity entity, final Header... array) {
        String s2 = null;
        final HttpPost httpPost = new HttpPost(s);
        if (array != null && array.length > 0) {
            for (int i = 0; i < array.length; ++i) {
                httpPost.setHeader(array[i]);
            }
        }
        CloseableHttpResponse closeableHttpResponse = null;
        try {
            if (entity != null) {
                httpPost.setEntity(entity);
            }
            if (s.startsWith("https") || s.startsWith("http")) {
                closeableHttpResponse = this.s().execute((HttpUriRequest)httpPost);
            }
            else {
                closeableHttpResponse = this.s().execute(this.u(), (HttpRequest)httpPost);
            }
            if (302 == closeableHttpResponse.getStatusLine().getStatusCode()) {
                s2 = ((closeableHttpResponse.getFirstHeader("Location") != null) ? closeableHttpResponse.getFirstHeader("Location").getValue() : null);
            }
        }
        catch (ConnectTimeoutException | SocketException ex4) {
            final Throwable t;
            net.tec.kyfw.c.c.a.warn("\u8fde\u63a5\u8d85\u65f6.", t);
        }
        catch (SocketTimeoutException ex) {
            net.tec.kyfw.c.c.a.warn("\u8bfb\u53d6\u6570\u636e\u8d85\u65f6.", ex);
        }
        catch (UnknownHostException ex2) {
            net.tec.kyfw.c.c.a.warn("\u7f51\u7edc\u8fde\u63a5\u5f02\u5e38.", ex2);
        }
        catch (Exception ex3) {
            net.tec.kyfw.c.c.a.error("\u672a\u77e5\u9519\u8bef.", ex3);
        }
        finally {
            this.a(entity);
            this.a(closeableHttpResponse);
            httpPost.abort();
        }
        return s2;
    }
    
    public boolean r() {
        return p.a(this.f) || System.currentTimeMillis() - this.h > 300000L;
    }
    
    public CloseableHttpClient s() {
        return this.i;
    }
    
    public CookieStore t() {
        return this.j;
    }
    
    public HttpHost u() {
        return this.k;
    }
    
    public void a(final HttpEntity httpEntity) {
        try {
            if (httpEntity != null) {
                EntityUtils.consume(httpEntity);
            }
        }
        catch (IOException ex) {}
    }
    
    public void a(final CloseableHttpResponse closeableHttpResponse) {
        try {
            if (closeableHttpResponse != null) {
                closeableHttpResponse.close();
            }
        }
        catch (IOException ex) {}
    }
    
    static {
        c.a = j.a(c.class);
    }
}
