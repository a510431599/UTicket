// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

import net.tec.kyfw.util.j;
import java.io.UnsupportedEncodingException;
import org.apache.http.client.methods.CloseableHttpResponse;
import java.net.HttpURLConnection;
import org.apache.http.HttpRequest;
import org.apache.http.client.methods.HttpPost;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.util.Iterator;
import org.apache.http.client.CookieStore;
import org.apache.http.HttpHost;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.cookie.BasicClientCookie;
import java.util.Date;
import net.tec.kyfw.util.e;
import net.tec.kyfw.a.i;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import net.tec.kyfw.util.DateUtil;
import net.tec.kyfw.b.H;
import java.util.List;
import net.tec.kyfw.util.t;
import java.util.Map;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.ObservableList;
import net.tec.kyfw.util.p;
import net.tec.kyfw.util.r;
import net.tec.kyfw.d.d;
import net.tec.kyfw.d.c;
import javafx.collections.FXCollections;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import java.nio.charset.StandardCharsets;
import org.apache.http.message.BasicNameValuePair;
import java.util.ArrayList;
import net.tec.kyfw.f;
import org.apache.log4j.Logger;

public class g
{
    private static Logger b;
    private static String c;
    public static String a;
    private static String d;
    private static String e;
    private static String f;
    private static String g;
    private static String h;
    private static String i;
    private static String j;
    private static String k;
    private static String l;
    private static String m;
    private static String n;
    private static String o;
    private static String p;
    private static String q;
    private static String r;
    private static String s;
    private static String t;
    private static String u;
    private static String v;
    private static String w;
    private static String x;
    private static String y;
    private static String z;
    private static String A;
    private static String B;
    private static String C;
    private static String D;
    private static String E;
    private static String F;
    private static String G;
    private static String H;
    private static String I;
    private static String J;
    private static String K;
    private static String L;
    private static String M;
    
    public static h a(final f f, final String s, final String s2, final String s3) {
        Boolean b = Boolean.FALSE;
        String s4 = net.tec.kyfw.c.a.SUCCESS.E;
        String s5 = ("Y".equals(s3) ? "\u53d8\u66f4\u5230\u7ad9" : "\u6539\u7b7e") + "\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        list.add(new BasicNameValuePair("ticketkey", s));
        list.add(new BasicNameValuePair("sequenceNo", s2));
        list.add(new BasicNameValuePair("changeTSFlag", s3));
        list.add(new BasicNameValuePair("_json_att", ""));
        final net.tec.kyfw.c.f a = f.a(net.tec.kyfw.c.g.L, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8), new BasicHeader("Origin", "https://kyfw.12306.cn"), new BasicHeader("Referer", "https://kyfw.12306.cn/otn/leftTicket/init"));
        String s6;
        if (net.tec.kyfw.c.b.SUCCESS.equals(a.a())) {
            s6 = a(a.c());
        }
        else {
            s6 = a.b();
        }
        if (a(s6)) {
            final JSONObject jsonObject = new JSONObject(s6);
            if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                if ("N".equals(jsonObject2.getString("existError"))) {
                    b = Boolean.TRUE;
                }
                else {
                    s5 = jsonObject2.optString("errorMsg");
                }
            }
            else {
                final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                for (int i = 0; i < jsonArray.length(); ++i) {
                    s5 = s5 + jsonArray.getString(i) + "\r\n";
                }
                s5 = s5.trim();
            }
        }
        else if ("-302".equals(s6)) {
            s4 = net.tec.kyfw.c.a.INVALID_SESSION.E;
            s5 = net.tec.kyfw.c.a.INVALID_SESSION.M;
        }
        else {
            s4 = s6;
            s5 = net.tec.kyfw.c.a.getErrorMessage(s4, s5);
        }
        return net.tec.kyfw.c.h.a(b, s5, s4);
    }
    
    public static h a(final f f, final String s, final String s2, final String s3, final String s4) {
        final Boolean false = Boolean.FALSE;
        String string = "";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        list.add(new BasicNameValuePair("queryType", s));
        list.add(new BasicNameValuePair("queryStartDate", s2));
        list.add(new BasicNameValuePair("queryEndDate", s3));
        list.add(new BasicNameValuePair("come_from_flag", "my_order"));
        list.add(new BasicNameValuePair("pageSize", "50"));
        list.add(new BasicNameValuePair("pageIndex", "0"));
        list.add(new BasicNameValuePair("query_where", "G"));
        list.add(new BasicNameValuePair("sequeue_train_name", s4));
        final String a = a(f, net.tec.kyfw.c.g.F, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        String s5;
        if (a(a)) {
            final JSONObject jsonObject = new JSONObject(a);
            if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                final Boolean true = Boolean.TRUE;
                final ObservableList observableArrayList = FXCollections.observableArrayList();
                if (jsonObject2.keySet().contains("OrderDTODataList") && !jsonObject2.isNull("OrderDTODataList")) {
                    int n = 1;
                    final JSONArray jsonArray = jsonObject2.getJSONArray("OrderDTODataList");
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        final JSONArray jsonArray2 = jsonArray.getJSONObject(i).getJSONArray("tickets");
                        for (int j = 0; j < jsonArray2.length(); ++j) {
                            final c c = new c();
                            final JSONObject jsonObject3 = jsonArray2.getJSONObject(j);
                            final JSONObject jsonObject4 = jsonObject3.getJSONObject("stationTrainDTO");
                            final JSONObject jsonObject5 = jsonObject3.getJSONObject("passengerDTO");
                            final String optString = jsonObject3.optString("resign_flag");
                            final String optString2 = jsonObject3.optString("return_flag");
                            c.setIndex(String.valueOf(n++));
                            c.setSequenceNo(jsonObject3.optString("sequence_no"));
                            c.setTicketNo(jsonObject3.optString("ticket_no"));
                            c.setTrainInfo(jsonObject3.optString("start_train_date_page") + "\u5f00\r\n" + jsonObject4.optString("station_train_code") + " " + jsonObject4.optString("from_station_name") + "-" + jsonObject4.optString("to_station_name"));
                            c.setSeatInfo(jsonObject3.optString("coach_name") + "\u8f66\u53a2" + jsonObject3.optString("seat_name") + "\r\n" + jsonObject3.optString("seat_type_name"));
                            c.setPassengerInfo(jsonObject5.optString("passenger_name") + "\r\n" + jsonObject5.optString("passenger_id_type_name"));
                            c.setTicketInfo(jsonObject3.optString("ticket_type_name") + "\r\n" + jsonObject3.optString("str_ticket_price_page") + "\u5143");
                            c.setStatus(jsonObject3.optString("ticket_status_name"));
                            c.setName(jsonObject5.optString("passenger_name"));
                            c.setCardType(net.tec.kyfw.d.d.a.getName(jsonObject5.optString("passenger_id_type_code")));
                            c.setCardCode(jsonObject5.optString("passenger_id_no"));
                            c.setPassengerType(net.tec.kyfw.util.r.a.getPassengerType(jsonObject3.optString("ticket_type_code")));
                            c.setStationTrainCode(jsonObject4.optString("station_train_code"));
                            c.setTrainDate(jsonObject3.getString("train_date").substring(0, 10));
                            c.setFromStationName(jsonObject4.optString("from_station_name"));
                            c.setFromStationTelecode(jsonObject4.optString("from_station_telecode"));
                            c.setToStationName(jsonObject4.optString("to_station_name"));
                            c.setToStationTelecode(jsonObject4.optString("to_station_telecode"));
                            if ("1".equals(optString)) {
                                c.setResignFlag(true);
                                c.setReturnFlag(true);
                            }
                            else if ("2".equals(optString)) {
                                c.setResignFlag(true);
                                c.setReturnFlag(false);
                            }
                            else if ("3".equals(optString)) {
                                c.setResignFlag(false);
                                c.setReturnFlag(true);
                            }
                            else {
                                c.setResignFlag(false);
                                c.setReturnFlag(false);
                            }
                            if (!"4".equals(optString) && "Y".equals(optString2)) {
                                c.setTicketkey(jsonObject3.optString("sequence_no") + "," + jsonObject3.optString("batch_no") + "," + jsonObject3.optString("coach_no") + "," + jsonObject3.optString("seat_no") + "," + jsonObject3.optString("start_train_date_page") + "#");
                            }
                            else {
                                c.setTicketkey(jsonObject3.optString("sequence_no") + "," + jsonObject3.optString("batch_no") + "," + jsonObject3.optString("coach_no") + "," + jsonObject3.optString("seat_no") + "," + jsonObject3.optString("start_train_date") + "#");
                            }
                            observableArrayList.add((Object)c);
                        }
                    }
                }
                return net.tec.kyfw.c.h.a(true, string, observableArrayList);
            }
            final JSONArray jsonArray3 = jsonObject.getJSONArray("messages");
            for (int k = 0; k < jsonArray3.length(); ++k) {
                string = string + jsonArray3.getString(k) + "\r\n";
            }
            s5 = string.trim();
        }
        else if ("-302".equals(a) || a.startsWith("<")) {
            s5 = net.tec.kyfw.c.a.INVALID_SESSION.M;
        }
        else {
            s5 = net.tec.kyfw.c.a.getErrorMessage(a, "\u67e5\u8be2\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        if (net.tec.kyfw.util.p.a((Object)s5)) {
            s5 = "\u67e5\u8be2\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        }
        return net.tec.kyfw.c.h.a(false, s5);
    }
    
    public static h a(final f f, final String s, final Boolean b) {
        Boolean b2 = Boolean.FALSE;
        String s2 = "\u64cd\u4f5c\u5931\u8d25\uff01";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        if (b) {
            if (!a(f, s, "resign")) {
                return net.tec.kyfw.c.h.a(b2, "\u6539\u7b7e\u8ba2\u5355\u53d6\u6d88\u5931\u8d25\uff01");
            }
            final String c = c(f, net.tec.kyfw.c.g.K);
            if (c == null) {
                return net.tec.kyfw.c.h.a(b2, "\u6539\u7b7e\u8ba2\u5355\u53d6\u6d88\u5931\u8d25\uff01");
            }
            final Matcher matcher = Pattern.compile("(?m)(?s)parOrderDTOJson\\s*\\=\\s*[\"']{1}(.*?)[\"']{1}\\;.*?sequence\\_no\\s*\\=\\s*[\"']{1}(.*?)[\"']{1}.*?orderRequestDTOJson\\s*\\=\\s*[\"']{1}(.*?)[\"']{1}").matcher(c);
            if (!matcher.find()) {
                return net.tec.kyfw.c.h.a(b2, "\u6539\u7b7e\u8ba2\u5355\u53d6\u6d88\u5931\u8d25\uff01");
            }
            list.add(new BasicNameValuePair("parOrderDTOJson", matcher.group(1).replaceAll("\\\\", "")));
            list.add(new BasicNameValuePair("sequence_no", matcher.group(2)));
            list.add(new BasicNameValuePair("orderRequestDTOJson", matcher.group(3)));
        }
        else if ("--".equals(s)) {
            list.add(new BasicNameValuePair("tourFlag", "dc"));
        }
        else {
            list.add(new BasicNameValuePair("sequence_no", s));
            list.add(new BasicNameValuePair("cancel_flag", "cancel_order"));
        }
        final String a = a(f, "--".equals(s) ? net.tec.kyfw.c.g.I : (b ? net.tec.kyfw.c.g.H : net.tec.kyfw.c.g.G), new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        if (a(a)) {
            final JSONObject jsonObject = new JSONObject(a);
            if (jsonObject.getBoolean("status")) {
                final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                if ("N".equals(jsonObject2.optString("existError")) || jsonObject2.optBoolean("cancelStatus")) {
                    b2 = Boolean.TRUE;
                }
            }
            else {
                final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                for (int i = 0; i < jsonArray.length(); ++i) {
                    s2 = s2 + jsonArray.getString(i) + "\r\n";
                }
                s2 = s2.trim();
            }
        }
        else {
            s2 = net.tec.kyfw.c.a.getErrorMessage(a, "\u64cd\u4f5c\u5931\u8d25\uff01");
        }
        return net.tec.kyfw.c.h.a(b2, s2);
    }
    
    public static Boolean a(final f f, final String s, final String s2) {
        Boolean b = Boolean.FALSE;
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        list.add(new BasicNameValuePair("sequence_no", s));
        list.add(new BasicNameValuePair("pay_flag", s2));
        final String a = a(f, net.tec.kyfw.c.g.J, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        if (a(a)) {
            final JSONObject jsonObject = new JSONObject(a);
            if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data") && "N".equals(jsonObject.getJSONObject("data").getString("existError"))) {
                b = Boolean.TRUE;
            }
        }
        return b;
    }
    
    public static h a(final f f) {
        final Boolean false = Boolean.FALSE;
        String string = "";
        final String b = b(f, net.tec.kyfw.c.g.E);
        String s;
        if (a(b)) {
            final JSONObject jsonObject = new JSONObject(b);
            if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                final Boolean true = Boolean.TRUE;
                final h.a a = new h.a();
                if (jsonObject2.keySet().contains("orderCacheDTO") && !jsonObject2.isNull("orderCacheDTO")) {
                    final JSONObject jsonObject3 = jsonObject2.getJSONObject("orderCacheDTO");
                    ((HashMap<String, String>)a).put("orderId", "--");
                    ((HashMap<String, String>)a).put("ticketCount", jsonObject3.optString("ticketCount"));
                    ((HashMap<String, String>)a).put("ticketTotalPrice", "--");
                    ((HashMap<String, String>)a).put("stationTrainCode", jsonObject3.optString("stationTrainCode"));
                    ((HashMap<String, String>)a).put("trainDate", jsonObject3.optString("startTimeString"));
                    ((HashMap<String, String>)a).put("fromStationName", jsonObject3.optString("fromStationName"));
                    ((HashMap<String, String>)a).put("toStationName", jsonObject3.optString("toStationName"));
                    if (jsonObject3.optInt("waitTime") != -2) {
                        ((HashMap<String, String>)a).put("ticketStatus", "\u6392\u961f\u7b49\u5f85\u4e2d");
                        ((HashMap<String, String>)a).put("waitTime", jsonObject3.optInt("waitTime"));
                    }
                    else {
                        ((HashMap<String, String>)a).put("error", true);
                        ((HashMap<String, String>)a).put("ticketStatus", jsonObject3.optJSONObject("message").optString("message"));
                    }
                    final JSONArray jsonArray = jsonObject3.getJSONArray("tickets");
                    final ArrayList<h.a> list = new ArrayList<h.a>();
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        final JSONObject jsonObject4 = jsonArray.getJSONObject(i);
                        final h.a a2 = new h.a();
                        ((HashMap<String, String>)a2).put("train", jsonObject3.optString("startTimeString") + "\u5f00 " + jsonObject3.optString("stationTrainCode") + " " + jsonObject3.optString("fromStationName") + "-" + jsonObject3.optString("toStationName"));
                        ((HashMap<String, String>)a2).put("seat", jsonObject4.optString("seatTypeName"));
                        ((HashMap<String, String>)a2).put("passenger", jsonObject4.optString("passengerName") + "\uff0c" + jsonObject4.optString("ticketTypeName"));
                        list.add(a2);
                    }
                    ((HashMap<String, String>)a).put("tickets", list);
                }
                else if (jsonObject2.keySet().contains("orderDBList") && !jsonObject2.isNull("orderDBList")) {
                    final JSONObject jsonObject5 = jsonObject2.getJSONArray("orderDBList").getJSONObject(0);
                    final JSONArray jsonArray2 = jsonObject5.getJSONArray("tickets");
                    ((HashMap<String, String>)a).put("orderId", jsonObject5.optString("sequence_no"));
                    ((HashMap<String, String>)a).put("payFlag", "Y".equals(jsonObject5.optString("pay_flag")) ? "pay" : "resign");
                    ((HashMap<String, String>)a).put("ticketCount", jsonObject5.optString("ticket_totalnum"));
                    ((HashMap<String, String>)a).put("ticketTotalPrice", "\uffe5" + jsonObject5.opt("ticket_total_price_page"));
                    ((HashMap<String, String>)a).put("ticketStatus", jsonArray2.getJSONObject(0).optString("ticket_status_name"));
                    ((HashMap<String, String>)a).put("trainDate", jsonObject5.optString("start_train_date_page"));
                    ((HashMap<String, String>)a).put("fromStationName", jsonObject5.getJSONArray("from_station_name_page").join(",").replaceAll("\"", ""));
                    ((HashMap<String, String>)a).put("toStationName", jsonObject5.getJSONArray("to_station_name_page").join(",").replaceAll("\"", ""));
                    final ArrayList<HashMap<String, String>> list2 = new ArrayList<HashMap<String, String>>();
                    for (int j = 0; j < jsonArray2.length(); ++j) {
                        final JSONObject jsonObject6 = jsonArray2.getJSONObject(j);
                        final JSONObject jsonObject7 = jsonObject6.getJSONObject("stationTrainDTO");
                        final JSONObject jsonObject8 = jsonObject6.getJSONObject("passengerDTO");
                        final h.a a3 = new h.a();
                        ((HashMap<String, String>)a3).put("train", jsonObject6.optString("start_train_date_page") + "\u5f00 " + jsonObject7.optString("station_train_code") + " " + jsonObject7.optString("from_station_name") + "-" + jsonObject7.optString("to_station_name"));
                        ((HashMap<String, String>)a3).put("seat", jsonObject6.optString("seat_type_name") + jsonObject6.optString("coach_no") + "\u8f66" + jsonObject6.optString("seat_name"));
                        ((HashMap<String, String>)a3).put("passenger", jsonObject8.optString("passenger_name") + "\uff0c" + jsonObject6.optString("ticket_type_name") + "\uff0c\uffe5" + jsonObject6.opt("str_ticket_price_page"));
                        list2.add((HashMap<String, String>)a3);
                    }
                    ((HashMap<String, String>)a).put("tickets", list2);
                }
                return net.tec.kyfw.c.h.a(true, string, a);
            }
            final JSONArray jsonArray3 = jsonObject.getJSONArray("messages");
            for (int k = 0; k < jsonArray3.length(); ++k) {
                string = string + jsonArray3.getString(k) + "\r\n";
            }
            s = string.trim();
        }
        else if ("-302".equals(b) || b.startsWith("<")) {
            s = net.tec.kyfw.c.a.INVALID_SESSION.M;
        }
        else {
            s = net.tec.kyfw.c.a.getErrorMessage(b, "\u67e5\u8be2\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        if (net.tec.kyfw.util.p.a((Object)s)) {
            s = "\u60a8\u6ca1\u6709\u672a\u5b8c\u6210\u8ba2\u5355\uff0c\u53ef\u4ee5\u901a\u8fc7\u8f66\u7968\u9884\u8ba2\u529f\u80fd\uff0c\u6765\u5236\u5b9a\u51fa\u884c\u8ba1\u5212\uff01";
        }
        return net.tec.kyfw.c.h.a(false, s);
    }
    
    public static h a(final f f, final Map<String, String> map) {
        h(f);
        Boolean b = Boolean.FALSE;
        String s = net.tec.kyfw.c.a.SUCCESS.E;
        String s2 = "";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        if (!f.r()) {
            list.add(new BasicNameValuePair(f.f, f.g));
        }
        list.add(new BasicNameValuePair("secretStr", map.get("secretStr")));
        list.add(new BasicNameValuePair("train_date", map.get("train_date")));
        list.add(new BasicNameValuePair("back_train_date", map.get("back_train_date")));
        list.add(new BasicNameValuePair("tour_flag", map.get("tour_flag")));
        list.add(new BasicNameValuePair("purpose_codes", map.get("purpose_codes")));
        list.add(new BasicNameValuePair("query_from_station_name", map.get("query_from_station_name")));
        list.add(new BasicNameValuePair("query_to_station_name", map.get("query_to_station_name")));
        final String a = a(f, net.tec.kyfw.c.g.u, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        if (a(a)) {
            try {
                final JSONObject jsonObject = new JSONObject(a);
                if (jsonObject.getBoolean("status")) {
                    b = Boolean.TRUE;
                }
                else {
                    final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        s2 = s2 + jsonArray.getString(i) + "\r\n";
                    }
                    s2 = s2.trim();
                    if (s2.contains("\u672a\u5904\u7406\u7684\u8ba2\u5355")) {
                        s2 = "\u60a8\u8fd8\u6709\u672a\u5904\u7406\u7684\u8ba2\u5355,\u8bf7\u5230\u201c\u6211\u7684\u8ba2\u5355\u201d\u4e2d\u8fdb\u884c\u5904\u7406!";
                    }
                    else {
                        a(f, s2);
                    }
                }
            }
            catch (Exception ex) {
                net.tec.kyfw.c.g.b.error(a);
                net.tec.kyfw.c.g.b.error("\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25", ex);
            }
        }
        else if ("-302".equals(a)) {
            s = net.tec.kyfw.c.a.INVALID_SESSION.E;
            s2 = net.tec.kyfw.c.a.INVALID_SESSION.M;
        }
        else {
            s = a;
            s2 = net.tec.kyfw.c.a.getErrorMessage(s, "\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        return net.tec.kyfw.c.h.a(b, s2, s);
    }
    
    public static h b(final f f, final Map<String, String> map) {
        h(f);
        Boolean b = Boolean.FALSE;
        String s = net.tec.kyfw.c.a.SUCCESS.E;
        String s2 = "";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        if (!f.r()) {
            list.add(new BasicNameValuePair(f.f, f.g));
        }
        list.add(new BasicNameValuePair("myversion", "undefined"));
        list.add(new BasicNameValuePair("secretStr", map.get("secretStr")));
        list.add(new BasicNameValuePair("train_date", map.get("train_date")));
        list.add(new BasicNameValuePair("tour_flag", map.get("tour_flag")));
        list.add(new BasicNameValuePair("purpose_codes", map.get("purpose_codes")));
        list.add(new BasicNameValuePair("query_from_station_name", map.get("query_from_station_name")));
        list.add(new BasicNameValuePair("query_to_station_name", map.get("query_to_station_name")));
        list.add(new BasicNameValuePair("cancel_flag", "2"));
        list.add(new BasicNameValuePair("bed_level_order_num", "000000000000000000000000000000"));
        list.add(new BasicNameValuePair("passengerTicketStr", map.get("passengerTicketStr")));
        list.add(new BasicNameValuePair("oldPassengerStr", map.get("oldPassengerStr")));
        final String a = a(f, net.tec.kyfw.c.g.v, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        if (a(a)) {
            try {
                final JSONObject jsonObject = new JSONObject(a);
                if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                    final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                    if (jsonObject2.getBoolean("submitStatus")) {
                        final String optString = jsonObject2.optString("result");
                        final String optString2 = jsonObject2.optString("ifShowPassCode");
                        final String value = String.valueOf(jsonObject2.optInt("ifShowPassCodeTime"));
                        b = Boolean.TRUE;
                        final h.a a2 = new h.a();
                        ((HashMap<String, String>)a2).put("result", optString);
                        ((HashMap<String, String>)a2).put("ifShowPassCode", optString2);
                        ((HashMap<String, String>)a2).put("ifShowPassCodeTime", value);
                        return net.tec.kyfw.c.h.a(b, s2, s, a2);
                    }
                    s2 = b(jsonObject2.getString("errMsg"));
                }
                else if (jsonObject.keySet().contains("messages")) {
                    final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                    s2 = "";
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        s2 = s2 + jsonArray.getString(i) + "\r\n";
                    }
                    s2 = b(s2.trim());
                    if (s2.contains("\u672a\u5904\u7406\u7684\u8ba2\u5355")) {
                        s2 = "\u60a8\u8fd8\u6709\u672a\u5904\u7406\u7684\u8ba2\u5355\uff0c\u8bf7\u5230\u201c\u6211\u7684\u8ba2\u5355\u201d\u4e2d\u8fdb\u884c\u5904\u7406!";
                    }
                    else {
                        a(f, s2);
                    }
                }
            }
            catch (Exception ex) {
                net.tec.kyfw.c.g.b.error(a);
                net.tec.kyfw.c.g.b.error("\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25", ex);
            }
        }
        else if ("-302".equals(a)) {
            s = net.tec.kyfw.c.a.INVALID_SESSION.E;
            s2 = net.tec.kyfw.c.a.INVALID_SESSION.M;
        }
        else {
            s = a;
            s2 = net.tec.kyfw.c.a.getErrorMessage(s, "\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        if (net.tec.kyfw.util.p.a((Object)s2)) {
            s2 = "\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        }
        return net.tec.kyfw.c.h.a(b, s2, s);
    }
    
    public static h c(final f f, final Map<String, String> map) {
        Boolean b = Boolean.FALSE;
        String s = net.tec.kyfw.c.a.SUCCESS.E;
        String s2 = "";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        list.add(new BasicNameValuePair("train_date", map.get("train_date")));
        list.add(new BasicNameValuePair("train_no", map.get("train_no")));
        list.add(new BasicNameValuePair("stationTrainCode", map.get("stationTrainCode")));
        list.add(new BasicNameValuePair("seatType", map.get("seatType")));
        list.add(new BasicNameValuePair("fromStationTelecode", map.get("fromStationTelecode")));
        list.add(new BasicNameValuePair("toStationTelecode", map.get("toStationTelecode")));
        list.add(new BasicNameValuePair("leftTicket", map.get("leftTicket")));
        list.add(new BasicNameValuePair("purpose_codes", "ADULT"));
        final String a = a(f, net.tec.kyfw.c.g.z, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        if (a(a)) {
            try {
                final JSONObject jsonObject = new JSONObject(a);
                if (jsonObject.getBoolean("status")) {
                    final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                    final Integer value = jsonObject2.isNull("countT") ? 0 : jsonObject2.getInt("countT");
                    final String string = jsonObject2.getString("op_2");
                    final String string2 = jsonObject2.getString("ticket");
                    b = Boolean.TRUE;
                    final h.a a2 = new h.a();
                    ((HashMap<String, Integer>)a2).put("countT", value);
                    ((HashMap<String, Integer>)a2).put("op_2", string);
                    ((HashMap<String, Integer>)a2).put("ticket", string2);
                    return net.tec.kyfw.c.h.a(b, s2, s, a2);
                }
                if (jsonObject.keySet().contains("messages")) {
                    final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                    s2 = "";
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        s2 = s2 + jsonArray.getString(i) + "\r\n";
                    }
                    s2 = s2.trim();
                }
            }
            catch (Exception ex) {
                net.tec.kyfw.c.g.b.error(a);
                net.tec.kyfw.c.g.b.error("\u83b7\u53d6\u6392\u961f\u4eba\u6570\u5931\u8d25", ex);
            }
        }
        else if ("-302".equals(a)) {
            s = net.tec.kyfw.c.a.INVALID_SESSION.E;
            s2 = net.tec.kyfw.c.a.INVALID_SESSION.M;
        }
        else {
            s = a;
            s2 = net.tec.kyfw.c.a.getErrorMessage(s, "\u83b7\u53d6\u6392\u961f\u4eba\u6570\u5931\u8d25\uff01");
        }
        if (net.tec.kyfw.util.p.a((Object)s2)) {
            s2 = "\u83b7\u53d6\u6392\u961f\u4eba\u6570\u5931\u8d25\uff01";
        }
        return net.tec.kyfw.c.h.a(b, s2, s);
    }
    
    public static h b(final f f) {
        final Boolean false = Boolean.FALSE;
        String e = net.tec.kyfw.c.a.SUCCESS.E;
        String errorMessage = "\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        final String c = c(f, net.tec.kyfw.c.g.w);
        if (c.startsWith("-")) {
            e = c;
            errorMessage = net.tec.kyfw.c.a.getErrorMessage(e, "\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        else {
            final String d = net.tec.kyfw.util.t.d(c);
            if (net.tec.kyfw.util.p.b((Object)d)) {
                f.f = net.tec.kyfw.util.t.e(b(f, d));
                if (net.tec.kyfw.util.p.b((Object)f.f)) {
                    f.g = net.tec.kyfw.util.t.a(f.f);
                }
            }
            if (net.tec.kyfw.util.p.b((Object)c)) {
                final Matcher matcher = Pattern.compile("(?s)(?i)globalRepeatSubmitToken\\s*\\=\\s*(['\"]+)([^'\"]*)").matcher(c);
                if (matcher.find()) {
                    final String group = matcher.group(2);
                    final Matcher matcher2 = Pattern.compile("(?s)(?i)'key_check_isChange'\\s*\\:\\s*(['\"]{1})([^'\"]*)").matcher(c);
                    if (matcher2.find()) {
                        final String group2 = matcher2.group(2);
                        final Boolean true = Boolean.TRUE;
                        final h.a a = new h.a();
                        ((HashMap<String, String>)a).put("token", group);
                        ((HashMap<String, String>)a).put("key_check_isChange", group2);
                        f.d(net.tec.kyfw.c.g.m);
                        return net.tec.kyfw.c.h.a(true, errorMessage, e, a);
                    }
                }
            }
        }
        return net.tec.kyfw.c.h.a(false, errorMessage, e);
    }
    
    public static h c(final f f) {
        final Boolean false = Boolean.FALSE;
        String e = net.tec.kyfw.c.a.SUCCESS.E;
        String errorMessage = "\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        final String c = c(f, net.tec.kyfw.c.g.x);
        if (c.startsWith("-")) {
            e = c;
            errorMessage = net.tec.kyfw.c.a.getErrorMessage(e, "\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        else {
            final String d = net.tec.kyfw.util.t.d(c);
            if (net.tec.kyfw.util.p.b((Object)d)) {
                f.f = net.tec.kyfw.util.t.e(b(f, d));
                if (net.tec.kyfw.util.p.b((Object)f.f)) {
                    f.g = net.tec.kyfw.util.t.a(f.f);
                }
            }
            if (net.tec.kyfw.util.p.b((Object)c)) {
                final Matcher matcher = Pattern.compile("(?s)(?i)globalRepeatSubmitToken\\s*\\=\\s*(['\"]+)([^'\"]*)").matcher(c);
                if (matcher.find()) {
                    final String group = matcher.group(2);
                    final Matcher matcher2 = Pattern.compile("(?s)(?i)'key_check_isChange'\\s*\\:\\s*(['\"]{1})([^'\"]*)").matcher(c);
                    if (matcher2.find()) {
                        final String group2 = matcher2.group(2);
                        final Boolean true = Boolean.TRUE;
                        final h.a a = new h.a();
                        ((HashMap<String, String>)a).put("token", group);
                        ((HashMap<String, String>)a).put("key_check_isChange", group2);
                        f.d(net.tec.kyfw.c.g.m);
                        return net.tec.kyfw.c.h.a(true, errorMessage, e, a);
                    }
                }
            }
        }
        return net.tec.kyfw.c.h.a(false, errorMessage, e);
    }
    
    public static h d(final f f, final Map<String, String> map) {
        Boolean b = Boolean.FALSE;
        String e = net.tec.kyfw.c.a.SUCCESS.E;
        String s = "";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        if (!f.r()) {
            list.add(new BasicNameValuePair(f.f, f.g));
        }
        list.add(new BasicNameValuePair("tour_flag", map.get("tour_flag")));
        list.add(new BasicNameValuePair("cancel_flag", "2"));
        list.add(new BasicNameValuePair("bed_level_order_num", "000000000000000000000000000000"));
        list.add(new BasicNameValuePair("passengerTicketStr", map.get("passengerTicketStr")));
        list.add(new BasicNameValuePair("oldPassengerStr", map.get("oldPassengerStr")));
        list.add(new BasicNameValuePair("randCode", map.get("randCode")));
        list.add(new BasicNameValuePair("REPEAT_SUBMIT_TOKEN", map.get("REPEAT_SUBMIT_TOKEN")));
        final String a = a(f, net.tec.kyfw.c.g.y, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        if (a(a)) {
            try {
                final JSONObject jsonObject = new JSONObject(a);
                if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                    final JSONObject optJSONObject = jsonObject.optJSONObject("data");
                    if (optJSONObject.getBoolean("submitStatus")) {
                        final String optString = optJSONObject.optString("ifShowPassCode");
                        final String value = String.valueOf(optJSONObject.optInt("ifShowPassCodeTime"));
                        b = Boolean.TRUE;
                        final h.a a2 = new h.a();
                        ((HashMap<String, String>)a2).put("ifShowPassCode", optString);
                        ((HashMap<String, String>)a2).put("ifShowPassCodeTime", value);
                        return net.tec.kyfw.c.h.a(b, s, e, a2);
                    }
                    s = b(optJSONObject.getString("errMsg"));
                    if (s.equals("randCodeError") || s.equals("FALSE") || s.equals("EXPIRED")) {
                        s = "\u9a8c\u8bc1\u7801\u9519\u8bef\uff01";
                    }
                }
                else {
                    final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                    s = "";
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        s = s + jsonArray.getString(i) + "\r\n";
                    }
                    s = s.trim();
                    a(f, s);
                }
            }
            catch (Exception ex) {
                net.tec.kyfw.c.g.b.error(a);
                net.tec.kyfw.c.g.b.error("\u63d0\u4ea4\u8ba2\u5355\u51fa\u95191/2", ex);
            }
        }
        else {
            e = a;
            s = net.tec.kyfw.c.a.getErrorMessage(e, "\u8ba2\u5355\u63d0\u4ea4\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        return net.tec.kyfw.c.h.a(b, s, e);
    }
    
    public static h a(final f f, final Map<String, String> map, final boolean b) {
        Boolean b2 = Boolean.FALSE;
        String s = net.tec.kyfw.c.a.SUCCESS.E;
        String s2 = "";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        String s3;
        if (b) {
            list.add(new BasicNameValuePair("passengerTicketStr", map.get("passengerTicketStr")));
            list.add(new BasicNameValuePair("oldPassengerStr", map.get("oldPassengerStr")));
            list.add(new BasicNameValuePair("randCode", map.get("randCode")));
            list.add(new BasicNameValuePair("purpose_codes", "ADULT"));
            list.add(new BasicNameValuePair("key_check_isChange", map.get("key_check_isChange")));
            list.add(new BasicNameValuePair("leftTicketStr", map.get("leftTicketStr")));
            list.add(new BasicNameValuePair("train_location", map.get("train_location")));
            list.add(new BasicNameValuePair("choose_seats", map.get("choose_seats")));
            list.add(new BasicNameValuePair("seatDetailType", "000"));
            list.add(new BasicNameValuePair("roomType", "00"));
            list.add(new BasicNameValuePair("_json_att", ""));
            s3 = net.tec.kyfw.c.g.C;
        }
        else {
            list.add(new BasicNameValuePair("passengerTicketStr", map.get("passengerTicketStr")));
            list.add(new BasicNameValuePair("oldPassengerStr", map.get("oldPassengerStr")));
            list.add(new BasicNameValuePair("randCode", map.get("randCode")));
            list.add(new BasicNameValuePair("seatDetailType", "000"));
            list.add(new BasicNameValuePair("roomType", "00"));
            list.add(new BasicNameValuePair("choose_seats", map.get("choose_seats")));
            list.add(new BasicNameValuePair("purpose_codes", "00"));
            list.add(new BasicNameValuePair("key_check_isChange", map.get("key_check_isChange")));
            list.add(new BasicNameValuePair("leftTicketStr", map.get("leftTicketStr")));
            list.add(new BasicNameValuePair("train_location", map.get("train_location")));
            list.add(new BasicNameValuePair("REPEAT_SUBMIT_TOKEN", map.get("REPEAT_SUBMIT_TOKEN")));
            if ("gc".equals(map.get("tour_flag"))) {
                s3 = net.tec.kyfw.c.g.B;
            }
            else {
                s3 = net.tec.kyfw.c.g.A;
            }
        }
        final String a = a(f, s3, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        if (a(a)) {
            if (c(a)) {
                s = net.tec.kyfw.c.a.INVALID_SESSION.E;
                s2 = net.tec.kyfw.c.a.INVALID_SESSION.M;
            }
            else {
                try {
                    final JSONObject jsonObject = new JSONObject(a);
                    if (jsonObject.getBoolean("status")) {
                        final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                        if (jsonObject2.getBoolean("submitStatus")) {
                            b2 = Boolean.TRUE;
                        }
                        else if (!jsonObject2.isNull("errMsg")) {
                            s2 = b(jsonObject2.getString("errMsg"));
                            if (s2.equals("randCodeError") || s2.equals("FALSE") || s2.equals("EXPIRED")) {
                                s2 = "\u9a8c\u8bc1\u7801\u9519\u8bef\uff01";
                            }
                            else if (s2.equals("\u51fa\u7968\u5931\u8d25\uff01")) {}
                        }
                    }
                    else {
                        final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                        s2 = "";
                        for (int i = 0; i < jsonArray.length(); ++i) {
                            s2 = s2 + jsonArray.getString(i) + "\r\n";
                        }
                        s2 = s2.trim();
                    }
                }
                catch (Exception ex) {
                    net.tec.kyfw.c.g.b.error(a);
                    net.tec.kyfw.c.g.b.error("\u63d0\u4ea4\u8ba2\u5355\u51fa\u95192/2", ex);
                }
            }
        }
        else {
            s = a;
            s2 = net.tec.kyfw.c.a.getErrorMessage(s, "\u8ba2\u5355\u63d0\u4ea4\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01");
        }
        return net.tec.kyfw.c.h.a(b2, s2, s);
    }
    
    public static h d(final f f) {
        Boolean b = Boolean.FALSE;
        String e = net.tec.kyfw.c.a.SUCCESS.E;
        String s = "";
        final String b2 = b(f, net.tec.kyfw.c.g.D);
        if (a(b2)) {
            try {
                final JSONObject jsonObject = new JSONObject(b2);
                if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                    final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                    final Integer value = jsonObject2.getInt("waitTime");
                    final Integer value2 = jsonObject2.getInt("waitCount");
                    String s2 = "";
                    b = Boolean.TRUE;
                    if (value == -1) {
                        s2 = ((jsonObject2.getString("orderId") != null) ? jsonObject2.getString("orderId") : "");
                    }
                    else if (value == -2) {
                        s = jsonObject2.getString("msg");
                    }
                    final h.a a = new h.a();
                    ((HashMap<String, Integer>)a).put("waitTime", value);
                    ((HashMap<String, Integer>)a).put("waitCount", value2);
                    ((HashMap<String, Integer>)a).put("orderId", s2);
                    return net.tec.kyfw.c.h.a(b, s, e, a);
                }
                final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                s = "";
                for (int i = 0; i < jsonArray.length(); ++i) {
                    s = s + jsonArray.getString(i) + "\r\n";
                }
                s = s.trim();
            }
            catch (Exception ex) {
                net.tec.kyfw.c.g.b.warn("\u83b7\u53d6\u6392\u961f\u65f6\u95f4\u51fa\u9519", ex);
            }
        }
        else {
            e = b2;
            s = net.tec.kyfw.c.a.getErrorMessage(e, "\u83b7\u53d6\u6392\u961f\u7b49\u5f85\u65f6\u95f4\u5931\u8d25\uff01");
        }
        final h.a a2 = new h.a();
        ((HashMap<String, Integer>)a2).put("waitTime", -1);
        ((HashMap<String, Integer>)a2).put("waitCount", 0);
        ((HashMap<String, Integer>)a2).put("orderId", "");
        return net.tec.kyfw.c.h.a(b, s, e, a2);
    }
    
    public static List<String[]> a(final f f, final net.tec.kyfw.d.g g) {
        final ArrayList list = new ArrayList<Object>();
        final String format = String.format(g.t, g.getTrainNo(), g.getFromStationNo(), g.getToStationNo(), g.getSeatTypes(), g.getTrainDate());
        try {
            final String b = b(f, format);
            final String[] array = { "O", "M", "P", "A3", "A1", "A4", "A2", "A6", "A9", "WZ" };
            final String[] array2 = { "\u4e8c\u7b49\u5ea7", "\u4e00\u7b49\u5ea7", "\u7279\u7b49\u5ea7", "\u786c\u5367", "\u786c\u5ea7", "\u8f6f\u5367", "\u8f6f\u5ea7", "\u9ad8\u7ea7\u8f6f\u5367", "\u5546\u52a1\u5ea7", "\u65e0\u5ea7" };
            final ArrayList<String> list2 = new ArrayList<String>();
            for (int i = 0; i < array2.length; ++i) {
                final String s = g.invoke(g.methods.get(array2[i]));
                if (!"--".equals(s)) {
                    final String[] array3 = { array2[i], s, "--" };
                    list2.add(array[i]);
                    list.add(array3);
                }
            }
            if (a(b)) {
                final JSONObject jsonObject = new JSONObject(b);
                if (jsonObject.getBoolean("status")) {
                    final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                    for (int j = 0; j < list.size(); ++j) {
                        final String[] array4 = list.get(j);
                        if (jsonObject2.keySet().contains(list2.get(j))) {
                            array4[2] = jsonObject2.getString(list2.get(j));
                        }
                    }
                }
            }
        }
        catch (Exception ex) {
            g.b.error("\u5904\u7406\u4ef7\u76ee\u6570\u636e\u51fa\u9519!", ex);
        }
        return (List<String[]>)list;
    }
    
    public static h e(final f f, final Map<String, String> map) {
        final String b = b(f, String.format(net.tec.kyfw.c.g.s, map.get("train_no"), map.get("from_station_telecode"), map.get("to_station_telecode"), map.get("depart_date")));
        List<H.a> list = null;
        Boolean b2 = Boolean.FALSE;
        String s = "\u64cd\u4f5c\u5931\u8d25, \u8bf7\u91cd\u8bd5!";
        try {
            if (a(b)) {
                final JSONObject jsonObject = new JSONObject(b);
                if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                    final JSONArray jsonArray = jsonObject.getJSONObject("data").getJSONArray("data");
                    list = new ArrayList<H.a>();
                    final JSONObject jsonObject2 = jsonArray.getJSONObject(0);
                    list.add(new H.a(jsonObject2.getString("station_no"), jsonObject2.getString("station_name"), jsonObject2.getString("arrive_time"), jsonObject2.getString("start_time"), jsonObject2.getString("stopover_time"), jsonObject2.getString("station_train_code"), jsonObject2.getString("start_station_name"), jsonObject2.getString("end_station_name"), jsonObject2.getString("train_class_name"), map.get("train_seat_feature"), jsonObject2.getBoolean("isEnabled"), jsonObject2.getString("service_type")));
                    for (int i = 1; i < jsonArray.length(); ++i) {
                        final JSONObject jsonObject3 = jsonArray.getJSONObject(i);
                        list.add(new H.a(jsonObject3.getString("station_no"), jsonObject3.getString("station_name"), jsonObject3.getString("arrive_time"), jsonObject3.getString("start_time"), jsonObject3.getString("stopover_time"), jsonObject3.getBoolean("isEnabled")));
                    }
                    b2 = Boolean.TRUE;
                    s = "";
                }
                else if (jsonObject.keySet().contains("messages")) {
                    final JSONArray jsonArray2 = jsonObject.getJSONArray("messages");
                    s = "";
                    for (int j = 0; j < jsonArray2.length(); ++j) {
                        s = s + jsonArray2.getString(j) + "\r\n";
                    }
                    s = s.trim();
                }
            }
        }
        catch (Exception ex) {
            net.tec.kyfw.c.g.b.warn(ex);
        }
        return net.tec.kyfw.c.h.a(b2, s, list);
    }
    
    public static h e(final f f) {
        final net.tec.kyfw.c.f d = f.d(net.tec.kyfw.c.g.m);
        if (!net.tec.kyfw.c.b.SUCCESS.equals(d.a())) {
            return net.tec.kyfw.c.h.a("\u83b7\u53d6\u8054\u7cfb\u4eba\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01", d.b());
        }
        final ArrayList<d> list = new ArrayList<d>();
        final JSONObject jsonObject = new JSONObject(a(d.c())).getJSONObject("data");
        if (jsonObject.keySet().contains("isExist") && jsonObject.getBoolean("isExist")) {
            final JSONArray jsonArray = jsonObject.getJSONArray("normal_passengers");
            for (int i = 0; i < jsonArray.length(); ++i) {
                final JSONObject jsonObject2 = (JSONObject)jsonArray.get(i);
                String s = "\u6210\u4eba";
                if (jsonObject2.keySet().contains("passenger_type_name")) {
                    s = (jsonObject2.getString("passenger_type_name").contains("\u4f24\u6b8b") ? "\u6b8b\u519b" : jsonObject2.getString("passenger_type_name"));
                }
                list.add(new d(jsonObject2.getString("passenger_name"), jsonObject2.getString("passenger_id_type_name"), jsonObject2.getString("passenger_id_no"), jsonObject2.getString("mobile_no"), s, net.tec.kyfw.d.d.getCheckState(jsonObject2.getString("passenger_id_type_code"), jsonObject2.getString("total_times"))));
            }
            return net.tec.kyfw.c.h.a("\u8054\u7cfb\u4eba\u5217\u8868\u66f4\u65b0\u6210\u529f\uff01", d.b(), list);
        }
        return net.tec.kyfw.c.h.a(jsonObject.optString("exMsg"), d.b());
    }
    
    public static h a(final f f, final Map<String, String> map, final int n) {
        final String s = (n == 0) ? f(f, map) : ((n == 1) ? h(f, map) : g(f, map));
        Boolean b = Boolean.FALSE;
        String s2 = "\u64cd\u4f5c\u5931\u8d25, \u8bf7\u91cd\u8bd5!";
        if (net.tec.kyfw.util.p.b((Object)s)) {
            final JSONObject jsonObject = new JSONObject(s);
            if (jsonObject.getBoolean("status") && jsonObject.keySet().contains("data")) {
                final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                if (jsonObject2.optBoolean("flag")) {
                    b = Boolean.TRUE;
                    s2 = "";
                }
                else {
                    s2 = jsonObject2.optString("message");
                }
            }
            else if (jsonObject.keySet().contains("messages")) {
                final JSONArray jsonArray = jsonObject.getJSONArray("messages");
                String string = "";
                for (int i = 0; i < jsonArray.length(); ++i) {
                    string = string + jsonArray.getString(i) + "\r\n";
                }
                s2 = string.trim();
            }
        }
        return net.tec.kyfw.c.h.a(b, s2);
    }
    
    public static String f(final f f, final Map<String, String> map) {
        try {
            final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            list.add(new BasicNameValuePair("passenger_name", map.get("passenger_name")));
            list.add(new BasicNameValuePair("sex_code", map.get("sex_code")));
            list.add(new BasicNameValuePair("passenger_id_type_code", map.get("passenger_id_type_code")));
            list.add(new BasicNameValuePair("passenger_id_no", map.get("passenger_id_no")));
            list.add(new BasicNameValuePair("mobile_no", map.get("mobile_no")));
            list.add(new BasicNameValuePair("passenger_type", map.get("passenger_type")));
            list.add(new BasicNameValuePair("country_code", "CN"));
            list.add(new BasicNameValuePair("_birthDate", ""));
            list.add(new BasicNameValuePair("phone_no", ""));
            list.add(new BasicNameValuePair("email", ""));
            list.add(new BasicNameValuePair("address", ""));
            list.add(new BasicNameValuePair("postalcode", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.province_code", "11"));
            list.add(new BasicNameValuePair("studentInfoDTO.school_code", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.school_name", "\u7b80\u7801/\u6c49\u5b57"));
            list.add(new BasicNameValuePair("studentInfoDTO.department", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.school_class", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.student_no", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.school_system", "1"));
            list.add(new BasicNameValuePair("studentInfoDTO.enter_year", DateUtil.a("yyyy")));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_card_no", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_from_station_name", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_from_station_code", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_to_station_name", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_to_station_code", ""));
            return a(f, net.tec.kyfw.c.g.n, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        }
        catch (Exception ex) {
            net.tec.kyfw.c.g.b.warn("\u6dfb\u52a0\u8054\u7cfb\u4eba\u5931\u8d25", ex);
            return null;
        }
    }
    
    public static String g(final f f, final Map<String, String> map) {
        try {
            final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            list.add(new BasicNameValuePair("passenger_name", map.get("passenger_name")));
            list.add(new BasicNameValuePair("passenger_id_type_code", map.get("passenger_id_type_code")));
            list.add(new BasicNameValuePair("passenger_id_no", map.get("passenger_id_no")));
            list.add(new BasicNameValuePair("isUserSelf", "N"));
            return a(f, net.tec.kyfw.c.g.p, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        }
        catch (Exception ex) {
            net.tec.kyfw.c.g.b.warn("\u5220\u9664\u8054\u7cfb\u4eba\u5931\u8d25", ex);
            return null;
        }
    }
    
    public static String h(final f f, final Map<String, String> map) {
        try {
            final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            list.add(new BasicNameValuePair("passenger_name", map.get("passenger_name")));
            list.add(new BasicNameValuePair("old_passenger_name", map.get("old_passenger_name")));
            list.add(new BasicNameValuePair("sex_code", map.get("sex_code")));
            list.add(new BasicNameValuePair("passenger_id_type_code", map.get("passenger_id_type_code")));
            list.add(new BasicNameValuePair("old_passenger_id_type_code", map.get("old_passenger_id_type_code")));
            list.add(new BasicNameValuePair("passenger_id_no", map.get("passenger_id_no")));
            list.add(new BasicNameValuePair("old_passenger_id_no", map.get("old_passenger_id_no")));
            list.add(new BasicNameValuePair("mobile_no", map.get("mobile_no")));
            list.add(new BasicNameValuePair("passenger_type", map.get("passenger_type")));
            list.add(new BasicNameValuePair("country_code", "CN"));
            list.add(new BasicNameValuePair("_birthDate", "2014-10-03"));
            list.add(new BasicNameValuePair("phone_no", ""));
            list.add(new BasicNameValuePair("email", ""));
            list.add(new BasicNameValuePair("address", ""));
            list.add(new BasicNameValuePair("postalcode", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.province_code", "11"));
            list.add(new BasicNameValuePair("studentInfoDTO.school_code", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.school_name", "\u7b80\u7801/\u6c49\u5b57"));
            list.add(new BasicNameValuePair("studentInfoDTO.department", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.school_class", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.student_no", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.school_system", "1"));
            list.add(new BasicNameValuePair("studentInfoDTO.enter_year", DateUtil.a("yyyy")));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_card_no", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_from_station_name", "\u7b80\u7801/\u6c49\u5b57"));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_from_station_code", ""));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_to_station_name", "\u7b80\u7801/\u6c49\u5b57"));
            list.add(new BasicNameValuePair("studentInfoDTO.preference_to_station_code", ""));
            return a(f, net.tec.kyfw.c.g.o, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
        }
        catch (Exception ex) {
            net.tec.kyfw.c.g.b.warn("\u4fee\u6539\u8054\u7cfb\u4eba\u5931\u8d25.", ex);
            return null;
        }
    }
    
    public static byte[] a(final f f, final Boolean b) {
        h(f);
        byte[] array = f.a(String.format(b ? net.tec.kyfw.c.g.i : net.tec.kyfw.c.g.j, b ? "login" : "passenger", b ? "sjrand" : "randp"), new Header[0]).c();
        if (array != null) {
            InputStream inputStream = null;
            ByteArrayOutputStream byteArrayOutputStream = null;
            try {
                inputStream = new ByteArrayInputStream(array);
                ImageIO.write(ImageIO.read(inputStream), "png", byteArrayOutputStream = new ByteArrayOutputStream());
                array = byteArrayOutputStream.toByteArray();
            }
            catch (Exception ex) {}
            finally {
                try {
                    byteArrayOutputStream.close();
                    ((ByteArrayInputStream)inputStream).close();
                }
                catch (IOException ex2) {}
            }
            return array;
        }
        return array;
    }
    
    public static Boolean b(final f f, final String s, final Boolean b) {
        Boolean b2 = Boolean.FALSE;
        final String s2 = b ? "sjrand" : "randp";
        final String s3 = b ? net.tec.kyfw.c.g.k : net.tec.kyfw.c.g.l;
        try {
            final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            if (b) {
                list.add(new BasicNameValuePair("answer", s));
                list.add(new BasicNameValuePair("rand", s2));
                list.add(new BasicNameValuePair("login_site", "E"));
            }
            else {
                list.add(new BasicNameValuePair("randCode", s));
                list.add(new BasicNameValuePair("rand", s2));
            }
            final UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(list, StandardCharsets.UTF_8);
            if (b) {
                final net.tec.kyfw.c.f a = f.a(s3, urlEncodedFormEntity, new Header[0]);
                if (b.SUCCESS.equals(a.a())) {
                    final String a2 = a(a.c());
                    if (net.tec.kyfw.util.p.b((Object)a2) && "4".equals(new JSONObject(a2).optString("result_code"))) {
                        b2 = Boolean.TRUE;
                    }
                }
            }
            else {
                int i = 0;
                while (i < 15) {
                    final net.tec.kyfw.c.f a3 = f.a(s3, urlEncodedFormEntity, new Header[0]);
                    if (!b.SUCCESS.equals(a3.a())) {
                        break;
                    }
                    final JSONObject jsonObject = new JSONObject(a(a3.c())).getJSONObject("data");
                    final String optString = jsonObject.optString("result");
                    if (net.tec.kyfw.util.p.b((Object)jsonObject.optString("msg"))) {
                        if (net.tec.kyfw.util.p.b((Object)optString) && optString.equals("1")) {
                            b2 = Boolean.TRUE;
                            break;
                        }
                        break;
                    }
                    else {
                        if (i < 14) {
                            try {
                                Thread.sleep(10L);
                            }
                            catch (Exception ex2) {
                                break;
                            }
                        }
                        ++i;
                    }
                }
            }
        }
        catch (Exception ex) {
            net.tec.kyfw.c.g.b.error("\u68c0\u6d4b\u9a8c\u8bc1\u7801\u5f02\u5e38.", ex);
        }
        return b2;
    }
    
    public static h b(final f f, final String s, final String s2) {
        final h a = net.tec.kyfw.c.h.a();
        Boolean b = Boolean.FALSE;
        String optString = "\u767b\u5f55\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        try {
            final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
            list.add(new BasicNameValuePair("username", s));
            list.add(new BasicNameValuePair("password", s2));
            list.add(new BasicNameValuePair("appid", "otn"));
            if (!net.tec.kyfw.util.p.a(f.f)) {
                list.add(new BasicNameValuePair(f.f, f.g));
            }
            final net.tec.kyfw.c.f a2 = f.a(net.tec.kyfw.c.g.d, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8), new Header[0]);
            if (a2.a().equals(net.tec.kyfw.c.b.SUCCESS)) {
                final JSONObject jsonObject = new JSONObject(a(a2.c()));
                if ("0".equals(jsonObject.optString("result_code"))) {
                    b = l(f);
                    if (b) {
                        k(f);
                        optString = "\u767b\u5f55\u6210\u529f";
                    }
                }
                else {
                    optString = jsonObject.optString("result_message");
                    if (optString.equals("randCodeError") || optString.equals("FALSE") || optString.equals("EXPIRED")) {
                        optString = "\u9a8c\u8bc1\u7801\u9519\u8bef\uff01";
                    }
                    a(f, optString);
                }
            }
        }
        catch (Exception ex) {
            net.tec.kyfw.c.g.b.warn("\u767b\u5f55\u5931\u8d25", ex);
        }
        a.a(b);
        a.b(optString);
        return a;
    }
    
    private static Boolean l(final f f) {
        Boolean b = Boolean.FALSE;
        final String e = f.e(net.tec.kyfw.c.g.e);
        if (e != null) {
            if (e.contains("userLogin")) {
                final String c = c(f, net.tec.kyfw.c.g.f);
                if (a(c)) {
                    final JSONObject jsonObject = new JSONObject(c);
                    if ("0".equals(jsonObject.optString("result_code"))) {
                        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
                        list.add(new BasicNameValuePair("tk", jsonObject.optString("newapptk")));
                        final String a = a(f, net.tec.kyfw.c.g.g, new UrlEncodedFormEntity(list, StandardCharsets.UTF_8));
                        if (a(a) && "0".equals(new JSONObject(a).optString("result_code"))) {
                            return l(f);
                        }
                    }
                }
            }
            else if (e.contains("initMy12306")) {
                b = Boolean.TRUE;
            }
            else if (e.contains("logFiles/error.html")) {}
        }
        return b;
    }
    
    public static void f(final f f) {
        f.a(net.tec.kyfw.c.g.h, new Header[0]);
        f.k();
        k(f);
        if (!"D".equals(f.f()) && !"Q".equals(f.f()) && !"T".equals(f.f())) {
            f.m();
        }
    }
    
    public static h a(final f f, final String s, final String s2, final String s3, final String s4, final String s5, final List<String> list, final List<String> list2) {
        h(f);
        ObservableList observableArrayList = null;
        Boolean b = false;
        String s6 = "~>_<~ \u67e5\u8be2\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        final HttpHost a = net.tec.kyfw.a.i.a();
        try {
            final HashMap<Object, String> hashMap = new HashMap<Object, String>();
            hashMap.put("_jc_save_fromStation", net.tec.kyfw.util.e.a(s2 + "," + s3));
            hashMap.put("_jc_save_toStation", net.tec.kyfw.util.e.a(s4 + "," + s5));
            hashMap.put("_jc_save_fromDate", s);
            hashMap.put("_jc_save_toDate", DateUtil.a(new Date(), "yyyy-MM-dd"));
            hashMap.put("_jc_save_wfdc_flag", "dc");
            if (f.d().e != null) {
                hashMap.put("fp_ver", "4.5.1");
                hashMap.put("RAIL_EXPIRATION", f.d().d);
                hashMap.put("RAIL_DEVICEID", f.d().e);
            }
            final CookieStore t = f.d().t();
            for (final String s7 : hashMap.keySet()) {
                final BasicClientCookie basicClientCookie = new BasicClientCookie(s7, hashMap.get(s7));
                basicClientCookie.setPath("/");
                basicClientCookie.setDomain(a.getHostName());
                t.addCookie(basicClientCookie);
            }
        }
        catch (Exception ex2) {}
        final net.tec.kyfw.c.f a2 = f.d().a(a, String.format(net.tec.kyfw.c.g.r, s, s3, s5), new BasicHeader("Referer", "https://kyfw.12306.cn/otn/leftTicket/init"), new BasicHeader("If-Modified-Since", "0"), new BasicHeader("Connection", "close"), new BasicHeader("Host", "kyfw.12306.cn"));
        if (net.tec.kyfw.c.b.SUCCESS.equals(a2.a())) {
            final String a3 = a(a2.c());
            if (a(a3)) {
                try {
                    final JSONObject jsonObject = new JSONObject(a3);
                    if (jsonObject.keySet().contains("c_url")) {
                        net.tec.kyfw.c.g.r = "/otn/" + jsonObject.getString("c_url") + "?leftTicketDTO.train_date=%s&leftTicketDTO.from_station=%s&leftTicketDTO.to_station=%s&purpose_codes=ADULT";
                        return a(f, s, s2, s3, s4, s5, list, list2);
                    }
                    b = (boolean)jsonObject.get("status");
                    if (b && jsonObject.keySet().contains("data") && jsonObject.get("data") != null) {
                        final JSONObject jsonObject2 = jsonObject.getJSONObject("data");
                        if (!"1".equals(jsonObject2.getString("flag"))) {
                            b = false;
                            s6 = "\u5f88\u62b1\u6b49, \u6309\u60a8\u7684\u67e5\u8be2\u6761\u4ef6, \u5f53\u524d\u672a\u627e\u5230\u4ece\u201c" + s2 + "\u201d\u5230\u201c" + s4 + "\u201d \u7684\u5217\u8f66.";
                        }
                        else {
                            final JSONObject jsonObject3 = jsonObject2.getJSONObject("map");
                            final JSONArray jsonArray = jsonObject2.getJSONArray("result");
                            if (jsonArray.length() == 0) {
                                b = false;
                                s6 = "\u5f88\u62b1\u6b49, \u6309\u60a8\u7684\u67e5\u8be2\u6761\u4ef6, \u5f53\u524d\u672a\u627e\u5230\u4ece\u201c" + s2 + "\u201d\u5230\u201c" + s4 + "\u201d \u7684\u5217\u8f66.";
                            }
                            else {
                                b = true;
                                s6 = "\u5f88\u62b1\u6b49, \u6ca1\u6709\u6ee1\u8db3\u60a8\u8981\u6c42\u7684\u8f66\u6b21.";
                                observableArrayList = FXCollections.observableArrayList();
                                for (int i = 0; i < jsonArray.length(); ++i) {
                                    final String[] split = jsonArray.getString(i).split("\\|", 36);
                                    final net.tec.kyfw.d.g g = new net.tec.kyfw.d.g(net.tec.kyfw.util.p.b(split[1]).replaceAll("<br/>", "\r\n"), net.tec.kyfw.util.p.b(split[3]), net.tec.kyfw.util.p.b(split[2]), net.tec.kyfw.util.p.b(split[4]), net.tec.kyfw.util.p.b(split[13]), net.tec.kyfw.util.p.b(s), net.tec.kyfw.util.p.b(split[5]), net.tec.kyfw.util.p.b(jsonObject3.getString(split[6])), net.tec.kyfw.util.p.b(split[6]), net.tec.kyfw.util.p.b(split[16]), net.tec.kyfw.util.p.b(split[8]), net.tec.kyfw.util.p.b(jsonObject3.getString(split[7])), net.tec.kyfw.util.p.b(split[7]), net.tec.kyfw.util.p.b(split[17]), net.tec.kyfw.util.p.b(split[9]), net.tec.kyfw.util.p.b(split[10]), net.tec.kyfw.util.p.b((Object)split[32]) ? split[32] : "--", net.tec.kyfw.util.p.b((Object)split[25]) ? split[25] : "--", net.tec.kyfw.util.p.b((Object)split[31]) ? split[31] : "--", net.tec.kyfw.util.p.b((Object)split[30]) ? split[30] : "--", net.tec.kyfw.util.p.b((Object)split[21]) ? split[21] : "--", net.tec.kyfw.util.p.b((Object)split[23]) ? split[23] : (net.tec.kyfw.util.p.b((Object)split[33]) ? split[33] : "--"), net.tec.kyfw.util.p.b((Object)split[28]) ? split[28] : "--", net.tec.kyfw.util.p.b((Object)split[24]) ? split[24] : "--", net.tec.kyfw.util.p.b((Object)split[29]) ? split[29] : "--", net.tec.kyfw.util.p.b((Object)split[26]) ? split[26] : "--", net.tec.kyfw.util.p.b((Object)split[22]) ? split[22] : "--", net.tec.kyfw.util.p.b((Object)split[20]) ? split[20] : "--", net.tec.kyfw.util.p.b((Object)split[27]) ? split[27] : "--", net.tec.kyfw.util.p.b(split[11]), net.tec.kyfw.util.p.b(split[18]), net.tec.kyfw.util.p.b(split[15]), net.tec.kyfw.util.p.b(split[35]), net.tec.kyfw.util.p.b(split[14]), net.tec.kyfw.util.p.b(split[34]), net.tec.kyfw.util.p.b(split[12]), net.tec.kyfw.util.p.b(split[0]));
                                    observableArrayList.add((Object)g);
                                    if (!list.contains(g.getFromStationTelecode())) {
                                        if (g.getFromStationTelecode().equals(s3)) {
                                            list.add(0, g.getFromStationTelecode());
                                        }
                                        else {
                                            list.add(g.getFromStationTelecode());
                                        }
                                    }
                                    if (!list2.contains(g.getToStationTelecode())) {
                                        if (g.getToStationTelecode().equals(s5)) {
                                            list2.add(0, g.getToStationTelecode());
                                        }
                                        else {
                                            list2.add(g.getToStationTelecode());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (jsonObject.keySet().contains("messages")) {
                        b = false;
                        s6 = jsonObject.optString("messages");
                    }
                    else {
                        b = false;
                        s6 = "\u5f88\u62b1\u6b49, \u6309\u60a8\u7684\u67e5\u8be2\u6761\u4ef6, \u5f53\u524d\u672a\u627e\u5230\u4ece\u201c" + s2 + "\u201d\u5230\u201c" + s4 + "\u201d \u7684\u5217\u8f66.";
                    }
                }
                catch (Exception ex) {
                    net.tec.kyfw.c.g.b.error(a3);
                    net.tec.kyfw.c.g.b.error("\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5f02\u5e38.", ex);
                    s6 = "\u67e5\u8be2\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u7cfb\u7edf\u5f02\u5e38\uff01";
                }
            }
        }
        else if (net.tec.kyfw.c.b.CONNECTION_TIMEOUT.equals(a2.a())) {
            if (a.getPort() == 443 && !"kyfw.12306.cn".equals(a.getHostName())) {
                net.tec.kyfw.a.i.a(a.getHostName());
            }
        }
        else if (a2.b().equals("-403")) {
            s6 = "[12306]\u63d0\u793a\uff1a403\u62d2\u7edd\u8bbf\u95ee\uff01";
        }
        else if (a2.b().equals("-405")) {
            s6 = "[12306]\u63d0\u793a\uff1a405\u975e\u6cd5\u8bf7\u6c42\uff01";
        }
        if (b) {
            return net.tec.kyfw.c.h.a(s6, observableArrayList);
        }
        return net.tec.kyfw.c.h.a(s6);
    }
    
    public static h a(final String s, final String s2, final String s3) {
        ObservableList observableArrayList = null;
        Boolean b = Boolean.FALSE;
        String s4 = "~>_<~ \u67e5\u8be2\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01";
        final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
        list.add(new BasicNameValuePair("value", "{\"IsBus\":false,\"Filter\":\"0\",\"Catalog\":\"\",\"IsGaoTie\":false,\"IsDongChe\":false,\"CatalogName\":\"\",\"DepartureCity\":\"shenzhenbei\",\"ArrivalCity\":\"hengyangdong\",\"HubCity\":\"\",\"DepartureCityName\":\"" + s2 + "\",\"ArrivalCityName\":\"" + s3 + "\",\"DepartureDate\":\"" + s + "\",\"DepartureDateReturn\":\"" + s + "\",\"ArrivalDate\":\"\",\"TrainNumber\":\"\"}"));
        final net.tec.kyfw.c.f a = net.tec.kyfw.f.d().a("http://trains.ctrip.com/TrainBooking/Ajax/SearchListHandler.ashx?Action=getSearchList", new UrlEncodedFormEntity(list, StandardCharsets.UTF_8), new Header[0]);
        if (net.tec.kyfw.c.b.SUCCESS.equals(a.a())) {
            final String a2 = a(a.c());
            if (a(a2)) {
                try {
                    final JSONObject jsonObject = new JSONObject(a2);
                    if (jsonObject.keySet().contains("TrainItemsList")) {
                        final JSONArray jsonArray = jsonObject.getJSONArray("TrainItemsList");
                        if (jsonArray != null) {
                            b = Boolean.TRUE;
                            s4 = "\u67e5\u8be2\u6210\u529f";
                            observableArrayList = FXCollections.observableArrayList();
                            for (int i = 0; i < jsonArray.length(); ++i) {
                                final JSONObject jsonObject2 = jsonArray.getJSONObject(i);
                                final String optString = jsonObject2.optString("EndStationName");
                                final String optString2 = jsonObject2.optString("EndTime");
                                final String optString3 = jsonObject2.optString("StartStationName");
                                final String optString4 = jsonObject2.optString("StratTime");
                                final String optString5 = jsonObject2.optString("TrainName");
                                final String[] split = jsonObject2.optString("TakeTime").replaceAll("\u5c0f\u65f6", ":").replaceAll("\u5206", "").split(":");
                                if (split[1].length() < 2) {
                                    split[1] = "0" + split[1];
                                }
                                observableArrayList.add((Object)new net.tec.kyfw.d.g(optString5, optString3, optString, split[0] + ":" + split[1], optString4, optString2));
                            }
                        }
                    }
                }
                catch (Exception ex) {
                    net.tec.kyfw.c.g.b.error(a2);
                    net.tec.kyfw.c.g.b.error("\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5f02\u5e38.", ex);
                    s4 = "\u67e5\u8be2\u8f66\u6b21\u4fe1\u606f\u5931\u8d25\uff0c\u7cfb\u7edf\u5f02\u5e38\uff01";
                }
            }
        }
        if (b) {
            return net.tec.kyfw.c.h.a(s4, observableArrayList);
        }
        return net.tec.kyfw.c.h.a(s4);
    }
    
    public static boolean g(final f f) {
        boolean b = false;
        final String b2 = b(f, net.tec.kyfw.c.g.q);
        if (net.tec.kyfw.util.p.b((Object)b2)) {
            final Matcher matcher = Pattern.compile("(?s)(?i)sessionInit\\s*\\=\\s*(['\"]{1})([^'\"]*)").matcher(b2);
            if (matcher.find() && net.tec.kyfw.util.p.b((Object)matcher.group(2))) {
                b = true;
            }
            final String d = net.tec.kyfw.util.t.d(b2);
            if (net.tec.kyfw.util.p.b((Object)d)) {
                f.f = net.tec.kyfw.util.t.e(b(f, d));
                if (net.tec.kyfw.util.p.b((Object)f.f)) {
                    f.g = net.tec.kyfw.util.t.a(f.f);
                }
                f.h = System.currentTimeMillis();
            }
            if (b) {
                f.d(net.tec.kyfw.c.g.m);
            }
        }
        return b;
    }
    
    public static void h(final f f) {
        if (f.r()) {
            m(f);
        }
    }
    
    public static void i(final f f) {
        final String c = c(f, net.tec.kyfw.c.g.q + "?pre_step_flag=gcInit");
        if (c != null) {
            final Matcher matcher = Pattern.compile("CLeftTicketUrl\\s*\\=\\s*[\"']{1}(.*?)[\"']{1}").matcher(c);
            if (matcher.find()) {
                net.tec.kyfw.c.g.r = "/otn/" + matcher.group(1) + "?leftTicketDTO.train_date=%s&leftTicketDTO.from_station=%s&leftTicketDTO.to_station=%s&purpose_codes=ADULT";
            }
        }
        final String d = net.tec.kyfw.util.t.d(c);
        if (net.tec.kyfw.util.p.b((Object)d)) {
            f.f = net.tec.kyfw.util.t.e(b(f, d));
            if (net.tec.kyfw.util.p.b((Object)f.f)) {
                f.g = net.tec.kyfw.util.t.a(f.f);
            }
            f.h = System.currentTimeMillis();
        }
    }
    
    private static void m(final f f) {
        final String b = b(f, net.tec.kyfw.c.g.q);
        if (b != null) {
            final Matcher matcher = Pattern.compile("CLeftTicketUrl\\s*\\=\\s*[\"']{1}(.*?)[\"']{1}").matcher(b);
            if (matcher.find()) {
                net.tec.kyfw.c.g.r = "/otn/" + matcher.group(1) + "?leftTicketDTO.train_date=%s&leftTicketDTO.from_station=%s&leftTicketDTO.to_station=%s&purpose_codes=ADULT";
            }
        }
        final String d = net.tec.kyfw.util.t.d(b);
        if (net.tec.kyfw.util.p.b((Object)d)) {
            f.f = net.tec.kyfw.util.t.e(b(f, d));
            if (net.tec.kyfw.util.p.b((Object)f.f)) {
                f.g = net.tec.kyfw.util.t.a(f.f);
            }
            f.h = System.currentTimeMillis();
        }
        if (f.i()) {
            f.d(net.tec.kyfw.c.g.m);
        }
    }
    
    public static int j(final f f) {
        HttpURLConnection httpURLConnection = null;
        try {
            final StringBuffer sb = new StringBuffer();
            final List<Cookie> cookies = f.t().getCookies();
            if (cookies != null && !cookies.isEmpty()) {
                for (int i = 0; i < cookies.size(); ++i) {
                    sb.append(cookies.get(i).getName()).append("=").append(cookies.get(i).getValue());
                    if (i != cookies.size() - 1) {
                        sb.append("; ");
                    }
                }
            }
            final URL url = new URL(net.tec.kyfw.c.g.M);
            if (net.tec.kyfw.e.d()) {
                httpURLConnection = (HttpsURLConnection)url.openConnection(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(net.tec.kyfw.e.a(net.tec.kyfw.e.a.PROXY_HOST), Integer.parseInt(net.tec.kyfw.e.a(net.tec.kyfw.e.a.PROXY_PORT)))));
            }
            else {
                httpURLConnection = (HttpsURLConnection)url.openConnection();
            }
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.addRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36");
            httpURLConnection.addRequestProperty("Accept", "*/*");
            httpURLConnection.addRequestProperty("Cache-Control", "no-cache");
            httpURLConnection.addRequestProperty("Referer", "https://kyfw.12306.cn/otn/login/init");
            httpURLConnection.addRequestProperty("Cookie", sb.toString());
            httpURLConnection.setInstanceFollowRedirects(false);
            httpURLConnection.connect();
            int n = httpURLConnection.getResponseCode();
            if (n == 302) {
                final ArrayList<BasicNameValuePair> list = new ArrayList<BasicNameValuePair>();
                list.add(new BasicNameValuePair("appid", "otn"));
                final UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(list, StandardCharsets.UTF_8);
                final String a = a(f, "/passport/web/auth/uamtk", urlEncodedFormEntity);
                if (a != null) {
                    final JSONObject jsonObject = new JSONObject(a);
                    if ("0".equals(jsonObject.optString("result_code"))) {
                        f.a(urlEncodedFormEntity);
                        final ArrayList<BasicNameValuePair> list2 = new ArrayList<BasicNameValuePair>();
                        list2.add(new BasicNameValuePair("tk", jsonObject.optString("newapptk")));
                        final UrlEncodedFormEntity urlEncodedFormEntity2 = new UrlEncodedFormEntity(list2, StandardCharsets.UTF_8);
                        final String a2 = a(f, "/otn/uamauthclient", urlEncodedFormEntity2);
                        if (a2 != null && "0".equals(new JSONObject(a2).optString("result_code")) && l(f)) {
                            final HttpPost httpPost = new HttpPost(net.tec.kyfw.c.g.m);
                            CloseableHttpResponse execute = null;
                            try {
                                execute = f.s().execute(f.u(), (HttpRequest)httpPost);
                                if (302 == execute.getStatusLine().getStatusCode()) {
                                    n = execute.getStatusLine().getStatusCode();
                                }
                                else {
                                    m(f);
                                    n = 200;
                                }
                            }
                            catch (Exception ex) {
                                net.tec.kyfw.c.g.b.warn("\u83b7\u53d6\u7528\u6237\u767b\u5f55\u4fe1\u606f\u5931\u8d25.", ex);
                            }
                            finally {
                                f.a(execute);
                            }
                        }
                        f.a(urlEncodedFormEntity2);
                    }
                }
            }
            return n;
        }
        catch (Exception ex2) {
            net.tec.kyfw.c.g.b.warn("\u83b7\u53d6\u7528\u6237\u767b\u5f55\u4fe1\u606f\u5931\u8d25.", ex2);
        }
        finally {
            try {
                httpURLConnection.disconnect();
            }
            catch (Exception ex3) {}
        }
        return -1;
    }
    
    public static void a(final f f, final String s) {
        if (s.contains("\u975e\u6cd5\u8bf7\u6c42") || s.contains("\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6") || s.contains("\u7cfb\u7edf\u7e41\u5fd9")) {
            k(f);
        }
    }
    
    public static void k(final f f) {
        f.f = null;
        f.g = null;
    }
    
    public static net.tec.kyfw.util.a.a a() {
        net.tec.kyfw.util.a.a a = null;
        net.tec.kyfw.c.f f = net.tec.kyfw.f.b().a("https://git.oschina.net/download/kyfw12306/raw/master/update/lastRelease.json", new Header[0]);
        Boolean i = Boolean.FALSE;
        if (!net.tec.kyfw.c.b.SUCCESS.equals(f.a())) {
            i = Boolean.TRUE;
            f = net.tec.kyfw.f.b().a("https://raw.githubusercontent.com/ebert-chan/kyfw12306/master/update/lastRelease.json", new Header[0]);
        }
        if (net.tec.kyfw.c.b.SUCCESS.equals(f.a())) {
            final JSONObject jsonObject = new JSONObject(a(f.c()));
            a = new net.tec.kyfw.util.a.a(jsonObject.getString("FULLNAME"), jsonObject.getString("VERSION"), jsonObject.getLong("LENGHT"), jsonObject.getString("DATE"), jsonObject.getString("SIGN"), jsonObject.getString("OCRLIB"), jsonObject.getString("SITE"), jsonObject.getString("UPLOG"));
            a.i = i;
        }
        return a;
    }
    
    public static String b(final f f, final String s) {
        final net.tec.kyfw.c.f a = f.a(s, new Header[0]);
        if (net.tec.kyfw.c.b.SUCCESS.equals(a.a())) {
            return a(a.c());
        }
        return a.b();
    }
    
    public static String c(final f f, final String s) {
        return a(f, s, (HttpEntity)null);
    }
    
    public static String a(final f f, final String s, final HttpEntity httpEntity) {
        final net.tec.kyfw.c.f a = f.a(s, httpEntity, new Header[0]);
        if (net.tec.kyfw.c.b.SUCCESS.equals(a.a())) {
            return a(a.c());
        }
        return a.b();
    }
    
    private static boolean a(final String s) {
        return net.tec.kyfw.util.p.b((Object)s) && !s.startsWith("-") && (s.startsWith("{") || s.startsWith("["));
    }
    
    private static String a(final byte[] array) {
        try {
            return new String(array, net.tec.kyfw.c.g.c);
        }
        catch (UnsupportedEncodingException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    private static String b(String replaceAll) {
        final Matcher matcher = Pattern.compile("(<[^>]*>)").matcher(replaceAll);
        if (matcher.find()) {
            replaceAll = matcher.replaceAll("");
        }
        return replaceAll;
    }
    
    private static boolean c(final String s) {
        return !net.tec.kyfw.util.p.a((Object)s) && (Pattern.compile("(?s)(?i)(\u7528\u6237\u672a\u767b\u5f55|\u767b\u5f55|isRelogin)").matcher(s).find() || (!s.startsWith("{") && !s.endsWith("}")));
    }
    
    static {
        net.tec.kyfw.c.g.b = net.tec.kyfw.util.j.a(g.class);
        net.tec.kyfw.c.g.c = "utf-8";
        net.tec.kyfw.c.g.a = "https://kyfw.12306.cn/otn/resources/js/framework/station_name.js";
        net.tec.kyfw.c.g.d = "/passport/web/login";
        net.tec.kyfw.c.g.e = "/otn/login/userLogin";
        net.tec.kyfw.c.g.f = "/passport/web/auth/uamtk?appid=otn";
        net.tec.kyfw.c.g.g = "/otn/uamauthclient";
        net.tec.kyfw.c.g.h = "/otn/login/loginOut";
        net.tec.kyfw.c.g.i = "/passport/captcha/captcha-image?login_site=E&module=%s&rand=%s";
        net.tec.kyfw.c.g.j = "/otn/passcodeNew/getPassCodeNew?module=%s&rand=%s";
        net.tec.kyfw.c.g.k = "/passport/captcha/captcha-check";
        net.tec.kyfw.c.g.l = "/otn/passcodeNew/checkRandCodeAnsyn";
        net.tec.kyfw.c.g.m = "/otn/confirmPassenger/getPassengerDTOs";
        net.tec.kyfw.c.g.n = "/otn/passengers/add";
        net.tec.kyfw.c.g.o = "/otn/passengers/edit";
        net.tec.kyfw.c.g.p = "/otn/passengers/delete";
        net.tec.kyfw.c.g.q = "/otn/leftTicket/init";
        net.tec.kyfw.c.g.r = "/otn/leftTicket/query?leftTicketDTO.train_date=%s&leftTicketDTO.from_station=%s&leftTicketDTO.to_station=%s&purpose_codes=ADULT";
        net.tec.kyfw.c.g.s = "/otn/czxx/queryByTrainNo?train_no=%s&from_station_telecode=%s&to_station_telecode=%s&depart_date=%s";
        net.tec.kyfw.c.g.t = "/otn/leftTicket/queryTicketPrice?train_no=%s&from_station_no=%s&to_station_no=%s&seat_types=%s&train_date=%s";
        net.tec.kyfw.c.g.u = "/otn/leftTicket/submitOrderRequest";
        net.tec.kyfw.c.g.v = "/otn/confirmPassenger/autoSubmitOrderRequest";
        net.tec.kyfw.c.g.w = "/otn/confirmPassenger/initDc";
        net.tec.kyfw.c.g.x = "/otn/confirmPassenger/initGc";
        net.tec.kyfw.c.g.y = "/otn/confirmPassenger/checkOrderInfo";
        net.tec.kyfw.c.g.z = "/otn/confirmPassenger/getQueueCountAsync";
        net.tec.kyfw.c.g.A = "/otn/confirmPassenger/confirmSingleForQueue";
        net.tec.kyfw.c.g.B = "/otn/confirmPassenger/confirmResignForQueue";
        net.tec.kyfw.c.g.C = "/otn/confirmPassenger/confirmSingleForQueueAsys";
        net.tec.kyfw.c.g.D = "/otn/confirmPassenger/queryOrderWaitTime?tourFlag=dc";
        net.tec.kyfw.c.g.E = "/otn/queryOrder/queryMyOrderNoComplete";
        net.tec.kyfw.c.g.F = "/otn/queryOrder/queryMyOrder";
        net.tec.kyfw.c.g.G = "/otn/queryOrder/cancelNoCompleteMyOrder";
        net.tec.kyfw.c.g.H = "/otn/payOrder/cancelResign";
        net.tec.kyfw.c.g.I = "/otn/queryOrder/cancelQueueNoCompleteMyOrder";
        net.tec.kyfw.c.g.J = "/otn/queryOrder/continuePayNoCompleteMyOrder";
        net.tec.kyfw.c.g.K = "/otn/payOrder/init";
        net.tec.kyfw.c.g.L = "/otn/queryOrder/resginTicket";
        net.tec.kyfw.c.g.M = "https://kyfw.12306.cn/otn/modifyUser/initQueryUserInfo";
    }
}
