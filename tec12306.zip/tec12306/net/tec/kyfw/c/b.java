// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.c;

public enum b
{
    SUCCESS, 
    CONNECTION_TIMEOUT, 
    SO_TIMEOUT, 
    UNKNOWN_HOST_EXCEPTION, 
    UNKNOWN_EXCEPTION, 
    ERR_RESP_CODE;
}
