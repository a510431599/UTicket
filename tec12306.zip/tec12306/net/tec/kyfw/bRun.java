// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw;

import javafx.event.EventHandler;
import net.tec.kyfw.util.i;
import net.tec.kyfw.util.p;
import net.tec.kyfw.util.f;
import javafx.control.dialog.Dialogs;
import javafx.stage.Window;
import net.tec.kyfw.util.uLib;

class bRun implements Runnable
{
    final /* synthetic */ aTask a;

    bRun(final aTask a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        final boolean b = !"1".equals(uLib.cAuth.aAuth(uLib.cPoint, "Software\\12306", "agreement"));
        int a = 1;
        if (b) {
//            a = net.tec.kyfw.b.a.a((Window)this.a.aStage).a();
            if (a == 1) {
                a = 0;
                try {
                    Thread.sleep(300L);
                }
                catch (Exception ex) {}
                Dialogs.create().owner((Window)this.a.aStage).title("\u6e29\u99a8\u63d0\u9192").message("\u6e29\u99a8\u63d0\u9192\uff1a\u672c\u8f6f\u4ef6\u4e0d\u5bf9\u5916\u51fa\u552e\uff0c\u8c28\u9632\u53d7\u9a97\uff01\u5982\u53d1\u73b0\u6709\u4eba\u51fa\u552e\u6b64\u8f6f\u4ef6\u8bf7\u5411\u6211\u4eec\u4e3e\u62a5\uff0c\u611f\u8c22\u60a8\u7684\u652f\u6301\uff01\r\n\u4e3e\u62a5\u90ae\u7bb1\uff1ateam12306@163.com").alert();
            }
        }
        if (!f.b() && a == 1) {
            if (net.tec.kyfw.util.a.a != null && p.b((Object)net.tec.kyfw.util.a.a.h)) {
                final String[] split = net.tec.kyfw.util.a.a.h.split("\\|");
                if (split.length == 1) {
                    Dialogs.create().owner((Window)this.a.aStage).title("\u6e29\u99a8\u63d0\u9192").message(split[0]).alert();
                }
                else if (split.length > 1) {
                    Dialogs.create().owner((Window)this.a.aStage).title("\u6e29\u99a8\u63d0\u9192").message(split[0]).confirm(() -> i.e.a(split[1]));
                }
            }
            else {
                Dialogs.create().owner((Window)this.a.aStage).title("\u6e29\u99a8\u63d0\u9192").message("\u611f\u8c22\u60a8\u4f7f\u7528\u6b64\u8f6f\u4ef6\uff0c\u5982\u8f6f\u4ef6\u80fd\u591f\u987a\u5229\u5e2e\u52a9\u60a8\u4e70\u5230\u7968\uff0c\u8bf7\u6350\u52a9\u652f\u6301\u6211\u4eec\uff0c\u8c22\u8c22\uff01").alert();
            }
            net.tec.kyfw.util.a.a = null;
        }
        this.a.aStage.setOnShown((EventHandler)null);
    }
}
