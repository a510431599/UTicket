// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import javafx.event.Event;
import javafx.scene.media.MediaPlayer;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class k implements EventHandler<ActionEvent>
{
    final /* synthetic */ MediaPlayer a;
    final /* synthetic */ i b;
    
    k(final i b, final MediaPlayer a) {
        this.b = b;
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        this.a.stop();
        this.a.dispose();
    }
}
