// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.util.j;
import java.io.InputStream;
import java.net.URLConnection;
import java.io.RandomAccessFile;
import java.net.URL;
import java.net.HttpURLConnection;
import net.tec.kyfw.util.o;
import net.tec.kyfw.util.p;
import javafx.application.Platform;
import java.io.File;
import net.tec.kyfw.util.i;
import java.net.URLDecoder;
import net.tec.kyfw.App;
import net.tec.kyfw.f;
import net.tec.kyfw.e;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.LoadingController;
import org.apache.log4j.Logger;
import javafx.a.a;

public class c extends a<Double>
{
    private static Logger c;
    long a;
    long b;
    
    public c() {
        this.a = 100L;
        this.b = 0L;
    }
    
    public Double g() {
        final LoadingController loadingController = this.a(LoadingController.class);
        this.a("\u521d\u59cb\u5316...");
        e.a();
        this.a(10L);
        this.a("\u521d\u59cb\u5316\u7f51\u7edc\u8fde\u63a5...");
        f.a();
        this.a(20L);
        if (App.b != null && App.b.length == 4) {
            int n = 1;
            final int int1 = Integer.parseInt(App.b[1]);
            final String decode = URLDecoder.decode(App.b[3], "UTF-8");
            while (i.e.a(int1)) {
                this.a("\u68c0\u6d4b\u5230\u4e00\u4e2a\u4f4e\u7248\u672c\u7a0b\u5e8f\u672a\u5173\u95ed\uff0c\u6b63\u5728\u5173\u95ed\u8be5\u7a0b\u5e8f...");
                try {
                    Thread.sleep(1000L);
                }
                catch (Exception ex2) {}
                if (++n == 10) {
                    i.e.b(int1);
                    break;
                }
            }
            this.a("\u6b63\u5728\u66f4\u65b0\u7a0b\u5e8f...");
            final File file = new File(decode);
            if (file.exists()) {
                file.delete();
            }
            this.a("\u66f4\u65b0\u5b8c\u6210\uff01");
            this.a(40L);
            try {
                Thread.sleep(100L);
            }
            catch (Exception ex3) {}
        }
        else {
            this.a("\u68c0\u67e5\u66f4\u65b0...");
            final net.tec.kyfw.util.a a = new net.tec.kyfw.util.a();
            final boolean a2 = a.a();
            this.a(40L);
            if (!a2) {
                this.a("\u68c0\u6d4b\u5230\u65b0\u7248\u672c(" + net.tec.kyfw.util.a.a.b + ")\uff0c\u6b63\u5728\u4e0b\u8f7d\uff1a");
                this.a(0L);
                final String a3 = this.a(a);
                if (a3 != null) {
                    this.a("\u4e0b\u8f7d\u5df2\u5b8c\u6210\uff0c\u7cfb\u7edf\u5c06\u5728\u9000\u51fa\u540e\u81ea\u52a8\u5b8c\u6210\u66f4\u65b0\uff0c5\u79d2\u540e\u81ea\u52a8\u9000\u51fa...");
                    for (int i = 4; i >= 0; --i) {
                        try {
                            Thread.sleep(1000L);
                        }
                        catch (Exception ex4) {}
                        this.a("\u4e0b\u8f7d\u5df2\u5b8c\u6210\uff0c\u7cfb\u7edf\u5c06\u5728\u9000\u51fa\u540e\u81ea\u52a8\u5b8c\u6210\u66f4\u65b0\uff0c" + i + "\u79d2\u540e\u81ea\u52a8\u9000\u51fa...");
                    }
                    try {
                        Thread.sleep(300L);
                    }
                    catch (Exception ex5) {}
                    Platform.runLater((Runnable)new d(this, a3));
                }
                else {
                    Platform.runLater((Runnable)new net.tec.kyfw.e.e(this, loadingController));
                }
                return null;
            }
        }
        this.a("\u521d\u59cb\u5316\u7cfb\u7edf\u8bbe\u7f6e...");
        e.b();
        this.a(60L);
        net.tec.kyfw.a.i.c();
        this.a(70L);
        final String a4 = e.a(e.a.DM_ACCOUNT);
        if (p.b((Object)a4)) {
            final String[] split = a4.split(",");
            if ("\u6253\u7801\u5154".equals(split[0])) {
                net.tec.kyfw.a.a.a(split[1], split[2]);
            }
        }
        this.a(80L);
        this.a("\u9a8c\u8bc1\u6388\u6743\u8bb8\u53ef...");
        net.tec.kyfw.util.f.a();
        this.a(90L);
        final File file2 = new File("./\u8054\u7cfb\u4eba\u5bfc\u5165\u6a21\u677f.txt");
        if (!file2.exists()) {
            o.a(o.a(o.a("/res/conf/contacts_template.txt")), file2);
        }
        this.a("\u521d\u59cb\u5316\u5b8c\u6210\uff0c\u6b63\u5728\u52a0\u8f7d\u4e3b\u754c\u9762...");
        this.a(this.a);
        final AbstractController abstractController;
        this.a(() -> {
            try {
                App.a(abstractController.getStage());
            }
            catch (Exception ex) {
                net.tec.kyfw.e.c.c.error("\u542f\u52a8\u4e3b\u7a0b\u5e8f\u51fa\u9519\uff01", ex);
                this.h();
            }
            return;
        });
        return null;
    }
    
    protected void a(final String text) {
        this.a(() -> this.a(LoadingController.class).loadState.setText(text));
    }
    
    private void a(final long n) {
        if (n > this.b) {
            while (n >= this.b) {
                this.a(++this.b, this.a);
                try {
                    Thread.sleep(15L);
                }
                catch (Exception ex) {}
            }
        }
        else {
            this.a(n, this.a);
        }
    }
    
    private String a(final net.tec.kyfw.util.a a) {
        final net.tec.kyfw.util.a.a a2 = net.tec.kyfw.util.a.a;
        URLConnection urlConnection = null;
        InputStream inputStream = null;
        RandomAccessFile randomAccessFile = null;
        try {
            if (a2 != null) {
                long length = 0L;
                final String a3 = a2.a;
                final File file = new File(a3 + ".tmp");
                urlConnection = new URL(a2.g + a2.a).openConnection();
                urlConnection.setConnectTimeout(5000);
                urlConnection.setReadTimeout(10000);
                urlConnection.setUseCaches(false);
                if (file.exists() && a2.i) {
                    length = file.length();
                    urlConnection.setRequestProperty("RANGE", "bytes=" + length + "-");
                }
                final long n = a2.i ? urlConnection.getContentLengthLong() : a2.c;
                if (length == n) {
                    this.a(this.a, this.a);
                }
                else {
                    this.a(length, this.a = length + n);
                    randomAccessFile = new RandomAccessFile(file, "rw");
                    randomAccessFile.seek(length);
                    final byte[] array = new byte[2048];
                    inputStream = urlConnection.getInputStream();
                    int read;
                    while ((read = inputStream.read(array)) != -1) {
                        length += read;
                        randomAccessFile.write(array, 0, read);
                        this.a(length, this.a);
                    }
                }
                randomAccessFile.close();
                randomAccessFile = null;
                final File file2 = new File(a3);
                if (file2.exists()) {
                    file2.delete();
                }
                file.renameTo(file2);
                return a2.a;
            }
        }
        catch (Exception ex) {
            net.tec.kyfw.e.c.c.warn("\u4e0b\u8f7d\u66f4\u65b0\u6587\u4ef6\u51fa\u9519!", ex);
        }
        finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (urlConnection != null) {
                    ((HttpURLConnection)urlConnection).disconnect();
                }
                if (randomAccessFile != null) {
                    randomAccessFile.close();
                }
            }
            catch (Exception ex2) {}
        }
        return null;
    }
    
    protected void h() {
        this.a(() -> Platform.exit());
    }
    
    static {
        net.tec.kyfw.e.c.c = j.a(c.class);
    }
}
