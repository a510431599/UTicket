// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.c.h;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.OrderController;
import javafx.a.a;

public class n extends a<Void>
{
    @Override
    public void c() {
        super.c();
        this.a(() -> this.a(OrderController.class).overlay.setVisible(false));
    }
    
    protected Void g() {
        final f f = this.a(0);
        final OrderController orderController = this.a(OrderController.class);
        this.a(() -> orderController.overlay.setVisible(true));
        if (this.e()) {
            return null;
        }
        boolean b;
        do {
            b = false;
            final h a = g.a(f);
            if (this.e()) {
                return null;
            }
            if (a.b()) {
                if (!((h.a)a.e()).d("waitTime")) {
                    b = true;
                }
                final OrderController orderController2;
                final h.a a2;
                this.a(() -> {
                    orderController2.noresult.setText("");
                    orderController2.noresult.setVisible(false);
                    orderController2.ticketResult.setVisible(true);
                    orderController2.a(a2);
                    orderController2.overlay.setVisible(false);
                    orderController2.buttonPay.setUserData((Object)(a2.e("payFlag") ? "" : a2.a("payFlag")));
                    if (a2.d("waitTime")) {
                        if (a2.d("error")) {
                            orderController2.buttonPay.setVisible(true);
                            orderController2.buttonCancel.setVisible(true);
                        }
                        else {
                            orderController2.buttonPay.setVisible(false);
                            orderController2.buttonCancel.setVisible(false);
                        }
                    }
                    else {
                        orderController2.buttonPay.setVisible(false);
                        orderController2.buttonCancel.setVisible(true);
                    }
                    return;
                });
            }
            else {
                final OrderController orderController3;
                this.a(() -> {
                    orderController3.noresult.setText(a.c());
                    orderController3.noresult.setVisible(true);
                    orderController3.ticketResult.setVisible(false);
                    orderController3.overlay.setVisible(false);
                    return;
                });
            }
            if (this.e()) {
                return null;
            }
            try {
                Thread.sleep(1000L);
            }
            catch (Exception ex) {}
        } while (!this.e() && b);
        return null;
    }
}
