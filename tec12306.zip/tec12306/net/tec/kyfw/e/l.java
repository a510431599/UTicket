// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.util.j;
import net.tec.kyfw.c.h;
import javafx.collections.FXCollections;
import java.util.Collection;
import javafx.stage.Window;
import javafx.control.dialog.Tooltips;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.PassengerController;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import org.apache.log4j.Logger;
import javafx.a.a;

public class l extends a<Void>
{
    private static Logger a;
    
    public Void g() {
        l.a.info("\u5237\u65b0\u8054\u7cfb\u4eba\u5217\u8868!");
        g.e(this.a(0));
        if (this.e()) {
            return null;
        }
        final PassengerController passengerController;
        final h h;
        this.a(() -> {
            passengerController = this.a(PassengerController.class);
            Tooltips.show((Window)passengerController.getStage(), h.c());
            if (h.b()) {
                passengerController.passengerTable.setItems(FXCollections.observableArrayList((Collection)h.e()));
            }
            return;
        });
        return null;
    }
    
    static {
        l.a = j.a(l.class);
    }
}
