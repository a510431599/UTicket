// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.util.j;
import javafx.stage.Stage;
import javafx.control.dialog.Dialogs;
import net.tec.kyfw.util.o;
import net.tec.kyfw.controller.MainController;
import javafx.stage.Window;
import java.util.concurrent.CountDownLatch;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.c.h;
import java.util.Map;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import java.util.HashMap;
import net.tec.kyfw.util.r;
import net.tec.kyfw.controller.TicketController;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.BuyController;
import net.tec.kyfw.b.e;
import org.apache.log4j.Logger;
import javafx.a.a;

public class p extends a<Void>
{
    private static Logger a;
    private e b;
    
    public p() {
        this.b = null;
    }
    
    @Override
    public void a() {
        super.a();
        final BuyController buyController;
        this.a(() -> {
            buyController = this.a(BuyController.class);
            buyController.waitMsg.setText("\u6b63\u5728\u68c0\u67e5\u8ba2\u5355...");
            buyController.overlay.setVisible(true);
        });
    }
    
    @Override
    public void c() {
        super.c();
        final BuyController buyController;
        this.a(() -> {
            buyController = this.a(BuyController.class);
            buyController.waitMsg.setText("");
            buyController.overlay.setVisible(false);
        });
    }
    
    protected Void g() {
        p.a.info("\u68c0\u67e5\u8ba2\u5355...");
        final TicketController ticketController = this.a(TicketController.class);
        final BuyController buyController = this.a(BuyController.class);
        final String[] a = r.a(buyController.b, buyController.a.getItems(), Boolean.valueOf(ticketController.submitOption.isSelected()));
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("passengerTicketStr", a[0]);
        hashMap.put("oldPassengerStr", a[1]);
        hashMap.put("randCode", "");
        hashMap.put("tour_flag", "dc");
        hashMap.put("leftTicketStr", buyController.b.getYpInfo());
        hashMap.put("train_location", buyController.b.getLocationCode());
        hashMap.put("key_check_isChange", buyController.d);
        hashMap.put("REPEAT_SUBMIT_TOKEN", buyController.c);
        if (this.e()) {
            return null;
        }
        h d = null;
        for (int i = 0; i < 3; ++i) {
            d = g.d(f.b(), hashMap);
            if (this.e()) {
                break;
            }
            if (!d.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                break;
            }
            p.a.info("\u8fde\u63a5\u8d85\u65f6...");
        }
        if (this.e()) {
            return null;
        }
        if (d.b()) {
            this.a(a, Boolean.valueOf("Y".equals(((h.a)d.e()).c("ifShowPassCode"))));
        }
        else {
            final String c = d.c();
            if (c.contains("\u975e\u6cd5\u8bf7\u6c42") || c.contains("\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6")) {
                this.h();
                if (!this.e()) {
                    final String s;
                    final BuyController buyController2;
                    final String s2;
                    this.a(() -> {
                        if (s.equals("Y")) {
                            this.restart();
                        }
                        else {
                            buyController2.waitMsg.setText("");
                            buyController2.overlay.setVisible(false);
                            Tooltips.show(buyController2.getWindow(), s2);
                        }
                        return;
                    });
                }
            }
            else {
                final BuyController buyController3;
                final String s3;
                this.a(() -> {
                    buyController3.waitMsg.setText("");
                    buyController3.overlay.setVisible(false);
                    Tooltips.show(buyController3.getWindow(), s3);
                    return;
                });
            }
        }
        return null;
    }
    
    private String h() {
        final String s = null;
        p.a.info("\u91cd\u65b0\u52a0\u8f7d\u8f66\u6b21\u4fe1\u606f...");
        final BuyController buyController = this.a(BuyController.class);
        this.a(() -> buyController.waitMsg.setText("\u91cd\u65b0\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\uff0c\u8bf7\u7a0d\u5019..."));
        h b = null;
        for (int i = 0; i < 3; ++i) {
            b = g.b(f.b());
            if (this.e()) {
                break;
            }
            if (!b.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                break;
            }
            p.a.info("\u8fde\u63a5\u8d85\u65f6...");
        }
        if (this.e()) {
            return s;
        }
        String c;
        if (b.b()) {
            final h.a a = b.e();
            buyController.c = a.a("token");
            buyController.d = a.a("key_check_isChange");
            c = "Y";
        }
        else {
            c = b.c();
        }
        p.a.info("\u52a0\u8f7d\u5b8c\u6210!");
        return c;
    }
    
    private String a(final f f, final boolean b) {
        Object o = null;
        final TicketController ticketController = this.a(TicketController.class);
        while (!this.e()) {
            final CountDownLatch countDownLatch = new CountDownLatch(1);
            this.a(() -> this.b = e.a(f, b, countDownLatch).a(ticketController.getWindow()).b());
            try {
                countDownLatch.await();
                o = new String(this.b.c());
            }
            catch (InterruptedException ex) {
                p.a.warn("\u9a8c\u8bc1\u7801\u8f93\u5165\u5f02\u5e38", ex);
            }
            if ("#CANCEL#".equals(o)) {
                this.a(() -> this.cancel());
                return (String)o;
            }
            if (net.tec.kyfw.util.p.b(o)) {
                break;
            }
        }
        return (String)o;
    }
    
    private void a(final String[] array, final Boolean b) {
        String a = null;
        if (b) {
            a = this.a(f.b(), false);
        }
        if (this.e()) {
            return;
        }
        if ("#CANCEL#".equals(a)) {
            this.a(() -> this.cancel());
            return;
        }
        p.a.info("\u786e\u8ba4\u63d0\u4ea4\u8ba2\u5355\uff01");
        final BuyController buyController = this.a(BuyController.class);
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("passengerTicketStr", array[0]);
        hashMap.put("oldPassengerStr", array[1]);
        hashMap.put("randCode", a);
        hashMap.put("key_check_isChange", buyController.d);
        hashMap.put("leftTicketStr", buyController.b.getYpInfo());
        hashMap.put("train_location", buyController.b.getLocationCode());
        hashMap.put("REPEAT_SUBMIT_TOKEN", buyController.c);
        hashMap.put("choose_seats", r.a(array[0]));
        this.a(() -> buyController.waitMsg.setText("\u6b63\u5728\u63d0\u4ea4\u8ba2\u5355..."));
        if (this.e()) {
            return;
        }
        h h = null;
        for (int i = 0; i < 3; ++i) {
            h = g.a(f.b(), hashMap, false);
            if (this.e()) {
                break;
            }
            if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                break;
            }
            p.a.info("\u8fde\u63a5\u8d85\u65f6...");
        }
        if (this.e()) {
            return;
        }
        if (h.b()) {
            p.a.info("\u8ba2\u5355\u5df2\u7ecf\u63d0\u4ea4\uff0c\u7b49\u5f85\u51fa\u7968\uff01");
            this.a(() -> buyController.waitMsg.setText("\u8ba2\u5355\u5df2\u7ecf\u63d0\u4ea4\uff0c\u7b49\u5f85\u51fa\u7968..."));
            h.a a2 = null;
            while (a2 == null || (a2.b("waitTime") != -1 && a2.b("waitTime") != -2)) {
                for (int j = 0; j < 3; ++j) {
                    h = g.d(f.b());
                    if (this.e()) {
                        break;
                    }
                    if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                        break;
                    }
                    p.a.info("\u8fde\u63a5\u8d85\u65f6...");
                }
                if (this.e()) {
                    return;
                }
                a2 = h.e();
                final Integer b2 = a2.b("waitTime");
                if (b2 == -1 || b2 == -2) {
                    continue;
                }
                this.a(() -> buyController.waitMsg.setText(r.a(a2.b("waitCount"), b2)));
                try {
                    Thread.sleep(200L);
                }
                catch (Exception ex) {}
            }
            if (!a2.a("orderId").equals("")) {
                this.a(a2.a("orderId"));
            }
            else {
                final String c = h.c();
                final BuyController buyController2;
                this.a(() -> {
                    Tooltips.show((Window)buyController2.getStage(), c);
                    buyController2.waitMsg.setText("");
                    buyController2.overlay.setVisible(false);
                    return;
                });
                if (a2.b("waitTime") == -2 || c.contains("\u53d6\u6d88\u6b21\u6570\u8fc7\u591a") || c.contains("\u4e0d\u80fd\u7ed9\u8bc1\u4ef6\u7c7b\u578b\u4e3a\u8eab\u4efd\u8bc1\u7684\u4e58\u5ba2\u529e\u7406\u8d2d\u7968\u4e1a\u52a1") || c.contains("\u672a\u901a\u8fc7\u8eab\u4efd\u4fe1\u606f\u6838\u9a8c") || c.contains("\u884c\u7a0b\u51b2\u7a81") || c.contains("\u5df2\u8ba2")) {
                    final MainController mainController;
                    this.a(() -> {
                        mainController = this.a(MainController.class);
                        net.tec.kyfw.e.a = false;
                        mainController.framePane.getSelectionModel().select(0);
                        return;
                    });
                }
            }
        }
        else {
            if (h.c().indexOf("\u9a8c\u8bc1\u7801") != -1) {
                final AbstractController abstractController;
                final Window window;
                final String s;
                this.a(() -> {
                    abstractController.getStage();
                    if (!((Stage)window).isShowing()) {
                        ((Stage)window).show();
                    }
                    ((Stage)window).requestFocus();
                    Tooltips.show(window, s);
                    return;
                });
                this.a(array, b);
                return;
            }
            final BuyController buyController3;
            final String s2;
            this.a(() -> {
                Tooltips.show((Window)buyController3.getStage(), s2);
                buyController3.waitMsg.setText("");
                buyController3.overlay.setVisible(false);
                return;
            });
        }
        p.a.info("\u8ba2\u7968\u7ed3\u675f\uff01");
    }
    
    private void a(final String s) {
        g.k(f.b());
        final MainController mainController;
        final Window window;
        String string;
        final Dialogs dialogs;
        final StringBuilder sb;
        final String value;
        this.a(() -> {
            mainController = this.a(MainController.class);
            mainController.getStage();
            if (!((Stage)window).isShowing()) {
                ((Stage)window).show();
            }
            ((Stage)window).requestFocus();
            mainController.buyController.waitMsg.setText("");
            mainController.buyController.overlay.setVisible(false);
            if (mainController.ticketController.playMusic.isSelected()) {
                i.a(o.b("/res/conf/buy_success.mp3"));
            }
            Dialogs.create().owner(window).title("\u63d0\u793a\u4fe1\u606f");
            new StringBuilder().append("\u606d\u559c\u60a8\uff0c\u8ba2\u7968\u6210\u529f\uff01\u5e2d\u522b\u5df2\u9501\u5b9a");
            if (net.tec.kyfw.util.p.b((Object)s)) {
                string = "\uff0c\r\n\u8ba2\u5355\u53f7\uff1a" + s;
            }
            else {
                string = "";
            }
            dialogs.message(sb.append(string).append("\u3002\u8bf7\u5728\u89c4\u5b9a\u768430\u5206\u949f\u5185\u5b8c\u6210\u652f\u4ed8\uff01").toString()).alert();
            net.tec.kyfw.e.a = false;
            mainController.framePane.getSelectionModel().select(2);
            f.b().g();
            if (value.equals(mainController.orderController.account.getValue())) {
                mainController.orderController.refresh.fire();
            }
            else {
                mainController.orderController.account.setValue((Object)value);
            }
        });
    }
    
    static {
        p.a = j.a(p.class);
    }
}
