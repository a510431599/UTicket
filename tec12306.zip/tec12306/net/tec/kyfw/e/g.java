// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.c.h;
import net.tec.kyfw.f;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.LoginController;
import javafx.a.a;

public class g extends a<Void>
{
    @Override
    public void a() {
        super.a();
        final LoginController loginController;
        this.a(() -> {
            loginController = this.a(LoginController.class);
            loginController.errormsg.setText("");
            loginController.submit.setDisable(true);
            loginController.submit.setStyle("-fx-background-image:url('/res/images/loading.gif');-fx-background-repeat: no-repeat;-fx-background-position:21 1;");
        });
    }
    
    @Override
    public void d() {
        super.d();
        final LoginController loginController;
        this.a(() -> {
            loginController = this.a(LoginController.class);
            if (this.e()) {
                loginController.errormsg.setText("\u53d6\u6d88\u767b\u5f55");
            }
            loginController.submit.setDisable(false);
            loginController.submit.setStyle("");
        });
    }
    
    public Void g() {
        final LoginController loginController = this.a(LoginController.class);
        final h b = net.tec.kyfw.c.g.b(this.a(0), this.a(1), this.a(2));
        if (this.e()) {
            return null;
        }
        if (b.b()) {
            this.a(() -> loginController.c());
        }
        else {
            final LoginController loginController2;
            final h h;
            this.a(() -> {
                loginController2.b();
                loginController2.errormsg.setText(h.c());
                return;
            });
        }
        return null;
    }
}
