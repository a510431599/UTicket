// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.c.h;
import net.tec.kyfw.util.r;
import javafx.control.bean.SelectedProperty;
import javafx.a.d;
import javafx.collections.ObservableList;
import net.tec.kyfw.d.g;
import javafx.control.combo.MultipleComboBox;
import javafx.a.a;

public class b extends a<Void>
{
    public static void a(final String s, final String s2, final String s3, final MultipleComboBox<g> multipleComboBox, final ObservableList<g> list) {
        final b b = d.a((Class<? extends a<Object>>)b.class);
        b.a(new Object[] { s, s2, s3, multipleComboBox, list });
        b.start();
    }
    
    public static void a(final String s, final String s2, final String s3, final MultipleComboBox<g> multipleComboBox, final ObservableList<g> list, final MultipleComboBox<g> multipleComboBox2, final ObservableList<g> list2) {
        final b b = d.a((Class<? extends a<Object>>)b.class);
        b.a(new Object[] { s, s2, s3, multipleComboBox, list, multipleComboBox2, list2 });
        b.start();
    }
    
    public Void g() {
        final String s = this.a(0);
        final String s2 = this.a(1);
        final String s3 = this.a(2);
        final MultipleComboBox multipleComboBox = this.a(3);
        final ObservableList list = this.a(4);
        final MultipleComboBox<SelectedProperty> multipleComboBox2 = this.a(5);
        final ObservableList list2 = this.a(6);
        int i = 0;
        while (i < 3) {
            final h a = net.tec.kyfw.c.g.a(s, s2, s3);
            if (this.e()) {
                return null;
            }
            if (a.b()) {
                if (this.e()) {
                    return null;
                }
                final ObservableList options = a.e();
                if (multipleComboBox2 != null) {
                    final javafx.collections.ObservableList<SelectedProperty> a2 = r.a((javafx.collections.ObservableList<SelectedProperty>)a.e());
                    if (a2 != null && list2 != null && !list2.isEmpty()) {
                        for (int j = 0; j < a2.size(); ++j) {
                            if (list2.indexOf(a2.get(j)) != -1) {
                                ((g)a2.get(j)).setChecked(true);
                            }
                        }
                    }
                    this.a(() -> multipleComboBox2.setOptions(a2));
                }
                if (options != null && list != null && !list.isEmpty()) {
                    for (int k = 0; k < options.size(); ++k) {
                        if (list.indexOf(options.get(k)) != -1) {
                            ((g)options.get(k)).setChecked(true);
                        }
                    }
                }
                this.a(() -> multipleComboBox.setOptions(options));
                break;
            }
            else {
                ++i;
            }
        }
        return null;
    }
}
