// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.util.j;
import javafx.stage.Stage;
import net.tec.kyfw.util.o;
import net.tec.kyfw.c.h;
import net.tec.kyfw.d.g;
import net.tec.kyfw.controller.BuyController;
import javafx.control.dialog.Tooltips;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.TicketController;
import org.apache.log4j.Logger;
import javafx.a.a;

public class q extends a<Void>
{
    private static Logger a;
    
    @Override
    public void a() {
        super.a();
        this.a(() -> this.a(TicketController.class).overlay.setVisible(true));
    }
    
    @Override
    public void c() {
        super.c();
        this.a(() -> this.a(TicketController.class).overlay.setVisible(false));
    }
    
    public Void g() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: aload_0        
        //     1: iconst_0       
        //     2: invokevirtual   net/tec/kyfw/e/q.a:(I)Ljava/lang/Object;
        //     5: checkcast       Lnet/tec/kyfw/d/g;
        //     8: astore_1       
        //     9: getstatic       net/tec/kyfw/e/q.a:Lorg/apache/log4j/Logger;
        //    12: ldc             "\u52a0\u8f7d\u8f66\u6b21\u4fe1\u606f..."
        //    14: invokevirtual   org/apache/log4j/Logger.info:(Ljava/lang/Object;)V
        //    17: new             Ljava/util/HashMap;
        //    20: dup            
        //    21: invokespecial   java/util/HashMap.<init>:()V
        //    24: astore_2       
        //    25: aload_2        
        //    26: ldc             "secretStr"
        //    28: aload_1        
        //    29: invokevirtual   net/tec/kyfw/d/g.getSecretStr:()Ljava/lang/String;
        //    32: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    37: pop            
        //    38: aload_2        
        //    39: ldc             "train_date"
        //    41: aload_1        
        //    42: invokevirtual   net/tec/kyfw/d/g.getTrainDate:()Ljava/lang/String;
        //    45: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    50: pop            
        //    51: aload_2        
        //    52: ldc             "back_train_date"
        //    54: aload_1        
        //    55: invokevirtual   net/tec/kyfw/d/g.getTrainDate:()Ljava/lang/String;
        //    58: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    63: pop            
        //    64: aload_2        
        //    65: ldc             "tour_flag"
        //    67: ldc             "dc"
        //    69: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    74: pop            
        //    75: aload_2        
        //    76: ldc             "purpose_codes"
        //    78: ldc             "ADULT"
        //    80: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    85: pop            
        //    86: aload_2        
        //    87: ldc             "query_from_station_name"
        //    89: aload_1        
        //    90: invokevirtual   net/tec/kyfw/d/g.getFromStationName:()Ljava/lang/String;
        //    93: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    98: pop            
        //    99: aload_2        
        //   100: ldc             "query_to_station_name"
        //   102: aload_1        
        //   103: invokevirtual   net/tec/kyfw/d/g.getToStationName:()Ljava/lang/String;
        //   106: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   111: pop            
        //   112: aconst_null    
        //   113: astore_3       
        //   114: iconst_0       
        //   115: istore          4
        //   117: iconst_0       
        //   118: istore          4
        //   120: aload_0        
        //   121: invokevirtual   net/tec/kyfw/e/q.e:()Z
        //   124: ifeq            129
        //   127: aconst_null    
        //   128: areturn        
        //   129: iconst_0       
        //   130: istore          5
        //   132: iload           5
        //   134: iconst_3       
        //   135: if_icmpge       186
        //   138: invokestatic    net/tec/kyfw/f.b:()Lnet/tec/kyfw/f;
        //   141: aload_2        
        //   142: invokestatic    net/tec/kyfw/c/g.a:(Lnet/tec/kyfw/f;Ljava/util/Map;)Lnet/tec/kyfw/c/h;
        //   145: astore_3       
        //   146: aload_0        
        //   147: invokevirtual   net/tec/kyfw/e/q.e:()Z
        //   150: ifne            186
        //   153: aload_3        
        //   154: invokevirtual   net/tec/kyfw/c/h.d:()Ljava/lang/String;
        //   157: getstatic       net/tec/kyfw/c/a.CONNECTION_TIMEOUT:Lnet/tec/kyfw/c/a;
        //   160: getfield        net/tec/kyfw/c/a.E:Ljava/lang/String;
        //   163: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   166: ifne            172
        //   169: goto            186
        //   172: getstatic       net/tec/kyfw/e/q.a:Lorg/apache/log4j/Logger;
        //   175: ldc             "\u8fde\u63a5\u8d85\u65f6..."
        //   177: invokevirtual   org/apache/log4j/Logger.info:(Ljava/lang/Object;)V
        //   180: iinc            5, 1
        //   183: goto            132
        //   186: aload_0        
        //   187: invokevirtual   net/tec/kyfw/e/q.e:()Z
        //   190: ifeq            195
        //   193: aconst_null    
        //   194: areturn        
        //   195: aload_3        
        //   196: invokevirtual   net/tec/kyfw/c/h.b:()Ljava/lang/Boolean;
        //   199: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   202: ifeq            345
        //   205: iconst_0       
        //   206: istore          6
        //   208: iload           6
        //   210: iconst_3       
        //   211: if_icmpge       261
        //   214: invokestatic    net/tec/kyfw/f.b:()Lnet/tec/kyfw/f;
        //   217: invokestatic    net/tec/kyfw/c/g.b:(Lnet/tec/kyfw/f;)Lnet/tec/kyfw/c/h;
        //   220: astore_3       
        //   221: aload_0        
        //   222: invokevirtual   net/tec/kyfw/e/q.e:()Z
        //   225: ifne            261
        //   228: aload_3        
        //   229: invokevirtual   net/tec/kyfw/c/h.d:()Ljava/lang/String;
        //   232: getstatic       net/tec/kyfw/c/a.CONNECTION_TIMEOUT:Lnet/tec/kyfw/c/a;
        //   235: getfield        net/tec/kyfw/c/a.E:Ljava/lang/String;
        //   238: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   241: ifne            247
        //   244: goto            261
        //   247: getstatic       net/tec/kyfw/e/q.a:Lorg/apache/log4j/Logger;
        //   250: ldc             "\u8fde\u63a5\u8d85\u65f6..."
        //   252: invokevirtual   org/apache/log4j/Logger.info:(Ljava/lang/Object;)V
        //   255: iinc            6, 1
        //   258: goto            208
        //   261: aload_0        
        //   262: invokevirtual   net/tec/kyfw/e/q.e:()Z
        //   265: ifeq            270
        //   268: aconst_null    
        //   269: areturn        
        //   270: aload_3        
        //   271: invokevirtual   net/tec/kyfw/c/h.b:()Ljava/lang/Boolean;
        //   274: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   277: ifeq            330
        //   280: aload_3        
        //   281: invokevirtual   net/tec/kyfw/c/h.e:()Ljava/lang/Object;
        //   284: checkcast       Lnet/tec/kyfw/c/h$a;
        //   287: astore          6
        //   289: aload_0        
        //   290: ldc             Lnet/tec/kyfw/controller/TicketController;.class
        //   292: invokevirtual   net/tec/kyfw/e/q.a:(Ljava/lang/Class;)Ljava/lang/Object;
        //   295: checkcast       Lnet/tec/kyfw/controller/TicketController;
        //   298: astore          7
        //   300: aload_0        
        //   301: ldc             Lnet/tec/kyfw/controller/BuyController;.class
        //   303: invokevirtual   net/tec/kyfw/e/q.a:(Ljava/lang/Class;)Ljava/lang/Object;
        //   306: checkcast       Lnet/tec/kyfw/controller/BuyController;
        //   309: astore          8
        //   311: aload_0        
        //   312: aload           7
        //   314: aload           8
        //   316: aload_1        
        //   317: aload           6
        //   319: invokedynamic   run:(Lnet/tec/kyfw/controller/TicketController;Lnet/tec/kyfw/controller/BuyController;Lnet/tec/kyfw/d/g;Lnet/tec/kyfw/c/h$a;)Ljava/lang/Runnable;
        //   324: invokevirtual   net/tec/kyfw/e/q.a:(Ljava/lang/Runnable;)V
        //   327: goto            380
        //   330: aload_3        
        //   331: invokevirtual   net/tec/kyfw/c/h.c:()Ljava/lang/String;
        //   334: astore          5
        //   336: aload_0        
        //   337: aload           5
        //   339: invokespecial   net/tec/kyfw/e/q.a:(Ljava/lang/String;)V
        //   342: goto            380
        //   345: aload_3        
        //   346: invokevirtual   net/tec/kyfw/c/h.c:()Ljava/lang/String;
        //   349: astore          5
        //   351: aload           5
        //   353: ldc             "\u975e\u6cd5\u8bf7\u6c42"
        //   355: invokevirtual   java/lang/String.contains:(Ljava/lang/CharSequence;)Z
        //   358: ifne            371
        //   361: aload           5
        //   363: ldc             "\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6"
        //   365: invokevirtual   java/lang/String.contains:(Ljava/lang/CharSequence;)Z
        //   368: ifeq            374
        //   371: iconst_1       
        //   372: istore          4
        //   374: aload_0        
        //   375: aload           5
        //   377: invokespecial   net/tec/kyfw/e/q.a:(Ljava/lang/String;)V
        //   380: iload           4
        //   382: ifne            117
        //   385: getstatic       net/tec/kyfw/e/q.a:Lorg/apache/log4j/Logger;
        //   388: ldc             "\u52a0\u8f7d\u5b8c\u6210!"
        //   390: invokevirtual   org/apache/log4j/Logger.info:(Ljava/lang/Object;)V
        //   393: aconst_null    
        //   394: areturn        
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:757)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:655)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:532)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:499)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:141)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:130)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:105)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:317)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:238)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:123)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void a(final String s) {
        final TicketController ticketController;
        this.a(() -> {
            ticketController = this.a(TicketController.class);
            ticketController.overlay.setVisible(false);
            Tooltips.show(ticketController.getWindow(), s);
        });
    }
    
    static {
        q.a = j.a(q.class);
    }
}
