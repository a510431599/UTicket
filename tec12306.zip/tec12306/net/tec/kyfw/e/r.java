// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import java.util.Hashtable;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import java.util.concurrent.CountDownLatch;
import javafx.stage.Window;
import java.io.File;
import net.tec.kyfw.util.o;
import net.tec.kyfw.controller.TicketController;
import net.tec.kyfw.util.p;
import javafx.application.Platform;
import net.tec.kyfw.d.k;
import java.util.HashMap;
import net.tec.kyfw.d.d;
import javafx.stage.Stage;
import javafx.collections.transformation.FilteredList;
import net.tec.kyfw.c.h;
import net.tec.kyfw.util.b;
import javafx.collections.ObservableList;
import net.tec.kyfw.c.g;
import net.tec.kyfw.d.j;
import net.tec.kyfw.util.DateUtil;
import net.tec.kyfw.f;
import java.time.LocalTime;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.TaskController;
import java.util.ArrayList;
import net.tec.kyfw.b.e;
import javafx.control.dialog.Dialogs;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import javafx.a.a;

public class r extends a<Void>
{
    private static Logger b;
    public static Map<String, String> a;
    private List<String> c;
    private List<String> d;
    private int e;
    private int f;
    private net.tec.kyfw.d.a g;
    private String h;
    private String i;
    private String j;
    private String k;
    private boolean l;
    private Dialogs m;
    private e n;
    
    public r() {
        this.c = new ArrayList<String>();
        this.d = new ArrayList<String>();
        this.h = null;
        this.m = null;
    }
    
    @Override
    public void c() {
        super.c();
        final TaskController taskController;
        this.a(() -> {
            taskController = this.a(TaskController.class);
            this.g.setTaskState("\u7b49\u5f85\u8fd0\u884c");
            taskController.c(this.g.getAccount(), "\u4efb\u52a1\u5df2\u7ec8\u6b62");
        });
    }
    
    protected Void g() {
        this.g = this.a(0);
        final TaskController taskController = this.a(TaskController.class);
        if (this.g.getTimingBuy() && LocalTime.ofSecondOfDay(this.g.getTimingDate()).isAfter(LocalTime.now())) {
            this.a(() -> this.g.setTaskState("\u5b9a\u65f6\u5237\u65b0"));
            this.a(LocalTime.ofSecondOfDay(this.g.getTimingDate()), 0L);
            if (this.e()) {
                return null;
            }
        }
        final TaskController taskController2;
        this.a(() -> {
            this.g.setOrderId("");
            this.g.setTaskState("\u6b63\u5728\u8fd0\u884c");
            taskController2.c(this.g.getAccount(), "\u5f00\u59cb\u4efb\u52a1\uff0c\u6b63\u5728\u8fd0\u884c\u4e2d...");
            return;
        });
        this.h();
        return null;
    }
    
    private void a(LocalTime plusSeconds, long n) {
        this.a(TaskController.class).c(this.g.getAccount(), "\u5b9a\u65f6\u5237\u65b0\u6a21\u5f0f");
        n /= 1000L;
        int n2 = (n > 0L) ? 1 : 0;
        while (this.g.getTimingBuy() && LocalTime.ofSecondOfDay(this.g.getTimingDate()).isAfter(LocalTime.now()) && !this.e()) {
            final LocalTime now = LocalTime.now();
            if (now.isAfter(plusSeconds)) {
                if (n2 == 0 || now.toSecondOfDay() - plusSeconds.toSecondOfDay() >= n) {
                    break;
                }
                plusSeconds = plusSeconds.plusSeconds(n);
                n2 = 0;
            }
            try {
                Thread.sleep(1000L);
            }
            catch (InterruptedException ex) {}
        }
    }
    
    private void h() {
        final TaskController taskController = this.a(TaskController.class);
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        try {
            boolean b = true;
            int n = 0;
            h a2 = null;
            while (b && !this.e()) {
                if (this.g.getPassengerList() == null || this.g.getPassengerList().isEmpty()) {
                    this.a(() -> this.cancel());
                    return;
                }
                if (DateUtil.f()) {
                    final TaskController taskController2;
                    this.a(() -> {
                        this.g.setTaskState("\u8ba2\u7968\u5931\u8d25");
                        this.g.setOrderId("\u7cfb\u7edf\u7ef4\u62a4\u65f6\u6bb5");
                        taskController2.c(this.g.getAccount(), "\u4efb\u52a1\u5df2\u7ec8\u6b62");
                    });
                    return;
                }
                String s;
                if (this.g.getPriorDatesList() == null || this.g.getPriorDatesList().isEmpty()) {
                    s = this.g.getTrainDate();
                }
                else {
                    if (n == 0) {
                        s = this.g.getTrainDate();
                        ++n;
                    }
                    else {
                        s = ((j)this.g.getPriorDatesList().get(n - 1)).getDate();
                        ++n;
                    }
                    if (n > this.g.getPriorDatesList().size()) {
                        n = 0;
                    }
                }
                final String[] c = this.c(this.g.getFromStationTelecode(), this.g.getToStationTelecode());
                for (int i = 0; i < 3; ++i) {
                    if (this.e()) {
                        return;
                    }
                    a2 = net.tec.kyfw.c.g.a(a, s, this.g.getFromStation(), c[0], this.g.getToStation(), c[1], this.c, this.d);
                    if (this.e()) {
                        return;
                    }
                    if (!"\u67e5\u8be2\u5931\u8d25".equals(a2.c())) {
                        break;
                    }
                }
                r.b.debug("\u6267\u884c\u8bf7\u6c42&\u5904\u7406\u6570\u636e...");
                final ObservableList list = a2.e();
                FilteredList<net.tec.kyfw.d.g> a3;
                if (list != null && !list.isEmpty()) {
                    a3 = net.tec.kyfw.util.b.a(net.tec.kyfw.util.b.a((ObservableList<net.tec.kyfw.d.g>)a2.e(), this.g.getTrainList(), this.g.getSeatTypeList(), this.g.getSubmitOption(), this.g.getTrainLimit(), this.g.getPassengerList().size()), this.g.getBlackList(), this.g.getStartTime());
                }
                else {
                    a3 = null;
                }
                if (this.e()) {
                    break;
                }
                if (a3 != null && !a3.isEmpty()) {
                    r.b.debug("!-------------start task------------");
                    final int size = a3.size();
                    final net.tec.kyfw.util.r.d a4 = net.tec.kyfw.util.r.a(a3, this.g, r.a);
                    if (a4 == null) {
                        continue;
                    }
                    if (this.e()) {
                        break;
                    }
                    taskController.c(this.g.getAccount(), "\u67e5\u8be2\u53ef\u9884\u8ba2\u8f66\u6b21\u6709" + size + "\u8d9f");
                    if ("resign".equals(this.g.getFlag())) {
                        b = this.b(a4);
                    }
                    else {
                        b = this.a(a4);
                    }
                    if (!b) {
                        return;
                    }
                    continue;
                }
                else {
                    try {
                        Thread.sleep(net.tec.kyfw.e.b(net.tec.kyfw.e.a.QUERY_INTERVAL));
                    }
                    catch (Exception ex2) {}
                }
            }
        }
        catch (Exception ex) {
            r.b.error("\u5f02\u5e38\u7ec8\u6b62", ex);
            final TaskController taskController3;
            final Stage stage;
            this.a(() -> {
                taskController3.getStage();
                if (!stage.isShowing()) {
                    stage.show();
                    stage.requestFocus();
                }
                this.g.setTaskState("\u5f02\u5e38\u7ec8\u6b62");
                taskController3.c(this.g.getAccount(), "\u4efb\u52a1\u5df2\u7ec8\u6b62");
            });
        }
    }
    
    private boolean a(net.tec.kyfw.util.r.d d) {
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TaskController taskController = this.a(TaskController.class);
        h h = null;
        boolean equals = true;
        int i;
        do {
            i = 0;
            final ObservableList<d> passengerList = this.g.getPassengerList();
            final StringBuffer sb = new StringBuffer();
            final StringBuffer sb2 = new StringBuffer();
            String h2 = "";
            final int d2 = net.tec.kyfw.util.r.d(d.b, d.a.getSeatNo());
            for (int n = (d2 < passengerList.size()) ? d2 : passengerList.size(), j = 0; j < n; ++j) {
                final String e = net.tec.kyfw.util.r.e(d.b, d.a.getSeatName());
                final d d3 = (d)passengerList.get(j);
                sb.append(String.format("%s,0,%s,%s,%s,%s,%s,N_", e, net.tec.kyfw.util.r.a.getValue(d3.getPassengerType() + "\u7968"), d3.getName(), net.tec.kyfw.util.r.a.getValue(d3.getCardType()), d3.getCardCode(), d3.getMobileNo()));
                sb2.append(String.format("%s,%s,%s,%s_", d3.getName(), net.tec.kyfw.util.r.a.getValue(d3.getCardType()), d3.getCardCode(), net.tec.kyfw.util.r.a.getValue(d3.getPassengerType())));
                h2 += d3.getName();
                if (d3.getPassengerType().equals(net.tec.kyfw.util.r.a.CHILD.getName())) {
                    h2 += "(\u513f\u7ae5)";
                }
                if (j != n - 1) {
                    h2 += "\u3001";
                }
            }
            this.h = h2;
            sb.deleteCharAt(sb.lastIndexOf("_"));
            final HashMap<String, String> hashMap = new HashMap<String, String>();
            hashMap.put("secretStr", d.b.getSecretStr());
            hashMap.put("train_date", d.b.getTrainDate());
            hashMap.put("back_train_date", d.b.getTrainDate());
            hashMap.put("tour_flag", "dc");
            hashMap.put("purpose_codes", "ADULT");
            hashMap.put("query_from_station_name", d.b.getFromStationName());
            hashMap.put("query_to_station_name", d.b.getToStationName());
            hashMap.put("passengerTicketStr", sb.toString());
            hashMap.put("oldPassengerStr", sb2.toString());
            d.b.setPassengerTicketStr(sb.toString());
            d.b.setOldPassengerStr(sb2.toString());
            if (this.e()) {
                return false;
            }
            for (int k = 0; k < 3; ++k) {
                taskController.c(this.g.getAccount(), "\u6b63\u5728\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f...");
                h = net.tec.kyfw.c.g.b(a, hashMap);
                if (h.d().equals(net.tec.kyfw.c.a.INVALID_SESSION.E)) {
                    r.b.debug("\u7528\u6237\u8eab\u4efd\u4fe1\u606f\u5931\u6548, \u91cd\u65b0\u767b\u5f55...");
                    this.i();
                    i = 1;
                    break;
                }
                if (this.e()) {
                    break;
                }
                if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E) && !h.d().equals(net.tec.kyfw.c.a.SO_TIMEOUT.E)) {
                    break;
                }
                r.b.info("\u8fde\u63a5\u8d85\u65f6...");
            }
            if (this.e()) {
                return false;
            }
            if (i != 0) {
                continue;
            }
            if (!h.b()) {
                final String c = h.c();
                if (c.contains("\u975e\u6cd5\u8bf7\u6c42") || c.contains("\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6")) {
                    net.tec.kyfw.c.g.a(a, c);
                    i = 1;
                }
                else if (c.contains("\u5305\u542b\u6392\u961f")) {
                    i = 1;
                }
                else {
                    if (c.contains("\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25") || c.contains("\u8f66\u7968\u4fe1\u606f\u5df2\u8fc7\u671f") || c.contains("\u7cfb\u7edf\u7e41\u5fd9") || c.contains("\u7cfb\u7edf\u5fd9") || net.tec.kyfw.c.a.contains(h.d())) {
                        taskController.c(this.g.getAccount(), c);
                        return true;
                    }
                    taskController.c(this.g.getAccount(), c);
                    final String orderId;
                    this.a(() -> {
                        this.g.setTaskState("\u8ba2\u7968\u5931\u8d25");
                        this.g.setOrderId(orderId);
                        return;
                    });
                    return false;
                }
            }
            else {
                final h.a a2 = h.e();
                equals = "Y".equals(a2.a("ifShowPassCode"));
                final String[] split = a2.a("result").split("#");
                this.i = split[0];
                this.j = split[1];
                this.k = split[2];
                final String e2 = net.tec.kyfw.util.r.e(d.b, d.a.getSeatName());
                hashMap.clear();
                hashMap.put("train_date", DateUtil.a(DateUtil.a(d.b.getTrainDate(), "yyyy-MM-dd")));
                hashMap.put("train_no", d.b.getTrainNo());
                hashMap.put("stationTrainCode", d.b.getStationTrainCode());
                hashMap.put("seatType", e2);
                hashMap.put("fromStationTelecode", d.b.getFromStationTelecode());
                hashMap.put("toStationTelecode", d.b.getToStationTelecode());
                hashMap.put("leftTicket", this.k);
                if (this.e()) {
                    return false;
                }
                int l = 0;
                while (l < 2) {
                    taskController.c(this.g.getAccount(), "\u6b63\u5728\u83b7\u53d6\u6392\u961f\u4eba\u6570...");
                    h = net.tec.kyfw.c.g.c(a, hashMap);
                    if (this.e()) {
                        return false;
                    }
                    if (h.d().equals(net.tec.kyfw.c.a.INVALID_SESSION.E)) {
                        this.i();
                        i = 1;
                        break;
                    }
                    if (h.d().equals(net.tec.kyfw.c.a.SO_TIMEOUT.E)) {
                        i = 1;
                        taskController.c(this.g.getAccount(), "\u54cd\u5e94\u8d85\u65f6...");
                        break;
                    }
                    if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                        if (h.b()) {
                            final h.a a3 = h.e();
                            final boolean booleanValue = net.tec.kyfw.e.a(net.tec.kyfw.e.a.TRANSFORMOPTION, true);
                            d.b.setTicket(a3.a("ticket"));
                            final k a4 = net.tec.kyfw.util.r.a(d.b, a3.a("ticket"), d.a.getSeatNo());
                            final int intValue = a3.b("countT");
                            if (a3.a("op_2").equalsIgnoreCase("true") || (booleanValue && a4.sumSeatNum() < intValue)) {
                                final net.tec.kyfw.util.r.d a5 = net.tec.kyfw.util.r.a(d, this.g);
                                if (a5 != null) {
                                    d = a5;
                                    i = 1;
                                }
                                else {
                                    i = 0;
                                }
                            }
                            break;
                        }
                        break;
                    }
                    else {
                        ++l;
                    }
                }
                if (this.e()) {
                    return false;
                }
                continue;
            }
        } while (i != 0);
        if (h.b()) {
            return this.a(d, equals);
        }
        taskController.c(this.g.getAccount(), h.c());
        return true;
    }
    
    public boolean a(final net.tec.kyfw.util.r.d d, final boolean b) {
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TaskController taskController = this.a(TaskController.class);
        this.l = false;
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("passengerTicketStr", d.b.getPassengerTicketStr());
        hashMap.put("oldPassengerStr", d.b.getOldPassengerStr());
        hashMap.put("key_check_isChange", this.j);
        hashMap.put("leftTicketStr", this.k);
        hashMap.put("train_location", this.i);
        hashMap.put("choose_seats", net.tec.kyfw.util.r.a(d.b.getPassengerTicketStr()));
        h h = null;
        h.a a2 = null;
        taskController.c(this.g.getAccount(), "\u6b63\u5728\u63d0\u4ea4\u8ba2\u5355\uff0c" + d.b.getTrainDate() + "\uff0c" + d.b.getStationTrainCode() + "\uff0c" + d.a.getSeatName());
        boolean b2;
        do {
            b2 = false;
            if (b) {
                hashMap.put("randCode", this.a(true));
            }
            else {
                hashMap.put("randCode", "");
            }
            if (this.e()) {
                return false;
            }
            for (int i = 0; i < 3; ++i) {
                h = net.tec.kyfw.c.g.a(a, hashMap, true);
                if (this.e()) {
                    break;
                }
                if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                    break;
                }
                r.b.info("\u8fde\u63a5\u8d85\u65f6...");
            }
            if (this.e()) {
                return false;
            }
            if (h.b()) {
                taskController.c(this.g.getAccount(), "\u8ba2\u5355\u5df2\u7ecf\u63d0\u4ea4\uff0c\u7b49\u5f85\u51fa\u7968...");
                int n = 1;
                while (!this.l && (a2 == null || (a2.b("waitTime") != -1 && a2.b("waitTime") != -2))) {
                    for (int j = 0; j < 3; ++j) {
                        h = net.tec.kyfw.c.g.d(a);
                        if (this.e()) {
                            break;
                        }
                        if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                            break;
                        }
                        r.b.info("\u8fde\u63a5\u8d85\u65f6...");
                    }
                    if (this.e()) {
                        return false;
                    }
                    a2 = h.e();
                    final Integer b3 = a2.b("waitTime");
                    if (b3 == -1 || b3 == -2) {
                        continue;
                    }
                    final Integer b4 = a2.b("waitCount");
                    taskController.c(this.g.getAccount(), net.tec.kyfw.util.r.a(b4, b3));
                    if (n != 0 && b4 >= 300) {
                        n = 0;
                        final AbstractController abstractController;
                        final Window window;
                        final f f;
                        this.a(() -> {
                            abstractController.getStage();
                            if (!((Stage)window).isShowing()) {
                                ((Stage)window).show();
                                ((Stage)window).requestFocus();
                            }
                            Dialogs.create().owner(window).title("\u63d0\u793a\u4fe1\u606f\uff0c\u8d26\u53f7\uff1a" + this.g.getAccount()).message("\u5f53\u524d\u6392\u961f\u4eba\u6570\u8fc7\u591a\uff0c\u662f\u5426\u53d6\u6d88\u6392\u961f\u5e76\u628a\u8be5\u8f66\u6b21\u5e2d\u522b\u52a0\u5165\u5230\u4e0d\u53ef\u9884\u8ba2\u884c\u5217\uff1f").autoHide(8000).hideOldWindow().confirm(() -> new Thread(() -> {
                                if (net.tec.kyfw.c.g.a(f, "--", Boolean.valueOf(false)).b()) {
                                    this.l = true;
                                }
                            }).start());
                            return;
                        });
                    }
                    try {
                        Thread.sleep(200L);
                    }
                    catch (Exception ex) {}
                }
                if (this.m != null) {
                    Platform.runLater((Runnable)new s(this));
                }
                if (this.l) {
                    a(d.b.getStationTrainCode(), d.a.getSeatNo());
                    taskController.c(this.g.getAccount(), "\u5df2\u53d6\u6d88\u6392\u961f\uff01");
                    return true;
                }
                if (!a2.a("orderId").equals("")) {
                    String string;
                    final StringBuilder sb;
                    final String s;
                    final String s2;
                    final TaskController taskController2;
                    final Window window2;
                    final TicketController ticketController;
                    final String d2;
                    String string2;
                    final Dialogs dialogs;
                    final StringBuilder sb2;
                    this.a(() -> {
                        new StringBuilder().append(d.b.getTrainDate()).append("\uff0c").append(d.b.getStationTrainCode()).append("\uff0c").append(d.b.getFromStationName()).append("-").append(d.b.getToStationName()).append("\uff0c").append(d.a.getSeatName());
                        if (p.b((Object)this.h)) {
                            string = "\uff0c" + this.h;
                        }
                        else {
                            string = "";
                        }
                        sb.append(string).toString();
                        this.g.setOrderId(s + "\uff0c" + s2);
                        this.g.setTaskState("\u8ba2\u7968\u6210\u529f");
                        taskController2.getStage();
                        if (!((Stage)window2).isShowing()) {
                            ((Stage)window2).show();
                            ((Stage)window2).requestFocus();
                        }
                        ticketController = this.a(TicketController.class);
                        taskController2.c(this.g.getAccount(), "\u606d\u559c\u60a8\uff01\u8ba2\u7968\u6210\u529f\u3002\u8ba2\u5355\u4fe1\u606f\uff1a" + s2);
                        if (ticketController.playMusic.isSelected()) {
                            o.b("/res/conf/buy_success.mp3");
                            if (!net.tec.kyfw.e.f(net.tec.kyfw.e.a.MUSIC)) {
                                if (new File(net.tec.kyfw.e.a(net.tec.kyfw.e.a.MUSIC)).exists()) {
                                    d2 = o.d(net.tec.kyfw.e.a(net.tec.kyfw.e.a.MUSIC));
                                }
                            }
                            net.tec.kyfw.e.i.a(d2);
                        }
                        net.tec.kyfw.util.k.a(s, d.b.getTrainDate(), d.b.getStationTrainCode(), d.b.getFromStationName(), d.b.getToStationName(), d.a.getSeatName());
                        Dialogs.create().owner(window2).title("\u63d0\u793a\u4fe1\u606f\uff0c\u8d26\u53f7\uff1a" + this.g.getAccount());
                        new StringBuilder().append("\u606d\u559c\u60a8\uff0c\u8ba2\u7968\u6210\u529f\uff01\u5e2d\u522b\u5df2\u9501\u5b9a");
                        if (p.b((Object)s)) {
                            string2 = "\uff0c\r\n\u8ba2\u5355\u53f7\uff1a" + s;
                        }
                        else {
                            string2 = "";
                        }
                        dialogs.message(sb2.append(string2).append("\u3002\u8bf7\u5728\u89c4\u5b9a\u768430\u5206\u949f\u5185\u5b8c\u6210\u652f\u4ed8\uff01").toString()).alert();
                        return;
                    });
                    return false;
                }
                final String c = h.c();
                taskController.c(this.g.getAccount(), c);
                if (c.contains("\u53d6\u6d88\u6b21\u6570\u8fc7\u591a") || c.contains("\u4e0d\u80fd\u7ed9\u8bc1\u4ef6\u7c7b\u578b\u4e3a\u8eab\u4efd\u8bc1\u7684\u4e58\u5ba2\u529e\u7406\u8d2d\u7968\u4e1a\u52a1") || c.contains("\u672a\u901a\u8fc7\u8eab\u4efd\u4fe1\u606f\u6838\u9a8c") || c.contains("\u884c\u7a0b\u51b2\u7a81") || c.contains("\u5df2\u8ba2")) {
                    final String orderId;
                    this.a(() -> {
                        this.g.setTaskState("\u8ba2\u7968\u5931\u8d25");
                        this.g.setOrderId(orderId);
                        return;
                    });
                    return false;
                }
                if (!c.matches(".*?(\u6392\u961f\u4eba\u6570|\u6ca1\u6709\u8db3\u591f\u7684\u7968|\u4f59\u7968\u4e0d\u8db3).*?")) {
                    continue;
                }
                a(d.b.getStationTrainCode(), d.a.getSeatNo());
            }
            else if (h.c().contains("\u9a8c\u8bc1\u7801")) {
                b2 = true;
            }
            else {
                taskController.c(this.g.getAccount(), h.c());
                if (!h.c().matches(".*?(\u6392\u961f\u4eba\u6570|\u6ca1\u6709\u8db3\u591f\u7684\u7968|\u4f59\u7968\u4e0d\u8db3).*?")) {
                    continue;
                }
                a(d.b.getStationTrainCode(), d.a.getSeatNo());
            }
        } while (b2);
        return true;
    }
    
    private void i() {
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TaskController taskController = this.a(TaskController.class);
        taskController.c(this.g.getAccount(), "\u7528\u6237\u8eab\u4efd\u4fe1\u606f\u5931\u6548\uff0c\u6b63\u5728\u91cd\u65b0\u767b\u5f55");
        a.p();
        net.tec.kyfw.c.g.k(a);
        net.tec.kyfw.c.g.h(a);
        int n = 1;
        boolean b;
        do {
            if (n != 0) {
                this.a(true);
            }
            if (this.e()) {
                return;
            }
            final h b2 = net.tec.kyfw.c.g.b(a, this.g.getAccount(), this.g.getPassword());
            b = !b2.b();
            if (!b) {
                taskController.c(this.g.getAccount(), "\u767b\u5f55\u6210\u529f");
            }
            else if (b2.c().contains("\u975e\u6cd5\u8bf7\u6c42") || b2.c().contains("\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6")) {
                n = 0;
            }
            else if (b2.c().contains("\u9a8c\u8bc1\u7801")) {
                n = 1;
            }
            else {
                taskController.c(this.g.getAccount(), b2.c());
            }
        } while (b && !this.e());
        a.n();
    }
    
    private String a(final boolean b) {
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TicketController ticketController = this.a(TicketController.class);
        final TaskController taskController = this.a(TaskController.class);
        Object a2 = null;
        while (!this.e()) {
            if (ticketController.autoVerifyCode.isSelected() && net.tec.kyfw.a.a.a()) {
                if (net.tec.kyfw.c.g.a(a, Boolean.valueOf(b)) != null && !this.e()) {
                    taskController.c(this.g.getAccount(), "\u6b63\u5728\u8bf7\u6c42\u8fdc\u7a0b\u6253\u7801...");
                    a2 = net.tec.kyfw.a.a.a(a, b);
                    taskController.c(this.g.getAccount(), (a2 != null) ? "\u5df2\u6210\u529f\u83b7\u53d6\u9a8c\u8bc1\u7801\u3002" : "\u83b7\u53d6\u9a8c\u8bc1\u7801\u5931\u8d25\uff01");
                }
            }
            else {
                final CountDownLatch countDownLatch = new CountDownLatch(1);
                this.a(() -> this.n = net.tec.kyfw.b.e.a(a, b, countDownLatch).a(taskController.getWindow()).b());
                try {
                    countDownLatch.await();
                    a2 = new String(this.n.c());
                }
                catch (InterruptedException ex) {
                    r.b.warn("\u76d1\u63a7\u4efb\u52a1\u9a8c\u8bc1\u7801\u8f93\u5165\u5f02\u5e38", ex);
                }
                if ("#CANCEL#".equals(a2)) {
                    this.a(() -> this.cancel());
                    return (String)a2;
                }
            }
            if (p.b(a2)) {
                break;
            }
        }
        return (String)a2;
    }
    
    private boolean j() {
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TaskController taskController = this.a(TaskController.class);
        h a2 = null;
        while (!this.e()) {
            net.tec.kyfw.c.g.a(a, "2", DateUtil.a("yyyy-MM-dd"), DateUtil.a(DateUtil.b().toLocalDate(), "yyyy-MM-dd"), "");
            if (this.e()) {
                return false;
            }
            boolean b = false;
            for (int i = 0; i < 3; ++i) {
                taskController.c(this.g.getAccount(), "\u6b63\u5728\u63d0\u4ea4\u6539\u7b7e\u4fe1\u606f...");
                a2 = net.tec.kyfw.c.g.a(a, this.g.getTicketkey(), this.g.getSequenceNo(), this.g.getChangeTSFlag());
                if (a2.d().equals(net.tec.kyfw.c.a.INVALID_SESSION.E)) {
                    r.b.debug("\u7528\u6237\u8eab\u4efd\u4fe1\u606f\u5931\u6548, \u91cd\u65b0\u767b\u5f55...");
                    this.i();
                    b = true;
                    break;
                }
                if (this.e()) {
                    break;
                }
                if (!a2.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E) && !a2.d().equals(net.tec.kyfw.c.a.SO_TIMEOUT.E)) {
                    break;
                }
                r.b.info("\u8fde\u63a5\u8d85\u65f6...");
            }
            if (this.e()) {
                return false;
            }
            if (!b) {
                if (a2.b()) {
                    net.tec.kyfw.c.g.i(a);
                }
                else {
                    taskController.c(this.g.getAccount(), a2.c());
                }
                return true;
            }
        }
        return false;
    }
    
    private boolean b(final net.tec.kyfw.util.r.d d) {
        this.j();
        if (this.e()) {
            return false;
        }
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TaskController taskController = this.a(TaskController.class);
        final net.tec.kyfw.d.g b = d.b;
        r.b.info("\u52a0\u8f7d\u8f66\u6b21\u4fe1\u606f...");
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("secretStr", b.getSecretStr());
        hashMap.put("train_date", b.getTrainDate());
        hashMap.put("back_train_date", b.getTrainDate());
        hashMap.put("tour_flag", "gc");
        hashMap.put("purpose_codes", "ADULT");
        hashMap.put("query_from_station_name", b.getFromStationName());
        hashMap.put("query_to_station_name", b.getToStationName());
        h h = null;
        int i;
        do {
            taskController.c(this.g.getAccount(), "\u6b63\u5728\u52a0\u8f7d\u8f66\u6b21\u4fe1\u606f...");
            i = 0;
            if (this.e()) {
                return false;
            }
            for (int j = 0; j < 3; ++j) {
                h = net.tec.kyfw.c.g.a(a, hashMap);
                if (h.d().equals(net.tec.kyfw.c.a.INVALID_SESSION.E)) {
                    r.b.debug("\u7528\u6237\u8eab\u4efd\u4fe1\u606f\u5931\u6548, \u91cd\u65b0\u767b\u5f55...");
                    this.i();
                    i = 1;
                    break;
                }
                if (this.e()) {
                    break;
                }
                if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E) && !h.d().equals(net.tec.kyfw.c.a.SO_TIMEOUT.E)) {
                    break;
                }
                r.b.info("\u8fde\u63a5\u8d85\u65f6...");
            }
            if (this.e()) {
                return false;
            }
            if (i != 0) {
                continue;
            }
            if (!h.b()) {
                final String c = h.c();
                if (c.contains("\u975e\u6cd5\u8bf7\u6c42") || c.contains("\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6")) {
                    net.tec.kyfw.c.g.a(a, c);
                    i = 1;
                }
                else if (c.contains("\u5305\u542b\u6392\u961f")) {
                    i = 1;
                }
                else {
                    if (c.contains("\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\u5931\u8d25") || c.contains("\u8f66\u7968\u4fe1\u606f\u5df2\u8fc7\u671f") || c.contains("\u7cfb\u7edf\u7e41\u5fd9") || c.contains("\u7cfb\u7edf\u5fd9") || net.tec.kyfw.c.a.contains(h.d())) {
                        taskController.c(this.g.getAccount(), c);
                        return true;
                    }
                    taskController.c(this.g.getAccount(), c);
                    final String orderId;
                    this.a(() -> {
                        this.g.setTaskState("\u8ba2\u7968\u5931\u8d25");
                        this.g.setOrderId(orderId);
                        return;
                    });
                    return false;
                }
            }
            else {
                for (int k = 0; k < 3; ++k) {
                    h = net.tec.kyfw.c.g.c(a);
                    if (this.e()) {
                        break;
                    }
                    if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                        break;
                    }
                    r.b.info("\u8fde\u63a5\u8d85\u65f6...");
                }
                if (this.e()) {
                    return false;
                }
                continue;
            }
        } while (i != 0);
        if (h.b()) {
            final h.a a2 = h.e();
            this.j = a2.a("key_check_isChange");
            this.k = a2.a("token");
            return this.c(d);
        }
        taskController.c(this.g.getAccount(), h.c());
        return true;
    }
    
    private boolean c(final net.tec.kyfw.util.r.d d) {
        r.b.info("\u68c0\u67e5\u8ba2\u5355...");
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TaskController taskController = this.a(TaskController.class);
        taskController.c(this.g.getAccount(), "\u68c0\u67e5\u8ba2\u5355...");
        for (int i = 0; i < this.g.getPassengerList().size(); ++i) {
            ((d)this.g.getPassengerList().get(i)).setSeatType(d.a.getSeatName());
        }
        d.b.setSubmitFlag(this.g.getFlag());
        final String[] a2 = net.tec.kyfw.util.r.a(d.b, this.g.getPassengerList(), this.g.getSubmitOption());
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("passengerTicketStr", a2[0]);
        hashMap.put("oldPassengerStr", a2[1]);
        hashMap.put("randCode", "");
        hashMap.put("tour_flag", "gc");
        hashMap.put("leftTicketStr", d.b.getYpInfo());
        hashMap.put("train_location", d.b.getLocationCode());
        hashMap.put("key_check_isChange", this.j);
        hashMap.put("REPEAT_SUBMIT_TOKEN", this.k);
        if (this.e()) {
            return false;
        }
        h d2 = null;
        for (int j = 0; j < 3; ++j) {
            d2 = net.tec.kyfw.c.g.d(a, hashMap);
            if (this.e()) {
                break;
            }
            if (!d2.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                break;
            }
            r.b.info("\u8fde\u63a5\u8d85\u65f6...");
        }
        if (this.e()) {
            return false;
        }
        if (d2.b()) {
            return this.a(d, a2, Boolean.valueOf("Y".equals(((h.a)d2.e()).c("ifShowPassCode"))));
        }
        final String c = d2.c();
        if ((c.contains("\u975e\u6cd5\u8bf7\u6c42") || c.contains("\u7b2c\u4e09\u65b9\u8d2d\u7968\u8f6f\u4ef6")) && this.k().equals("Y")) {
            return this.c(d);
        }
        taskController.c(this.g.getAccount(), c);
        return true;
    }
    
    private boolean a(final net.tec.kyfw.util.r.d d, final String[] array, final Boolean b) {
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        final TaskController taskController = this.a(TaskController.class);
        this.l = false;
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("passengerTicketStr", array[0]);
        hashMap.put("oldPassengerStr", array[1]);
        hashMap.put("key_check_isChange", this.j);
        hashMap.put("leftTicketStr", d.b.getYpInfo());
        hashMap.put("train_location", d.b.getLocationCode());
        hashMap.put("REPEAT_SUBMIT_TOKEN", this.k);
        hashMap.put("tour_flag", "gc");
        hashMap.put("choose_seats", net.tec.kyfw.util.r.a(array[0]));
        h h = null;
        h.a a2 = null;
        taskController.c(this.g.getAccount(), "\u6b63\u5728\u63d0\u4ea4\u8ba2\u5355\uff0c" + d.b.getTrainDate() + "\uff0c" + d.b.getStationTrainCode() + "\uff0c" + d.a.getSeatName());
        boolean b2;
        do {
            b2 = false;
            if (b) {
                hashMap.put("randCode", this.a(true));
            }
            else {
                hashMap.put("randCode", "");
            }
            if (this.e()) {
                return false;
            }
            for (int i = 0; i < 3; ++i) {
                h = net.tec.kyfw.c.g.a(a, hashMap, false);
                if (this.e()) {
                    break;
                }
                if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                    break;
                }
                r.b.info("\u8fde\u63a5\u8d85\u65f6...");
            }
            if (this.e()) {
                return false;
            }
            if (h.b()) {
                taskController.c(this.g.getAccount(), "\u8ba2\u5355\u5df2\u7ecf\u63d0\u4ea4\uff0c\u7b49\u5f85\u51fa\u7968...");
                int n = 1;
                while (!this.l && (a2 == null || (a2.b("waitTime") != -1 && a2.b("waitTime") != -2))) {
                    for (int j = 0; j < 3; ++j) {
                        h = net.tec.kyfw.c.g.d(a);
                        if (this.e()) {
                            break;
                        }
                        if (!h.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                            break;
                        }
                        r.b.info("\u8fde\u63a5\u8d85\u65f6...");
                    }
                    if (this.e()) {
                        return false;
                    }
                    a2 = h.e();
                    final Integer b3 = a2.b("waitTime");
                    if (b3 == -1 || b3 == -2) {
                        continue;
                    }
                    final Integer b4 = a2.b("waitCount");
                    taskController.c(this.g.getAccount(), net.tec.kyfw.util.r.a(b4, b3));
                    if (n != 0 && b4 >= 300) {
                        n = 0;
                        final AbstractController abstractController;
                        final Window window;
                        final f f;
                        this.a(() -> {
                            abstractController.getStage();
                            if (!((Stage)window).isShowing()) {
                                ((Stage)window).show();
                                ((Stage)window).requestFocus();
                            }
                            Dialogs.create().owner(window).title("\u63d0\u793a\u4fe1\u606f\uff0c\u8d26\u53f7\uff1a" + this.g.getAccount()).message("\u5f53\u524d\u6392\u961f\u4eba\u6570\u8fc7\u591a\uff0c\u662f\u5426\u53d6\u6d88\u6392\u961f\u5e76\u628a\u8be5\u8f66\u6b21\u5e2d\u522b\u52a0\u5165\u5230\u4e0d\u53ef\u9884\u8ba2\u884c\u5217\uff1f").autoHide(8000).hideOldWindow().confirm(() -> new Thread(() -> {
                                if (net.tec.kyfw.c.g.a(f, "--", Boolean.valueOf(false)).b()) {
                                    this.l = true;
                                }
                            }).start());
                            return;
                        });
                    }
                    try {
                        Thread.sleep(200L);
                    }
                    catch (Exception ex) {}
                }
                if (this.m != null) {
                    Platform.runLater((Runnable)new t(this));
                }
                if (this.l) {
                    a(d.b.getStationTrainCode(), d.a.getSeatNo());
                    taskController.c(this.g.getAccount(), "\u5df2\u53d6\u6d88\u6392\u961f\uff01");
                    return true;
                }
                if (!a2.a("orderId").equals("")) {
                    final String s;
                    final String s2;
                    final TaskController taskController2;
                    final Window window2;
                    final TicketController ticketController;
                    final String d2;
                    String string;
                    final Dialogs dialogs;
                    final StringBuilder sb;
                    this.a(() -> {
                        new StringBuilder().append(d.b.getTrainDate()).append("\uff0c").append(d.b.getStationTrainCode()).append("\uff0c").append(d.b.getFromStationName()).append("-").append(d.b.getToStationName()).append("\uff0c").append(d.a.getSeatName()).toString();
                        this.g.setOrderId(s + "\uff0c" + s2);
                        this.g.setTaskState("\u8ba2\u7968\u6210\u529f");
                        taskController2.getStage();
                        if (!((Stage)window2).isShowing()) {
                            ((Stage)window2).show();
                            ((Stage)window2).requestFocus();
                        }
                        ticketController = this.a(TicketController.class);
                        taskController2.c(this.g.getAccount(), "\u606d\u559c\u60a8\uff01\u6539\u7b7e\u6210\u529f\u3002\u8ba2\u5355\u4fe1\u606f\uff1a" + s2);
                        if (ticketController.playMusic.isSelected()) {
                            o.b("/res/conf/buy_success.mp3");
                            if (!net.tec.kyfw.e.f(net.tec.kyfw.e.a.MUSIC)) {
                                if (new File(net.tec.kyfw.e.a(net.tec.kyfw.e.a.MUSIC)).exists()) {
                                    d2 = o.d(net.tec.kyfw.e.a(net.tec.kyfw.e.a.MUSIC));
                                }
                            }
                            net.tec.kyfw.e.i.a(d2);
                        }
                        net.tec.kyfw.util.k.a(s, d.b.getTrainDate(), d.b.getStationTrainCode(), d.b.getFromStationName(), d.b.getToStationName(), d.a.getSeatName());
                        Dialogs.create().owner(window2).title("\u63d0\u793a\u4fe1\u606f\uff0c\u8d26\u53f7\uff1a" + this.g.getAccount());
                        new StringBuilder().append("\u606d\u559c\u60a8\uff0c\u6539\u7b7e\u6210\u529f\uff01\u5e2d\u522b\u5df2\u9501\u5b9a");
                        if (p.b((Object)s)) {
                            string = "\uff0c\r\n\u8ba2\u5355\u53f7\uff1a" + s;
                        }
                        else {
                            string = "";
                        }
                        dialogs.message(sb.append(string).append("\u3002\u8bf7\u5728\u89c4\u5b9a\u768430\u5206\u949f\u5185\u5b8c\u6210\u652f\u4ed8\uff01").toString()).alert(() -> net.tec.kyfw.e.i.a());
                        return;
                    });
                    return false;
                }
                final String c = h.c();
                taskController.c(this.g.getAccount(), c);
                if (c.contains("\u53d6\u6d88\u6b21\u6570\u8fc7\u591a") || c.contains("\u4e0d\u80fd\u7ed9\u8bc1\u4ef6\u7c7b\u578b\u4e3a\u8eab\u4efd\u8bc1\u7684\u4e58\u5ba2\u529e\u7406\u8d2d\u7968\u4e1a\u52a1") || c.contains("\u672a\u901a\u8fc7\u8eab\u4efd\u4fe1\u606f\u6838\u9a8c") || c.contains("\u884c\u7a0b\u51b2\u7a81") || c.contains("\u5df2\u8ba2")) {
                    final String orderId;
                    this.a(() -> {
                        this.g.setTaskState("\u8ba2\u7968\u5931\u8d25");
                        this.g.setOrderId(orderId);
                        return;
                    });
                    return false;
                }
                if (!c.matches(".*?(\u6392\u961f\u4eba\u6570|\u6ca1\u6709\u8db3\u591f\u7684\u7968|\u4f59\u7968\u4e0d\u8db3).*?")) {
                    continue;
                }
                a(d.b.getStationTrainCode(), d.a.getSeatNo());
            }
            else if (h.c().contains("\u9a8c\u8bc1\u7801")) {
                b2 = true;
            }
            else {
                taskController.c(this.g.getAccount(), h.c());
                if (!h.c().matches(".*?(\u6392\u961f\u4eba\u6570|\u6ca1\u6709\u8db3\u591f\u7684\u7968|\u4f59\u7968\u4e0d\u8db3).*?")) {
                    continue;
                }
                a(d.b.getStationTrainCode(), d.a.getSeatNo());
            }
        } while (b2);
        return true;
    }
    
    private String k() {
        r.b.info("\u91cd\u65b0\u52a0\u8f7d\u8f66\u6b21\u4fe1\u606f...");
        final String s = null;
        final f a = net.tec.kyfw.f.a(this.g.getAccount());
        this.a(TaskController.class).c(this.g.getAccount(), "\u91cd\u65b0\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f\uff0c\u8bf7\u7a0d\u5019...");
        h b = null;
        for (int i = 0; i < 3; ++i) {
            b = net.tec.kyfw.c.g.b(a);
            if (this.e()) {
                break;
            }
            if (!b.d().equals(net.tec.kyfw.c.a.CONNECTION_TIMEOUT.E)) {
                break;
            }
            r.b.info("\u8fde\u63a5\u8d85\u65f6...");
        }
        if (this.e()) {
            return s;
        }
        String c;
        if (b.b()) {
            final h.a a2 = b.e();
            this.k = a2.a("token");
            this.j = a2.a("key_check_isChange");
            c = "Y";
        }
        else {
            c = b.c();
        }
        r.b.info("\u52a0\u8f7d\u5b8c\u6210!");
        return c;
    }
    
    private String[] c(final String s, final String s2) {
        final String[] array = { s, s2 };
        if (this.c.isEmpty()) {
            final boolean b = false;
            this.f = (b ? 1 : 0);
            this.e = (b ? 1 : 0);
        }
        else {
            array[0] = this.c.get(this.e);
            array[1] = this.d.get(this.f);
        }
        if (++this.f >= this.d.size()) {
            this.f = 0;
            ++this.e;
        }
        if (this.e >= this.c.size()) {
            this.e = 0;
        }
        return array;
    }
    
    public static void a(final String s, final String s2) {
        if (r.a.containsKey(s)) {
            if (!r.a.get(s).contains(s2)) {
                r.a.put(s, r.a.get(s) + s2);
            }
        }
        else {
            r.a.put(s, s2);
        }
        new Timeline(new KeyFrame[] { new KeyFrame(Duration.millis(300000.0), (EventHandler)new u(s, s2), new KeyValue[0]) }).play();
    }
    
    public static void b(final String s, final String s2) {
        if (r.a.containsKey(s)) {
            final String s3 = r.a.get(s);
            if (s3.contains(s2)) {
                final String replaceAll = s3.replaceAll(s2, "");
                if (replaceAll.equals("")) {
                    r.a.remove(s);
                }
                else {
                    r.a.put(s, replaceAll);
                }
            }
        }
    }
    
    static {
        r.b = net.tec.kyfw.util.j.a(r.class);
        r.a = new Hashtable<String, String>();
    }
}
