// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.util.i;

class d implements Runnable
{
    final /* synthetic */ String a;
    final /* synthetic */ c b;
    
    d(final c b, final String a) {
        this.b = b;
        this.a = a;
    }
    
    @Override
    public void run() {
        String s = i.e.a();
        if (s != null && !s.endsWith("/")) {
            if (s.endsWith("java.exe") || s.endsWith("javaw.exe")) {
                final String file = this.getClass().getProtectionDomain().getCodeSource().getLocation().getFile();
                s = file.substring(file.lastIndexOf("/") + 1);
            }
            else {
                s = s.substring(s.lastIndexOf("\\") + 1);
            }
        }
        i.e.a((String)null, "\"" + this.a + "\" -U " + i.a.GetCurrentProcessId() + " -D \"" + s + "\"");
        this.b.h();
    }
}
