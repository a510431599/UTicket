// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import javafx.scene.media.Media;
import javafx.event.EventHandler;
import javafx.animation.Timeline;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import javafx.beans.value.ChangeListener;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.media.MediaPlayer;
import javafx.beans.property.ObjectProperty;
import javafx.util.Duration;

public class i
{
    private Duration a;
    private ObjectProperty<MediaPlayer> b;
    private static i c;
    
    public i() {
        this.a = Duration.millis(500.0);
        (this.b = (ObjectProperty<MediaPlayer>)new SimpleObjectProperty()).addListener((ChangeListener)new j(this));
    }
    
    private void a(final MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            final Timeline timeline = new Timeline(new KeyFrame[] { new KeyFrame(this.a, new KeyValue[] { new KeyValue((WritableValue)mediaPlayer.volumeProperty(), (Object)0) }) });
            timeline.setOnFinished((EventHandler)new k(this, mediaPlayer));
            timeline.play();
        }
    }
    
    private void b(final MediaPlayer mediaPlayer) {
        if (mediaPlayer != null) {
            final Timeline timeline = new Timeline(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue((WritableValue)mediaPlayer.volumeProperty(), (Object)0) }), new KeyFrame(this.a, new KeyValue[] { new KeyValue((WritableValue)mediaPlayer.volumeProperty(), (Object)1) }) });
            mediaPlayer.play();
            timeline.play();
        }
    }
    
    public static void a(final String s) {
        i.c.b.set(new MediaPlayer(new Media(s)));
    }
    
    public static void a() {
        i.c.b.set(null);
    }
    
    static {
        i.c = new i();
    }
}
