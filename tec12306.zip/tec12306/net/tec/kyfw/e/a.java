// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import net.tec.kyfw.util.o;
import javafx.scene.image.Image;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.LoginController;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import net.tec.kyfw.util.j;
import org.apache.log4j.Logger;

public class a
{
    private static Logger a;
    
    static {
        net.tec.kyfw.e.a.a = j.a(a.class);
    }
    
    public static class a extends javafx.a.a<Boolean>
    {
        @Override
        public void a() {
            this.a(Boolean.FALSE);
        }
        
        public Boolean g() {
            final Boolean b = g.b(this.a(0), this.a(1), this.a(2));
            if (this.e()) {
                return Boolean.FALSE;
            }
            this.a(b);
            final LoginController loginController;
            final Boolean b2;
            this.a(() -> {
                loginController = this.a(LoginController.class);
                if (b2) {
                    loginController.submit.fire();
                }
                else {
                    loginController.b();
                }
                return;
            });
            net.tec.kyfw.e.a.a.info("\u9a8c\u8bc1\u7801\u6821\u9a8c\u5b8c\u6210");
            return b;
        }
    }
    
    public static class b extends a<Image>
    {
        @Override
        public void a() {
            final InputStream a = o.a("/res/images/yzm_loading.png");
            this.a(new Image(a));
            o.b(a);
        }
        
        public Image g() {
            final f f = this.a(0);
            final Boolean b = this.a(1);
            byte[] array = g.a(f, b);
            if (array == null && !this.e()) {
                array = g.a(f, b);
            }
            Image image = null;
            if (array != null) {
                InputStream inputStream = null;
                try {
                    inputStream = new ByteArrayInputStream(array);
                    image = new Image(inputStream);
                }
                catch (Exception ex) {
                    a.a.warn("\u521b\u5efa\u9a8c\u8bc1\u7801\u5f02\u5e38", ex);
                }
                finally {
                    if (inputStream != null) {
                        ((ByteArrayInputStream)inputStream).close();
                    }
                }
            }
            else {
                image = new Image(o.a("/res/images/yzm_loadfail.png"));
            }
            this.a(image);
            a.a.info("\u9a8c\u8bc1\u7801\u52a0\u8f7d\u5b8c\u6210");
            return image;
        }
    }
}
