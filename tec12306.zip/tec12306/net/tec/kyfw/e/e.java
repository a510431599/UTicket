// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import javafx.stage.Window;
import javafx.control.dialog.Dialogs;
import net.tec.kyfw.controller.LoadingController;

class e implements Runnable
{
    final /* synthetic */ LoadingController a;
    final /* synthetic */ c b;
    
    e(final c b, final LoadingController a) {
        this.b = b;
        this.a = a;
    }
    
    @Override
    public void run() {
        Dialogs.create().owner((Window)this.a.getStage()).message("\u4e0b\u8f7d\u66f4\u65b0\u7a0b\u5e8f\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5\uff01").alert();
        this.b.h();
    }
}
