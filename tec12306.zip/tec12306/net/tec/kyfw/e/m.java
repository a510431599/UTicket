// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.c.h;
import javafx.control.dialog.Tooltips;
import javafx.collections.ObservableList;
import net.tec.kyfw.c.g;
import net.tec.kyfw.f;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.OrderController;
import javafx.a.a;

public class m extends a<Void>
{
    @Override
    public void c() {
        super.c();
        final OrderController orderController;
        this.a(() -> {
            orderController = this.a(OrderController.class);
            orderController.overlay.setVisible(false);
            orderController.orderTable.setPlaceholder("\u8bf7\u70b9\u51fb\u67e5\u8be2\u6309\u94ae\u67e5\u8be2\u5df2\u5b8c\u6210\u7684\u8ba2\u5355");
        });
    }
    
    @Override
    public void d() {
        super.d();
        this.a(() -> this.a(OrderController.class).orderTable.setPlaceholder("\u8bf7\u70b9\u51fb\u67e5\u8be2\u6309\u94ae\u67e5\u8be2\u5df2\u5b8c\u6210\u7684\u8ba2\u5355"));
    }
    
    protected Void g() {
        final f f = this.a(0);
        final String s = this.a(1);
        final String s2 = this.a(2);
        final String s3 = this.a(3);
        final String s4 = this.a(4);
        final OrderController orderController = this.a(OrderController.class);
        final OrderController orderController2;
        this.a(() -> {
            orderController2.orderTable.setPlaceholder("\u6b63\u5728\u67e5\u8be2\uff0c\u8bf7\u7a0d\u5019...");
            if (orderController2.orderTable.getItems() != null) {
                orderController2.orderTable.getItems().clear();
            }
            return;
        });
        if (this.e()) {
            return null;
        }
        final h a = g.a(f, s, s2, s3, s4);
        if (this.e()) {
            return null;
        }
        if (a.b()) {
            this.a(() -> orderController.orderTable.setItems((ObservableList)a.e()));
        }
        else {
            this.a(() -> Tooltips.show(orderController.getWindow(), a.c()));
        }
        return null;
    }
}
