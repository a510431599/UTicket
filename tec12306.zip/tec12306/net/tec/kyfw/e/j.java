// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import javafx.scene.media.Media;
import javafx.event.EventHandler;
import javafx.animation.Timeline;
import javafx.beans.value.WritableValue;
import javafx.animation.KeyValue;
import javafx.animation.KeyFrame;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.ObjectProperty;
import javafx.util.Duration;
import javafx.beans.value.ObservableValue;
import javafx.scene.media.MediaPlayer;
import javafx.beans.value.ChangeListener;

class j implements ChangeListener<MediaPlayer>
{
    final /* synthetic */ i a;
    
    j(final i a) {
        this.a = a;
    }
    
    public void a(final ObservableValue<? extends MediaPlayer> observableValue, final MediaPlayer mediaPlayer, final MediaPlayer mediaPlayer2) {
        if (mediaPlayer != null) {
            this.a.a(mediaPlayer);
        }
        if (mediaPlayer2 != null) {
            this.a.b(mediaPlayer2);
        }
    }
}
