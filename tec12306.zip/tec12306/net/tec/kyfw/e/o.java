// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.c.h;
import java.util.List;
import net.tec.kyfw.b.H;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.TicketController;
import java.util.Map;
import net.tec.kyfw.f;
import net.tec.kyfw.util.DateUtil;
import java.util.HashMap;
import net.tec.kyfw.d.g;
import javafx.a.a;

public class o extends a<Void>
{
    public Void g() {
        final g g = this.a(0);
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("train_no", g.getTrainNo());
        hashMap.put("from_station_telecode", g.getFromStationTelecode());
        hashMap.put("to_station_telecode", g.getToStationTelecode());
        hashMap.put("depart_date", DateUtil.a(DateUtil.a(g.getStartTrainDate(), "yyyyMMdd"), "yyyy-MM-dd"));
        hashMap.put("train_seat_feature", g.getTrainSeatFeature());
        net.tec.kyfw.c.g.e(f.b(), hashMap);
        if (this.e()) {
            return null;
        }
        final h h;
        this.a(() -> H.a(javafx.controller.a.a(TicketController.class).getWindow()).a(h.e()).a());
        return null;
    }
}
