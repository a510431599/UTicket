// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import javafx.a.a;

public class f extends a<String>
{
    public String g() {
        while (!this.e()) {
            this.a(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            if (!this.e()) {
                Thread.sleep(1000L);
            }
        }
        return null;
    }
}
