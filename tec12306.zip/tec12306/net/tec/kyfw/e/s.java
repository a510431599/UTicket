// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import java.util.Hashtable;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import java.util.concurrent.CountDownLatch;
import javafx.stage.Window;
import java.io.File;
import net.tec.kyfw.util.o;
import net.tec.kyfw.controller.TicketController;
import net.tec.kyfw.util.p;
import javafx.application.Platform;
import net.tec.kyfw.d.k;
import java.util.HashMap;
import net.tec.kyfw.d.d;
import javafx.stage.Stage;
import javafx.collections.transformation.FilteredList;
import net.tec.kyfw.c.h;
import net.tec.kyfw.util.b;
import javafx.collections.ObservableList;
import net.tec.kyfw.c.g;
import net.tec.kyfw.d.j;
import net.tec.kyfw.util.DateUtil;
import net.tec.kyfw.f;
import java.time.LocalTime;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.TaskController;
import java.util.ArrayList;
import net.tec.kyfw.b.e;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import javafx.a.a;
import javafx.control.dialog.Dialogs;

class s implements Runnable
{
    final /* synthetic */ r a;
    
    s(final r a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        this.a.m.close();
        this.a.m = null;
    }
}
