// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.util.j;
import java.util.List;
import net.tec.kyfw.c.h;
import java.util.Collection;
import javafx.collections.FXCollections;
import net.tec.kyfw.util.b;
import net.tec.kyfw.util.DateUtil;
import java.time.LocalDate;
import net.tec.kyfw.d.f;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.TicketController;
import org.apache.log4j.Logger;
import net.tec.kyfw.d.g;
import javafx.collections.ObservableList;
import javafx.a.a;

public class v extends a<ObservableList<g>>
{
    private static Logger c;
    private ObservableList<g> d;
    int a;
    int b;
    
    public v() {
        this.d = null;
    }
    
    @Override
    public void d() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: aload_0        
        //     1: invokespecial   javafx/a/a.d:()V
        //     4: aload_0        
        //     5: ldc             Lnet/tec/kyfw/controller/TicketController;.class
        //     7: invokevirtual   net/tec/kyfw/e/v.a:(Ljava/lang/Class;)Ljava/lang/Object;
        //    10: checkcast       Lnet/tec/kyfw/controller/TicketController;
        //    13: astore_1       
        //    14: aload_0        
        //    15: aload_1        
        //    16: invokedynamic   run:(Lnet/tec/kyfw/controller/TicketController;)Ljava/lang/Runnable;
        //    21: invokevirtual   net/tec/kyfw/e/v.a:(Ljava/lang/Runnable;)V
        //    24: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:757)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:655)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:532)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:499)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:141)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:130)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:105)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:317)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:238)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:123)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public ObservableList<g> g() {
        final long currentTimeMillis = System.currentTimeMillis();
        final TicketController ticketController = this.a(TicketController.class);
        this.a(() -> ticketController.trainTable.setPlaceholder("\u6b63\u5728\u67e5\u8be2, \u8bf7\u7a0d\u5019..."));
        v.c.info("\u6267\u884c\u8bf7\u6c42&\u5904\u7406\u6570\u636e...");
        ObservableList observableArrayList = null;
        if (this.e()) {
            return null;
        }
        final String[] a = this.a(((f)ticketController.fromStation.getValue()).getStationTelecode(), ((f)ticketController.toStation.getValue()).getStationTelecode(), ticketController.a, ticketController.b);
        final h a2 = net.tec.kyfw.c.g.a(net.tec.kyfw.f.b(), DateUtil.a((LocalDate)ticketController.trainDate.getValue(), "yyyy-MM-dd"), ((f)ticketController.fromStation.getValue()).getStationName(), a[0], ((f)ticketController.toStation.getValue()).getStationName(), a[1], ticketController.a, ticketController.b);
        if (this.e()) {
            return null;
        }
        if (a2.b()) {
            v.c.info("\u8fc7\u6ee4\u975e\u9009\u9879...");
            this.d = net.tec.kyfw.util.b.a((ObservableList<g>)a2.e(), ticketController.trainShow.getItems(), ticketController.seatShow.getItems(), ticketController.submitOption.isSelected(), ticketController.riderShow.size());
            if (this.d != null && !this.d.isEmpty()) {
                observableArrayList = FXCollections.observableArrayList((Collection)net.tec.kyfw.util.b.a(this.d, ticketController.b(), ticketController.a(), ticketController.showCanBuy.isSelected()));
            }
            if (this.e()) {
                return null;
            }
            final long n = System.currentTimeMillis() - currentTimeMillis;
            if (n < 150L) {
                try {
                    Thread.sleep(150L - n);
                }
                catch (Exception ex) {}
            }
            v.c.info("\u5217\u8868\u52a0\u8f7d\u5b8c\u6210!");
            this.a((ObservableList<g>)observableArrayList);
        }
        this.a(() -> ticketController.trainTable.setPlaceholder(a2.c()));
        return (ObservableList<g>)observableArrayList;
    }
    
    @Override
    public void c() {
        super.c();
        this.a(() -> this.a(TicketController.class).trainTable.setPlaceholder("\u5df2\u53d6\u6d88\u67e5\u8be2\uff01"));
    }
    
    public ObservableList<g> h() {
        return this.d;
    }
    
    private String[] a(final String s, final String s2, final List<String> list, final List<String> list2) {
        final String[] array = { s, s2 };
        if (list.isEmpty()) {
            final boolean b = false;
            this.b = (b ? 1 : 0);
            this.a = (b ? 1 : 0);
        }
        else {
            array[0] = list.get(this.a);
            array[1] = list2.get(this.b);
        }
        if (++this.b >= list2.size()) {
            this.b = 0;
            ++this.a;
        }
        if (this.a >= list.size()) {
            this.a = 0;
        }
        return array;
    }
    
    static {
        v.c = j.a(v.class);
    }
}
