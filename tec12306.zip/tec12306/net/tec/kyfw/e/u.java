// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

final class u implements EventHandler<ActionEvent>
{
    final /* synthetic */ String a;
    final /* synthetic */ String b;
    
    u(final String a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    public void a(final ActionEvent actionEvent) {
        r.b(this.a, this.b);
    }
}
