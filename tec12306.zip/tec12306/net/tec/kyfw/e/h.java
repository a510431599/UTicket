// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.e;

import net.tec.kyfw.c.g;
import javafx.scene.control.Label;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.MainController;
import net.tec.kyfw.f;
import javafx.a.a;

public class h extends a<Void>
{
    public Void g() {
        final f f = this.a(0);
        if (f.f().equals("D")) {
            final MainController mainController;
            this.a(() -> {
                mainController = this.a(MainController.class);
                ((Label)mainController.login.getChildren().get(0)).setText("\u767b\u5f55/\u6ce8\u518c");
                mainController.bottomController.a((String)null);
                return;
            });
        }
        f.a(Boolean.valueOf(true));
        g.f(f);
        return null;
    }
}
