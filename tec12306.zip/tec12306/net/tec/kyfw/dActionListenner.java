// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.controller.AbstractController;
import javafx.controller.a;
import net.tec.kyfw.controller.MainController;
import java.awt.event.ActionEvent;
import javafx.stage.Stage;
import java.awt.event.ActionListener;

final class dActionListenner implements ActionListener
{
    final /* synthetic */ Stage aStage;

    dActionListenner(final Stage aStage) {
        this.aStage = aStage;
    }
    
    @Override
    public void actionPerformed(final ActionEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: aload_1        
        //     1: invokevirtual   java/awt/event/ActionEvent.getSource:()Ljava/lang/Object;
        //     4: checkcast       Ljava/awt/MenuItem;
        //     7: astore_2       
        //     8: aload_2        
        //     9: invokevirtual   java/awt/MenuItem.getActionCommand:()Ljava/lang/String;
        //    12: ldc             "0"
        //    14: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    17: ifeq            35
        //    20: aload_0        
        //    21: getfield        net/tec/kyfw/d.a:Ljavafx/stage/Stage;
        //    24: invokedynamic   run:(Ljavafx/stage/Stage;)Ljava/lang/Runnable;
        //    29: invokestatic    javafx/application/Platform.runLater:(Ljava/lang/Runnable;)V
        //    32: goto            140
        //    35: aload_2        
        //    36: invokevirtual   java/awt/MenuItem.getActionCommand:()Ljava/lang/String;
        //    39: ldc             "1"
        //    41: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    44: ifeq            62
        //    47: aload_0        
        //    48: getfield        net/tec/kyfw/d.a:Ljavafx/stage/Stage;
        //    51: invokedynamic   run:(Ljavafx/stage/Stage;)Ljava/lang/Runnable;
        //    56: invokestatic    javafx/application/Platform.runLater:(Ljava/lang/Runnable;)V
        //    59: goto            140
        //    62: aload_2        
        //    63: invokevirtual   java/awt/MenuItem.getActionCommand:()Ljava/lang/String;
        //    66: ldc             "2"
        //    68: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    71: ifeq            89
        //    74: aload_0        
        //    75: getfield        net/tec/kyfw/d.a:Ljavafx/stage/Stage;
        //    78: invokedynamic   run:(Ljavafx/stage/Stage;)Ljava/lang/Runnable;
        //    83: invokestatic    javafx/application/Platform.runLater:(Ljava/lang/Runnable;)V
        //    86: goto            140
        //    89: aload_2        
        //    90: invokevirtual   java/awt/MenuItem.getActionCommand:()Ljava/lang/String;
        //    93: ldc             "3"
        //    95: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    98: ifeq            116
        //   101: aload_0        
        //   102: getfield        net/tec/kyfw/d.a:Ljavafx/stage/Stage;
        //   105: invokedynamic   run:(Ljavafx/stage/Stage;)Ljava/lang/Runnable;
        //   110: invokestatic    javafx/application/Platform.runLater:(Ljava/lang/Runnable;)V
        //   113: goto            140
        //   116: aload_2        
        //   117: invokevirtual   java/awt/MenuItem.getActionCommand:()Ljava/lang/String;
        //   120: ldc             "4"
        //   122: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   125: ifeq            140
        //   128: aload_0        
        //   129: getfield        net/tec/kyfw/d.a:Ljavafx/stage/Stage;
        //   132: invokedynamic   run:(Ljavafx/stage/Stage;)Ljava/lang/Runnable;
        //   137: invokestatic    javafx/application/Platform.runLater:(Ljava/lang/Runnable;)V
        //   140: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:757)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:655)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:532)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:499)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:141)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:130)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:105)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:317)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:238)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:123)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
