// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.scene.input.MouseEvent;
import java.util.List;
import javafx.stage.Window;
import javafx.collections.ObservableMap;
import javafx.scene.Node;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.event.EventHandler;
import javafx.stage.Modality;
import javafx.stage.StageStyle;
import javafx.scene.paint.Paint;
import javafx.scene.paint.Color;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class H extends Stage
{
    public static H a;
    private Pane d;
    private VBox e;
    private HBox f;
    private ScrollPane g;
    private VBox h;
    private HBox i;
    private Label j;
    private Label k;
    private Label l;
    private Label m;
    protected double b;
    protected double c;
    
    private H() {
        this.d = new Pane();
        this.e = new VBox();
        this.f = new HBox();
        this.g = new ScrollPane();
        this.h = new VBox();
        this.i = new HBox();
        this.j = new Label();
        this.k = new Label();
        this.l = new Label();
        this.m = new Label();
        final Scene scene = new Scene((Parent)this.d);
        scene.setFill((Paint)Color.TRANSPARENT);
        this.initStyle(StageStyle.TRANSPARENT);
        this.initModality(Modality.NONE);
        this.setOnCloseRequest((EventHandler)new I(this));
        this.setScene(scene);
        final KeyCodeCombination keyCodeCombination = new KeyCodeCombination(KeyCode.ESCAPE, new KeyCombination.Modifier[0]);
        final KeyCodeCombination keyCodeCombination2 = new KeyCodeCombination(KeyCode.W, new KeyCombination.Modifier[] { KeyCombination.CONTROL_DOWN });
        final KeyCodeCombination keyCodeCombination3 = new KeyCodeCombination(KeyCode.F4, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final ObservableMap accelerators = scene.getAccelerators();
        final jRun j = new jRun(this);
        accelerators.put((Object)keyCodeCombination, (Object)j);
        accelerators.put((Object)keyCodeCombination2, (Object)j);
        accelerators.put((Object)keyCodeCombination3, (Object)j);
        this.e.setOnMousePressed((EventHandler)this.d());
        this.e.setOnMouseDragged((EventHandler)this.e());
        this.e.setStyle("-fx-font-size: 12;-fx-border-width:1;-fx-border-radius:3;-fx-border-color:#3063ac;-fx-background-radius:3;-fx-background-color:#f9f9f9;-fx-effect: dropshadow(gaussian, #7c8b94, 4, 0.3, 0 , 1);");
        this.e.setPrefSize(370.0, 231.0);
        this.f.setPrefSize(370.0, 28.0);
        this.f.setStyle("-fx-background-insets: 1 0 0 1;-fx-background-color: #6da0d4;");
        this.b();
        this.i.setPrefSize(370.0, 28.0);
        this.i.setStyle("-fx-border-width:1 0 0 0;-fx-border-color: #3063ac;");
        this.g.setPrefSize(370.0, 175.0);
        this.g.getStylesheets().add((Object)"/res/css/scrollbar.css");
        this.g.getStyleClass().add((Object)"custom-scroll");
        this.g.setContent((Node)this.h);
        this.c();
        this.e.getChildren().addAll((Object[])new Node[] { this.f, this.g, this.i });
        this.e.setLayoutX(4.0);
        this.e.setLayoutY(4.0);
        this.d.setPrefSize(378.0, 239.0);
        this.d.setStyle("-fx-background-color: transparent;");
        this.d.getChildren().add((Object)this.e);
    }
    
    public static H a(final Window window) {
        if (H.a == null) {
            (H.a = new H()).initOwner(window);
            H.a.setX(window.getX() + window.getWidth() / 2.0 - 189.0);
            H.a.setY(window.getY() + window.getHeight() / 2.0 - 119.0);
        }
        return H.a;
    }
    
    public H a(final List<a> list) {
        this.h.getChildren().clear();
        this.b(null);
        if (list != null && !list.isEmpty()) {
            for (int i = 0; i < list.size(); ++i) {
                this.a(list.get(i));
            }
            this.b(list.get(0));
        }
        return this;
    }
    
    public void a() {
        this.show();
    }
    
    public void hide() {
        super.hide();
        this.h.getChildren().clear();
        this.b(null);
    }
    
    private void b() {
        final String[] array = { "\u7ad9\u5e8f", "\u7ad9\u540d", "\u5230\u7ad9\u65f6\u95f4", "\u51fa\u53d1\u65f6\u95f4", "\u505c\u7559\u65f6\u95f4", "\u00d7" };
        final Integer[] array2 = { 50, 80, 70, 70, 70, 30 };
        for (int i = 0; i < array.length; ++i) {
            final Label label = new Label(array[i]);
            label.setPrefSize((double)array2[i], 28.0);
            label.setStyle("-fx-border-width:0 0 1 0;-fx-border-color: #3063ac;-fx-border-insets: 1 0 0 0;-fx-alignment: baseline-center;-fx-text-fill:#ffffff;-fx-font-weight:bold;");
            this.f.getChildren().add((Object)label);
            if (i == array.length - 1) {
                label.setStyle(label.getStyle() + "-fx-font-size:18;-fx-cursor:hand;");
                label.setOnMouseClicked((EventHandler)new K(this));
            }
        }
    }
    
    private void a(final a a) {
        final HBox hBox = new HBox();
        hBox.setPrefSize(340.0, 25.0);
        final Label label = new Label(a.a);
        label.setPrefSize(50.0, 25.0);
        label.setStyle("-fx-border-width:0;-fx-border-color: #3063ac;-fx-alignment: baseline-center;" + (a.k ? "-fx-text-fill:#38383b;" : "-fx-text-fill:#8b8b8f;"));
        final Label label2 = new Label(a.b);
        label2.setPrefSize(80.0, 25.0);
        label2.setStyle("-fx-border-width:0;-fx-border-color: #3063ac;-fx-alignment: baseline-center;" + (a.k ? "-fx-text-fill:#38383b;" : "-fx-text-fill:#8b8b8f;"));
        final Label label3 = new Label(a.c);
        label3.setPrefSize(70.0, 25.0);
        label3.setStyle("-fx-border-width:0;-fx-border-color: #3063ac;-fx-alignment: baseline-center;" + (a.k ? "-fx-text-fill:#38383b;" : "-fx-text-fill:#8b8b8f;"));
        final Label label4 = new Label(a.d);
        label4.setPrefSize(70.0, 25.0);
        label4.setStyle("-fx-border-width:0;-fx-border-color: #3063ac;-fx-alignment: baseline-center;" + (a.k ? "-fx-text-fill:#38383b;" : "-fx-text-fill:#8b8b8f;"));
        final Label label5 = new Label(a.e);
        label5.setPrefSize(68.0, 25.0);
        label5.setStyle("-fx-border-width:0;-fx-border-color: #3063ac;-fx-alignment: baseline-right;" + (a.k ? "-fx-text-fill:#38383b;" : "-fx-text-fill:#8b8b8f;"));
        hBox.getChildren().addAll((Object[])new Node[] { label, label2, label3, label4, label5 });
        this.h.getChildren().add((Object)hBox);
    }
    
    private void c() {
        this.j.setPrefSize(100.0, 28.0);
        this.j.setStyle("-fx-font-weight:bold;-fx-alignment: baseline-left;-fx-padding:0 0 0 5;");
        this.k.setPrefSize(150.0, 28.0);
        this.k.setStyle("-fx-alignment: baseline-left;");
        this.l.setPrefSize(50.0, 28.0);
        this.l.setStyle("-fx-alignment: baseline-center;");
        this.m.setPrefSize(70.0, 28.0);
        this.m.setStyle("-fx-alignment: baseline-center;");
        this.i.getChildren().addAll((Object[])new Node[] { this.j, this.k, this.l, this.m });
    }
    
    private void b(final a a) {
        this.j.setText((a != null) ? a.f : "");
        this.k.setText((a != null) ? (a.g + "\u2192" + a.h) : "");
        this.l.setText((a != null) ? a.i : "");
        this.m.setText((a != null) ? a.j : "");
    }
    
    private EventHandler<MouseEvent> d() {
        return (EventHandler<MouseEvent>)new L(this);
    }
    
    private EventHandler<MouseEvent> e() {
        return (EventHandler<MouseEvent>)new M(this);
    }
    
    static {
        H.a = null;
    }
    
    public static class a
    {
        public String a;
        public String b;
        public String c;
        public String d;
        public String e;
        public String f;
        public String g;
        public String h;
        public String i;
        public String j;
        public boolean k;
        public String l;
        
        public a(final String a, final String b, final String c, final String d, final String e, final String f, final String g, final String h, final String i, final String s, final boolean k, final String l) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
            this.f = f;
            this.g = g;
            this.h = h;
            this.i = i;
            this.k = k;
            this.l = l;
            if ("0".equals(s) || "2".equals(s) || "4".equals(s)) {
                this.j = "\u65e0\u7a7a\u8c03";
            }
            else {
                this.j = "\u6709\u7a7a\u8c03";
            }
        }
        
        public a(final String a, final String b, final String c, final String d, final String e, final boolean k) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.e = e;
            this.k = k;
        }
    }
}
