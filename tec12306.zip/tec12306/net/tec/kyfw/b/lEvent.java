// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;

class lEvent implements EventHandler<MouseEvent>
{
    final /* synthetic */ H a;

    lEvent(final H a) {
        this.a = a;
    }
    
    public void handle(final MouseEvent mouseEvent) {
        this.a.b = mouseEvent.getSceneX();
        this.a.c = mouseEvent.getSceneY();
    }
}
