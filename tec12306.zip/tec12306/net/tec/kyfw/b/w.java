// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.Color;
import net.tec.kyfw.a.l;
import java.io.InputStream;
import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableMap;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.scene.Parent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.layout.ColumnConstraints;
import javafx.geometry.VPos;
import javafx.scene.layout.RowConstraints;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.beans.value.ChangeListener;
import javafx.scene.image.Image;
import javafx.concurrent.Service;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.PopupControl;
import javafx.scene.Node;
import java.util.function.Predicate;

class w implements Predicate<Node>
{
    final /* synthetic */ s a;
    
    w(final s a) {
        this.a = a;
    }
    
    public boolean a(final Node node) {
        return !node.equals(this.a.o);
    }
}
