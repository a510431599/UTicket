// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.animation.Animation;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.collections.FXCollections;
import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.collections.ObservableList;
import javafx.scene.layout.StackPane;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class U implements EventHandler<ActionEvent>
{
    final /* synthetic */ oStackPane a;
    
    U(final oStackPane a) {
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        this.a.e();
    }
}
