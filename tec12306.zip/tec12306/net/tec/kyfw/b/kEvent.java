// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;

class kEvent implements EventHandler<MouseEvent>
{
    final /* synthetic */ H a;

    kEvent(final H a) {
        this.a = a;
    }
    
    public void handle(final MouseEvent mouseEvent) {
        this.a.hide();
    }
}
