// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

class jRun implements Runnable
{
    final /* synthetic */ H a;

    jRun(final H a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        this.a.hide();
    }
}
