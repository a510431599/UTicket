// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.event.Event;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;

class mEvent implements EventHandler<MouseEvent>
{
    final /* synthetic */ H a;

    mEvent(final H a) {
        this.a = a;
    }
    
    public void handle(final MouseEvent mouseEvent) {
        this.a.setX(mouseEvent.getScreenX() - this.a.b);
        this.a.setY(mouseEvent.getScreenY() - this.a.c);
    }
}
