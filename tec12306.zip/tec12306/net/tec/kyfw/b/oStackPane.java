// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.animation.Animation;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.beans.value.ChangeListener;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.animation.KeyValue;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.collections.FXCollections;
import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.collections.ObservableList;
import javafx.scene.layout.StackPane;

public class oStackPane extends StackPane
{
    private ObservableList<String[]> a;
    private Integer b;
    private Integer c;
    private Label d;
    private String e;
    private String f;
    private Timeline g;
    private FadeTransition h;
    private FadeTransition i;
    
    public oStackPane() {
        this.a = FXCollections.observableArrayList();
        this.b = 15000;
        this.c = 0;
        this.d = new Label();
        this.e = "-fx-label-padding: 0 5 0 0;-fx-cursor: hand;";
        this.f = "-fx-underline: true;";
        this.g = new Timeline(new KeyFrame[] { new KeyFrame(Duration.millis((double)this.b), new KeyValue[0]) });
        this.h = new FadeTransition(Duration.millis(300.0), (Node)this.d);
        this.i = new FadeTransition(Duration.millis(300.0), (Node)this.d);
        this.setAlignment(Pos.CENTER_LEFT);
        this.d.setStyle(this.e);
        this.d.hoverProperty().addListener((ChangeListener)new P(this));
        this.d.setOnMouseClicked((EventHandler)new Q(this));
        this.getChildren().add(this.d);
        this.g.setOnFinished((EventHandler)new R(this));
        this.i.setFromValue(1.0);
        this.i.setToValue(0.5);
        this.i.setOnFinished((EventHandler)new sEvent(this));
        this.h.setFromValue(0.5);
        this.h.setToValue(1.0);
        this.h.setOnFinished((EventHandler)new U(this));
    }
    
    private void e() {
        this.g.play();
    }
    
    public void f() {
        this.d.setText(this.d());
        this.h.play();
    }
    
    public void a() {
        if (!this.a.isEmpty()) {
            if (Platform.isFxApplicationThread()) {
                this.f();
            }
            else {
                Platform.runLater((Runnable)new V(this));
            }
        }
    }
    
    public void b() {
        if (this.g.getStatus().equals(Animation.Status.RUNNING)) {
            this.g.pause();
        }
        else if (this.h.getStatus().equals(Animation.Status.RUNNING)) {
            this.h.pause();
        }
        else if (this.i.getStatus().equals(Animation.Status.RUNNING)) {
            this.i.pause();
        }
    }
    
    public void c() {
        if (!this.a.isEmpty()) {
            if (this.g.getStatus().equals(Animation.Status.PAUSED)) {
                this.g.play();
            }
            else if (this.h.getStatus().equals(Animation.Status.PAUSED)) {
                this.h.play();
            }
            else if (this.i.getStatus().equals(Animation.Status.PAUSED)) {
                this.i.play();
            }
        }
    }
    
    public void a(final String[] array) {
        this.a.add(array);
    }
    
    public String d() {
        if (this.a.isEmpty()) {
            return null;
        }
        if (this.c == this.a.size()) {
            this.c = 0;
        }
        final String s = ((String[])this.a.get((int)this.c))[0];
        final Integer c = this.c;
        ++this.c;
        return s;
    }
}
