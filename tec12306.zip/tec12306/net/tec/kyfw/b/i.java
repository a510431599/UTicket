// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.event.Event;
import javafx.stage.WindowEvent;
import javafx.event.EventHandler;

class I implements EventHandler<WindowEvent>
{
    final /* synthetic */ H a;
    
    I(final H a) {
        this.a = a;
    }
    
    public void a(final WindowEvent windowEvent) {
        windowEvent.consume();
    }
}
