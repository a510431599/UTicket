// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import net.tec.kyfw.util.i;
import net.tec.kyfw.controller.MainController;
import net.tec.kyfw.controller.LoginController;
import net.tec.kyfw.e.h;
import javafx.controller.AbstractController;
import net.tec.kyfw.controller.PassengerController;
import net.tec.kyfw.f;
import javafx.control.dialog.Dialogs;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;
import javafx.event.ActionEvent;
import javafx.control.bean.SelectedProperty;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.util.p;
import javafx.a.d;
import net.tec.kyfw.e.r;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.scene.control.Hyperlink;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import net.tec.kyfw.util.o;
import javafx.scene.layout.GridPane;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.control.Provider;
import javafx.beans.property.IntegerProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import net.tec.kyfw.d.a;
import javafx.control.Cascade;
import javafx.scene.layout.VBox;

public class nBox extends VBox implements Cascade<a>
{
    private ObjectProperty<ObservableList<a>> a;
    private IntegerProperty b;
    private IntegerProperty c;
    private IntegerProperty d;
    private Provider<a> e;
    
    public nBox() {
        this.a = (ObjectProperty<ObservableList<a>>)new SimpleObjectProperty((Object)this, "items", (Object)FXCollections.observableArrayList());
        this.b = (IntegerProperty)new SimpleIntegerProperty((Object)this, "checked", 0);
        this.c = (IntegerProperty)new SimpleIntegerProperty((Object)this, "maxSize", 0);
        this.d = (IntegerProperty)new SimpleIntegerProperty((Object)this, "selectIndex", -1);
        this.b().addListener((observableValue, n, n2) -> {
            final Node lookup = this.lookup(".task-item-active");
            if (lookup != null) {
                lookup.getStyleClass().remove((Object)"task-item-active");
            }
            if (n2.intValue() != -1) {
                ((Node)this.getChildren().get(n2.intValue())).getStyleClass().add((Object)"task-item-active");
            }
        });
    }
    
    public ObservableList<a> getItems() {
        return (ObservableList<a>)this.a.get();
    }
    
    public IntegerProperty checkedProperty() {
        return this.b;
    }
    
    public Integer a() {
        return this.d.get();
    }
    
    public void a(final Integer n) {
        this.d.set((int)n);
    }
    
    public void a(final a a) {
        this.d.set(this.getItems().indexOf((Object)a));
    }
    
    public IntegerProperty b() {
        return this.d;
    }
    
    public int c() {
        return this.checkedProperty().get();
    }
    
    public IntegerProperty maxSizeProperty() {
        return this.c;
    }
    
    public int d() {
        return this.c.get();
    }
    
    public void a(final int n) {
        this.c.set(n);
    }
    
    public void setProvider(final Provider<a> e) {
        this.e = e;
    }
    
    public a a(final String s) {
        if (this.getItems() == null || this.getItems().isEmpty()) {
            return null;
        }
        for (int i = 0; i < this.getItems().size(); ++i) {
            if (((a)this.getItems().get(i)).getAccount().equals(s)) {
                return (a)this.getItems().get(i);
            }
        }
        return null;
    }
    
    public a e() {
        return (a)this.getItems().get((int)this.a());
    }
    
    public void b(final a a) {
        if (this.d() > 0 && this.c() >= this.d()) {
            return;
        }
        try {
            final GridPane gridPane = (GridPane)new FXMLLoader(o.c("/res/fxml/task_template_row.fxml")).load();
            this.getItems().add((Object)a);
            this.checkedProperty().set(this.checkedProperty().get() + 1);
            this.a(-1, gridPane, a);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final a a, final Boolean b) {
        this.b(a);
        this.a(Integer.valueOf(this.getItems().size() - 1));
    }
    
    public void a(final int n, final a a) {
        if (this.d() > 0 && this.c() >= this.d()) {
            return;
        }
        try {
            final GridPane gridPane = (GridPane)new FXMLLoader(o.c("/res/fxml/task_template_row.fxml")).load();
            this.getItems().add(n, (Object)a);
            this.checkedProperty().set(this.checkedProperty().get() + 1);
            this.a(n, gridPane, a);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void a(final int n, final GridPane gridPane, final a a) {
        if (n > -1) {
            this.getChildren().add(n, (Object)gridPane);
        }
        else {
            this.getChildren().add((Object)gridPane);
        }
        gridPane.setOnMouseClicked(mouseEvent -> {
            if ("\u9700\u8981\u767b\u5f55".equals(a.getTaskState())) {
                return;
            }
            this.a(Integer.valueOf(this.getChildren().indexOf((Object)gridPane)));
        });
        final Hyperlink hyperlink = (Hyperlink)gridPane.getChildren().get(1);
        final Label label = (Label)gridPane.getChildren().get(3);
        final Label label2 = (Label)gridPane.getChildren().get(5);
        final HBox hBox = (HBox)gridPane.getChildren().get(6);
        final Button button = (Button)hBox.getChildren().get(0);
        final Button button2 = (Button)hBox.getChildren().get(1);
        final Label label3 = (Label)gridPane.getChildren().get(8);
        final Label label4 = (Label)gridPane.getChildren().get(10);
        final Hyperlink hyperlink2 = (Hyperlink)gridPane.getChildren().get(12);
        hyperlink.textProperty().bind((ObservableValue)a.account);
        hyperlink.setOnAction(actionEvent -> i.e.a(f.a(a.getAccount()), "https://kyfw.12306.cn/otn/index/initMy12306"));
        label.textProperty().bind((ObservableValue)a.stationShow);
        label2.textProperty().addListener((observableValue, s, s2) -> {
            label2.getStyleClass().remove((Object)"state-success");
            label2.getStyleClass().remove((Object)"state-fail");
            if ("\u8ba2\u7968\u6210\u529f".equals(s2)) {
                label2.getStyleClass().add((Object)"state-success");
                button.setText("\u5f00\u59cb");
            }
            else if ("\u8ba2\u7968\u5931\u8d25".equals(s2) || "\u5f02\u5e38\u7ec8\u6b62".equals(s2)) {
                label2.getStyleClass().add((Object)"state-fail");
                button.setText("\u5f00\u59cb");
            }
            else if ("\u7b49\u5f85\u8fd0\u884c".equals(s2)) {
                button.setText("\u5f00\u59cb");
            }
            else if ("\u6b63\u5728\u8fd0\u884c".equals(s2) || "\u5b9a\u65f6\u5237\u65b0".equals(s2)) {
                button.setText("\u505c\u6b62");
            }
        });
        label2.textProperty().bind((ObservableValue)a.taskState);
        label4.textProperty().bind((ObservableValue)a.startTimeShow);
        label3.textProperty().bind((ObservableValue)a.riders);
        hyperlink2.textProperty().bind((ObservableValue)a.orderId);
        hyperlink2.setOnAction(actionEvent -> {
            if ("\u8ba2\u7968\u6210\u529f".equals(a.getTaskState())) {
                i.e.a(f.a(a.getAccount()), "https://kyfw.12306.cn/otn/queryOrder/initNoComplete");
            }
        });
        if ("\u9700\u8981\u767b\u5f55".equals(a.getTaskState())) {
            button.setText("\u767b\u5f55");
        }
        button.setOnAction(actionEvent -> {
            if (this.d(a)) {
                if (button.getText().equals("\u767b\u5f55")) {
                    javafx.controller.a.a(LoginController.class).a(a.getAccount(), a.getPassword());
                    javafx.controller.a.a(MainController.class).a.setArguments(f.c()).show();
                }
                else if (button.getText().equals("\u5f00\u59cb")) {
                    final r r = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)r.class, a.getAccount());
                    r.a(a);
                    r.start();
                }
                else {
                    final r r2 = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)r.class, a.getAccount());
                    if (r2.isRunning()) {
                        r2.cancel();
                    }
                }
            }
        });
        button2.setOnAction(actionEvent -> {
            String string;
            if ("\u8ba2\u7968\u6210\u529f".equals(a.getTaskState())) {
                string = "\u8be5\u4efb\u52a1\u8ba2\u7968\u6210\u529f\uff0c\u8bf7\u53ca\u65f6\u652f\u4ed8\u3002\u786e\u5b9a\u4ece\u4efb\u52a1\u5217\u8868\u4e2d\u79fb\u9664\u6b64\u9879\u4efb\u52a1\uff1f";
            }
            else if ("\u8ba2\u7968\u5931\u8d25".equals(a.getTaskState())) {
                string = "\u8be5\u4efb\u52a1\u5df2\u7ec8\u6b62\uff0c\u786e\u5b9a\u4ece\u4efb\u52a1\u5217\u8868\u4e2d\u79fb\u9664\u6b64\u9879\u4efb\u52a1\uff1f";
            }
            else if ("\u6b63\u5728\u8fd0\u884c".equals(a.getTaskState())) {
                string = "\u8be5\u4efb\u52a1\u6b63\u5728\u8fd0\u884c\uff0c\u786e\u5b9a\u4ece\u4efb\u52a1\u5217\u8868\u4e2d\u79fb\u9664\u6b64\u9879\u4efb\u52a1\uff1f";
            }
            else if (a.getTimingBuy()) {
                string = "\u8fd9\u662f\u4e00\u4e2a\u5b9a\u65f6\u4efb\u52a1\uff0c\u5b9a\u65f6\u5237\u65b0\u65f6\u95f4\uff1a" + LocalTime.ofSecondOfDay(a.getTimingDate()).format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "\uff0c\u786e\u5b9a\u4ece\u4efb\u52a1\u5217\u8868\u4e2d\u79fb\u9664\u6b64\u9879\u4efb\u52a1\uff1f";
            }
            else {
                string = "\u8be5\u4efb\u52a1\u672a\u5f00\u59cb\uff0c\u786e\u5b9a\u4ece\u4efb\u52a1\u5217\u8868\u4e2d\u79fb\u9664\u6b64\u9879\u4efb\u52a1\uff1f";
            }
            if (1 == Integer.valueOf(Dialogs.create().owner(button2.getScene().getWindow()).title("\u63d0\u793a\u4fe1\u606f").message(string).confirmAndWait())) {
                if ("\u6b63\u5728\u8fd0\u884c".equals(a.getTaskState()) || "\u5b9a\u65f6\u5237\u65b0".equals(a.getTaskState())) {
                    final r r = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)r.class, a.getAccount());
                    if (r.isRunning()) {
                        r.cancel();
                    }
                }
                this.c(a);
                if (!f.a(a.getAccount()).j() && !"\u9700\u8981\u767b\u5f55".equals(a.getTaskState())) {
                    final PassengerController passengerController = javafx.controller.a.a(PassengerController.class);
                    if (f.a(a.getAccount()).g().equals(passengerController.account.getValue())) {
                        passengerController.account.setValue((Object)null);
                    }
                    passengerController.account.getItems().remove((Object)f.a(a.getAccount()).g());
                    final h h = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)h.class);
                    h.a(f.a(a.getAccount()));
                    h.start();
                }
            }
        });
    }
    
    public void removeAll() {
        if (this.getItems() != null) {
            for (int i = this.getItems().size() - 1; i >= 0; --i) {
                this.b(i);
            }
        }
    }
    
    public void c(final a a) {
        int index = -1;
        for (int i = 0; i < this.getItems().size(); ++i) {
            if (this.getItems().get(i) == a) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            index = this.getItems().indexOf((Object)a);
        }
        if (index >= 0) {
            this.b(index);
        }
    }
    
    public void b(final int n) {
        final GridPane gridPane = (GridPane)this.getChildren().get(n);
        final Hyperlink hyperlink = (Hyperlink)gridPane.getChildren().get(1);
        final Label label = (Label)gridPane.getChildren().get(3);
        final Label label2 = (Label)gridPane.getChildren().get(5);
        final Label label3 = (Label)gridPane.getChildren().get(8);
        final Label label4 = (Label)gridPane.getChildren().get(10);
        final Hyperlink hyperlink2 = (Hyperlink)gridPane.getChildren().get(12);
        this.getChildren().remove(n);
        if (!"\u9700\u8981\u767b\u5f55".equals(((a)this.getItems().get(n)).getTaskState())) {
            ((a)this.getItems().get(n)).setTaskState("\u7b49\u5f85\u8fd0\u884c");
            javafx.a.d.b(r.class, ((a)this.getItems().get(n)).getAccount());
        }
        this.getItems().remove(n);
        this.checkedProperty().set(this.checkedProperty().get() - 1);
        if (n == this.a()) {
            this.a(Integer.valueOf(-1));
        }
        hyperlink.textProperty().unbind();
        label.textProperty().unbind();
        label2.textProperty().unbind();
        label4.textProperty().unbind();
        label3.textProperty().unbind();
        hyperlink2.textProperty().unbind();
    }
    
    private boolean d(final a a) {
        if ("\u9700\u8981\u767b\u5f55".equals(a.getTaskState())) {
            return true;
        }
        if (p.a((Object)a.getFromStation())) {
            Tooltips.show(this.getScene().getWindow(), "\u8bf7\u9009\u62e9\u51fa\u53d1\u5730!");
            return false;
        }
        if (p.a((Object)a.getToStation())) {
            Tooltips.show(this.getScene().getWindow(), "\u8bf7\u9009\u62e9\u76ee\u7684\u5730!");
            return false;
        }
        if (p.a((Object)a.getTrainDate())) {
            Tooltips.show(this.getScene().getWindow(), "\u8bf7\u9009\u62e9\u51fa\u53d1\u65e5\u671f\uff01");
            return false;
        }
        if (p.a((Object)a.getRiders())) {
            Tooltips.show(this.getScene().getWindow(), "\u8bf7\u9009\u62e9\u4e58\u8f66\u4eba\uff01");
            return false;
        }
        if (a.getTrainLimit()) {
            if (a.getTrainList().isEmpty() && a.getSeatTypeList().isEmpty()) {
                Tooltips.show(this.getScene().getWindow(), "\u8f66\u6b21\u548c\u5e2d\u522b\u81f3\u5c11\u9009\u62e9\u4e00\u9879\uff01");
                return false;
            }
        }
        else if (a.getSeatTypeList().isEmpty()) {
            Tooltips.show(this.getScene().getWindow(), "\u8bf7\u9009\u62e9\u5e2d\u522b\uff01");
            return false;
        }
        return true;
    }
}
