// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import javafx.beans.value.ObservableValue;
import javafx.scene.input.MouseEvent;
import javafx.control.bean.SelectedProperty;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.util.Iterator;
import javafx.scene.control.ComboBox;
import javafx.scene.Node;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import net.tec.kyfw.util.o;
import javafx.scene.layout.GridPane;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.control.Provider;
import javafx.beans.property.IntegerProperty;
import javafx.collections.ObservableList;
import javafx.beans.property.ObjectProperty;
import net.tec.kyfw.d.d;
import javafx.control.Cascade;
import javafx.scene.layout.VBox;

public class G extends VBox implements Cascade<d>
{
    private ObjectProperty<ObservableList<d>> a;
    private IntegerProperty b;
    private IntegerProperty c;
    private VBox d;
    private ObservableList<String> e;
    private String f;
    private Provider<d> g;
    
    public G() {
        this.a = (ObjectProperty<ObservableList<d>>)new SimpleObjectProperty((Object)this, "items", (Object)FXCollections.observableArrayList());
        this.b = (IntegerProperty)new SimpleIntegerProperty((Object)this, "checked", 0);
        this.c = (IntegerProperty)new SimpleIntegerProperty((Object)this, "maxSize", 0);
        this.e = null;
        this.f = null;
        try {
            this.getChildren().add((Object)new FXMLLoader(o.c("/res/fxml/buy_template_title.fxml")).load());
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        (this.d = new VBox()).setPrefHeight(136.0);
        this.getChildren().add((Object)this.d);
    }
    
    public void a(final ObservableList<String> e) {
        this.e = e;
    }
    
    public void a(final String s) {
        this.f = s;
        for (final Node node : this.d.lookupAll(".cell-seatType")) {
            if (node instanceof ComboBox) {
                ((ComboBox)node).setValue((Object)s);
            }
        }
    }
    
    public void a(final d d) {
        if (this.b() > 0 && this.a() >= this.b()) {
            return;
        }
        try {
            final GridPane gridPane = (GridPane)new FXMLLoader(o.c("/res/fxml/buy_template_row.fxml")).load();
            this.getItems().add((Object)d);
            this.checkedProperty().set(this.checkedProperty().get() + 1);
            this.a(gridPane, d);
            if (!d.isCopy() && d.getChildren() > 0) {
                final int index = this.getItems().indexOf((Object)d);
                for (int i = 0; i < d.getChildren(); ++i) {
                    final d d2 = (d)d.deepClone();
                    d2.setPassengerType("\u513f\u7ae5");
                    this.a(index + 1, d2);
                }
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void a(final int n, final d d) {
        if (this.b() > 0 && this.a() >= this.b()) {
            return;
        }
        try {
            final GridPane gridPane = (GridPane)new FXMLLoader(o.c("/res/fxml/buy_template_row.fxml")).load();
            this.getItems().add(n, (Object)d);
            this.checkedProperty().set(this.checkedProperty().get() + 1);
            this.a(gridPane, d);
            if (!d.isCopy() && d.getChildren() > 0) {
                final int index = this.getItems().indexOf((Object)d);
                for (int i = 0; i < d.getChildren(); ++i) {
                    final d d2 = (d)d.deepClone();
                    d2.setPassengerType("\u513f\u7ae5");
                    this.a(index + 1, d2);
                }
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void b(final d d) {
        int index = -1;
        for (int i = 0; i < this.getItems().size(); ++i) {
            if (this.getItems().get(i) == d) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            index = this.getItems().indexOf((Object)d);
        }
        if (index >= 0) {
            this.a(index);
        }
    }
    
    public void a(final int n) {
        final d d = (d)this.getItems().get(n);
        if (!d.isCopy()) {
            d.setChecked(false);
        }
        else {
            d.getParent().subtractChildren();
        }
        if (!d.isCopy() && d.getChildren() > 0) {
            for (int i = this.getItems().size() - 1; i > -1; --i) {
                if (((d)this.getItems().get(i)).isEquals(d.getItemValue())) {
                    this.d.getChildren().remove(i);
                    this.getItems().remove(i);
                    this.checkedProperty().set(this.checkedProperty().get() - 1);
                }
            }
        }
        else {
            this.d.getChildren().remove(n);
            this.getItems().remove(n);
            this.checkedProperty().set(this.checkedProperty().get() - 1);
        }
    }
    
    public void removeAll() {
        this.getItems().clear();
        this.d.getChildren().clear();
        this.b.set(0);
    }
    
    private void a(final GridPane gridPane, final d d) {
        this.d.getChildren().add((Object)gridPane);
        final ComboBox comboBox = (ComboBox)gridPane.getChildren().get(0);
        final TextField textField = (TextField)gridPane.getChildren().get(1);
        final ComboBox comboBox2 = (ComboBox)gridPane.getChildren().get(2);
        final TextField textField2 = (TextField)gridPane.getChildren().get(3);
        final TextField textField3 = (TextField)gridPane.getChildren().get(4);
        final TextField textField4 = (TextField)gridPane.getChildren().get(5);
        final Label label = (Label)gridPane.getChildren().get(6);
        final Label label2 = (Label)gridPane.getChildren().get(7);
        comboBox.setItems((ObservableList)this.e);
        comboBox.valueProperty().addListener((observableValue, s, s2) -> {
            final int index = this.d.getChildren().indexOf((Object)comboBox.getParent());
            if (index != -1) {
                ((d)this.getItems().get(index)).setSeatType((String)comboBox.getValue());
            }
        });
        comboBox.setValue((Object)this.f);
        textField.setText(d.getName());
        textField2.setText(d.getCardType());
        textField3.setText(d.getCardCode());
        textField4.setText(d.getMobileNo());
        if (d.isCopy()) {
            comboBox2.getItems().clear();
            comboBox2.getItems().add((Object)(d.getPassengerType() + "\u7968"));
            label.setVisible(false);
        }
        else {
            label.setOnMouseClicked(mouseEvent -> {
                if (this.b() > 0 && this.a() >= this.b()) {
                    return;
                }
                final int index = this.d.getChildren().indexOf((Object)label.getParent());
                final d d = (d)this.getItems().get(index);
                final d d2 = (d)d.deepClone();
                d2.setPassengerType("\u513f\u7ae5");
                d.addChildren();
                this.a(index + 1, d2);
            });
        }
        comboBox2.setValue((Object)(d.getPassengerType() + "\u7968"));
        label2.setOnMouseClicked(mouseEvent -> this.a(this.d.getChildren().indexOf((Object)label.getParent())));
    }
    
    public ObservableList<d> getItems() {
        return (ObservableList<d>)this.a.get();
    }
    
    public IntegerProperty checkedProperty() {
        return this.b;
    }
    
    public int a() {
        return this.checkedProperty().get();
    }
    
    public IntegerProperty maxSizeProperty() {
        return this.c;
    }
    
    public int b() {
        return this.c.get();
    }
    
    public void b(final int n) {
        this.c.set(n);
    }
    
    public void setProvider(final Provider<d> g) {
        this.g = g;
    }
}
