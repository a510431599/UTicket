// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.Color;
import net.tec.kyfw.a.l;
import java.io.InputStream;
import javax.imageio.ImageIO;
import java.io.ByteArrayInputStream;
import javafx.beans.value.ObservableValue;
import java.util.function.Predicate;
import javafx.collections.ObservableMap;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.layout.ColumnConstraints;
import javafx.geometry.VPos;
import javafx.scene.layout.RowConstraints;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.beans.value.ChangeListener;
import javafx.scene.image.Image;
import javafx.concurrent.Service;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.PopupControl;

class F implements Runnable
{
    final /* synthetic */ s a;
    
    F(final s a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        this.a.p.fire();
    }
}
