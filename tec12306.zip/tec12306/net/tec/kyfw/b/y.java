// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.b;

import java.awt.Color;
import net.tec.kyfw.a.l;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.function.Predicate;
import javafx.collections.ObservableMap;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.scene.Parent;
import javafx.scene.Node;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.layout.ColumnConstraints;
import javafx.geometry.VPos;
import javafx.scene.layout.RowConstraints;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.concurrent.Service;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.PopupControl;
import net.tec.kyfw.util.o;
import java.io.IOException;
import java.io.OutputStream;
import java.awt.image.RenderedImage;
import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;
import java.awt.image.BufferedImage;
import javafx.embed.swing.SwingFXUtils;
import javafx.beans.value.ObservableValue;
import javafx.scene.image.Image;
import javafx.beans.value.ChangeListener;

class y implements ChangeListener<Image>
{
    final /* synthetic */ s a;
    
    y(final s a) {
        this.a = a;
    }
    
    public void a(final ObservableValue<? extends Image> observableValue, final Image image, final Image image2) {
        if (image2 != null && image2.getHeight() == 190.0 && image2.getWidth() == 293.0) {
            final BufferedImage fromFXImage = SwingFXUtils.fromFXImage(image2, (BufferedImage)null);
            if (fromFXImage != null) {
                final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] byteArray = null;
                try {
                    ImageIO.write(fromFXImage, "png", byteArrayOutputStream);
                    byteArray = byteArrayOutputStream.toByteArray();
                }
                catch (IOException ex) {}
                finally {
                    try {
                        byteArrayOutputStream.close();
                    }
                    catch (IOException ex2) {}
                }
                if (byteArray != null) {
                    if (this.a.a(byteArray)) {
                        if (!this.a.j.getChildren().contains((Object)this.a.k)) {
                            this.a.z = 2;
                            this.a.A = 4;
                            this.a.j.getChildren().remove((Object)this.a.l);
                            this.a.j.getChildren().add((Object)this.a.k);
                            this.a.d();
                        }
                    }
                    else if (!this.a.j.getChildren().contains((Object)this.a.l)) {
                        this.a.z = 3;
                        this.a.A = 6;
                        this.a.j.getChildren().remove((Object)this.a.k);
                        this.a.j.getChildren().add((Object)this.a.l);
                        this.a.d();
                    }
                    this.a.w = o.a(byteArray);
                }
            }
        }
    }
}
