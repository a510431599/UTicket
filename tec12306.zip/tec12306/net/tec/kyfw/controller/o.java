// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.event.Event;
import java.io.File;
import net.tec.kyfw.util.p;
import java.util.List;
import java.util.ArrayList;
import javafx.stage.FileChooser;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class O implements EventHandler<ActionEvent>
{
    final /* synthetic */ SettingController a;
    
    O(final SettingController a) {
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        if (this.a.a == null) {
            this.a.a = new FileChooser();
            final ArrayList<String> list = new ArrayList<String>();
            list.add("*.wav");
            list.add("*.mp3");
            this.a.a.getExtensionFilters().add((Object)new FileChooser.ExtensionFilter("\u5a92\u4f53\u6587\u4ef6(*.wav, *.mp3)", (List)list));
        }
        if (p.b((Object)this.a.music.getText())) {
            final File initialDirectory = new File(this.a.music.getText().substring(0, this.a.music.getText().lastIndexOf("\\")));
            if (initialDirectory.exists() && initialDirectory.isDirectory()) {
                this.a.a.setInitialDirectory(initialDirectory);
            }
        }
        final File showOpenDialog = this.a.a.showOpenDialog(this.a.chooser.getScene().getWindow());
        if (showOpenDialog != null) {
            this.a.music.setText(showOpenDialog.getPath());
        }
    }
}
