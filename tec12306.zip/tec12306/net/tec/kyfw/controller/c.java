// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.event.Event;
import net.tec.kyfw.d.d;
import javafx.scene.control.TableCell;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;

class C implements EventHandler<MouseEvent>
{
    final /* synthetic */ TableCell a;
    final /* synthetic */ PassengerController b;
    
    C(final PassengerController b, final TableCell a) {
        this.b = b;
        this.a = a;
    }
    
    public void a(final MouseEvent mouseEvent) {
        if (!this.a.isEmpty()) {
            if (((d)this.a.getTableRow().getItem()).getCheckState().equals("\u5df2\u901a\u8fc7")) {
                this.a.setEditable(false);
            }
            else {
                this.a.setEditable(true);
            }
        }
    }
}
