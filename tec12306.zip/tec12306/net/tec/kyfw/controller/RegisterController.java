// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.util.j;
import javafx.controller.a;
import javafx.control.dialog.Dialogs;
import net.tec.kyfw.util.p;
import javafx.event.ActionEvent;
import net.tec.kyfw.util.i;
import javafx.scene.input.MouseEvent;
import javafx.scene.Node;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import net.tec.kyfw.util.f;
import net.tec.kyfw.util.o;
import javafx.scene.control.Label;
import javafx.control.field.AbstractTextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import org.apache.log4j.Logger;
import javafx.controller.AbstractController;

public class RegisterController extends AbstractController
{
    static Logger a;
    @FXML
    protected StackPane root;
    @FXML
    protected Button okBtn;
    @FXML
    protected Button cancelBtn;
    @FXML
    protected TextField computerNo;
    @FXML
    protected AbstractTextArea cdkey;
    @FXML
    protected Label deadline;
    @FXML
    protected Label email;
    @FXML
    protected Label qq;
    
    @Override
    public void initialize() {
        this.okBtn.setOnAction(actionEvent -> {
            if (p.b((Object)this.cdkey.getText())) {
                if (!f.a(this.cdkey.getText().trim(), true)) {
                    Dialogs.create().owner(this.okBtn.getParent().getScene().getWindow()).message("\u6388\u6743\u7801\u4e0d\u6b63\u786e\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165\uff01").alert();
                    return;
                }
                javafx.controller.a.a(MainController.class).register.setText("\u5df2\u6388\u6743");
            }
            this.getStage().hide();
        });
        this.cancelBtn.setOnAction(actionEvent -> this.getStage().hide());
        this.computerNo.setText(o.a());
        if (f.b()) {
            this.cdkey.setText(f.b);
            this.deadline.setText((f.a == 1L) ? "\u6c38\u4e45\u6388\u6743" : LocalDate.ofEpochDay(f.a).format(DateTimeFormatter.ofPattern("yyyy\u5e74MM\u6708dd\u65e5")));
        }
        else {
            this.deadline.setText("\u672a\u6ce8\u518c");
        }
        this.email.setOnMouseClicked(mouseEvent -> i.e.a("mailto:team12306@163.com"));
        this.qq.setOnMouseClicked(mouseEvent -> i.e.a("http://jq.qq.com/?_wv=1027&k=fVnP0o"));
    }
    
    @Override
    public void afterPropertySet() {
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    static {
        RegisterController.a = j.a(RegisterController.class);
    }
}
