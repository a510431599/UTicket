// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.util.i;
import javafx.scene.input.MouseEvent;
import net.tec.kyfw.util.p;
import javafx.scene.Node;
import javafx.scene.control.Tooltip;
import javafx.beans.value.ObservableValue;
import javafx.a.a;
import javafx.a.d;
import net.tec.kyfw.e.f;
import net.tec.kyfw.b.O;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import org.apache.log4j.Logger;
import javafx.controller.AbstractController;

public class BottomController extends AbstractController
{
    static Logger a;
    @FXML
    public StackPane root;
    @FXML
    public StackPane loginState;
    @FXML
    public Label userName;
    @FXML
    public Label time;
    @FXML
    public StackPane tipArea;
    @FXML
    public Label dateSync;
    public O b;
    f c;
    
    public BottomController() {
        this.b = new O();
        this.c = null;
    }
    
    @Override
    public void initialize() {
        this.c = d.a((Class<? extends a<Object>>)f.class);
        this.time.textProperty().bind((ObservableValue)this.c.valueProperty());
        this.userName.setOnMouseClicked(mouseEvent -> i.e.a(net.tec.kyfw.f.b(), "https://kyfw.12306.cn/otn/index/initMy12306"));
        this.tipArea.getChildren().add((Object)this.b);
        this.a();
        this.dateSync.setTooltip(new Tooltip("\u540c\u6b65\u65f6\u95f4"));
        this.dateSync.setOnMouseClicked(mouseEvent -> new Thread((Runnable)new g(this)).start());
    }
    
    @Override
    public void afterPropertySet() {
        this.c.start();
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    private void a() {
        new Thread((Runnable)new j(this)).start();
    }
    
    public void a(final String text) {
        if (p.a((Object)text)) {
            this.loginState.getStyleClass().remove((Object)"online");
            this.loginState.getStyleClass().add((Object)"offline");
            this.userName.setText("\u672a\u767b\u5f55");
        }
        else {
            this.loginState.getStyleClass().remove((Object)"offline");
            this.loginState.getStyleClass().add((Object)"online");
            this.userName.setText(text);
        }
    }
    
    static {
        BottomController.a = net.tec.kyfw.util.j.a(BottomController.class);
    }
}
