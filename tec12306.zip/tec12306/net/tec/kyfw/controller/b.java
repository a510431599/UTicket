// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.util.j;
import java.util.Iterator;
import net.tec.kyfw.util.p;
import net.tec.kyfw.util.q;
import net.tec.kyfw.util.o;
import javafx.stage.Window;
import javafx.event.ActionEvent;
import net.tec.kyfw.e;
import javafx.beans.value.ObservableValue;
import javafx.application.Platform;
import java.io.File;
import java.util.List;
import javafx.a.a;
import net.tec.kyfw.e.l;
import net.tec.kyfw.f;
import javafx.event.EventHandler;
import javafx.scene.control.TableColumn;
import javafx.scene.Node;
import javafx.scene.text.Text;
import javafx.geometry.Pos;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.ChoiceBoxTableCell;
import javafx.scene.control.TableCell;
import javafx.util.StringConverter;
import javafx.scene.control.cell.TextFieldTableCell;
import java.util.ArrayList;
import javafx.stage.FileChooser;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.control.field.AbstractTextField;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import org.apache.log4j.Logger;
import javafx.controller.AbstractController;
import java.lang.reflect.Method;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.c.h;
import javafx.control.pane.TablePane;
import net.tec.kyfw.d.d;
import javafx.concurrent.Task;

class B extends Task<Void>
{
    final /* synthetic */ d a;
    final /* synthetic */ String b;
    final /* synthetic */ String c;
    final /* synthetic */ TablePane d;
    final /* synthetic */ int e;
    final /* synthetic */ String f;
    final /* synthetic */ PassengerController g;
    
    B(final PassengerController g, final d a, final String b, final String c, final TablePane d, final int e, final String f) {
        this.g = g;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    protected Void a() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: new             Ljava/util/HashMap;
        //     3: dup            
        //     4: invokespecial   java/util/HashMap.<init>:()V
        //     7: astore_1       
        //     8: aload_1        
        //     9: ldc             "passenger_name"
        //    11: aload_0        
        //    12: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //    15: invokevirtual   net/tec/kyfw/d/d.getName:()Ljava/lang/String;
        //    18: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    23: pop            
        //    24: aload_1        
        //    25: ldc             "passenger_id_type_code"
        //    27: aload_0        
        //    28: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //    31: invokevirtual   net/tec/kyfw/d/d.getCardType:()Ljava/lang/String;
        //    34: invokestatic    net/tec/kyfw/d/d$a.getValue:(Ljava/lang/String;)Ljava/lang/String;
        //    37: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    42: pop            
        //    43: aload_1        
        //    44: ldc             "passenger_id_no"
        //    46: aload_0        
        //    47: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //    50: invokevirtual   net/tec/kyfw/d/d.getCardCode:()Ljava/lang/String;
        //    53: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    58: pop            
        //    59: aload_1        
        //    60: ldc             "old_passenger_name"
        //    62: aload_0        
        //    63: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //    66: invokevirtual   net/tec/kyfw/d/d.getName:()Ljava/lang/String;
        //    69: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    74: pop            
        //    75: aload_1        
        //    76: ldc             "old_passenger_id_type_code"
        //    78: aload_0        
        //    79: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //    82: invokevirtual   net/tec/kyfw/d/d.getCardType:()Ljava/lang/String;
        //    85: invokestatic    net/tec/kyfw/d/d$a.getValue:(Ljava/lang/String;)Ljava/lang/String;
        //    88: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //    93: pop            
        //    94: aload_1        
        //    95: ldc             "old_passenger_id_no"
        //    97: aload_0        
        //    98: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   101: invokevirtual   net/tec/kyfw/d/d.getCardCode:()Ljava/lang/String;
        //   104: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   109: pop            
        //   110: aload_1        
        //   111: ldc             "mobile_no"
        //   113: aload_0        
        //   114: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   117: invokevirtual   net/tec/kyfw/d/d.getMobileNo:()Ljava/lang/String;
        //   120: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   125: pop            
        //   126: aload_1        
        //   127: ldc             "passenger_type"
        //   129: aload_0        
        //   130: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   133: invokevirtual   net/tec/kyfw/d/d.getPassengerType:()Ljava/lang/String;
        //   136: invokestatic    net/tec/kyfw/d/d$a.getValue:(Ljava/lang/String;)Ljava/lang/String;
        //   139: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   144: pop            
        //   145: aload_0        
        //   146: getfield        net/tec/kyfw/controller/B.b:Ljava/lang/String;
        //   149: ldc             "name"
        //   151: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   154: ifeq            173
        //   157: aload_1        
        //   158: ldc             "passenger_name"
        //   160: aload_0        
        //   161: getfield        net/tec/kyfw/controller/B.c:Ljava/lang/String;
        //   164: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   169: pop            
        //   170: goto            286
        //   173: aload_0        
        //   174: getfield        net/tec/kyfw/controller/B.b:Ljava/lang/String;
        //   177: ldc             "cardCode"
        //   179: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   182: ifeq            230
        //   185: aload_1        
        //   186: ldc             "passenger_id_no"
        //   188: aload_0        
        //   189: getfield        net/tec/kyfw/controller/B.c:Ljava/lang/String;
        //   192: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   197: pop            
        //   198: aload_0        
        //   199: getfield        net/tec/kyfw/controller/B.g:Lnet/tec/kyfw/controller/PassengerController;
        //   202: invokestatic    net/tec/kyfw/controller/PassengerController.a:(Lnet/tec/kyfw/controller/PassengerController;)Ljava/lang/String;
        //   205: ifnull          286
        //   208: aload_1        
        //   209: ldc             "old_passenger_id_type_code"
        //   211: aload_0        
        //   212: getfield        net/tec/kyfw/controller/B.g:Lnet/tec/kyfw/controller/PassengerController;
        //   215: invokestatic    net/tec/kyfw/controller/PassengerController.a:(Lnet/tec/kyfw/controller/PassengerController;)Ljava/lang/String;
        //   218: invokestatic    net/tec/kyfw/d/d$a.getValue:(Ljava/lang/String;)Ljava/lang/String;
        //   221: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   226: pop            
        //   227: goto            286
        //   230: aload_0        
        //   231: getfield        net/tec/kyfw/controller/B.b:Ljava/lang/String;
        //   234: ldc             "mobileNo"
        //   236: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   239: ifeq            258
        //   242: aload_1        
        //   243: ldc             "mobile_no"
        //   245: aload_0        
        //   246: getfield        net/tec/kyfw/controller/B.c:Ljava/lang/String;
        //   249: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   254: pop            
        //   255: goto            286
        //   258: aload_0        
        //   259: getfield        net/tec/kyfw/controller/B.b:Ljava/lang/String;
        //   262: ldc             "passengerType"
        //   264: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   267: ifeq            286
        //   270: aload_1        
        //   271: ldc             "passenger_type"
        //   273: aload_0        
        //   274: getfield        net/tec/kyfw/controller/B.c:Ljava/lang/String;
        //   277: invokestatic    net/tec/kyfw/d/d$a.getValue:(Ljava/lang/String;)Ljava/lang/String;
        //   280: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   285: pop            
        //   286: aload_1        
        //   287: ldc             "sex_code"
        //   289: aload_0        
        //   290: getfield        net/tec/kyfw/controller/B.g:Lnet/tec/kyfw/controller/PassengerController;
        //   293: aload_0        
        //   294: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   297: invokevirtual   net/tec/kyfw/d/d.getCardCode:()Ljava/lang/String;
        //   300: invokestatic    net/tec/kyfw/controller/PassengerController.a:(Lnet/tec/kyfw/controller/PassengerController;Ljava/lang/String;)Ljava/lang/String;
        //   303: invokeinterface java/util/Map.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   308: pop            
        //   309: aload_0        
        //   310: getfield        net/tec/kyfw/controller/B.g:Lnet/tec/kyfw/controller/PassengerController;
        //   313: getfield        net/tec/kyfw/controller/PassengerController.account:Ljavafx/scene/control/ComboBox;
        //   316: invokevirtual   javafx/scene/control/ComboBox.getValue:()Ljava/lang/Object;
        //   319: checkcast       Ljava/lang/String;
        //   322: invokestatic    net/tec/kyfw/f.a:(Ljava/lang/String;)Lnet/tec/kyfw/f;
        //   325: aload_1        
        //   326: iconst_1       
        //   327: invokestatic    net/tec/kyfw/c/g.a:(Lnet/tec/kyfw/f;Ljava/util/Map;I)Lnet/tec/kyfw/c/h;
        //   330: astore_2       
        //   331: aload_2        
        //   332: invokevirtual   net/tec/kyfw/c/h.b:()Ljava/lang/Boolean;
        //   335: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   338: ifeq            463
        //   341: aload_0        
        //   342: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   345: aload_0        
        //   346: getfield        net/tec/kyfw/controller/B.b:Ljava/lang/String;
        //   349: invokevirtual   net/tec/kyfw/d/d.getMethod:(Ljava/lang/String;)Ljava/lang/reflect/Method;
        //   352: astore_3       
        //   353: aload_3        
        //   354: aload_0        
        //   355: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   358: iconst_1       
        //   359: anewarray       Ljava/lang/Object;
        //   362: dup            
        //   363: iconst_0       
        //   364: aload_0        
        //   365: getfield        net/tec/kyfw/controller/B.c:Ljava/lang/String;
        //   368: aastore        
        //   369: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //   372: pop            
        //   373: goto            383
        //   376: astore          4
        //   378: aload           4
        //   380: invokevirtual   java/lang/Exception.printStackTrace:()V
        //   383: aload_0        
        //   384: getfield        net/tec/kyfw/controller/B.b:Ljava/lang/String;
        //   387: ldc             "passengerType"
        //   389: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   392: ifeq            422
        //   395: aload_0        
        //   396: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   399: invokevirtual   net/tec/kyfw/d/d.getPassengerType:()Ljava/lang/String;
        //   402: getstatic       net/tec/kyfw/d/d$a.CHILD:Lnet/tec/kyfw/d/d$a;
        //   405: invokevirtual   net/tec/kyfw/d/d$a.getName:()Ljava/lang/String;
        //   408: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   411: ifeq            422
        //   414: aload_0        
        //   415: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   418: iconst_0       
        //   419: invokevirtual   net/tec/kyfw/d/d.setChildren:(I)V
        //   422: aload_0        
        //   423: getfield        net/tec/kyfw/controller/B.d:Ljavafx/control/pane/TablePane;
        //   426: aload_0        
        //   427: getfield        net/tec/kyfw/controller/B.e:I
        //   430: aload_0        
        //   431: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   434: invokedynamic   run:(Ljavafx/control/pane/TablePane;ILnet/tec/kyfw/d/d;)Ljava/lang/Runnable;
        //   439: invokestatic    javafx/application/Platform.runLater:(Ljava/lang/Runnable;)V
        //   442: aload_0        
        //   443: getfield        net/tec/kyfw/controller/B.g:Lnet/tec/kyfw/controller/PassengerController;
        //   446: aconst_null    
        //   447: invokestatic    net/tec/kyfw/controller/PassengerController.b:(Lnet/tec/kyfw/controller/PassengerController;Ljava/lang/String;)Ljava/lang/String;
        //   450: pop            
        //   451: aload_0        
        //   452: getfield        net/tec/kyfw/controller/B.g:Lnet/tec/kyfw/controller/PassengerController;
        //   455: aconst_null    
        //   456: invokestatic    net/tec/kyfw/controller/PassengerController.a:(Lnet/tec/kyfw/controller/PassengerController;Ljava/lang/Integer;)Ljava/lang/Integer;
        //   459: pop            
        //   460: goto            493
        //   463: aload_0        
        //   464: aload_0        
        //   465: getfield        net/tec/kyfw/controller/B.a:Lnet/tec/kyfw/d/d;
        //   468: aload_0        
        //   469: getfield        net/tec/kyfw/controller/B.b:Ljava/lang/String;
        //   472: aload_0        
        //   473: getfield        net/tec/kyfw/controller/B.f:Ljava/lang/String;
        //   476: aload_0        
        //   477: getfield        net/tec/kyfw/controller/B.d:Ljavafx/control/pane/TablePane;
        //   480: aload_0        
        //   481: getfield        net/tec/kyfw/controller/B.e:I
        //   484: aload_2        
        //   485: invokedynamic   run:(Lnet/tec/kyfw/controller/B;Lnet/tec/kyfw/d/d;Ljava/lang/String;Ljava/lang/String;Ljavafx/control/pane/TablePane;ILnet/tec/kyfw/c/h;)Ljava/lang/Runnable;
        //   490: invokestatic    javafx/application/Platform.runLater:(Ljava/lang/Runnable;)V
        //   493: aconst_null    
        //   494: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  353    373    376    383    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:757)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:655)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:532)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:499)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:141)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:130)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:105)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:317)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:238)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:123)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
