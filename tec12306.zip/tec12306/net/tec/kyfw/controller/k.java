// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.application.Platform;
import net.tec.kyfw.a.a;
import javafx.concurrent.Task;

class K extends Task<Void>
{
    final /* synthetic */ SettingController a;
    
    K(final SettingController a) {
        this.a = a;
    }
    
    protected Void a() {
        Platform.runLater(() -> this.a.dmBalance.setText(String.valueOf(net.tec.kyfw.a.a.c())));
        return null;
    }
}
