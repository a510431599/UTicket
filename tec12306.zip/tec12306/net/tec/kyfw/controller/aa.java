// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import java.time.temporal.TemporalAccessor;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import javafx.util.StringConverter;

class aa extends StringConverter<LocalDate>
{
    DateTimeFormatter a;
    final /* synthetic */ TicketController b;
    
    aa(final TicketController b) {
        this.b = b;
        this.a = DateTimeFormatter.ofPattern(this.b.trainDate.getPromptText());
    }
    
    public String a(final LocalDate localDate) {
        if (localDate != null) {
            return this.a.format(localDate);
        }
        return "";
    }
    
    public LocalDate a(final String s) {
        if (s != null && !s.isEmpty()) {
            return LocalDate.parse(s, this.a);
        }
        return null;
    }
}
