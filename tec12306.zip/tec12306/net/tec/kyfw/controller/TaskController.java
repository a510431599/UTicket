// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.scene.input.MouseEvent;
import javafx.event.Event;
import javafx.control.bean.SelectedProperty;
import net.tec.kyfw.util.p;
import javafx.event.ActionEvent;
import javafx.application.Platform;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import javafx.control.dialog.Dialogs;
import net.tec.kyfw.util.o;
import java.time.LocalTime;
import net.tec.kyfw.e.b;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import javafx.scene.Node;
import javafx.scene.control.Tooltip;
import javafx.collections.ObservableList;
import java.util.Collection;
import javafx.collections.FXCollections;
import net.tec.kyfw.util.r;
import javafx.collections.ListChangeListener;
import javafx.control.Cascade;
import javafx.util.StringConverter;
import javafx.util.Callback;
import net.tec.kyfw.util.DateUtil;
import javafx.beans.value.ObservableValue;
import javafx.controller.a;
import javafx.stage.FileChooser;
import net.tec.kyfw.b.N;
import javafx.control.pane.ScrollContainer;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;
import net.tec.kyfw.d.d;
import javafx.control.pane.CheckBoxArea;
import javafx.control.pane.TagBox;
import net.tec.kyfw.d.j;
import net.tec.kyfw.d.e;
import javafx.control.combo.MultipleComboBox;
import javafx.control.field.SpinnerTimeField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import net.tec.kyfw.d.g;
import javafx.control.pane.TablePane;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import net.tec.kyfw.d.f;
import javafx.control.combo.CompleteComboBox;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;

public class TaskController extends AbstractController
{
    @FXML
    public StackPane root;
    @FXML
    public CompleteComboBox<f> fromStation;
    @FXML
    public CompleteComboBox<f> toStation;
    @FXML
    public Label ticketExchange;
    @FXML
    public DatePicker trainDate;
    @FXML
    public TablePane<g> trainTable;
    @FXML
    public ComboBox<String> startTime;
    @FXML
    public ComboBox<String> endTime;
    @FXML
    public ComboBox<String> priorOption;
    @FXML
    public CheckBox submitOption;
    @FXML
    public CheckBox timingRef;
    @FXML
    public CheckBox trainLimit;
    @FXML
    public SpinnerTimeField spinner;
    @FXML
    public MultipleComboBox<g> priorTrain;
    @FXML
    public MultipleComboBox<e> priorSeat;
    @FXML
    public MultipleComboBox<j> priorDates;
    @FXML
    public MultipleComboBox<g> blackTrain;
    @FXML
    public TagBox<g> trainShow;
    @FXML
    public TagBox<e> seatShow;
    @FXML
    public TagBox<j> datesShow;
    @FXML
    public TagBox<g> blackShow;
    @FXML
    public CheckBoxArea<d> linkmanPane;
    @FXML
    public TagBox<d> chooseLinkman;
    @FXML
    public Button myLinkmans;
    @FXML
    public TextArea logarea;
    @FXML
    public Button buttonAdd;
    @FXML
    public Button buttonImp;
    @FXML
    public Button buttonExp;
    @FXML
    public Button buttonStop;
    @FXML
    public Button buttonClear;
    @FXML
    public ScrollContainer taskArea;
    public N a;
    private Boolean c;
    public FileChooser b;
    private String d;
    
    public TaskController() {
        this.c = Boolean.FALSE;
        this.d = "";
    }
    
    @Override
    public void initialize() {
        final TicketController ticketController = javafx.controller.a.a(TicketController.class);
        this.fromStation.optionsProperty().bind((ObservableValue)ticketController.fromStation.optionsProperty());
        this.toStation.optionsProperty().bind((ObservableValue)ticketController.toStation.optionsProperty());
        this.ticketExchange.setOnMouseClicked(mouseEvent -> {
            final f completeValue = (f)this.fromStation.getValue();
            this.fromStation.setCompleteValue((f)this.toStation.getValue());
            this.toStation.setCompleteValue(completeValue);
        });
        this.trainDate.setValue((Object)DateUtil.b().toLocalDate());
        this.trainDate.setEditable(false);
        this.trainDate.setDayCellFactory((Callback)new Q(this));
        this.trainDate.setConverter((StringConverter)new S(this));
        this.trainDate.getEditor().setOnMouseClicked(mouseEvent -> this.trainDate.show());
        this.priorTrain.bind(this.trainShow);
        this.trainShow.getItems().addListener((ListChangeListener)new T(this));
        this.priorSeat.bind(this.seatShow);
        this.priorSeat.setOptions((javafx.collections.ObservableList<e>)FXCollections.observableArrayList((Collection)r.a()));
        this.seatShow.getItems().addListener((ListChangeListener)new U(this));
        this.priorDates.bind(this.datesShow);
        this.priorDates.setOptions((javafx.collections.ObservableList<j>)FXCollections.observableArrayList((Collection)DateUtil.d()));
        this.datesShow.getItems().addListener((ListChangeListener)new V(this));
        this.blackTrain.bind(this.blackShow);
        this.blackShow.getItems().addListener((ListChangeListener)new W(this));
        this.fromStation.valueProperty().addListener((observableValue, f, f2) -> {
            if (this.c) {
                this.a.e().setFromStation((f2 != null) ? f2.getStationName() : null);
                this.a.e().setFromStationTelecode((f2 != null) ? f2.getStationTelecode() : null);
            }
            this.c();
        });
        this.toStation.valueProperty().addListener((observableValue, f, f2) -> {
            if (this.c) {
                this.a.e().setToStation((f2 != null) ? f2.getStationName() : null);
                this.a.e().setToStationTelecode((f2 != null) ? f2.getStationTelecode() : null);
            }
            this.c();
        });
        this.trainDate.valueProperty().addListener((observableValue, localDate, localDate2) -> {
            if (this.c) {
                this.a.e().setTrainDate((localDate2 != null) ? localDate2.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) : null);
            }
            this.c();
        });
        this.startTime.valueProperty().addListener((observableValue, s, s2) -> {
            if (this.c) {
                this.a.e().setStartTime(this.a());
            }
        });
        this.endTime.valueProperty().addListener((observableValue, s, s2) -> {
            if (this.c) {
                this.a.e().setStartTime(this.a());
            }
        });
        this.priorOption.valueProperty().addListener((observableValue, s, priorOption) -> {
            if (this.c) {
                this.a.e().setPriorOption(priorOption);
            }
        });
        this.submitOption.selectedProperty().addListener((observableValue, b, submitOption) -> {
            if (this.c) {
                this.a.e().setSubmitOption(submitOption);
            }
        });
        this.spinner.setValue(this.b());
        this.spinner.setMaxValue(this.a("22:59:59", "HH:mm:ss"));
        this.spinner.setMinValue(this.a("06:00:00", "HH:mm:ss"));
        this.timingRef.selectedProperty().addListener((observableValue, b, timingBuy) -> {
            if (this.c) {
                this.a.e().setTimingBuy(timingBuy);
                this.a.e().setTimingDate(((boolean)timingBuy) ? ((Long)this.spinner.getValue()) : 0L);
            }
            if (timingBuy) {
                final long b2 = this.b();
                if (this.spinner.getValue() < b2) {
                    this.spinner.setValue(b2);
                }
            }
        });
        this.spinner.valueProperty().addListener((observableValue, n, timingDate) -> {
            if (this.c) {
                this.a.e().setTimingDate(timingDate);
            }
        });
        this.trainLimit.selectedProperty().addListener((observableValue, b, trainLimit) -> {
            if (this.c) {
                this.a.e().setTrainLimit(trainLimit);
            }
        });
        this.priorTrain.setOnShowing(event -> this.c());
        this.linkmanPane.bind(this.chooseLinkman);
        this.chooseLinkman.setTooltip(new Tooltip("\u70b9\u51fb\u6b64\u533a\u57df\u6dfb\u52a0\u513f\u7ae5\u7968"));
        this.chooseLinkman.getItems().addListener((ListChangeListener)new X(this));
        this.spinner.disableProperty().bind((ObservableValue)this.timingRef.selectedProperty().not());
        (this.a = new N()).a(10);
        this.a.b().addListener((observableValue, n, n2) -> {
            if (n2.intValue() != -1) {
                this.c = Boolean.FALSE;
                final net.tec.kyfw.d.a e = this.a.e();
                this.fromStation.setCompleteValue(p.b((Object)e.getFromStation()) ? e.getFromStation() : null);
                this.toStation.setCompleteValue(p.b((Object)e.getToStation()) ? e.getToStation() : null);
                this.trainDate.setValue((Object)(p.b((Object)e.getTrainDate()) ? LocalDate.parse(e.getTrainDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd")) : DateUtil.b().toLocalDate()));
                if (p.b((Object)e.getStartTime())) {
                    final String[] split = e.getStartTime().split("--");
                    this.startTime.setValue((Object)split[0]);
                    this.endTime.setValue((Object)split[1]);
                }
                else {
                    this.startTime.setValue((Object)"00:00");
                    this.endTime.setValue((Object)"24:00");
                }
                this.priorOption.setValue((Object)(p.b((Object)e.getPriorOption()) ? e.getPriorOption() : "\u8f66\u6b21\u4f18\u5148"));
                this.submitOption.setSelected(e.getSubmitOption() == null || e.getSubmitOption());
                this.timingRef.setSelected(e.getTimingBuy() != null && e.getTimingBuy());
                if (this.timingRef.isSelected() && e.getTimingDate() != null && e.getTimingDate() != 0L) {
                    this.spinner.setValue(e.getTimingDate());
                }
                this.trainLimit.setSelected(e.getTrainLimit() == null || e.getTrainLimit());
                for (int i = this.trainShow.size() - 1; i >= 0; --i) {
                    this.trainShow.remove(i);
                }
                if (e.getTrainList() != null) {
                    for (int j = 0; j < e.getTrainList().size(); ++j) {
                        this.trainShow.add((g)e.getTrainList().get(j));
                    }
                }
                for (int k = this.seatShow.size() - 1; k >= 0; --k) {
                    this.seatShow.remove(k);
                }
                if (e.getSeatTypeList() != null) {
                    for (int l = 0; l < e.getSeatTypeList().size(); ++l) {
                        this.seatShow.add((e)e.getSeatTypeList().get(l));
                    }
                }
                for (int n3 = this.blackShow.size() - 1; n3 >= 0; --n3) {
                    this.blackShow.remove(n3);
                }
                if (e.getBlackList() != null) {
                    for (int n4 = 0; n4 < e.getBlackList().size(); ++n4) {
                        this.blackShow.add((g)e.getBlackList().get(n4));
                    }
                }
                for (int n5 = this.datesShow.size() - 1; n5 >= 0; --n5) {
                    this.datesShow.remove(n5);
                }
                if (e.getPriorDatesList() != null) {
                    for (int n6 = 0; n6 < e.getPriorDatesList().size(); ++n6) {
                        this.datesShow.add((j)e.getPriorDatesList().get(n6));
                    }
                }
                final ObservableList<d> list = net.tec.kyfw.e.c.get(e.getAccount());
                if (this.linkmanPane.getItems() != null) {
                    this.linkmanPane.getItems().clear();
                }
                if (list != null && !list.isEmpty()) {
                    final ObservableList observableArrayList = FXCollections.observableArrayList();
                    final ObservableList<d> passengerList = this.a.e().getPassengerList();
                    for (int n7 = 0; n7 < list.size(); ++n7) {
                        final d d = (d)((d)list.get(n7)).cloneNewInstance();
                        int children = 0;
                        for (int n8 = 0; n8 < passengerList.size(); ++n8) {
                            if (((d)passengerList.get(n8)).equals(d) && ((d)passengerList.get(n8)).isCopy()) {
                                ++children;
                            }
                        }
                        d.setChildren(children);
                        d.setChecked(passengerList.contains((Object)d));
                        observableArrayList.add((Object)d);
                    }
                    this.linkmanPane.setItems((javafx.collections.ObservableList<d>)observableArrayList);
                }
                this.myLinkmans.setDisable(false);
                this.ticketExchange.setDisable("resign".equals(e.getFlag()));
                this.linkmanPane.setDisable("resign".equals(e.getFlag()));
                this.chooseLinkman.setDisable("resign".equals(e.getFlag()));
                this.submitOption.setDisable("resign".equals(e.getFlag()));
                this.fromStation.setDisable("resign".equals(e.getFlag()));
                this.toStation.setDisable("resign".equals(e.getFlag()) && "N".equals(e.getChangeTSFlag()));
                this.c = Boolean.TRUE;
            }
            else {
                this.c = Boolean.FALSE;
                if (this.linkmanPane.getItems() != null) {
                    this.linkmanPane.setItems(null);
                    this.chooseLinkman.removeAll();
                }
                this.myLinkmans.setDisable(true);
                this.ticketExchange.setDisable(false);
                this.linkmanPane.setDisable(false);
                this.chooseLinkman.setDisable(false);
                this.submitOption.setDisable(false);
                this.fromStation.setDisable(false);
                this.toStation.setDisable(false);
            }
        });
        this.taskArea.setContent((Node)this.a);
        this.myLinkmans.setOnAction(actionEvent -> {
            final MainController mainController = javafx.controller.a.a(MainController.class);
            mainController.passengerController.account.setValue((Object)this.a.e().getAccount());
            mainController.framePane.getSelectionModel().select(3);
        });
        this.buttonAdd.setOnAction(actionEvent -> {
            if (this.a.d() == 0 || this.a.c() < this.a.d()) {
                javafx.controller.a.a(MainController.class).a.setArguments(net.tec.kyfw.f.c()).show();
            }
            else {
                Dialogs.create().owner(this.getWindow()).message("\u4ec5\u5141\u8bb8\u6dfb\u52a0" + this.a.d() + "\u4e2a\u4efb\u52a1\u3002").alert();
            }
        });
        this.buttonStop.setOnAction(actionEvent -> {
            if (this.a.getItems() != null) {
                for (int i = 0; i < this.a.getItems().size(); ++i) {
                    final net.tec.kyfw.d.a a = (net.tec.kyfw.d.a)this.a.getItems().get(i);
                    if (!"\u9700\u8981\u767b\u5f55".equals(a.getTaskState())) {
                        final net.tec.kyfw.e.r r = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)net.tec.kyfw.e.r.class, a.getAccount());
                        if (r.isRunning()) {
                            r.cancel();
                        }
                    }
                }
            }
        });
        this.buttonExp.setOnAction(actionEvent -> {
            if (this.a.getItems() != null && !this.a.getItems().isEmpty()) {
                final FileChooser e = this.e();
                e.setInitialFileName("task_" + DateUtil.a("yyyyMMdd") + ".dat");
                this.a(e.showSaveDialog(this.root.getScene().getWindow()));
            }
        });
        this.buttonImp.setOnAction(actionEvent -> this.d());
        this.buttonClear.setOnAction(actionEvent -> this.logarea.clear());
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    private void c() {
        if (this.fromStation.getValue() == null || this.toStation.getValue() == null || this.trainDate.getValue() == null) {
            return;
        }
        if (((f)this.fromStation.getValue()).equals(this.toStation.getValue())) {
            return;
        }
        final String string = ((LocalDate)this.trainDate.getValue()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "," + ((f)this.fromStation.getValue()).getStationTelecode() + "," + ((f)this.toStation.getValue()).getStationTelecode();
        if (string.equals(this.d)) {
            return;
        }
        this.d = string;
        net.tec.kyfw.e.b.a(DateUtil.a((LocalDate)this.trainDate.getValue(), "yyyy-MM-dd"), ((f)this.fromStation.getValue()).getStationName(), ((f)this.toStation.getValue()).getStationName(), this.priorTrain, this.trainShow.getItems(), this.blackTrain, this.blackShow.getItems());
    }
    
    public String a() {
        return (String)this.startTime.getValue() + "--" + (String)this.endTime.getValue();
    }
    
    public long b() {
        final int n = LocalTime.now().getHour() + 1;
        return LocalTime.of((n == 24) ? 0 : n, 0).toSecondOfDay();
    }
    
    public long a(final String s, final String s2) {
        return LocalTime.parse(s, DateTimeFormatter.ofPattern(s2)).toSecondOfDay();
    }
    
    private void d() {
        final File showOpenDialog = this.e().showOpenDialog(this.getWindow());
        if (showOpenDialog != null) {
            try {
                final List<net.tec.kyfw.d.a> stringToList = net.tec.kyfw.d.a.stringToList(new String(net.tec.kyfw.util.e.b(o.a(showOpenDialog)), "utf-8"));
                if (stringToList != null && !stringToList.isEmpty()) {
                    for (int i = 0; i < stringToList.size(); ++i) {
                        final net.tec.kyfw.d.a a = this.a.a(stringToList.get(i).getAccount());
                        if (a != null) {
                            if ("\u6b63\u5728\u8fd0\u884c".equals(a.getTaskState()) || "\u5b9a\u65f6\u5237\u65b0".equals(a.getTaskState())) {
                                this.c(stringToList.get(i).getAccount(), "\u6b64\u8d26\u53f7\u5728\u4efb\u52a1\u5217\u8868\u4e2d\u5df2\u5b58\u5728\u4e14\u6b63\u5728\u8fd0\u884c\u4e2d\uff0c\u4e0d\u5141\u8bb8\u5bfc\u5165\u3002 ");
                            }
                            else {
                                if (!net.tec.kyfw.f.b(stringToList.get(i).getAccount())) {
                                    stringToList.get(i).setTaskState("\u9700\u8981\u767b\u5f55");
                                }
                                else {
                                    stringToList.get(i).setTaskState("\u7b49\u5f85\u8fd0\u884c");
                                }
                                final int index = this.a.getItems().indexOf((Object)a);
                                this.a.c(a);
                                this.a.a(index, stringToList.get(i));
                            }
                        }
                        else if (this.a.d() == 0 || this.a.c() < this.a.d()) {
                            if (!net.tec.kyfw.f.b(stringToList.get(i).getAccount())) {
                                stringToList.get(i).setTaskState("\u9700\u8981\u767b\u5f55");
                            }
                            else {
                                stringToList.get(i).setTaskState("\u7b49\u5f85\u8fd0\u884c");
                            }
                            this.a.b(stringToList.get(i));
                        }
                        else {
                            this.c(stringToList.get(i).getAccount(), "\u5bfc\u5165\u5931\u8d25\uff0c\u4ec5\u5141\u8bb8\u6dfb\u52a0" + this.a.d() + "\u4e2a\u4efb\u52a1 " + stringToList.get(i).getTrainDate() + " " + stringToList.get(i).getFromStation() + "\u2192" + stringToList.get(i).getToStation() + " " + stringToList.get(i).getRiders());
                        }
                    }
                }
                else {
                    Dialogs.create().owner(this.getWindow()).message("\u5bfc\u5165\u7684\u4efb\u52a1\u65e0\u6548\u6216\u5df2\u4e0d\u5728\u9884\u552e\u671f\u8303\u56f4\u4e4b\u5185\u3002").alert();
                }
            }
            catch (Exception ex) {
                Dialogs.create().owner(this.getWindow()).message("\u4efb\u52a1\u5bfc\u5165\u5931\u8d25\uff0c\u6587\u4ef6\u683c\u5f0f\u9519\u8bef\u3002").alert();
            }
        }
    }
    
    private void a(final File file) {
        if (file != null) {
            try {
                final StringBuffer sb = new StringBuffer();
                for (int n = this.a.getItems().size() - 1, i = 0; i <= n; ++i) {
                    sb.append(((net.tec.kyfw.d.a)this.a.getItems().get(i)).toString());
                    if (i != n) {
                        sb.append(";");
                    }
                }
                o.a(net.tec.kyfw.util.e.a(sb.toString().getBytes("utf-8")), file);
                Dialogs.create().owner(this.getWindow()).message("\u4efb\u52a1\u5bfc\u51fa\u6210\u529f\uff01").alert();
            }
            catch (Exception ex) {
                ex.printStackTrace();
                Dialogs.create().owner(this.getWindow()).message("\u4efb\u52a1\u5bfc\u51fa\u5931\u8d25\u3002").alert();
            }
        }
    }
    
    private FileChooser e() {
        if (this.b == null) {
            this.b = new FileChooser();
            final ArrayList<String> list = new ArrayList<String>();
            list.add("*.dat");
            this.b.getExtensionFilters().add((Object)new FileChooser.ExtensionFilter("\u4efb\u52a1\u5907\u4efd\u6587\u4ef6(*.dat)", (List)list));
            this.b.setInitialDirectory(new File("./"));
        }
        return this.b;
    }
    
    public net.tec.kyfw.d.a b(final String s, final String s2) {
        return new net.tec.kyfw.d.a(s, s2, ((LocalDate)this.trainDate.getValue()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), (this.fromStation.getValue() != null) ? ((f)this.fromStation.getValue()).getStationName() : null, (this.toStation.getValue() != null) ? ((f)this.toStation.getValue()).getStationName() : null, (this.fromStation.getValue() != null) ? ((f)this.fromStation.getValue()).getStationTelecode() : null, (this.toStation.getValue() != null) ? ((f)this.toStation.getValue()).getStationTelecode() : null, this.a(), (String)this.priorOption.getValue(), this.submitOption.isSelected(), this.trainLimit.isSelected(), this.trainShow.getItems(), this.seatShow.getItems(), null, this.datesShow.getItems(), this.blackShow.getItems(), this.timingRef.isSelected(), this.timingRef.isSelected() ? this.spinner.getValue() : 0L);
    }
    
    public void c(final String s, final String s2) {
        if (Platform.isFxApplicationThread()) {
            this.logarea.appendText(DateUtil.a("HH:mm:ss.SSS") + "  [" + s + "]" + s2.replaceAll("\r\n", "\uff0c") + "\r\n");
        }
        else {
            Platform.runLater(() -> this.logarea.appendText(DateUtil.a("HH:mm:ss.SSS") + "  [" + s + "]" + s2.replaceAll("\r\n", "\uff0c") + "\r\n"));
        }
    }
}
