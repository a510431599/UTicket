// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.control.dialog.Dialogs;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.KeyEvent;
import net.tec.kyfw.util.i;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import net.tec.kyfw.e.g;
import javafx.beans.value.ObservableValue;
import net.tec.kyfw.f;
import javafx.collections.ObservableMap;
import javafx.scene.Node;
import javafx.scene.input.Mnemonic;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import net.tec.kyfw.util.p;
import javafx.scene.image.Image;
import javafx.concurrent.Service;
import javafx.stage.Window;
import javafx.application.Platform;
import java.util.List;
import javafx.collections.ObservableList;
import java.util.Collection;
import javafx.collections.FXCollections;
import net.tec.kyfw.e;
import javafx.a.d;
import net.tec.kyfw.e.a;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import net.tec.kyfw.b.s;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import net.tec.kyfw.d.b;
import javafx.control.combo.OperableComboBox;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;

public class LoginController extends AbstractController
{
    @FXML
    public StackPane root;
    @FXML
    public Button submit;
    @FXML
    public Button cancel;
    @FXML
    public OperableComboBox<net.tec.kyfw.d.b> userName;
    @FXML
    public PasswordField password;
    @FXML
    public Label errormsg;
    @FXML
    public Hyperlink register;
    @FXML
    public Label chooseCaptcha;
    @FXML
    public CheckBox saveOption;
    public s a;
    public StringProperty b;
    private long c;
    
    public LoginController() {
        this.b = (StringProperty)new SimpleStringProperty("");
        this.c = 0L;
    }
    
    @Override
    public void initialize() {
        this.b.addListener((observableValue, s, s2) -> {
            if (p.b((Object)s2)) {
                a.a(this.getAbstractWindow().getArgument(0), (String)this.b.get(), true);
                a.start();
            }
        });
        this.cancel.setOnAction(actionEvent -> this.getStage().hide());
        this.submit.setOnAction(actionEvent -> {
            if (this.d()) {
                final String trim = this.userName.getEditor().getText().trim();
                if (f.b(trim)) {
                    Dialogs.create().owner(this.getWindow()).message("\u8be5\u8d26\u53f7\u5df2\u7ecf\u767b\u5f55\u5230\u7cfb\u7edf\uff0c\u8bf7\u4f7f\u7528\u5176\u5b83\u8d26\u53f7\u767b\u5f55\uff01").alert();
                    return;
                }
                final String text = this.password.getText();
                final g g = d.a((Class<? extends javafx.a.a<Object>>)g.class);
                g.a(this.getAbstractWindow().getArgument(0), trim, text);
                g.start();
                this.c = 0L;
                this.a.b();
            }
        });
        this.chooseCaptcha.setOnMouseClicked(mouseEvent -> this.a());
        this.userName.setFixedCellSize(30.0);
        this.userName.setOnHandler((operableComboBox, p1, b) -> {
            e.a(b.getUserName());
            operableComboBox.removeItem(b);
            return;
        });
        this.userName.getSelectionModel().selectedItemProperty().addListener((observableValue, b, b2) -> this.password.setText((b2 != null) ? b2.getPassword() : ""));
        this.password.setOnKeyReleased(keyEvent -> {
            final String trim = p.b(this.password.getText()).trim();
            if (keyEvent.getCode().equals((Object)KeyCode.ENTER) && !trim.isEmpty()) {
                this.submit.requestFocus();
                if (p.a(this.b.get())) {
                    this.a();
                }
                else {
                    this.submit.fire();
                }
            }
        });
        final List<net.tec.kyfw.d.b> f = e.f();
        if (!f.isEmpty()) {
            this.userName.setOptions((javafx.collections.ObservableList<net.tec.kyfw.d.b>)FXCollections.observableArrayList((Collection)f));
            this.userName.setValue(this.userName.getOptions().get(0));
        }
        this.register.setOnAction(actionEvent -> i.e.a("https://kyfw.12306.cn/otn/regist/init"));
    }
    
    public void a() {
        final long currentTimeMillis = System.currentTimeMillis();
        final Boolean value = this.c == 0L || currentTimeMillis - this.c > 180000L;
        if (value) {
            this.c = System.currentTimeMillis();
        }
        if (value) {
            this.b();
        }
        else {
            final Window window;
            Platform.runLater(() -> {
                this.getStage();
                this.a.show(window, ((Stage)window).getX() + this.chooseCaptcha.getLayoutX(), ((Stage)window).getY() - this.chooseCaptcha.getLayoutY() + 268.0);
            });
        }
    }
    
    public void b() {
        final a.b b;
        final Window window;
        Platform.runLater(() -> {
            b = d.a((Class<? extends javafx.a.a<Object>>)a.b.class);
            if (this.a == null) {
                this.a = new s().a(this.b).a(b).a(() -> {
                    this.c = 0L;
                    this.a();
                    return;
                });
            }
            this.getStage();
            this.a.show(window, ((Stage)window).getX() + this.chooseCaptcha.getLayoutX(), ((Stage)window).getY() - this.chooseCaptcha.getLayoutY() + 268.0);
            this.a.b();
            b.a(this.getAbstractWindow().getArgument(0), true);
            b.start();
            this.c = System.currentTimeMillis();
        });
    }
    
    private boolean d() {
        final String trim = p.b(this.userName.getEditor().getText()).trim();
        final String b = p.b(this.password.getText());
        final String b2 = p.b((String)this.b.get());
        if (p.a((Object)b2)) {
            this.a();
        }
        return !trim.isEmpty() && !b.isEmpty() && !b2.isEmpty();
    }
    
    @Override
    public void afterPropertySet() {
        this.submit.requestFocus();
        this.getStage().showingProperty().addListener((observableValue, b, b2) -> {
            if (b) {
                this.userName.getEditor().setEditable(true);
                final a.b b3 = d.a((Class<? extends javafx.a.a<Object>>)a.b.class);
                final g g = d.a((Class<? extends javafx.a.a<Object>>)g.class);
                if (b3.isRunning()) {
                    b3.cancel();
                }
                if (g.isRunning()) {
                    g.cancel();
                }
            }
        });
        final KeyCodeCombination keyCodeCombination = new KeyCodeCombination(KeyCode.C, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final KeyCodeCombination keyCodeCombination2 = new KeyCodeCombination(KeyCode.F4, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final KeyCodeCombination keyCodeCombination3 = new KeyCodeCombination(KeyCode.L, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final KeyCodeCombination keyCodeCombination4 = new KeyCodeCombination(KeyCode.ENTER, new KeyCombination.Modifier[0]);
        final ObservableMap accelerators = this.getScene().getAccelerators();
        this.getScene().addMnemonic(new Mnemonic((Node)this.cancel, (KeyCombination)keyCodeCombination));
        this.getScene().addMnemonic(new Mnemonic((Node)this.cancel, (KeyCombination)keyCodeCombination2));
        this.getScene().addMnemonic(new Mnemonic((Node)this.submit, (KeyCombination)keyCodeCombination3));
        accelerators.put((Object)keyCodeCombination4, (Object)new l(this));
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    public void c() {
        final f f = this.getAbstractWindow().getArgument(0);
        final String trim = p.b(this.userName.getEditor().getText()).trim();
        final String b = p.b(this.password.getText());
        if (this.saveOption.isSelected()) {
            e.a(trim, b);
            final net.tec.kyfw.d.b value = new net.tec.kyfw.d.b(trim, b);
            if (this.userName.getOptions().contains((Object)value)) {
                this.userName.removeItem(value);
            }
            this.userName.addItem(0, value);
            this.userName.setCompleteValue((net.tec.kyfw.d.b)null);
            this.userName.setValue((Object)value);
        }
        if (f.equals(net.tec.kyfw.f.b())) {
            final MainController mainController = javafx.controller.a.a(MainController.class);
            ((Label)mainController.login.getChildren().get(0)).setText("\u9000\u51fa\u767b\u5f55");
            mainController.bottomController.a(trim);
            f.a(trim, b);
            final PassengerController passengerController = javafx.controller.a.a(PassengerController.class);
            final ObservableList items = passengerController.account.getItems();
            if (!items.contains((Object)trim)) {
                items.add((Object)trim);
            }
            passengerController.account.setValue((Object)trim);
            final TaskController taskController = javafx.controller.a.a(TaskController.class);
            final net.tec.kyfw.d.a a = taskController.a.a(trim);
            if (a != null) {
                a.setPassword(b);
                a.setTaskState("\u7b49\u5f85\u8fd0\u884c");
                taskController.a.a(a);
            }
        }
        else if (f.equals(net.tec.kyfw.f.c())) {
            f.c(trim).a(trim, b);
            final PassengerController passengerController2 = javafx.controller.a.a(PassengerController.class);
            final ObservableList items2 = passengerController2.account.getItems();
            if (!items2.contains((Object)trim)) {
                items2.add((Object)trim);
            }
            passengerController2.account.setValue((Object)trim);
            final TaskController taskController2 = javafx.controller.a.a(TaskController.class);
            final net.tec.kyfw.d.a a2 = taskController2.a.a(trim);
            if (a2 != null) {
                a2.setPassword(b);
                a2.setTaskState("\u7b49\u5f85\u8fd0\u884c");
                taskController2.a.a(a2);
            }
            else {
                taskController2.a.a(taskController2.b(trim, b), Boolean.valueOf(true));
            }
        }
        this.getStage().hide();
    }
    
    public void a(final String completeValue, final String text) {
        this.userName.getEditor().setEditable(false);
        this.userName.setCompleteValue(completeValue);
        this.password.setText(text);
    }
}
