// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import java.net.URI;
import java.awt.Desktop;

class L extends Thread
{
    final /* synthetic */ SettingController a;
    
    L(final SettingController a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        if (Desktop.isDesktopSupported()) {
            try {
                Desktop.getDesktop().browse(new URI("http://www.dama2.com/"));
            }
            catch (Exception ex) {}
        }
    }
}
