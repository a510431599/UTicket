// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.a.a;
import javafx.a.d;
import net.tec.kyfw.e.o;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Hyperlink;
import net.tec.kyfw.d.g;
import javafx.scene.control.TableCell;

class ad extends TableCell<g, String>
{
    final /* synthetic */ TicketController a;
    
    ad(final TicketController a) {
        this.a = a;
    }
    
    public void a(final String text, final boolean b) {
        super.updateItem((Object)text, b);
        if (!b) {
            this.setText((String)null);
            final Hyperlink graphic = new Hyperlink(text);
            graphic.setOnAction(actionEvent -> {
                final o o = d.a((Class<? extends a<Object>>)o.class);
                o.a(this.getTableView().getItems().get(this.getIndex()));
                o.start();
            });
            this.setGraphic((Node)graphic);
        }
        else {
            this.setText(text);
            this.setGraphic((Node)null);
        }
    }
}
