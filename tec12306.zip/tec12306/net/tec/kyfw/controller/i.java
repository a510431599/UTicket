// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.control.dialog.Tooltips;

class I implements Runnable
{
    final /* synthetic */ String a;
    final /* synthetic */ H b;
    
    I(final H b, final String a) {
        this.b = b;
        this.a = a;
    }
    
    @Override
    public void run() {
        Tooltips.show(this.b.a.a.getWindow(), this.a);
        this.b.a.a.testSms.setDisable(false);
    }
}
