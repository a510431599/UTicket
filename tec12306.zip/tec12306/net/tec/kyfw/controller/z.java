// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.util.DateUtil;
import java.time.LocalDate;
import javafx.scene.control.DateCell;

class Z extends DateCell
{
    final /* synthetic */ Y a;
    
    Z(final Y a) {
        this.a = a;
    }
    
    public void updateItem(final LocalDate localDate, final boolean b) {
        super.updateItem(localDate, b);
        if (!DateUtil.a(localDate)) {
            this.setDisable(true);
        }
    }
}
