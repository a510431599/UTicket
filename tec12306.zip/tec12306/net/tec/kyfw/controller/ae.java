// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.geometry.Pos;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Label;
import net.tec.kyfw.d.g;
import javafx.scene.control.TableCell;

class ae extends TableCell<g, String>
{
    final /* synthetic */ TicketController a;
    
    ae(final TicketController a) {
        this.a = a;
    }
    
    public void a(final String s, final boolean b) {
        super.updateItem((Object)s, b);
        this.setText((String)null);
        if (!b) {
            final String[] split = s.split("\r\n");
            final Label label = new Label(split[0]);
            label.prefWidthProperty().bind((ObservableValue)this.widthProperty().subtract(12));
            label.setPrefHeight(33.0);
            label.setAlignment(Pos.BASELINE_LEFT);
            label.setStyle("-fx-text-fill:#38383b;-fx-padding:0;-fx-line-spacing:-3;-fx-label-padding:-16 0 0 0;" + (split[2].equals("true") ? "-fx-background-image:url('/res/images/train_start.png');-fx-background-repeat: no-repeat;-fx-background-position:right 3;" : ""));
            final Label label2 = new Label(split[1]);
            label2.prefWidthProperty().bind((ObservableValue)this.widthProperty().subtract(12));
            label2.setPrefHeight(33.0);
            label2.setAlignment(Pos.BASELINE_LEFT);
            label2.setStyle("-fx-text-fill:#8b8b8f;-fx-padding:0;-fx-line-spacing:-3;-fx-label-padding:12 0 0 0;" + (split[3].equals("true") ? "-fx-background-image:url('/res/images/train_end.png');-fx-background-repeat: no-repeat;-fx-background-position:right 17;" : ""));
            final StackPane graphic = new StackPane();
            graphic.getChildren().addAll((Object[])new Node[] { label, label2 });
            graphic.prefWidthProperty().bind((ObservableValue)this.widthProperty().subtract(12));
            graphic.setPrefHeight(33.0);
            this.setGraphic((Node)graphic);
        }
        else {
            this.setGraphic((Node)null);
        }
    }
}
