// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.application.Platform;
import net.tec.kyfw.util.k;
import javafx.concurrent.Task;

class H extends Task<Void>
{
    final /* synthetic */ G a;
    
    H(final G a) {
        this.a = a;
    }
    
    protected Void a() {
        Platform.runLater((Runnable)new I(this, k.a(this.a.a.useFeixin.isSelected() ? 1 : 2, this.a.a.fxusername.getText(), this.a.a.fxpassword.getText())));
        return null;
    }
}
