// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import java.net.URI;
import java.awt.Desktop;

class J extends Thread
{
    final /* synthetic */ SettingController a;
    
    J(final SettingController a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        if (Desktop.isDesktopSupported()) {
            try {
                Desktop.getDesktop().browse(new URI("http://www.dama2.com/index/ureg?tj=1268652&vali=32a33323a8d4a8198e61e6cfe38e4394"));
            }
            catch (Exception ex) {}
        }
    }
}
