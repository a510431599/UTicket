// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.d.d;

class A implements Runnable
{
    final /* synthetic */ z a;
    
    A(final z a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        this.a.a.passengerTable.getItems().add((Object)new d(this.a.a.nameField.getText(), (String)this.a.a.cardTypeChoice.getValue(), this.a.a.cardCodeField.getText(), this.a.a.mobileNoField.getText(), (String)this.a.a.passengerTypeChoice.getValue(), "\u5f85\u6838\u9a8c"));
        this.a.a.nameField.setText("");
        this.a.a.cardCodeField.setText("");
        this.a.a.mobileNoField.setText("");
        this.a.a.buttonAdd.setDisable(false);
    }
}
