// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.application.Platform;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.a.a;
import javafx.concurrent.Task;

class N extends Task<Void>
{
    final /* synthetic */ M a;
    
    N(final M a) {
        this.a = a;
    }
    
    protected Void a() {
        final a.d d;
        Platform.runLater(() -> {
            net.tec.kyfw.a.a.b(this.a.a.dmUserName.getText(), this.a.a.dmPassword.getText());
            Tooltips.show(this.a.a.getWindow(), (d.c >= 0) ? "\u6d4b\u8bd5\u6210\u529f\uff01" : d.d);
            this.a.a.dmTest.setDisable(false);
            if (d.c >= 0) {
                this.a.a.dmBalance.setText(String.valueOf(d.a));
            }
            return;
        });
        return null;
    }
}
