// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class F implements EventHandler<ActionEvent>
{
    final /* synthetic */ SettingController a;
    
    F(final SettingController a) {
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        this.a.useFeixin.setSelected(false);
        this.a.fxusername.setDisable(!this.a.useEmail.isSelected());
        this.a.fxpassword.setDisable(!this.a.useEmail.isSelected());
        this.a.testSms.setDisable(!this.a.useEmail.isSelected());
    }
}
