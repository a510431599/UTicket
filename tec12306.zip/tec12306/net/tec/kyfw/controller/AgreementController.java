// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.scene.input.MouseEvent;
import javafx.beans.value.ChangeListener;
import net.tec.kyfw.util.o;
import javafx.event.EventHandler;
import java.util.ResourceBundle;
import java.net.URL;
import javafx.scene.web.WebEngine;
import javafx.scene.control.CheckBox;
import javafx.scene.web.WebView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Pane;
import javafx.fxml.FXML;
import javafx.scene.layout.GridPane;
import javafx.fxml.Initializable;

public class AgreementController implements Initializable
{
    @FXML
    public GridPane dialogTitle;
    @FXML
    public Pane dialogBottom;
    @FXML
    public StackPane contentPane;
    @FXML
    public Label titleLabel;
    @FXML
    public Label close;
    @FXML
    public Button agreeBtn;
    @FXML
    public Button cancelBtn;
    @FXML
    public WebView webView;
    @FXML
    public CheckBox agree;
    public WebEngine a;
    public double b;
    public double c;
    
    public void initialize(final URL url, final ResourceBundle resourceBundle) {
        this.titleLabel.setOnMousePressed((EventHandler)this.a());
        this.titleLabel.setOnMouseDragged((EventHandler)this.b());
        this.close.setOnMouseClicked((EventHandler)this.c());
        this.cancelBtn.setOnAction((EventHandler)new a(this));
        (this.a = this.webView.getEngine()).load(o.b("/res/web/agreement.html"));
        this.agree.selectedProperty().addListener((ChangeListener)new b(this));
        this.agreeBtn.setOnAction((EventHandler)new c(this));
    }
    
    private EventHandler<MouseEvent> a() {
        return (EventHandler<MouseEvent>)new d(this);
    }
    
    private EventHandler<MouseEvent> b() {
        return (EventHandler<MouseEvent>)new e(this);
    }
    
    private EventHandler<MouseEvent> c() {
        return (EventHandler<MouseEvent>)new f(this);
    }
}
