// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.event.Event;
import javafx.scene.input.PickResult;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import net.tec.kyfw.e.q;
import net.tec.kyfw.d.j;
import javafx.collections.ObservableList;
import net.tec.kyfw.util.DateUtil;
import javafx.collections.FXCollections;
import javafx.a.d;
import net.tec.kyfw.e.r;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javafx.control.dialog.Dialogs;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.f;
import javafx.controller.AbstractController;
import javafx.controller.a;
import net.tec.kyfw.d.g;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class ah implements EventHandler<ActionEvent>
{
    final /* synthetic */ g a;
    final /* synthetic */ ag b;
    
    ah(final ag b, final g a) {
        this.b = b;
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        final MainController mainController = javafx.controller.a.a(MainController.class);
        if (f.b().i()) {
            if (this.a.isCanTimingBuy()) {
                if (this.b.a.seatShow.getItems().isEmpty()) {
                    Tooltips.show(this.b.a.getWindow(), "\u8bf7\u9009\u62e9\u5e2d\u522b\uff01");
                    return;
                }
                if (this.b.a.riderShow.getItems().isEmpty()) {
                    Tooltips.show(this.b.a.getWindow(), "\u8bf7\u9009\u62e9\u4e58\u8f66\u4eba\uff01");
                    return;
                }
                if (Integer.valueOf(Dialogs.create().owner(this.b.a.getWindow()).message("\u60a8\u9009\u62e9\u9884\u8ba2 " + this.a.getTrainDate() + " \u7684 " + this.a.getStationTrainCode() + " \u6b21\u5217\u8f66\r\n\u9884\u552e\u65f6\u95f4\u662f " + LocalTime.parse(this.a.getSaleTime(), DateTimeFormatter.ofPattern("HHmm")).format(DateTimeFormatter.ofPattern("HH:mm")) + "\r\n\u786e\u8ba4\u73b0\u5728\u5f00\u59cb\u8ba2\u7968 ?").confirmAndWait()) == 0) {
                    return;
                }
                final TaskController taskController = javafx.controller.a.a(TaskController.class);
                final net.tec.kyfw.d.a a = taskController.a.a(f.b().g());
                if (a != null) {
                    final r r = d.a((Class<? extends javafx.a.a<Object>>)r.class, a.getAccount());
                    if (r.isRunning()) {
                        r.cancel();
                    }
                    taskController.a.c(a);
                }
                taskController.a.a(new net.tec.kyfw.d.a(f.b().g(), f.b().h(), this.a.getTrainDate(), this.a.getFromStationName(), this.a.getToStationName(), this.a.getFromStationTelecode(), this.a.getToStationTelecode(), "00:00--24:00", (String)this.b.a.priorOption.getValue(), this.b.a.submitOption.isSelected(), true, (ObservableList<g>)FXCollections.observableArrayList((Object[])new g[] { this.a }), this.b.a.seatShow.getItems(), this.b.a.riderShow.getItems(), null, null, true, DateUtil.b(this.a.getSaleTime())), Boolean.valueOf(true));
                mainController.framePane.getSelectionModel().select(1);
            }
            else {
                final q q = d.a((Class<? extends javafx.a.a<Object>>)q.class);
                q.a(this.a);
                q.start();
            }
        }
        else {
            mainController.login.fireEvent((Event)new MouseEvent(MouseEvent.MOUSE_CLICKED, 0.0, 0.0, 0.0, 0.0, (MouseButton)null, 2, true, true, true, true, true, true, true, true, true, true, (PickResult)null));
        }
    }
}
