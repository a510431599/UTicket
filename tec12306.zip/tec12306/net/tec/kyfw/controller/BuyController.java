// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.f;
import net.tec.kyfw.e.q;
import javafx.control.dialog.Tooltips;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.scene.layout.HBox;
import java.util.List;
import net.tec.kyfw.util.p;
import java.util.Collection;
import net.tec.kyfw.util.r;
import javafx.control.bean.SelectedProperty;
import javafx.controller.a;
import net.tec.kyfw.e;
import javafx.control.Cascade;
import javafx.scene.Node;
import javafx.geometry.Insets;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import net.tec.kyfw.d.g;
import net.tec.kyfw.b.G;
import net.tec.kyfw.d.d;
import javafx.control.pane.CheckBoxArea;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;

public class BuyController extends AbstractController
{
    @FXML
    public StackPane root;
    @FXML
    public VBox content;
    @FXML
    public Label trainNo;
    @FXML
    public Label trainType;
    @FXML
    public Label fromStation;
    @FXML
    public Label startTime;
    @FXML
    public Label lishi;
    @FXML
    public Label toStation;
    @FXML
    public Label arriveTime;
    @FXML
    public Button submit;
    @FXML
    public Button back;
    @FXML
    public Hyperlink refresh;
    @FXML
    public VBox priceList;
    @FXML
    public CheckBoxArea<d> linkmanPane;
    @FXML
    public StackPane overlay;
    @FXML
    public Label waitMsg;
    @FXML
    public Label buyCancel;
    public G a;
    public g b;
    public String c;
    public String d;
    public ObservableList<String> e;
    public String f;
    
    public BuyController() {
        this.e = (ObservableList<String>)FXCollections.observableArrayList();
        this.f = "";
    }
    
    @Override
    public void initialize() {
        (this.a = new G()).b(5);
        VBox.setMargin((Node)this.a, new Insets(0.0, 5.0, 0.0, 5.0));
        this.content.getChildren().add(4, (Object)this.a);
        this.linkmanPane.bind(this.a);
        this.refresh.setOnAction(actionEvent -> this.b());
        this.back.setOnAction(actionEvent -> {
            net.tec.kyfw.e.a = Boolean.FALSE;
            final q q = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)q.class);
            if (q.isRunning()) {
                q.cancel();
            }
            net.tec.kyfw.c.g.k(net.tec.kyfw.f.b());
            javafx.controller.a.a(MainController.class).framePane.getSelectionModel().select(0);
        });
        this.submit.setOnAction(actionEvent -> {
            if (this.a.getItems().size() < 1) {
                Tooltips.show(this.getWindow(), "\u8bf7\u9009\u62e9\u4e58\u8f66\u4eba\uff01");
                return;
            }
            javafx.a.d.a((Class<? extends javafx.a.a<Object>>)net.tec.kyfw.e.p.class).start();
        });
        this.buyCancel.setOnMouseClicked(mouseEvent -> {
            final net.tec.kyfw.e.p p = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)net.tec.kyfw.e.p.class);
            if (p.isRunning()) {
                p.cancel();
            }
            this.overlay.setVisible(false);
        });
    }
    
    public void a(final g b, final String c, final String d) {
        net.tec.kyfw.e.a = Boolean.TRUE;
        this.b = b;
        this.c = c;
        this.d = d;
        this.b();
        this.trainNo.setText(b.getStationTrainCode());
        this.trainType.setText(b.getTrainType());
        this.fromStation.setText(b.getFromStationName());
        this.toStation.setText(b.getToStationName());
        this.startTime.setText(this.a(b.getTrainDate(), b.getStartTime(), "0"));
        this.arriveTime.setText(this.a(b.getTrainDate(), b.getArriveTime(), b.getDayDifference()));
        this.lishi.setText(b.getLishi());
        if (b.getStartStationTelecode().equals(b.getFromStationTelecode())) {
            this.fromStation.getStyleClass().add((Object)"start-station");
        }
        else {
            this.fromStation.getStyleClass().remove((Object)"start-station");
        }
        if (b.getEndStationTelecode().equals(b.getToStationTelecode())) {
            this.toStation.getStyleClass().add((Object)"end-station");
        }
        else {
            this.toStation.getStyleClass().remove((Object)"end-station");
        }
        this.b();
        this.a();
        this.a.a(this.e);
        this.a.a(this.f);
        final javafx.collections.ObservableList<SelectedProperty> options = javafx.controller.a.a(TicketController.class).priorRider.getOptions();
        final ObservableList observableArrayList = FXCollections.observableArrayList();
        for (int i = 0; i < options.size(); ++i) {
            observableArrayList.add((Object)((d)options.get(i)).cloneNewInstance());
        }
        this.linkmanPane.getItems().clear();
        this.linkmanPane.setItems((javafx.collections.ObservableList<d>)observableArrayList);
        javafx.controller.a.a(MainController.class).framePane.getSelectionModel().select(4);
    }
    
    @Override
    public void afterPropertySet() {
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    public void a() {
        final TicketController ticketController = javafx.controller.a.a(TicketController.class);
        try {
            this.e.clear();
            this.e.addAll((Collection)r.b(this.b));
            this.f = "";
            if (ticketController.seatShow.size() > 0) {
                final javafx.collections.ObservableList<net.tec.kyfw.d.e> items = ticketController.seatShow.getItems();
                for (int i = 0; i < items.size(); ++i) {
                    int j = 0;
                    while (j < this.e.size()) {
                        if (((net.tec.kyfw.d.e)items.get(i)).getItemValue().equals(this.e.get(j))) {
                            if (!"\u65e0".equals(this.b.invoke(g.methods.get(this.e.get(j))))) {
                                this.f = (String)this.e.get(j);
                                break;
                            }
                            break;
                        }
                        else {
                            ++j;
                        }
                    }
                    if (!p.a((Object)this.f)) {
                        break;
                    }
                }
            }
            if (p.a((Object)this.f)) {
                for (int k = 0; k < this.e.size(); ++k) {
                    if (!"\u65e0".equals(this.b.invoke(g.methods.get(this.e.get(k))))) {
                        this.f = (String)this.e.get(k);
                        break;
                    }
                }
            }
            if (p.a((Object)this.f)) {
                this.f = (String)this.e.get(0);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void b() {
        new Thread((Runnable)new k(this)).start();
    }
    
    public void a(final List<String[]> list) {
        this.priceList.getChildren().clear();
        if (list != null) {
            for (int i = 0; i < list.size(); ++i) {
                final String[] array = list.get(i);
                final HBox hBox = new HBox();
                hBox.getStyleClass().add((Object)"item");
                if ("\u65e0".equals(array[1]) || "*".equals(array[1])) {
                    hBox.getStyleClass().add((Object)"price-wp");
                }
                else if (array[1].equals("\u6709") || Integer.parseInt(array[1]) >= 30) {
                    hBox.getStyleClass().add((Object)"price-yp");
                }
                else {
                    hBox.getStyleClass().add((Object)"price-little");
                }
                final Label label = new Label(array[0]);
                label.getStyleClass().add((Object)"label0");
                label.setOnMouseClicked(mouseEvent -> this.a.a(((Label)mouseEvent.getSource()).getText()));
                final Label label2 = new Label(array[1]);
                label2.getStyleClass().add((Object)"label1");
                final Label label3 = new Label(array[2]);
                label3.getStyleClass().add((Object)"label2");
                hBox.getChildren().addAll((Object[])new Node[] { label, label2, label3 });
                this.priceList.getChildren().add((Object)hBox);
            }
        }
    }
    
    private String a(final String s, final String s2, final String s3) {
        return LocalDateTime.of(LocalDate.parse(s, DateTimeFormatter.ofPattern("yyyy-MM-dd")), LocalTime.parse(s2, DateTimeFormatter.ofPattern("HH:mm"))).plusDays(Integer.parseInt(s3)).format(DateTimeFormatter.ofPattern("MM\u6708dd\u65e5 HH:mm"));
    }
}
