// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.util.Callback;

class Y implements Callback<DatePicker, DateCell>
{
    final /* synthetic */ TicketController a;
    
    Y(final TicketController a) {
        this.a = a;
    }
    
    public DateCell a(final DatePicker datePicker) {
        return new Z(this);
    }
}
