// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.util.j;
import java.util.Iterator;
import net.tec.kyfw.util.p;
import net.tec.kyfw.util.q;
import net.tec.kyfw.util.o;
import javafx.stage.Window;
import javafx.event.ActionEvent;
import net.tec.kyfw.e;
import javafx.beans.value.ObservableValue;
import java.lang.reflect.Method;
import javafx.application.Platform;
import java.io.File;
import java.util.List;
import javafx.a.a;
import net.tec.kyfw.e.l;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.f;
import javafx.event.EventHandler;
import javafx.scene.control.TableColumn;
import javafx.scene.Node;
import javafx.scene.text.Text;
import javafx.geometry.Pos;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.ChoiceBoxTableCell;
import javafx.scene.control.TableCell;
import javafx.util.StringConverter;
import javafx.scene.control.cell.TextFieldTableCell;
import java.util.ArrayList;
import javafx.stage.FileChooser;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.control.field.AbstractTextField;
import net.tec.kyfw.d.d;
import javafx.control.pane.TablePane;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import org.apache.log4j.Logger;
import javafx.controller.AbstractController;

public class PassengerController extends AbstractController
{
    private static Logger b;
    @FXML
    public StackPane root;
    @FXML
    public Hyperlink refresh;
    @FXML
    public ComboBox<String> account;
    @FXML
    public TablePane<d> passengerTable;
    @FXML
    public AbstractTextField nameField;
    @FXML
    public AbstractTextField cardCodeField;
    @FXML
    public AbstractTextField mobileNoField;
    @FXML
    public ChoiceBox<String> passengerTypeChoice;
    @FXML
    public ChoiceBox<String> cardTypeChoice;
    @FXML
    public Button buttonAdd;
    @FXML
    public Button buttonImport;
    public FileChooser a;
    private String c;
    private Integer d;
    
    public PassengerController() {
        this.c = null;
        this.d = null;
    }
    
    @Override
    public void initialize() {
        this.refresh.setOnAction(actionEvent -> this.a());
        this.account.getSelectionModel().selectedItemProperty().addListener((observableValue, s, s2) -> {
            if (s2 == null) {
                this.passengerTable.setItems((ObservableList)null);
            }
            else {
                final ObservableList<d> items = e.c.get(s2);
                if (items != null && !items.isEmpty()) {
                    this.passengerTable.setItems((ObservableList)items);
                }
                else {
                    this.a();
                }
            }
        });
        final String[] array = { "\u59d3\u540d", "\u8bc1\u4ef6\u7c7b\u578b", "\u8bc1\u4ef6\u53f7\u7801", "\u624b\u673a\u53f7\u7801", "\u65c5\u5ba2\u7c7b\u578b", "\u6838\u9a8c\u72b6\u6001", "\u64cd\u4f5c" };
        final double[] array2 = { 2.0, 2.0, 3.0, 3.0, 2.0, 2.0, 1.0 };
        final boolean[] array3 = { true, true, true, true, true, false, false };
        final String[] array4 = { "name", "cardType", "cardCode", "mobileNo", "passengerType", "checkState", "name" };
        final ArrayList<TablePane.TableCellFactory> list = new ArrayList<TablePane.TableCellFactory>();
        final javafx.scene.control.TableCell<Object, String> tableCell;
        list.add(() -> {
            tableCell = (javafx.scene.control.TableCell<Object, String>)new TextFieldTableCell((StringConverter)this.d());
            this.a((TableCell<d, String>)tableCell);
            return tableCell;
        });
        final javafx.scene.control.TableCell<Object, String> tableCell2;
        list.add(() -> {
            tableCell2 = (javafx.scene.control.TableCell<Object, String>)new ChoiceBoxTableCell((StringConverter)this.d(), (ObservableList)net.tec.kyfw.d.d.CARD_TYPE_LIST);
            this.a((TableCell<d, String>)tableCell2);
            return tableCell2;
        });
        final javafx.scene.control.TableCell<Object, String> tableCell3;
        list.add(() -> {
            tableCell3 = (javafx.scene.control.TableCell<Object, String>)new TextFieldTableCell((StringConverter)this.d());
            this.a((TableCell<d, String>)tableCell3);
            return tableCell3;
        });
        list.add(() -> new TextFieldTableCell((StringConverter)this.d()));
        list.add(() -> new ChoiceBoxTableCell((StringConverter)this.d(), (ObservableList)net.tec.kyfw.d.d.PASSENGER_TYPE_LIST));
        list.add(() -> new u(this));
        list.add(() -> new v(this));
        final ObservableList observableArrayList = FXCollections.observableArrayList();
        for (int i = 0; i < array4.length; ++i) {
            final TablePane.Column column = new TablePane.Column();
            column.setAlign(Pos.CENTER);
            column.setField(array4[i]);
            column.setText(array[i]);
            column.setWidth(array2[i]);
            column.setTableCellFactory(list.get(i));
            column.setEditable(array3[i]);
            observableArrayList.add((Object)column);
        }
        this.passengerTable.setEditable(true);
        this.passengerTable.setTableColumn((javafx.collections.ObservableList<TablePane.Column<d>>)observableArrayList);
        this.passengerTable.setPlaceholder((Node)new Text("\u6682\u65e0\u8054\u7cfb\u4eba\uff01"));
        final ObservableList columns = this.passengerTable.getColumns();
        for (int j = 0; j < 5; ++j) {
            ((TableColumn)columns.get(j)).setOnEditCommit((EventHandler)this.a(array4[j]));
        }
        this.buttonAdd.setOnAction(actionEvent -> {
            if (this.account.getValue() == null || !f.a((String)this.account.getValue()).i()) {
                Tooltips.show(this.getWindow(), "\u60a8\u672a\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u4e0d\u80fd\u6267\u884c\u6b64\u64cd\u4f5c\uff01");
                return;
            }
            Integer n = 0;
            if (p.a((Object)this.nameField.getText())) {
                ++n;
            }
            if (p.a((Object)this.cardCodeField.getText())) {
                ++n;
            }
            if (n > 0) {
                Tooltips.show(this.getWindow(), "\u4fe1\u606f\u586b\u5199\u4e0d\u5b8c\u6574\uff01");
                return;
            }
            if (this.passengerTable.getItems() != null) {
                final Iterator iterator = this.passengerTable.getItems().iterator();
                while (iterator.hasNext()) {
                    if (iterator.next().getCardCode().equalsIgnoreCase(this.cardCodeField.getText())) {
                        Tooltips.show(this.getWindow(), "\u8bc1\u4ef6\u53f7\u7801\u91cd\u590d\uff01");
                        return;
                    }
                }
            }
            this.buttonAdd.setDisable(true);
            this.c();
        });
        this.buttonImport.setOnAction(actionEvent -> {
            if (this.account.getValue() == null || !f.a((String)this.account.getValue()).i()) {
                Tooltips.show(this.getWindow(), "\u60a8\u672a\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u4e0d\u80fd\u6267\u884c\u6b64\u64cd\u4f5c\uff01");
                return;
            }
            final File showOpenDialog = this.e().showOpenDialog((Window)this.getStage());
            if (showOpenDialog != null) {
                final List<d> a = q.a(o.a(showOpenDialog));
                if (a != null && !a.isEmpty()) {
                    if (this.passengerTable.getItems() != null && !this.passengerTable.getItems().isEmpty()) {
                        for (int i = a.size() - 1; i >= 0; --i) {
                            if (this.passengerTable.getItems().contains((Object)a.get(i))) {
                                a.remove(i);
                            }
                        }
                    }
                    if (!a.isEmpty()) {
                        this.buttonImport.setDisable(true);
                        new Thread((Runnable)new y(this, a)).start();
                    }
                    else {
                        this.buttonImport.setDisable(false);
                        Tooltips.show(this.getWindow(), "\u5bfc\u5165\u7684\u8054\u7cfb\u4eba\u5df2\u5b58\u5728\uff01");
                    }
                }
                else {
                    Tooltips.show(this.getWindow(), "\u6570\u636e\u683c\u5f0f\u6709\u8bef\uff01");
                    this.buttonImport.setDisable(false);
                }
            }
        });
        this.passengerTable.itemsProperty().addListener((observableValue, list, options) -> {
            final String s = (String)this.account.getValue();
            if (s != null) {
                if (options != null) {
                    final ObservableList<d> list2 = e.c.get(s);
                    if (list2 != null && !list2.equals(options)) {
                        for (int i = 0; i < list2.size(); ++i) {
                            if (((d)list2.get(i)).isChecked()) {
                                if (options.contains(list2.get(i))) {
                                    final d d = (d)options.get(options.indexOf(list2.get(i)));
                                    d.setChildren(((d)list2.get(i)).getChildren());
                                    d.setChecked(true);
                                }
                                else {
                                    ((d)list2.get(i)).setChecked(false);
                                }
                            }
                        }
                    }
                    e.c.put(s, (ObservableList<d>)options);
                    final TaskController taskController = javafx.controller.a.a(TaskController.class);
                    if (taskController.a.a(f.a((String)this.account.getValue()).g()) != null && (taskController.linkmanPane.getItems() == null || taskController.linkmanPane.getItems().isEmpty())) {
                        final ObservableList observableArrayList = FXCollections.observableArrayList();
                        for (int j = 0; j < options.size(); ++j) {
                            observableArrayList.add((Object)((d)options.get(j)).cloneNewInstance());
                        }
                        taskController.linkmanPane.setItems((javafx.collections.ObservableList<d>)observableArrayList);
                    }
                }
                if (s.equals(f.b().g())) {
                    javafx.controller.a.a(TicketController.class).priorRider.setOptions((javafx.collections.ObservableList<d>)options);
                }
            }
            else {
                final TicketController ticketController = javafx.controller.a.a(TicketController.class);
                ticketController.priorRider.setOptions((javafx.collections.ObservableList<d>)FXCollections.observableArrayList());
                ticketController.riderShow.removeAll();
            }
        });
    }
    
    public void a() {
        if (this.account.getValue() == null || !f.a((String)this.account.getValue()).i()) {
            Tooltips.show(this.getWindow(), "\u60a8\u672a\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u4e0d\u80fd\u6267\u884c\u6b64\u64cd\u4f5c\uff01");
            return;
        }
        final l l = javafx.a.d.a((Class<? extends a<Object>>)l.class);
        l.a(f.a((String)this.account.getValue()));
        l.start();
    }
    
    private EventHandler<TableColumn.CellEditEvent<d, String>> a(final String s) {
        return (EventHandler<TableColumn.CellEditEvent<d, String>>)(cellEditEvent -> {
            if (((String)cellEditEvent.getNewValue()).equals(cellEditEvent.getOldValue()) && this.c == null) {
                return;
            }
            final d d = (d)cellEditEvent.getTableView().getItems().get(cellEditEvent.getTablePosition().getRow());
            if (s.equals("cardType")) {
                this.d = cellEditEvent.getTablePosition().getRow();
                this.c = (String)cellEditEvent.getOldValue();
                final Method method = d.getMethod(s);
                try {
                    method.invoke(d, cellEditEvent.getNewValue());
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                Platform.runLater(() -> {
                    this.passengerTable.edit((int)this.d, tableColumn);
                    this.passengerTable.getFocusModel().focus((int)this.d, tableColumn);
                });
            }
            else {
                this.a(d, s, (String)cellEditEvent.getNewValue(), (String)cellEditEvent.getOldValue(), (TablePane<d>)cellEditEvent.getTableView(), cellEditEvent.getTablePosition().getRow());
            }
        });
    }
    
    private void c() {
        new Thread((Runnable)new z(this)).start();
    }
    
    private void a(final d d, final String s, final String s2, final String s3, final TablePane<d> tablePane, final int n) {
        new Thread((Runnable)new B(this, d, s, s2, tablePane, n, s3)).start();
    }
    
    private String b(final String s) {
        String s2 = "F";
        if (s != null && s.length() > 2) {
            try {
                if (Integer.parseInt(String.valueOf(s.charAt(s.length() - 2))) % 2 == 1) {
                    s2 = "M";
                }
            }
            catch (Exception ex) {}
        }
        return s2;
    }
    
    private void a(final TableCell<d, String> tableCell) {
        tableCell.setOnMousePressed((EventHandler)new C(this, tableCell));
    }
    
    private StringConverter<String> d() {
        return new D(this);
    }
    
    private FileChooser e() {
        if (this.a == null) {
            this.a = new FileChooser();
            final ArrayList<String> list = new ArrayList<String>();
            list.add("*.txt");
            this.a.getExtensionFilters().add((Object)new FileChooser.ExtensionFilter("\u6587\u672c\u6587\u4ef6(*.txt)", (List)list));
            this.a.setInitialDirectory(new File("./"));
            this.a.setInitialFileName("\u8054\u7cfb\u4eba\u5bfc\u5165\u6a21\u677f.txt");
        }
        return this.a;
    }
    
    @Override
    public void afterPropertySet() {
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    static {
        PassengerController.b = j.a(PassengerController.class);
    }
}
