// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class E implements EventHandler<ActionEvent>
{
    final /* synthetic */ SettingController a;
    
    E(final SettingController a) {
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        this.a.useEmail.setSelected(false);
        this.a.fxusername.setDisable(!this.a.useFeixin.isSelected());
        this.a.fxpassword.setDisable(!this.a.useFeixin.isSelected());
        this.a.testSms.setDisable(!this.a.useFeixin.isSelected());
    }
}
