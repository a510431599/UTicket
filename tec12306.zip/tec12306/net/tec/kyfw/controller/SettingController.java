// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.control.dialog.Tooltips;
import net.tec.kyfw.a.i;
import javafx.scene.input.MouseEvent;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.stage.WindowEvent;
import javafx.collections.ObservableMap;
import javafx.scene.Node;
import javafx.scene.input.Mnemonic;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyCode;
import javafx.collections.FXCollections;
import javafx.event.EventHandler;
import javafx.scene.control.Tooltip;
import java.io.File;
import net.tec.kyfw.util.p;
import net.tec.kyfw.e;
import javafx.beans.property.Property;
import javafx.controller.a;
import javafx.stage.FileChooser;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Button;
import javafx.control.field.SpinnerLongField;
import javafx.scene.layout.VBox;
import javafx.control.pane.FramePane;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;

public class SettingController extends AbstractController
{
    @FXML
    public StackPane root;
    @FXML
    public FramePane framePane;
    @FXML
    public VBox menuArea;
    @FXML
    public SpinnerLongField queryInterval;
    @FXML
    public Button close;
    @FXML
    public CheckBox submitOption;
    @FXML
    public CheckBox autoVerifyCode;
    @FXML
    public CheckBox transformOption;
    @FXML
    public ComboBox<String> chooseSeat;
    @FXML
    public CheckBox playMusic;
    @FXML
    public TextField music;
    @FXML
    public Button chooser;
    @FXML
    public CheckBox clearCache;
    @FXML
    public CheckBox useFeixin;
    @FXML
    public CheckBox useEmail;
    @FXML
    public TextField fxusername;
    @FXML
    public PasswordField fxpassword;
    @FXML
    public Button testSms;
    @FXML
    public TextField proxyHost;
    @FXML
    public TextField proxyPort;
    @FXML
    public ComboBox<String> dmPlatform;
    @FXML
    public TextField dmUserName;
    @FXML
    public PasswordField dmPassword;
    @FXML
    public TextField dmBalance;
    @FXML
    public Hyperlink dmReg;
    @FXML
    public Button dmRef;
    @FXML
    public Button dmTest;
    @FXML
    public Button dmRecharge;
    protected FileChooser a;
    
    @Override
    public void initialize() {
        final TicketController ticketController = javafx.controller.a.a(TicketController.class);
        this.submitOption.selectedProperty().bindBidirectional((Property)ticketController.submitOption.selectedProperty());
        this.autoVerifyCode.selectedProperty().bindBidirectional((Property)ticketController.autoVerifyCode.selectedProperty());
        this.playMusic.selectedProperty().bindBidirectional((Property)ticketController.playMusic.selectedProperty());
        this.transformOption.setSelected((boolean)e.a(e.a.TRANSFORMOPTION, true));
        this.clearCache.setSelected((boolean)e.a(e.a.CDN_OPTION, true));
        this.queryInterval.setValue(e.a(e.a.QUERY_INTERVAL, Long.valueOf(2000L)));
        final String a = e.a(e.a.MUSIC, "");
        if (p.b((Object)a) && new File(a).exists()) {
            this.music.setText(a);
        }
        else {
            e.a(e.a.MUSIC, (Object)null);
        }
        this.proxyHost.setText(e.a(e.a.PROXY_HOST, ""));
        this.proxyPort.setText(e.a(e.a.PROXY_PORT, ""));
        this.chooseSeat.setValue((Object)e.a(e.a.GT_CHOOSE_SEAT, "\u7cfb\u7edf\u968f\u673a"));
        this.a();
        this.useFeixin.setTooltip(new Tooltip("\u76ee\u524d\u53ea\u652f\u6301\u79fb\u52a8\u624b\u673a\u7528\u6237"));
        this.useFeixin.setOnAction((EventHandler)new E(this));
        this.useEmail.setOnAction((EventHandler)new F(this));
        this.testSms.setOnAction((EventHandler)new G(this));
        this.dmPlatform.setItems(FXCollections.observableArrayList((Object[])new String[] { "\u6253\u7801\u5154" }));
        this.b();
        this.dmReg.setOnAction(actionEvent -> new J(this).start());
        this.dmRef.setOnAction(actionEvent -> {
            if (p.a((Object)this.dmUserName.getText())) {
                return;
            }
            if (p.a((Object)this.dmPassword.getText())) {
                return;
            }
            if (!net.tec.kyfw.a.a.a()) {
                Tooltips.show(this.getWindow(), "\u8bf7\u5148\u70b9\u51fb\u6d4b\u8bd5\u6309\u94ae\uff01");
                return;
            }
            new Thread((Runnable)new K(this)).start();
        });
        this.dmRecharge.setOnAction(actionEvent -> new L(this).start());
        this.dmTest.setOnAction((EventHandler)new M(this));
        this.chooser.setOnAction((EventHandler)new O(this));
        this.transformOption.selectedProperty().addListener((observableValue, b, b2) -> e.a(e.a.TRANSFORMOPTION, b2));
        this.clearCache.selectedProperty().addListener((observableValue, b, b2) -> {
            e.a(e.a.CDN_OPTION, b2);
            if (b2) {
                i.c();
            }
        });
        this.queryInterval.valueProperty().addListener((observableValue, n, n2) -> e.a(e.a.QUERY_INTERVAL, (Object)n2));
        this.chooseSeat.valueProperty().addListener((observableValue, s, s2) -> e.a(e.a.GT_CHOOSE_SEAT, (Object)s2));
        this.music.textProperty().addListener((observableValue, s, s2) -> e.a(e.a.MUSIC, (Object)(new File(s2).exists() ? s2 : null)));
        this.proxyHost.textProperty().addListener((observableValue, s, s2) -> e.a(e.a.PROXY_HOST, (Object)s2));
        this.proxyPort.textProperty().addListener((observableValue, s, s2) -> e.a(e.a.PROXY_PORT, (Object)s2));
        for (int i = this.menuArea.getChildren().size() - 1; i >= 0; --i) {
            final StackPane stackPane = (StackPane)this.menuArea.getChildren().get(i);
            stackPane.setOnMouseClicked(mouseEvent -> this.framePane.getSelectionModel().select(Integer.parseInt(stackPane.getUserData().toString())));
        }
        this.framePane.getSelectionModel().selectedIndexProperty().addListener((observableValue, n, n2) -> {
            final Node node = (Node)this.menuArea.getChildren().get(n2.intValue());
            final Node lookup = this.menuArea.lookup(".active");
            if (lookup.equals(node)) {
                return;
            }
            lookup.getStyleClass().remove((Object)"active");
            node.getStyleClass().add((Object)"active");
        });
        this.queryInterval.getEditer().setEditable(false);
        this.close.setOnAction(actionEvent -> this.getStage().hide());
    }
    
    private void a() {
        try {
            final String a = e.a(e.a.MSGAPI);
            if (p.b((Object)a)) {
                final String[] split = a.split(",");
                if ("1".equals(split[0])) {
                    this.useFeixin.setSelected(true);
                    this.fxusername.setDisable(false);
                    this.fxpassword.setDisable(false);
                    this.testSms.setDisable(false);
                }
                else if ("2".equals(split[0])) {
                    this.useFeixin.setSelected(true);
                    this.fxusername.setDisable(false);
                    this.fxpassword.setDisable(false);
                    this.testSms.setDisable(false);
                }
                this.fxusername.setText(split[1]);
                this.fxpassword.setText(split[2]);
            }
        }
        catch (Exception ex) {
            e.a(e.a.MSGAPI, (Object)null);
        }
    }
    
    private void b() {
        try {
            final String a = e.a(e.a.DM_ACCOUNT);
            if (p.b((Object)a)) {
                final String[] split = a.split(",");
                this.dmPlatform.setValue((Object)split[0]);
                this.dmUserName.setText(split[1]);
                this.dmPassword.setText(split[2]);
                if (net.tec.kyfw.a.a.a()) {
                    this.dmRef.fire();
                }
            }
            else {
                this.dmPlatform.setValue((Object)"\u6253\u7801\u5154");
            }
        }
        catch (Exception ex) {
            e.a(e.a.DM_ACCOUNT, (Object)null);
        }
    }
    
    private void c() {
        if (p.b((Object)this.fxusername.getText()) && p.b((Object)this.fxpassword.getText())) {
            e.a(e.a.MSGAPI, (Object)((this.useFeixin.isSelected() ? "1" : (this.useEmail.isSelected() ? "2" : "0")) + "," + (this.fxusername.getText().trim() + "," + this.fxpassword.getText().trim())));
        }
        else {
            e.a(e.a.MSGAPI, (Object)null);
        }
        if (p.b((Object)this.dmUserName.getText()) && p.b((Object)this.dmPassword.getText())) {
            e.a(e.a.DM_ACCOUNT, (Object)((String)this.dmPlatform.getValue() + "," + (this.dmUserName.getText().trim() + "," + this.dmPassword.getText().trim())));
        }
        else {
            net.tec.kyfw.a.a.b();
            e.a(e.a.DM_ACCOUNT, (Object)null);
        }
    }
    
    @Override
    public void afterPropertySet() {
        this.getStage().setOnHiding(windowEvent -> this.c());
        final KeyCodeCombination keyCodeCombination = new KeyCodeCombination(KeyCode.C, new KeyCombination.Modifier[] { KeyCombination.ALT_DOWN });
        final KeyCodeCombination keyCodeCombination2 = new KeyCodeCombination(KeyCode.ENTER, new KeyCombination.Modifier[0]);
        final ObservableMap accelerators = this.getScene().getAccelerators();
        this.getScene().addMnemonic(new Mnemonic((Node)this.close, (KeyCombination)keyCodeCombination));
        accelerators.put((Object)keyCodeCombination2, (Object)new P(this));
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
}
