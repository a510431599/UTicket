// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.util.StringConverter;

class D extends StringConverter<String>
{
    final /* synthetic */ PassengerController a;
    
    D(final PassengerController a) {
        this.a = a;
    }
    
    public String a(final String s) {
        return s;
    }
    
    public String b(final String s) {
        return s;
    }
}
