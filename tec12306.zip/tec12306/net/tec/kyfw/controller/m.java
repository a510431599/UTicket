// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.event.Event;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.util.p;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class M implements EventHandler<ActionEvent>
{
    final /* synthetic */ SettingController a;
    
    M(final SettingController a) {
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        if (p.a((Object)this.a.dmUserName.getText())) {
            Tooltips.show(this.a.getWindow(), "\u8bf7\u8f93\u5165\u8d26\u53f7\uff01");
            this.a.dmUserName.requestFocus();
            return;
        }
        if (p.a((Object)this.a.dmPassword.getText())) {
            Tooltips.show(this.a.getWindow(), "\u8bf7\u8f93\u5165\u8d26\u53f7\u5bc6\u7801\uff01");
            this.a.dmPassword.requestFocus();
            return;
        }
        this.a.dmTest.setDisable(true);
        this.a.dmUserName.requestFocus();
        new Thread((Runnable)new N(this)).start();
    }
}
