// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.util.DateUtil;
import java.time.LocalDate;
import javafx.control.pane.Scrollbar;

class ab extends Scrollbar.ScrollbarConverter<LocalDate>
{
    final /* synthetic */ TicketController a;
    
    ab(final TicketController a) {
        this.a = a;
    }
    
    public String a(final LocalDate localDate) {
        if (localDate != null) {
            return DateUtil.b(localDate);
        }
        return "";
    }
}
