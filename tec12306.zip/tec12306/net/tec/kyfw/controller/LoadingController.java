// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.application.Platform;
import net.tec.kyfw.App;
import java.awt.SystemTray;
import net.tec.kyfw.f;
import javafx.stage.WindowEvent;
import javafx.scene.Node;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.controller.AbstractController;

public class LoadingController extends AbstractController
{
    @FXML
    public Pane root;
    @FXML
    public Label loadState;
    @FXML
    public Label logoText;
    @FXML
    public ProgressBar progressBar;
    
    @Override
    public void initialize() {
        ((Label)this.logoText.getGraphic()).setText("version 3.0.0.1014");
    }
    
    @Override
    public void afterPropertySet() {
        this.getStage().setOnCloseRequest(windowEvent -> {
            f.q();
            SystemTray.getSystemTray().remove(App.a);
            Platform.setImplicitExit(true);
            Platform.exit();
        });
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
}
