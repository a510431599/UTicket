// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.scene.input.MouseEvent;
import javafx.scene.control.TableCell;
import javafx.beans.value.ObservableValue;
import net.tec.kyfw.d.j;
import net.tec.kyfw.d.e;
import net.tec.kyfw.d.g;
import java.util.HashSet;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.control.dialog.Dialogs;
import net.tec.kyfw.e.n;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.f;
import javafx.scene.control.Tooltip;
import javafx.scene.Node;
import java.util.List;
import net.tec.kyfw.c.h;
import javafx.util.StringConverter;
import net.tec.kyfw.util.DateUtil;
import java.time.LocalDate;
import javafx.a.a;
import javafx.a.d;
import net.tec.kyfw.e.m;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.collections.FXCollections;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import net.tec.kyfw.d.c;
import javafx.control.pane.TablePane;
import javafx.control.pane.FramePane;
import javafx.scene.control.Label;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;

public class OrderController extends AbstractController
{
    @FXML
    StackPane root;
    @FXML
    public Hyperlink refresh;
    @FXML
    public ComboBox<String> account;
    @FXML
    public Label noCompleteButton;
    @FXML
    public Label myOrderButton;
    @FXML
    public FramePane framePane;
    @FXML
    public TablePane<c> orderTable;
    @FXML
    public VBox ticketResult;
    @FXML
    public GridPane tickets;
    @FXML
    public Button buttonPay;
    @FXML
    public Button buttonCancel;
    @FXML
    public Label orderId;
    @FXML
    public Label ticketCount;
    @FXML
    public Label ticketTotalPrice;
    @FXML
    public Label ticketStatus;
    @FXML
    public Label trainDate;
    @FXML
    public Label fromStationName;
    @FXML
    public Label toStationName;
    @FXML
    public Label noresult;
    @FXML
    public StackPane overlay;
    @FXML
    public ComboBox<String> queryType;
    @FXML
    public DatePicker startDate;
    @FXML
    public DatePicker endDate;
    @FXML
    public TextField keywords;
    @FXML
    public Button buttonQuery;
    @FXML
    public Button buttonResign;
    @FXML
    public Button buttonReturn;
    
    @Override
    public void initialize() {
        this.noCompleteButton.setOnMouseClicked(mouseEvent -> {
            this.myOrderButton.getStyleClass().remove((Object)"frame-title-active");
            this.noCompleteButton.getStyleClass().remove((Object)"frame-title-active");
            this.noCompleteButton.getStyleClass().add((Object)"frame-title-active");
            this.framePane.getSelectionModel().select(Integer.parseInt(this.noCompleteButton.getUserData().toString()));
        });
        this.myOrderButton.setOnMouseClicked(mouseEvent -> {
            this.noCompleteButton.getStyleClass().remove((Object)"frame-title-active");
            this.myOrderButton.getStyleClass().remove((Object)"frame-title-active");
            this.myOrderButton.getStyleClass().add((Object)"frame-title-active");
            this.framePane.getSelectionModel().select(Integer.parseInt(this.myOrderButton.getUserData().toString()));
        });
        final String[] array = { "\u9009\u62e9", "\u8ba2\u5355\u53f7", "\u8f66\u6b21\u4fe1\u606f", "\u5e2d\u4f4d\u4fe1\u606f", "\u65c5\u5ba2\u4fe1\u606f", "\u7968\u6b3e\u91d1\u989d", "\u8f66\u7968\u72b6\u6001", "\u64cd\u4f5c" };
        final double[] array2 = { 1.0, 1.5, 2.0, 2.0, 2.0, 1.5, 1.5, 2.0 };
        final String[] array3 = { "index", "sequenceNo", "trainInfo", "seatInfo", "passengerInfo", "ticketInfo", "status", "ticketkey" };
        final ObservableList observableArrayList = FXCollections.observableArrayList();
        for (int i = 0; i < array3.length; ++i) {
            final TablePane.Column column = new TablePane.Column();
            column.setAlign(Pos.CENTER);
            column.setField(array3[i]);
            column.setText(array[i]);
            column.setWidth(array2[i]);
            observableArrayList.add((Object)column);
        }
        ((TablePane.Column)observableArrayList.get(0)).setTableCellFactory(() -> new o(this));
        ((TablePane.Column)observableArrayList.get(observableArrayList.size() - 1)).setTableCellFactory(() -> new p(this));
        this.orderTable.setTableColumn((javafx.collections.ObservableList<TablePane.Column<c>>)observableArrayList);
        final m m = d.a((Class<? extends a<Object>>)m.class);
        this.orderTable.setPlaceholder("\u8bf7\u70b9\u51fb\u67e5\u8be2\u6309\u94ae\u67e5\u8be2\u5df2\u5b8c\u6210\u7684\u8ba2\u5355");
        this.orderTable.setFixedCellSize(40.0);
        this.startDate.setEditable(false);
        this.endDate.setEditable(false);
        this.startDate.setValue((Object)LocalDate.now());
        this.endDate.setValue((Object)DateUtil.b().toLocalDate());
        this.startDate.setConverter((StringConverter)new q(this));
        this.endDate.setConverter((StringConverter)new r(this));
        this.queryType.valueProperty().addListener((observableValue, s, s2) -> {
            if (s2.equals("\u6309\u4e58\u8f66\u65e5\u671f\u67e5\u8be2")) {
                this.startDate.setValue((Object)LocalDate.now());
                this.endDate.setValue((Object)DateUtil.b().toLocalDate());
            }
            else {
                this.startDate.setValue((Object)LocalDate.now().plusDays(-29L));
                this.endDate.setValue((Object)LocalDate.now());
            }
        });
        this.refresh.setOnAction(actionEvent -> this.a());
        this.account.getSelectionModel().selectedItemProperty().addListener((observableValue, s, s2) -> {
            if (s2 != null) {
                if (this.framePane.getSelectionModel().getSelectedIndex() == 0) {
                    this.a();
                }
                else {
                    this.buttonQuery.fire();
                }
            }
            else if (this.orderTable.getItems() != null) {
                this.orderTable.getItems().clear();
            }
        });
        this.buttonPay.setOnAction(actionEvent -> this.a(this.orderId.getText(), (String)this.buttonPay.getUserData()));
        this.buttonCancel.setOnAction(actionEvent -> this.a(this.orderId.getText()));
        this.buttonQuery.setOnAction(actionEvent -> {
            if (this.account.getValue() == null || !f.a((String)this.account.getValue()).i()) {
                Tooltips.show(this.getWindow(), "\u60a8\u672a\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u4e0d\u80fd\u6267\u884c\u6b64\u64cd\u4f5c\uff01");
                return;
            }
            m.a(f.a((String)this.account.getValue()), ((String)this.queryType.getValue()).equals("\u6309\u4e58\u8f66\u65e5\u671f\u67e5\u8be2") ? "2" : "1", DateUtil.a((LocalDate)this.startDate.getValue(), "yyyy-MM-dd"), DateUtil.a((LocalDate)this.endDate.getValue(), "yyyy-MM-dd"), (this.keywords.getText() != null) ? this.keywords.getText() : "");
            m.start();
        });
        this.buttonResign.setOnAction(actionEvent -> {
            if (this.account.getValue() == null || !f.a((String)this.account.getValue()).i()) {
                Tooltips.show(this.getWindow(), "\u60a8\u672a\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u4e0d\u80fd\u6267\u884c\u6b64\u64cd\u4f5c\uff01");
                return;
            }
            if (this.orderTable.getItems() == null || this.orderTable.getItems().isEmpty()) {
                Tooltips.show(this.getWindow(), "\u8bf7\u9009\u62e9\u60a8\u8981\u6539\u7b7e\u7684\u8f66\u7968");
                return;
            }
            final ArrayList<c> list = new ArrayList<c>();
            final HashSet<String> set = new HashSet<String>();
            for (int i = 0; i < this.orderTable.getItems().size(); ++i) {
                if (((c)this.orderTable.getItems().get(i)).isChecked()) {
                    set.add(((c)this.orderTable.getItems().get(i)).getSequenceNo());
                    list.add((c)this.orderTable.getItems().get(i));
                }
            }
            if (set.size() != 1) {
                Tooltips.show(this.getWindow(), "\u8bf7\u9009\u62e9\u60a8\u8981\u6539\u7b7e\u7684\u8f66\u7968\uff0c\u4e14\u6240\u9009\u8f66\u7968\u8ba2\u5355\u53f7\u5fc5\u987b\u4e00\u81f4\uff01");
                return;
            }
            if (Integer.valueOf(Dialogs.create().owner(this.getWindow()).message("\u60a8\u786e\u5b9a\u8981\u6539\u7b7e\uff08\u53d8\u66f4\u5230\u7ad9\uff09\u5417\uff1f\u5982\u6709\u8ba2\u9910\uff0c\u8bf7\u6309\u89c4\u5b9a\u5230\u7f51\u7ad9\u81ea\u884c\u529e\u7406\u9000\u9910\u3002").confirmAndWait()) == 0) {
                return;
            }
            final TaskController taskController = javafx.controller.a.a(TaskController.class);
            final net.tec.kyfw.d.a a = taskController.a.a(f.a((String)this.account.getValue()).g());
            if (a != null) {
                final net.tec.kyfw.e.r r = d.a((Class<? extends a<Object>>)net.tec.kyfw.e.r.class, a.getAccount());
                if (r.isRunning()) {
                    r.cancel();
                }
                taskController.a.c(a);
            }
            final ObservableList observableArrayList = FXCollections.observableArrayList();
            final StringBuffer sb = new StringBuffer();
            for (int j = 0; j < list.size(); ++j) {
                final c c = list.get(j);
                observableArrayList.add((Object)new net.tec.kyfw.d.d(c.getName(), c.getCardType(), c.getCardCode(), c.getPassengerType()));
                sb.append(c.getTicketkey());
            }
            final net.tec.kyfw.d.a a2 = new net.tec.kyfw.d.a(f.a((String)this.account.getValue()).g(), f.a((String)this.account.getValue()).h(), list.get(0).getTrainDate(), list.get(0).getFromStationName(), list.get(0).getToStationName(), list.get(0).getFromStationTelecode(), list.get(0).getToStationTelecode(), "00:00--24:00", "\u5e2d\u522b\u4f18\u5148", false, true, null, null, (ObservableList<net.tec.kyfw.d.d>)observableArrayList, null, (ObservableList<g>)FXCollections.observableArrayList((Object[])new g[] { new g(list.get(0).getStationTrainCode()) }), false, 0L);
            a2.setChangeTSFlag("N");
            a2.setFlag("resign");
            a2.setSequenceNo(list.get(0).getSequenceNo());
            a2.setTicketkey(sb.toString());
            taskController.a.a(a2, Boolean.valueOf(true));
            javafx.controller.a.a(MainController.class).framePane.getSelectionModel().select(1);
        });
        this.buttonReturn.setOnAction(actionEvent -> {
            if (this.account.getValue() == null || !f.a((String)this.account.getValue()).i()) {
                Tooltips.show(this.getWindow(), "\u60a8\u672a\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u4e0d\u80fd\u6267\u884c\u6b64\u64cd\u4f5c\uff01");
                return;
            }
            if (this.orderTable.getItems() == null || this.orderTable.getItems().isEmpty()) {
                Tooltips.show(this.getWindow(), "\u8bf7\u9009\u62e9\u60a8\u8981\u53d8\u66f4\u5230\u7ad9\u7684\u8f66\u7968");
                return;
            }
            final ArrayList<c> list = new ArrayList<c>();
            final HashSet<String> set = new HashSet<String>();
            for (int i = 0; i < this.orderTable.getItems().size(); ++i) {
                if (((c)this.orderTable.getItems().get(i)).isChecked()) {
                    set.add(((c)this.orderTable.getItems().get(i)).getSequenceNo());
                    list.add((c)this.orderTable.getItems().get(i));
                }
            }
            if (set.size() != 1) {
                Tooltips.show(this.getWindow(), "\u8bf7\u9009\u62e9\u60a8\u8981\u53d8\u66f4\u5230\u7ad9\u7684\u8f66\u7968\uff0c\u4e14\u6240\u9009\u8f66\u7968\u8ba2\u5355\u53f7\u5fc5\u987b\u4e00\u81f4\uff01");
                return;
            }
            if (Integer.valueOf(Dialogs.create().owner(this.getWindow()).message("\u60a8\u786e\u5b9a\u8981\u6539\u7b7e\uff08\u53d8\u66f4\u5230\u7ad9\uff09\u5417\uff1f\u5982\u6709\u8ba2\u9910\uff0c\u8bf7\u6309\u89c4\u5b9a\u5230\u7f51\u7ad9\u81ea\u884c\u529e\u7406\u9000\u9910\u3002").confirmAndWait()) == 0) {
                return;
            }
            final TaskController taskController = javafx.controller.a.a(TaskController.class);
            final net.tec.kyfw.d.a a = taskController.a.a(f.a((String)this.account.getValue()).g());
            if (a != null) {
                final net.tec.kyfw.e.r r = d.a((Class<? extends a<Object>>)net.tec.kyfw.e.r.class, a.getAccount());
                if (r.isRunning()) {
                    r.cancel();
                }
                taskController.a.c(a);
            }
            final ObservableList observableArrayList = FXCollections.observableArrayList();
            final StringBuffer sb = new StringBuffer();
            for (int j = 0; j < list.size(); ++j) {
                final c c = list.get(j);
                observableArrayList.add((Object)new net.tec.kyfw.d.d(c.getName(), c.getCardType(), c.getCardCode(), c.getPassengerType()));
                sb.append(c.getTicketkey());
            }
            final net.tec.kyfw.d.a a2 = new net.tec.kyfw.d.a(f.a((String)this.account.getValue()).g(), f.a((String)this.account.getValue()).h(), list.get(0).getTrainDate(), list.get(0).getFromStationName(), list.get(0).getToStationName(), list.get(0).getFromStationTelecode(), list.get(0).getToStationTelecode(), "00:00--24:00", "\u5e2d\u522b\u4f18\u5148", false, true, null, null, (ObservableList<net.tec.kyfw.d.d>)observableArrayList, null, (ObservableList<g>)FXCollections.observableArrayList((Object[])new g[] { new g(list.get(0).getStationTrainCode()) }), false, 0L);
            a2.setChangeTSFlag("Y");
            a2.setFlag("resign");
            a2.setSequenceNo(list.get(0).getSequenceNo());
            a2.setTicketkey(sb.toString());
            taskController.a.a(a2, Boolean.valueOf(true));
            javafx.controller.a.a(MainController.class).framePane.getSelectionModel().select(1);
        });
    }
    
    public void a(final h.a a) {
        this.orderId.setText(a.a("orderId"));
        this.ticketCount.setText(a.a("ticketCount") + "\u5f20");
        this.ticketTotalPrice.setText(a.a("ticketTotalPrice"));
        this.trainDate.setText(a.a("trainDate"));
        this.fromStationName.setText(a.a("fromStationName"));
        this.toStationName.setText(a.a("toStationName"));
        final List<h.a> list = a.c("tickets");
        this.tickets.getChildren().clear();
        final String[] array = { "train", "seat", "passenger" };
        for (int i = 0; i < list.size(); ++i) {
            final h.a a2 = list.get(i);
            for (int j = 0; j < array.length; ++j) {
                final Label label = new Label(a2.a(array[j]));
                label.getStyleClass().add((Object)"grid-value");
                GridPane.setRowIndex((Node)label, i);
                GridPane.setColumnIndex((Node)label, j);
                this.tickets.getChildren().add((Object)label);
            }
        }
        if (a.d("waitTime")) {
            this.ticketStatus.setText(a.a("ticketStatus"));
        }
        else {
            final String a3 = net.tec.kyfw.util.r.a(a.b("waitTime"));
            this.ticketStatus.setText(net.tec.kyfw.util.p.a((Object)a3) ? a.a("ticketStatus") : a3);
        }
        this.ticketStatus.setTooltip(new Tooltip(this.ticketStatus.getText()));
    }
    
    private void a() {
        final int selectedIndex = this.framePane.getSelectionModel().getSelectedIndex();
        if (this.account.getValue() == null || !f.a((String)this.account.getValue()).i()) {
            Tooltips.show(this.getWindow(), "\u60a8\u672a\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u4e0d\u80fd\u6267\u884c\u6b64\u64cd\u4f5c\uff01");
            return;
        }
        if (selectedIndex == 0) {
            final n n = d.a((Class<? extends a<Object>>)n.class);
            n.a(f.a((String)this.account.getValue()));
            n.start();
        }
        else {
            this.buttonQuery.fire();
        }
    }
    
    private void a(final String s, final String s2) {
        new Thread((Runnable)new s(this, s, s2)).start();
    }
    
    public void a(final String s) {
        String s2;
        if ("--".equals(s)) {
            s2 = "\u786e\u5b9a\u53d6\u6d88\u6392\u961f\u4e2d\u7684\u8ba2\u5355?";
        }
        else {
            s2 = "\u786e\u8ba4\u53d6\u6d88\u8be5\u7b14\u8ba2\u5355?\r\n\u4e00\u5929\u51853\u6b21\u7533\u8bf7\u8f66\u7968\u6210\u529f\u540e\u53d6\u6d88\u8ba2\u5355\uff0c\u5f53\u65e5\u5c06\u4e0d\u80fd\u5728\u7f51\u7ad9\u8d2d\u7968\u3002";
        }
        if (Integer.valueOf(Dialogs.create().owner(this.getWindow()).title("\u786e\u8ba4\u4fe1\u606f").message(s2).confirmAndWait()) == 1) {
            new Thread((Runnable)new t(this, s)).start();
        }
    }
    
    @Override
    public void afterPropertySet() {
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
}
