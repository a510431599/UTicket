// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.application.Platform;
import javafx.event.Event;
import net.tec.kyfw.App;
import net.tec.kyfw.e.h;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.a.d;
import net.tec.kyfw.e.r;
import javafx.control.dialog.Dialogs;
import org.apache.http.client.CookieStore;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.cookie.BasicClientCookie;
import java.util.ArrayList;
import net.tec.kyfw.e;
import javafx.scene.input.MouseEvent;
import javafx.geometry.Rectangle2D;
import javafx.stage.Stage;
import javafx.stage.Screen;
import javafx.controller.a;
import javafx.stage.Window;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;
import net.tec.kyfw.util.o;
import javafx.scene.Node;
import net.tec.kyfw.util.f;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.control.dialog.Popups;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.control.pane.FramePane;
import javafx.scene.layout.GridPane;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;

public class MainController extends AbstractController
{
    @FXML
    public StackPane rootWarp;
    @FXML
    public StackPane root;
    @FXML
    public StackPane title;
    @FXML
    public GridPane buttonArea;
    @FXML
    public GridPane menuArea;
    @FXML
    public StackPane login;
    @FXML
    public FramePane framePane;
    @FXML
    public StackPane set;
    @FXML
    public StackPane minimize;
    @FXML
    public StackPane maximize;
    @FXML
    public StackPane close;
    @FXML
    public Label version;
    @FXML
    public StackPane bodyOverlay;
    @FXML
    public StackPane overlay;
    @FXML
    public StackPane bottom;
    @FXML
    public BottomController bottomController;
    @FXML
    public StackPane passenger;
    @FXML
    public PassengerController passengerController;
    @FXML
    public StackPane ticket;
    @FXML
    public TicketController ticketController;
    @FXML
    public StackPane task;
    @FXML
    public TaskController taskController;
    @FXML
    public StackPane buy;
    @FXML
    public BuyController buyController;
    @FXML
    public StackPane order;
    @FXML
    public OrderController orderController;
    @FXML
    public Hyperlink register;
    public Popups a;
    public Popups b;
    private double d;
    private double e;
    boolean c;
    
    public MainController() {
        this.c = false;
    }
    
    @Override
    public void initialize() {
        this.minimize.setOnMouseClicked(mouseEvent -> this.getStage().hide());
        this.close.setOnMouseClicked(mouseEvent -> {
            if (!Boolean.valueOf(App.a(null, this.getStage()))) {
                return;
            }
            Platform.setImplicitExit(true);
            this.getStage().hide();
        });
        this.maximize.setOnMouseClicked(mouseEvent -> this.b());
        this.title.setOnMousePressed((EventHandler)this.c());
        this.title.setOnMouseDragged((EventHandler)this.d());
        this.title.setOnMouseClicked(mouseEvent -> {
            if (mouseEvent.getClickCount() == 2) {
                this.b();
            }
        });
        this.buttonArea.setOnMouseClicked(mouseEvent -> mouseEvent.consume());
        this.buttonArea.setOnMouseDragged(mouseEvent -> mouseEvent.consume());
        this.menuArea.setOnMouseClicked(mouseEvent -> mouseEvent.consume());
        this.menuArea.setOnMouseDragged(mouseEvent -> mouseEvent.consume());
        for (int i = this.menuArea.getChildren().size() - 2; i >= 0; --i) {
            final StackPane stackPane = (StackPane)this.menuArea.getChildren().get(i);
            stackPane.setOnMouseClicked(mouseEvent -> {
                if ("0".equals(stackPane.getUserData().toString()) && net.tec.kyfw.e.a) {
                    this.framePane.getSelectionModel().select(4);
                }
                else {
                    this.framePane.getSelectionModel().select(Integer.parseInt(stackPane.getUserData().toString()));
                }
            });
        }
        this.framePane.getSelectionModel().selectedIndexProperty().addListener((observableValue, n, n2) -> {
            int intValue = n2.intValue();
            if (intValue == 4) {
                intValue = 0;
            }
            final Node node = (Node)this.menuArea.getChildren().get(intValue);
            final Node lookup = this.menuArea.lookup(".menu-item-active");
            if (lookup.equals(node)) {
                return;
            }
            lookup.getStyleClass().remove((Object)"menu-item-active");
            node.getStyleClass().add((Object)"menu-item-active");
        });
        this.login.setOnMouseClicked(mouseEvent -> {
            if (net.tec.kyfw.e.a) {
                return;
            }
            if (((Label)this.login.getChildren().get(0)).getText().equals("\u9000\u51fa\u767b\u5f55")) {
                final TaskController taskController = javafx.controller.a.a(TaskController.class);
                final net.tec.kyfw.d.a a = taskController.a.a(net.tec.kyfw.f.b().g());
                Integer n;
                if (a != null && ("\u6b63\u5728\u8fd0\u884c".equals(a.getTaskState()) || "\u5b9a\u65f6\u5237\u65b0".equals(a.getTaskState()))) {
                    n = Dialogs.create().owner((Window)this.getStage()).title("\u786e\u8ba4\u63d0\u793a").message("\u5f53\u524d\u767b\u5f55\u8d26\u53f7\u6b63\u5728\u5237\u7968\u4e2d\uff0c\u786e\u8ba4\u6ce8\u9500\u672c\u6b21\u4f1a\u8bdd\uff1f").confirmAndWait();
                }
                else {
                    n = Dialogs.create().owner((Window)this.getStage()).title("\u786e\u8ba4\u63d0\u793a").message("\u60a8\u5df2\u767b\u5f55\u672c\u7cfb\u7edf\uff0c\u786e\u8ba4\u6ce8\u9500\u672c\u6b21\u4f1a\u8bdd\uff1f").confirmAndWait();
                }
                if (n == 1) {
                    if (a != null) {
                        if ("\u6b63\u5728\u8fd0\u884c".equals(a.getTaskState()) || "\u5b9a\u65f6\u5237\u65b0".equals(a.getTaskState())) {
                            final r r = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)r.class, a.getAccount());
                            if (r.isRunning()) {
                                r.cancel();
                            }
                        }
                        taskController.a.c(a);
                    }
                    if (net.tec.kyfw.f.b().g().equals(this.passengerController.account.getValue())) {
                        this.passengerController.account.setValue((Object)null);
                    }
                    this.passengerController.account.getItems().remove((Object)net.tec.kyfw.f.b().g());
                    if (!net.tec.kyfw.f.b().g().equals(this.passengerController.account.getValue())) {
                        this.ticketController.priorRider.setOptions((javafx.collections.ObservableList<net.tec.kyfw.d.d>)FXCollections.observableArrayList());
                        this.ticketController.riderShow.removeAll();
                    }
                    final h h = javafx.a.d.a((Class<? extends javafx.a.a<Object>>)h.class);
                    h.a(net.tec.kyfw.f.b());
                    h.start();
                }
            }
            else {
                this.a.setArguments(net.tec.kyfw.f.b()).show();
            }
        });
        this.orderController.account.itemsProperty().bind((ObservableValue)this.passengerController.account.itemsProperty());
        this.set.setOnMouseClicked(mouseEvent -> this.a(0));
        this.register.setOnMouseClicked(mouseEvent -> {
            try {
                final FXMLLoader fxmlLoader = new FXMLLoader(o.c("/res/fxml/register.fxml"));
                final Parent parent = (Parent)fxmlLoader.load();
                fxmlLoader.getController();
                Popups.create().title("\u6ce8\u518c\u8f6f\u4ef6").owner((Window)this.getStage()).content((Node)parent).size(380.0).show();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        if (f.b()) {
            this.register.setText("\u5df2\u6388\u6743");
        }
        this.version.setText("version 3.0.0.1014");
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    @Override
    public void afterPropertySet() {
        try {
            final FXMLLoader fxmlLoader = new FXMLLoader(o.c("/res/fxml/login.fxml"));
            final Parent parent = (Parent)fxmlLoader.load();
            fxmlLoader.getController();
            this.a = Popups.create().title("\u767b\u5f55\u7a97\u53e3").owner((Window)this.getStage()).content((Node)parent).size(400.0);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        this.a();
    }
    
    public void a(final int n) {
        if (this.b == null) {
            try {
                final FXMLLoader fxmlLoader = new FXMLLoader(o.c("/res/fxml/setting.fxml"));
                final Parent parent = (Parent)fxmlLoader.load();
                fxmlLoader.getController();
                this.b = Popups.create().title("\u8bbe\u7f6e\u7a97\u53e3").owner((Window)this.getStage()).content((Node)parent).size(480.0, 330.0);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        javafx.controller.a.a(SettingController.class).framePane.getSelectionModel().select(n);
        this.b.show();
    }
    
    private void b() {
        final Stage stage = this.getStage();
        if (this.c) {
            stage.setWidth(1042.0);
            stage.setHeight(678.0);
            stage.centerOnScreen();
            ((Node)this.maximize.getChildren().get(0)).getStyleClass().remove((Object)"restore");
            this.c = false;
        }
        else {
            ((Node)this.maximize.getChildren().get(0)).getStyleClass().add((Object)"restore");
            final Rectangle2D visualBounds = Screen.getPrimary().getVisualBounds();
            stage.setX(-10.0);
            stage.setY(-10.0);
            stage.setWidth(visualBounds.getWidth() + 20.0);
            stage.setHeight(visualBounds.getHeight() + 20.0);
            this.c = true;
        }
    }
    
    private EventHandler<MouseEvent> c() {
        return (EventHandler<MouseEvent>)(mouseEvent -> {
            this.d = mouseEvent.getSceneX();
            this.e = mouseEvent.getSceneY();
        });
    }
    
    private EventHandler<MouseEvent> d() {
        return (EventHandler<MouseEvent>)(mouseEvent -> {
            final Stage stage = this.getStage();
            if (this.c) {
                return;
            }
            stage.setX(mouseEvent.getScreenX() - this.d);
            stage.setY(mouseEvent.getScreenY() - this.e);
        });
    }
    
    public void a() {
        Boolean b = Boolean.TRUE;
        if (!net.tec.kyfw.e.e(net.tec.kyfw.e.a.COOKIES)) {
            final String[] split = net.tec.kyfw.e.a(net.tec.kyfw.e.a.COOKIES).split("@");
            final String[] split2 = split[0].split(",");
            final String[] split3 = split[1].split("\\|");
            final CookieStore t = net.tec.kyfw.f.b().t();
            final ArrayList<BasicClientCookie> list = new ArrayList<BasicClientCookie>();
            for (int i = 0; i < split3.length; ++i) {
                list.add(net.tec.kyfw.e.c(split3[i]));
            }
            if (!list.isEmpty()) {
                for (int j = 0; j < split3.length; ++j) {
                    t.addCookie((Cookie)list.get(j));
                }
                new Thread((Runnable)new m(this, split2)).start();
                b = Boolean.FALSE;
            }
            net.tec.kyfw.e.a(net.tec.kyfw.e.a.COOKIES, (Object)null);
        }
        if (b) {
            new Thread((Runnable)new n(this)).start();
        }
    }
}
