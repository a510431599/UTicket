// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import net.tec.kyfw.d.g;
import javafx.scene.control.TableCell;

class af extends TableCell<g, String>
{
    final /* synthetic */ String a;
    final /* synthetic */ TicketController b;
    
    af(final TicketController b, final String a) {
        this.b = b;
        this.a = a;
    }
    
    public void a(final String text, final boolean b) {
        super.updateItem((Object)text, b);
        this.getStyleClass().remove((Object)"prior");
        this.getStyleClass().remove((Object)"discount");
        this.getStyleClass().remove((Object)"wp");
        this.getStyleClass().remove((Object)"yp");
        this.setText(text);
        if (!b) {
            if (text.equals("\u65e0") || text.equals("--") || text.equals("*")) {
                this.getStyleClass().add((Object)"wp");
            }
            else {
                if ("\u6709".equals(text)) {
                    this.getStyleClass().add((Object)"yp");
                }
                if (((g)this.getTableView().getItems().get(this.getIndex())).invoke(g.methods_disc.get(this.a))) {
                    this.getStyleClass().add((Object)"discount");
                }
                if (this.b.seatShow.contains(this.a) && (this.b.submitOption.isSelected() || "\u6709".equals(text) || Integer.parseInt(text) >= this.b.riderShow.size()) && ((g)this.getTableView().getItems().get(this.getIndex())).getPriorTrain()) {
                    this.getStyleClass().add((Object)"prior");
                }
            }
        }
    }
}
