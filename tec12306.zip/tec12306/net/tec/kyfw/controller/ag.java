// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.scene.Node;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import net.tec.kyfw.d.g;
import javafx.scene.control.TableCell;

class ag extends TableCell<g, String>
{
    final /* synthetic */ TicketController a;
    
    ag(final TicketController a) {
        this.a = a;
    }
    
    public void a(final String s, final boolean b) {
        super.updateItem((Object)s, b);
        if (!b) {
            final g g = (g)this.getTableView().getItems().get(this.getIndex());
            if (("Y".equalsIgnoreCase(g.getCanWebBuy()) && s.equals("\u9884\u8ba2")) || g.isCanTimingBuy()) {
                final Button graphic = new Button(s);
                graphic.setStyle("-fx-text-fill:#c90000;-fx-pref-width:70;-fx-pref-height:25;");
                graphic.setOnAction((EventHandler)new ah(this, g));
                this.setText((String)null);
                this.setGraphic((Node)graphic);
            }
            else {
                this.setText(s);
                this.setGraphic((Node)null);
            }
        }
        else {
            this.setText(s);
            this.setGraphic((Node)null);
        }
    }
}
