// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.scene.input.MouseEvent;
import javafx.event.Event;
import javafx.control.bean.SelectedProperty;
import net.tec.kyfw.util.p;
import javafx.event.ActionEvent;
import javafx.application.Platform;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import javafx.control.dialog.Dialogs;
import net.tec.kyfw.util.o;
import java.time.LocalTime;
import net.tec.kyfw.e.b;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import javafx.scene.Node;
import javafx.scene.control.Tooltip;
import java.util.Collection;
import javafx.collections.FXCollections;
import net.tec.kyfw.util.r;
import javafx.control.Cascade;
import javafx.util.StringConverter;
import javafx.util.Callback;
import net.tec.kyfw.util.DateUtil;
import javafx.beans.value.ObservableValue;
import javafx.controller.a;
import javafx.stage.FileChooser;
import net.tec.kyfw.b.N;
import javafx.control.pane.ScrollContainer;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;
import javafx.control.pane.CheckBoxArea;
import javafx.control.pane.TagBox;
import net.tec.kyfw.d.j;
import net.tec.kyfw.d.e;
import javafx.control.combo.MultipleComboBox;
import javafx.control.field.SpinnerTimeField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import net.tec.kyfw.d.g;
import javafx.control.pane.TablePane;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import net.tec.kyfw.d.f;
import javafx.control.combo.CompleteComboBox;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;
import javafx.collections.ObservableList;
import net.tec.kyfw.d.d;
import javafx.collections.ListChangeListener;

class X implements ListChangeListener<d>
{
    final /* synthetic */ TaskController a;
    
    X(final TaskController a) {
        this.a = a;
    }
    
    public void onChanged(final ListChangeListener.Change<? extends d> change) {
        if (change.next() && this.a.c) {
            this.a.a.e().setPassengerList((ObservableList<d>)change.getList());
        }
    }
}
