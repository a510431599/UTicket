// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.controller.AbstractController;
import net.tec.kyfw.a.a;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;

class ac implements ChangeListener<Boolean>
{
    final /* synthetic */ TicketController a;
    
    ac(final TicketController a) {
        this.a = a;
    }
    
    public void a(final ObservableValue<? extends Boolean> observableValue, final Boolean b, final Boolean b2) {
        if (b2 && !net.tec.kyfw.a.a.a()) {
            javafx.controller.a.a(MainController.class).a(2);
        }
    }
}
