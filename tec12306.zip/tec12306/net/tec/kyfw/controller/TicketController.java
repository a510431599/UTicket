// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.a.d;
import javafx.control.dialog.Dialogs;
import javafx.scene.input.PickResult;
import javafx.scene.input.MouseButton;
import javafx.event.Event;
import net.tec.kyfw.e.i;
import net.tec.kyfw.e.q;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.TableCell;
import javafx.control.dialog.Tooltips;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import javafx.application.Platform;
import net.tec.kyfw.util.b;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.a.a;
import net.tec.kyfw.e.v;
import net.tec.kyfw.util.DateUtil;
import javafx.scene.control.Tooltip;
import net.tec.kyfw.util.r;
import javafx.control.Cascade;
import javafx.util.StringConverter;
import javafx.util.Callback;
import javafx.collections.ObservableList;
import java.util.Collection;
import javafx.collections.FXCollections;
import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;
import java.util.List;
import javafx.beans.property.StringProperty;
import javafx.scene.control.Button;
import java.time.LocalDate;
import javafx.control.pane.Scrollbar;
import javafx.control.pane.TagBox;
import net.tec.kyfw.d.j;
import net.tec.kyfw.d.dProperty;
import net.tec.kyfw.d.e;
import javafx.control.combo.MultipleComboBox;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import net.tec.kyfw.d.g;
import javafx.control.pane.TablePane;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import net.tec.kyfw.d.fProperty;
import javafx.control.combo.CompleteComboBox;
import javafx.scene.layout.VBox;
import javafx.fxml.FXML;
import javafx.scene.layout.StackPane;
import javafx.controller.AbstractController;

public class TicketController extends AbstractController
{
    @FXML
    public StackPane root;
    @FXML
    public VBox content;
    @FXML
    public CompleteComboBox<fProperty> fromStation;
    @FXML
    public CompleteComboBox<fProperty> toStation;
    @FXML
    public Label ticketExchange;
    @FXML
    public DatePicker trainDate;
    @FXML
    public TablePane<g> trainTable;
    @FXML
    public ComboBox<String> startTime;
    @FXML
    public ComboBox<String> endTime;
    @FXML
    public ComboBox<String> priorOption;
    @FXML
    public CheckBox trainClassAll;
    @FXML
    public CheckBox trainClassGC;
    @FXML
    public CheckBox trainClassD;
    @FXML
    public CheckBox trainClassZ;
    @FXML
    public CheckBox trainClassT;
    @FXML
    public CheckBox trainClassK;
    @FXML
    public CheckBox trainClassO;
    @FXML
    public CheckBox autoVerifyCode;
    @FXML
    public CheckBox submitOption;
    @FXML
    public CheckBox playMusic;
    @FXML
    public CheckBox showCanBuy;
    @FXML
    public MultipleComboBox<g> priorTrain;
    @FXML
    public MultipleComboBox<e> priorSeat;
    @FXML
    public MultipleComboBox<dProperty> priorRider;
    @FXML
    public MultipleComboBox<j> priorDates;
    @FXML
    public TagBox<g> trainShow;
    @FXML
    public TagBox<e> seatShow;
    @FXML
    public TagBox<dProperty> riderShow;
    @FXML
    public TagBox<j> datesShow;
    @FXML
    public Scrollbar<LocalDate> timesRotate;
    @FXML
    public Button buttonQuery;
    @FXML
    public Button buttonBrush;
    @FXML
    public StackPane overlay;
    @FXML
    public Label buyCancel;
    private StringProperty c;
    public List<String> a;
    public List<String> b;
    private String d;
    
    public TicketController() {
        this.c = (StringProperty)new SimpleStringProperty();
        this.a = new ArrayList<String>();
        this.b = new ArrayList<String>();
        this.d = "";
    }
    
    @Override
    public void initialize() {
        final ObservableList observableArrayList = FXCollections.observableArrayList((Collection)net.tec.kyfw.eMap.b);
        this.fromStation.setOptions((javafx.collections.ObservableList<fProperty>)observableArrayList);
        this.toStation.setOptions((javafx.collections.ObservableList<fProperty>)observableArrayList);
        this.ticketExchange.setOnMouseClicked(mouseEvent -> {
            final fProperty completeValue = (fProperty)this.fromStation.getValue();
            this.fromStation.setCompleteValue((fProperty)this.toStation.getValue());
            this.toStation.setCompleteValue(completeValue);
        });
        this.trainDate.setDayCellFactory((Callback)new Y(this));
        this.trainDate.setConverter((StringConverter)new aa(this));
        this.trainDate.getEditor().setOnMouseClicked(mouseEvent -> this.trainDate.show());
        this.priorTrain.bind(this.trainShow);
        this.priorSeat.bind(this.seatShow);
        this.priorSeat.setOptions((javafx.collections.ObservableList<e>)FXCollections.observableArrayList((Collection)r.a()));
        this.riderShow.setTooltip(new Tooltip("\u70b9\u51fb\u6b64\u533a\u57df\u6dfb\u52a0\u513f\u7ae5\u7968"));
        this.priorRider.bind(this.riderShow);
        this.priorDates.bind(this.datesShow);
        this.priorDates.setOptions((javafx.collections.ObservableList<j>)FXCollections.observableArrayList((Collection)DateUtil.d()));
        this.timesRotate.setConverter(new ab(this));
        this.timesRotate.setOnItemClicked((p0, value) -> {
            this.trainDate.setValue(value);
            this.aMethod(Boolean.FALSE);
            return;
        });
        this.timesRotate.setItems((javafx.collections.ObservableList<LocalDate>)FXCollections.observableArrayList((Collection)DateUtil.c()));
        final v v = javafx.a.d.a((Class<? extends a<Object>>)v.class);
        this.buttonQuery.setOnAction(actionEvent -> {
            if (this.buttonQuery.getText().equals("\u67e5\u8be2\u4f59\u7968")) {
                this.timesRotate.setActive((LocalDate)this.trainDate.getValue());
                this.aMethod(Boolean.TRUE);
            }
            else if (v.isRunning()) {
                v.cancel();
            }
        });
        this.buttonBrush.setOnAction(actionEvent -> {
            final MainController mainController = javafx.controller.a.a(MainController.class);
            if (!net.tec.kyfw.f.b().i()) {
                mainController.login.fireEvent((Event)new MouseEvent(MouseEvent.MOUSE_CLICKED, 0.0, 0.0, 0.0, 0.0, (MouseButton)null, 2, true, true, true, true, true, true, true, true, true, true, (PickResult)null));
                return;
            }
            final TaskController taskController = javafx.controller.a.a(TaskController.class);
            final net.tec.kyfw.d.a a = taskController.a.a(net.tec.kyfw.f.b().g());
            if (a != null) {
                if ((a.getTaskState().equals("\u6b63\u5728\u8fd0\u884c") || a.getTaskState().equals("\u5b9a\u65f6\u5237\u65b0") || a.getTaskState().equals("\u8ba2\u7968\u6210\u529f")) && Integer.valueOf(Dialogs.create().owner(this.getWindow()).message("\u8be5\u8d26\u53f7\u5df2\u52a0\u5165\u5230\u4efb\u52a1\u5217\u8868\u4e2d\uff0c\u786e\u8ba4\u66ff\u6362\u5f53\u524d\u6b63\u5728\u6267\u884c\u4e2d\u7684\u4efb\u52a1\uff1f").confirmAndWait()) == 0) {
                    return;
                }
                final net.tec.kyfw.e.r r = javafx.a.d.a((Class<? extends a<Object>>)net.tec.kyfw.e.r.class, a.getAccount());
                if (r.isRunning()) {
                    r.cancel();
                }
                taskController.a.c(a);
            }
            taskController.a.a(new net.tec.kyfw.d.a(net.tec.kyfw.f.b().g(), net.tec.kyfw.f.b().h(), ((LocalDate)this.trainDate.getValue()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), (this.fromStation.getValue() != null) ? ((fProperty)this.fromStation.getValue()).getStationName() : null, (this.toStation.getValue() != null) ? ((fProperty)this.toStation.getValue()).getStationName() : null, (this.fromStation.getValue() != null) ? ((fProperty)this.fromStation.getValue()).getStationTelecode() : null, (this.toStation.getValue() != null) ? ((fProperty)this.toStation.getValue()).getStationTelecode() : null, this.aMethod(), (String)this.priorOption.getValue(), this.submitOption.isSelected(), true, this.trainShow.getItems(), this.seatShow.getItems(), this.riderShow.getItems(), this.datesShow.getItems(), null, false, 0L), Boolean.valueOf(true));
            mainController.framePane.getSelectionModel().select(1);
        });
        final String[] array = { "\u8f66\u6b21", "\u51fa\u53d1\u7ad9\r\n\u5230\u8fbe\u7ad9", "\u65f6\u523b", "\u5386\u65f6", "\u5546\u52a1\u5ea7", "\u7279\u7b49\u5ea7", "\u4e00\u7b49\u5ea7", "\u4e8c\u7b49\u5ea7", "\u9ad8\u7ea7\r\n\u8f6f\u5367", "\u8f6f\u5367\r\n\u52a8\u5367", "\u786c\u5367", "\u8f6f\u5ea7", "\u786c\u5ea7", "\u65e0\u5ea7", "\u5176\u4ed6", "\u9884\u8ba2" };
        final String[] array2 = { "stationTrainCode", "trainInfo", "timeTable", "lishiShow", "swz", "tz", "zy", "ze", "gr", "rw", "yw", "rz", "yz", "wz", "qt", "buttonTextInfo" };
        final double[] array3 = { 1.8, 1.8, 1.0, 1.4, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 2.0 };
        final List<TablePane.TableCellFactory<g>> d = this.dMethod();
        final ObservableList observableArrayList2 = FXCollections.observableArrayList();
        for (int i = 0; i < array2.length; ++i) {
            final TablePane.Column<g> column = new TablePane.Column<g>();
            column.setAlign(Pos.CENTER);
            column.setField(array2[i]);
            column.setText(array[i]);
            column.setWidth(array3[i]);
            column.setTableCellFactory(d.get(i));
            observableArrayList2.add((Object)column);
        }
        this.trainTable.setTableColumn((javafx.collections.ObservableList<TablePane.Column<g>>)observableArrayList2);
        this.trainTable.itemsProperty().bind((ObservableValue)v.valueProperty());
        this.trainTable.setPlaceholder("\u8bf7\u70b9\u51fb\u67e5\u8be2\u4f59\u7968\u83b7\u53d6\u8f66\u6b21\u4fe1\u606f");
        this.c.addListener((observableValue, s, s2) -> {
            this.a.clear();
            this.b.clear();
        });
        this.startTime.valueProperty().addListener((observableValue, s, s2) -> this.cMethod());
        this.endTime.valueProperty().addListener((observableValue, s, s2) -> this.cMethod());
        this.fromStation.valueProperty().addListener((observableValue, f, f2) -> this.fMethod());
        this.toStation.valueProperty().addListener((observableValue, f, f2) -> this.fMethod());
        this.priorTrain.setOnShowing(event -> this.fMethod());
        this.priorRider.setOnShown(event -> {
            if (!net.tec.kyfw.f.b().i()) {
                ((MainController) javafx.controller.a.a(MainController.class)).login.fireEvent((Event)new MouseEvent(MouseEvent.MOUSE_CLICKED, 0.0, 0.0, 0.0, 0.0, (MouseButton)null, 2, true, true, true, true, true, true, true, true, true, true, (PickResult)null));
            }
        });
        this.playMusic.selectedProperty().addListener((observableValue, b, b2) -> {
            if (b) {
                i.a();
            }
        });
        this.buyCancel.setOnMouseClicked(mouseEvent -> ((q) javafx.a.d.a((Class<? extends a<Object>>) q.class)).cancel());
        this.eMethod();
        this.autoVerifyCode.selectedProperty().addListener((ChangeListener)new ac(this));
    }
    
    @Override
    public void afterPropertySet() {
        if (this.trainDate.getValue() != null) {
            this.timesRotate.setActive((LocalDate)this.trainDate.getValue());
        }
        else {
            this.timesRotate.setActive(this.timesRotate.getItems().size() - 1);
            this.trainDate.setValue(this.timesRotate.getItems().get(this.timesRotate.getItems().size() - 1));
        }
    }
    
    @Override
    public Node getRootNode() {
        return (Node)this.root;
    }
    
    @FXML
    public void handleTrainClassAllAction(final ActionEvent actionEvent) {
        this.trainClassGC.setSelected(this.trainClassAll.isSelected());
        this.trainClassD.setSelected(this.trainClassAll.isSelected());
        this.trainClassZ.setSelected(this.trainClassAll.isSelected());
        this.trainClassT.setSelected(this.trainClassAll.isSelected());
        this.trainClassK.setSelected(this.trainClassAll.isSelected());
        this.trainClassO.setSelected(this.trainClassAll.isSelected());
        this.cMethod();
    }
    
    @FXML
    public void handleTrainClassChangedAction(final ActionEvent actionEvent) {
        final CheckBox checkBox = (CheckBox)actionEvent.getSource();
        if (checkBox.isSelected()) {
            Integer n = 0;
            if (this.trainClassGC.isSelected()) {
                ++n;
            }
            if (this.trainClassD.isSelected()) {
                ++n;
            }
            if (this.trainClassZ.isSelected()) {
                ++n;
            }
            if (this.trainClassT.isSelected()) {
                ++n;
            }
            if (this.trainClassK.isSelected()) {
                ++n;
            }
            if (this.trainClassO.isSelected()) {
                ++n;
            }
            if (n == 6) {
                this.trainClassAll.setSelected(checkBox.isSelected());
            }
        }
        else {
            Integer n2 = 6;
            if (!this.trainClassGC.isSelected()) {
                --n2;
            }
            if (!this.trainClassD.isSelected()) {
                --n2;
            }
            if (!this.trainClassZ.isSelected()) {
                --n2;
            }
            if (!this.trainClassT.isSelected()) {
                --n2;
            }
            if (!this.trainClassK.isSelected()) {
                --n2;
            }
            if (!this.trainClassO.isSelected()) {
                --n2;
            }
            if (n2 < 6) {
                this.trainClassAll.setSelected(checkBox.isSelected());
            }
        }
        this.cMethod();
    }
    
    @FXML
    public void handleShowCanBuyAction() {
        this.cMethod();
    }
    
    public String aMethod() {
        return (String)this.startTime.getValue() + "--" + (String)this.endTime.getValue();
    }
    
    public String bMethod() {
        if (this.trainClassAll.isSelected()) {
            return this.trainClassAll.getUserData().toString();
        }
        final StringBuffer sb = new StringBuffer();
        if (this.trainClassGC.isSelected()) {
            sb.append(this.trainClassGC.getUserData()).append(",");
        }
        if (this.trainClassD.isSelected()) {
            sb.append(this.trainClassD.getUserData()).append(",");
        }
        if (this.trainClassZ.isSelected()) {
            sb.append(this.trainClassZ.getUserData()).append(",");
        }
        if (this.trainClassT.isSelected()) {
            sb.append(this.trainClassT.getUserData()).append(",");
        }
        if (this.trainClassK.isSelected()) {
            sb.append(this.trainClassK.getUserData()).append(",");
        }
        if (this.trainClassO.isSelected()) {
            sb.append(this.trainClassO.getUserData()).append(",");
        }
        if (!sb.toString().isEmpty()) {
            sb.deleteCharAt(sb.lastIndexOf(","));
        }
        else {
            sb.append(this.trainClassAll.getUserData());
        }
        return sb.toString();
    }
    
    private void cMethod() {
        final v v = javafx.a.d.a((Class<? extends a<Object>>)v.class);
        if (v.h() != null && !v.h().isEmpty()) {
            final v v2 = new v();
            final String s = null;
            final String s2 = null;
            Platform.runLater(() -> {
                this.aMethod();
                this.bMethod();
                if (v2.getValue() != null) {
                    ((ObservableList)v2.getValue()).clear();
                    ((ObservableList)v2.getValue()).addAll((Collection)net.tec.kyfw.util.b.a(v2.h(), s, s2, this.showCanBuy.isSelected()));
                }
            });
        }
    }
    
    private List<TablePane.TableCellFactory<g>> dMethod() {
        final ArrayList<TablePane.TableCellFactory<g>> list = new ArrayList<TablePane.TableCellFactory<g>>();
        list.add(() -> new ad(this));
        list.add(() -> new ae(this));
        list.add(null);
        list.add(null);
        final String[] array = { "\u5546\u52a1\u5ea7", "\u7279\u7b49\u5ea7", "\u4e00\u7b49\u5ea7", "\u4e8c\u7b49\u5ea7", "\u9ad8\u7ea7\u8f6f\u5367", "\u8f6f\u5367", "\u786c\u5367", "\u8f6f\u5ea7", "\u786c\u5ea7", "\u65e0\u5ea7", "\u5176\u4ed6" };
        for (int i = 0; i < array.length; ++i) {
            final int s=i;
            list.add(() -> new af(this, array[s]));
        }
        list.add(() -> new ag(this));
        return (List<TablePane.TableCellFactory<g>>)list;
    }
    
    private void eMethod() {
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.FROM_STATION)) {
            this.fromStation.setValue(fProperty.stringToObject(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.FROM_STATION)));
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.TO_STATION)) {
            this.toStation.setValue(fProperty.stringToObject(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TO_STATION)));
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.TRAINDATE)) {
            final LocalDate parse = LocalDate.parse(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINDATE), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            if (parse.isAfter(LocalDate.now()) || parse.isEqual(LocalDate.now())) {
                this.trainDate.setValue(parse);
            }
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.STARTTIME)) {
            final String[] split = net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.STARTTIME).split("--");
            this.startTime.setValue(split[0]);
            this.endTime.setValue(split[1]);
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.PRIOROPTION)) {
            this.priorOption.setValue(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.PRIOROPTION));
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS) && !net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS).equals("ALL")) {
            this.trainClassAll.setSelected(false);
            this.trainClassGC.setSelected(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS).contains((CharSequence)this.trainClassGC.getUserData()));
            this.trainClassD.setSelected(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS).contains((CharSequence)this.trainClassD.getUserData()));
            this.trainClassZ.setSelected(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS).contains((CharSequence)this.trainClassZ.getUserData()));
            this.trainClassT.setSelected(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS).contains((CharSequence)this.trainClassT.getUserData()));
            this.trainClassK.setSelected(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS).contains((CharSequence)this.trainClassK.getUserData()));
            this.trainClassO.setSelected(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS).contains((CharSequence)this.trainClassO.getUserData()));
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.PRIORTRAINS)) {
            final String[] split2 = net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.PRIORTRAINS).split("\\|");
            for (int i = 0; i < split2.length; ++i) {
                this.trainShow.add(new g(split2[i]));
            }
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.PRIORSEATS)) {
            final List<e> stringToList = e.stringToList(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.PRIORSEATS));
            for (int j = 0; j < stringToList.size(); ++j) {
                this.seatShow.add(stringToList.get(j));
                if (!this.priorSeat.getItems().isEmpty()) {
                    final int index = this.priorSeat.getOptions().indexOf((Object)stringToList.get(j));
                    if (index != -1) {
                        ((e)this.priorSeat.getOptions().get(index)).setChecked(true);
                    }
                }
            }
        }
        if (!net.tec.kyfw.eMap.fMethod(net.tec.kyfw.eMap.aEnum.PRIORDATES)) {
            final List<j> stringToList2 = j.stringToList(net.tec.kyfw.eMap.aMethod(net.tec.kyfw.eMap.aEnum.PRIORDATES));
            for (int k = 0; k < stringToList2.size(); ++k) {
                this.datesShow.add(stringToList2.get(k));
                if (!this.priorDates.getItems().isEmpty()) {
                    final int index2 = this.priorDates.getOptions().indexOf((Object)stringToList2.get(k));
                    if (index2 != -1) {
                        ((j)this.priorDates.getOptions().get(index2)).setChecked(true);
                    }
                }
            }
        }
        if (!net.tec.kyfw.eMap.eMethod(net.tec.kyfw.eMap.aEnum.AUTOVERIFYCODE)) {
            this.autoVerifyCode.setSelected((boolean)net.tec.kyfw.eMap.cMethod(net.tec.kyfw.eMap.aEnum.AUTOVERIFYCODE));
        }
        if (!net.tec.kyfw.eMap.eMethod(net.tec.kyfw.eMap.aEnum.SUBMITOPTION)) {
            this.submitOption.setSelected((boolean)net.tec.kyfw.eMap.cMethod(net.tec.kyfw.eMap.aEnum.SUBMITOPTION));
        }
        if (!net.tec.kyfw.eMap.eMethod(net.tec.kyfw.eMap.aEnum.SHOWCANBUY)) {
            this.showCanBuy.setSelected((boolean)net.tec.kyfw.eMap.cMethod(net.tec.kyfw.eMap.aEnum.SHOWCANBUY));
        }
        if (!net.tec.kyfw.eMap.eMethod(net.tec.kyfw.eMap.aEnum.PLAYMUSIC)) {
            this.playMusic.setSelected((boolean)net.tec.kyfw.eMap.cMethod(net.tec.kyfw.eMap.aEnum.PLAYMUSIC));
        }
    }
    
    private void aMethod(final Boolean b) {
        if (this.fromStation.getValue() == null) {
            if (b) {
                Tooltips.show(this.getWindow(), "\u8bf7\u9009\u62e9\u51fa\u53d1\u5730\uff01");
                this.fromStation.requestFocus();
            }
            return;
        }
        if (this.toStation.getValue() == null) {
            if (b) {
                Tooltips.show(this.getWindow(), "\u8bf7\u9009\u62e9\u76ee\u7684\u5730\uff01");
                this.toStation.requestFocus();
            }
            return;
        }
        this.buttonQuery.setText("\u53d6\u6d88\u67e5\u8be2");
        if (!this.buttonQuery.getStyleClass().contains((Object)"ticket-button-cancel")) {
            this.buttonQuery.getStyleClass().add("ticket-button-cancel");
        }
        this.c.set((Object)(((fProperty)this.fromStation.getValue()).getStationTelecode() + "-" + ((f)this.toStation.getValue()).getStationTelecode()));
        this.trainTable.getSelectionModel().clearSelection();
        ((v) javafx.a.d.a((Class<? extends a<Object>>) v.class)).start();
    }
    
    private void fMethod() {
        if (this.fromStation.getValue() == null || this.toStation.getValue() == null || this.trainDate.getValue() == null) {
            return;
        }
        if (((fProperty)this.fromStation.getValue()).equals(this.toStation.getValue())) {
            return;
        }
        final String string = ((LocalDate)this.trainDate.getValue()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "," + ((fProperty)this.fromStation.getValue()).getStationTelecode() + "," + ((fProperty)this.toStation.getValue()).getStationTelecode();
        if (string.equals(this.d)) {
            return;
        }
        this.d = string;
        net.tec.kyfw.e.b.a(DateUtil.a((LocalDate)this.trainDate.getValue(), "yyyy-MM-dd"), ((fProperty)this.fromStation.getValue()).getStationName(), ((fProperty)this.toStation.getValue()).getStationName(), this.priorTrain, this.trainShow.getItems());
    }
}
