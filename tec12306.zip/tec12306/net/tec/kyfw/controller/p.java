// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

class P implements Runnable
{
    final /* synthetic */ SettingController a;
    
    P(final SettingController a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        if (this.a.close.isFocused()) {
            this.a.close.fire();
        }
    }
}
