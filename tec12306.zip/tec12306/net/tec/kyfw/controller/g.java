// 
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw.controller;

import javafx.event.Event;
import javafx.control.dialog.Tooltips;
import net.tec.kyfw.util.p;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

class G implements EventHandler<ActionEvent>
{
    final /* synthetic */ SettingController a;
    
    G(final SettingController a) {
        this.a = a;
    }
    
    public void a(final ActionEvent actionEvent) {
        if (p.a((Object)this.a.fxusername.getText())) {
            Tooltips.show(this.a.getWindow(), "\u8bf7\u8f93\u5165\u8d26\u53f7\uff01");
            this.a.fxusername.requestFocus();
            return;
        }
        if (p.a((Object)this.a.fxpassword.getText())) {
            Tooltips.show(this.a.getWindow(), "\u8bf7\u8f93\u5165\u8d26\u53f7\u5bc6\u7801\uff01");
            this.a.fxpassword.requestFocus();
            return;
        }
        this.a.testSms.setDisable(true);
        this.a.fxusername.requestFocus();
        new Thread((Runnable)new H(this)).start();
    }
}
