 //
// Decompiled by Procyon v0.5.30
// 

package net.tec.kyfw;

import java.util.Calendar;
import org.apache.http.impl.cookie.BasicClientCookie;
import net.tec.kyfw.util.uLib;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.ObjectOutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.http.cookie.Cookie;
import net.tec.kyfw.util.DateUtil;
import java.time.LocalDate;
import net.tec.kyfw.util.pUtil;
import javafx.controller.AbstractController;
import javafx.controller.a;
import net.tec.kyfw.controller.TicketController;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.Collection;
import javafx.collections.FXCollections;
import net.tec.kyfw.d.b;
import java.util.ArrayList;
import java.util.regex.Pattern;
import net.tec.kyfw.c.g;
import java.util.Properties;
import net.tec.kyfw.a.i;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.io.ByteArrayInputStream;
import net.tec.kyfw.util.o;
import java.io.FileInputStream;
import java.io.File;
import net.tec.kyfw.d.dProperty;
import javafx.collections.ObservableList;
import java.util.Map;
import net.tec.kyfw.d.fProperty;
import java.util.List;
import java.util.HashMap;

public class eMap extends HashMap<Object, Object>
{
    public static Boolean a;
    public static List<fProperty> b;
    public static Map<String, ObservableList<dProperty>> cMap;
    public static String d;
    private static eMap eMap;
    
    public static void aMethod() {
        InputStream inputStream = null;
        InputStream inputStream2 = null;
        ObjectInputStream objectInputStream = null;
        try {
            final File file = new File("settings");
            if (file.exists()) {
                inputStream = new FileInputStream(file);
                inputStream2 = new ByteArrayInputStream(net.tec.kyfw.util.e.b(o.a(inputStream)));
                objectInputStream = new ObjectInputStream(inputStream2);
                net.tec.kyfw.eMap.eMap = (eMap)objectInputStream.readObject();
            }
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
        catch (ClassNotFoundException ex3) {
            ex3.printStackTrace();
        }
        finally {
            o.b(inputStream);
            o.b(inputStream2);
            o.b(objectInputStream);
        }
        if (net.tec.kyfw.eMap.eMap == null) {
            net.tec.kyfw.eMap.eMap = new eMap();
        }
        if (eMethod(net.tec.kyfw.eMap.aEnum.QUERY_INTERVAL)) {
            aMethod(net.tec.kyfw.eMap.aEnum.QUERY_INTERVAL, (Object)2000L);
        }
        if (eMethod(net.tec.kyfw.eMap.aEnum.TRANSFORMOPTION)) {
            aMethod(net.tec.kyfw.eMap.aEnum.TRANSFORMOPTION, (Object)true);
        }
        if (eMethod(net.tec.kyfw.eMap.aEnum.CDN_OPTION)) {
            aMethod(net.tec.kyfw.eMap.aEnum.CDN_OPTION, (Object)true);
        }
        if (eMethod(net.tec.kyfw.eMap.aEnum.SUBMITOPTION)) {
            aMethod(net.tec.kyfw.eMap.aEnum.SUBMITOPTION, (Object)true);
        }
        if (eMethod(net.tec.kyfw.eMap.aEnum.PLAYMUSIC)) {
            aMethod(net.tec.kyfw.eMap.aEnum.PLAYMUSIC, (Object)true);
        }
        if (eMethod(net.tec.kyfw.eMap.aEnum.GT_CHOOSE_SEAT)) {
            aMethod(net.tec.kyfw.eMap.aEnum.GT_CHOOSE_SEAT, (Object)"\u7cfb\u7edf\u968f\u673a");
        }
        if (!fMethod(net.tec.kyfw.eMap.aEnum.HOSTS_UPDATE_DATE)) {
            i.c = aMethod(net.tec.kyfw.eMap.aEnum.HOSTS_UPDATE_DATE);
        }
    }
    
    public static void bMethod() {
        final InputStream a = o.a("/res/conf/system_config.properties");
        final Properties properties = new Properties();
        try {
            properties.load(a);
            final String b = g.b(net.tec.kyfw.f.b(), g.a);
            String s;
            if (b != null) {
                final Matcher matcher = Pattern.compile("[\"']{1}(.+?)[\"']{1}").matcher(b);
                if (matcher.find()) {
                    s = matcher.group(1);
                }
                else {
                    s = properties.getProperty("station_name");
                }
            }
            else {
                s = properties.getProperty("station_name");
            }
            final String[] split = s.split("@");
            net.tec.kyfw.eMap.b = new ArrayList<fProperty>();
            for (int i = 1; i < split.length; ++i) {
                final String[] split2 = split[i].split("\\|");
                net.tec.kyfw.eMap.b.add(new fProperty(split2[0], split2[3], split2[1], split2[2], Integer.parseInt(split2[5])));
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        finally {
            o.b(a);
        }
        for (final b b2 : fMethod()) {
            final List<dProperty> b3 = bMethod(b2.getUserName());
            if (b3 != null) {
                net.tec.kyfw.eMap.cMap.put(b2.getUserName(), (ObservableList<dProperty>)FXCollections.observableArrayList((Collection)b3));
            }
        }
    }
    
    public static void cMethod() {
        final TicketController ticketController = javafx.controller.a.a(TicketController.class);
        aMethod(net.tec.kyfw.eMap.aEnum.FROM_STATION, (Object)pUtil.cMethod(ticketController.fromStation.getValue()));
        aMethod(net.tec.kyfw.eMap.aEnum.TO_STATION, (Object)pUtil.cMethod(ticketController.toStation.getValue()));
        aMethod(net.tec.kyfw.eMap.aEnum.TRAINDATE, (Object)DateUtil.a((LocalDate)ticketController.trainDate.getValue(), "yyyy-MM-dd"));
        aMethod(net.tec.kyfw.eMap.aEnum.STARTTIME, (Object)ticketController.aMethod());
        aMethod(net.tec.kyfw.eMap.aEnum.PRIOROPTION, ticketController.priorOption.getValue());
        aMethod(net.tec.kyfw.eMap.aEnum.TRAINCLASS, (Object)ticketController.bMethod());
        aMethod(net.tec.kyfw.eMap.aEnum.PRIORTRAINS, (Object)pUtil.aMethod((List<?>)ticketController.trainShow.getItems()));
        aMethod(net.tec.kyfw.eMap.aEnum.PRIORSEATS, (Object)pUtil.aMethod((List<?>)ticketController.seatShow.getItems()));
        aMethod(net.tec.kyfw.eMap.aEnum.PRIORDATES, (Object)pUtil.aMethod((List<?>)ticketController.datesShow.getItems()));
        aMethod(net.tec.kyfw.eMap.aEnum.SUBMITOPTION, (Object)ticketController.submitOption.isSelected());
        aMethod(net.tec.kyfw.eMap.aEnum.AUTOVERIFYCODE, (Object)ticketController.autoVerifyCode.isSelected());
        aMethod(net.tec.kyfw.eMap.aEnum.SHOWCANBUY, (Object)ticketController.showCanBuy.isSelected());
        aMethod(net.tec.kyfw.eMap.aEnum.PLAYMUSIC, (Object)ticketController.playMusic.isSelected());
        if (pUtil.bMethod((Object)i.c) && !i.b.isEmpty()) {
            aMethod(net.tec.kyfw.eMap.aEnum.HOSTS_UPDATE_DATE, (Object)i.c);
            aMethod(net.tec.kyfw.eMap.aEnum.HOSTS, (Object)pUtil.aMethod(i.b));
        }
        if (!net.tec.kyfw.eMap.cMap.isEmpty()) {
            for (final String s : net.tec.kyfw.eMap.cMap.keySet()) {
                aMethod(s, (List)net.tec.kyfw.eMap.cMap.get(s));
            }
        }
        if (net.tec.kyfw.f.b().i()) {
            final StringBuffer sb = new StringBuffer();
            sb.append(net.tec.kyfw.f.b().g() + "," + net.tec.kyfw.f.b().h());
            sb.append("@");
            final List<Cookie> cookies = net.tec.kyfw.f.b().t().getCookies();
            for (int i = 0; i < cookies.size(); ++i) {
                sb.append(aMethod(cookies.get(i)));
                if (i < cookies.size() - 1) {
                    sb.append("|");
                }
            }
            aMethod(net.tec.kyfw.eMap.aEnum.COOKIES, (Object)sb.toString());
        }
        FileOutputStream fileOutputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        ObjectOutputStream objectOutputStream = null;
        try {
            final File file = new File("settings");
            byteArrayOutputStream = new ByteArrayOutputStream();
            objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(net.tec.kyfw.eMap.eMap);
            final byte[] a = net.tec.kyfw.util.e.a(byteArrayOutputStream.toByteArray());
            fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(a);
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
        finally {
            o.a(fileOutputStream);
            o.a(byteArrayOutputStream);
            o.a(objectOutputStream);
        }
    }
    
    public static boolean dMethod() {
        return pUtil.bMethod((Object)aMethod(net.tec.kyfw.eMap.aEnum.PROXY_HOST)) && pUtil.bMethod((Object)aMethod(net.tec.kyfw.eMap.aEnum.PROXY_PORT));
    }
    
    public static String aMethod(final Object o) {
        String s = null;
        if (net.tec.kyfw.eMap.cMap.get(o) != null) {
            s = (String) ((HashMap) net.tec.kyfw.eMap.cMap).get(o);
        }
        return s;
    }
    
    public static String aMethod(final Object o, final String s) {
        return (aMethod(o) != null) ? aMethod(o) : s;
    }
    
    public static Long bMethod(final Object o) {
        Long n = null;
        if (net.tec.kyfw.eMap.cMap.get(o) != null) {
            n = (Long) ((HashMap)net.tec.kyfw.eMap.cMap).get(o);
        }
        return n;
    }
    
    public static Long aMethod(final Object o, final Long n) {
        return (bMethod(o) != null) ? bMethod(o) : n;
    }
    
    public static Boolean cMethod(final Object o) {
        Boolean b = null;
        if (net.tec.kyfw.eMap.cMap.get(o) != null) {
            b = (Boolean) ((HashMap)net.tec.kyfw.eMap.cMap).get(o);
        }
        return b;
    }
    
    public static Boolean aMethod(final Object o, final boolean b) {
        if (eMethod(o)) {
            return b;
        }
        return cMethod(o);
    }
    
    public static <T> T dMethod(final Object o) {
        Object value = null;
        if (net.tec.kyfw.eMap.cMap.get(o) != null) {
            value = ((HashMap)net.tec.kyfw.eMap.cMap).get(o);
        }
        return (T)value;
    }
    
    public static void aMethod(final Object o, final Object o2) {
        if (o2 == null || "".equals(o2)) {
            net.tec.kyfw.eMap.cMap.remove(o);
        }
        else {
            net.tec.kyfw.eMap.cMap.put((String) o, (ObservableList<dProperty>) o2);
        }
    }
    
    public static boolean eMethod(final Object o) {
        return net.tec.kyfw.eMap.cMap.get(o) == null;
    }
    
    public static boolean fMethod(final Object o) {
        return net.tec.kyfw.eMap.cMap.get(o) == null || "".equals(aMethod(o));
    }
    
    public static String eMethod() {
        if (net.tec.kyfw.eMap.d == null) {
            net.tec.kyfw.eMap.d = uLib.cAuth.aAuth(uLib.dPoint, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\IEXPLORE.EXE", "");
            if (pUtil.aMethod((Object)net.tec.kyfw.eMap.d)) {
                net.tec.kyfw.eMap.d = "C:\\Program Files\\Internet Explorer\\IEXPLORE.EXE";
            }
        }
        return net.tec.kyfw.eMap.d;
    }
    
    public static List<b> fMethod() {
        final ArrayList<b> list = new ArrayList<b>();
        try {
            if (!eMethod(net.tec.kyfw.eMap.aEnum.USERS)) {
                final List<Map> list2 = dMethod(net.tec.kyfw.eMap.aEnum.USERS);
                if (list2 != null) {
                    for (final Map<String, String> map : list2) {
                        list.add(new b(map.get("USERNAME"), map.get("PASSWORD")));
                    }
                }
            }
        }
        catch (Exception ex) {
            aMethod(net.tec.kyfw.eMap.aEnum.USERS, (Object)null);
            ex.printStackTrace();
        }
        return list;
    }
    
    public static void aMethod(final String s) {
        try {
            final List<Map> list = dMethod(net.tec.kyfw.eMap.aEnum.USERS);
            if (list != null) {
                for (int i = 0; i < list.size(); ++i) {
                    if (s.equals(list.get(i).get("USERNAME"))) {
                        list.remove(i);
                        break;
                    }
                }
            }
        }
        catch (Exception ex) {
            aMethod(net.tec.kyfw.eMap.aEnum.USERS, (Object)null);
            ex.printStackTrace();
        }
    }
    
    public static void aMethod(final String s, final String s2) {
        aMethod(s);
        try {
            Object o;
            if (eMethod(net.tec.kyfw.eMap.aEnum.USERS)) {
                o = new ArrayList<Map<String, String>>();
                ((HashMap)net.tec.kyfw.eMap.cMap).put(net.tec.kyfw.eMap.aEnum.USERS, o);
            }
            else {
                o = dMethod(net.tec.kyfw.eMap.aEnum.USERS);
            }
            final HashMap<String, String> hashMap = new HashMap<String, String>();
            hashMap.put("USERNAME", s);
            hashMap.put("PASSWORD", s2);
            ((List<HashMap<String, String>>)o).add(0, hashMap);
        }
        catch (Exception ex) {
            aMethod(net.tec.kyfw.eMap.aEnum.USERS, (Object)null);
            ex.printStackTrace();
        }
    }
    
    public static List<dProperty> bMethod(final String s) {
        List<dProperty> stringToList = null;
        try {
            if (!eMethod(net.tec.kyfw.eMap.aEnum.USERS)) {
                final List<Map> list = dMethod(net.tec.kyfw.eMap.aEnum.USERS);
                if (list != null) {
                    int i = 0;
                    while (i < list.size()) {
                        if (s.equals(list.get(i).get("USERNAME"))) {
                            final String s2 = (String) list.get(i).get("PASSENGERS");
                            if (pUtil.bMethod((Object)s2)) {
                                stringToList = net.tec.kyfw.d.dProperty.stringToList(s2);
                                break;
                            }
                            break;
                        }
                        else {
                            ++i;
                        }
                    }
                }
            }
        }
        catch (Exception ex) {
            aMethod(net.tec.kyfw.eMap.aEnum.USERS, (Object)null);
            ex.printStackTrace();
        }
        return stringToList;
    }
    
    public static void aMethod(final String s, final List<dProperty> list) {
        try {
            if (eMethod(net.tec.kyfw.eMap.aEnum.USERS)) {
                return;
            }
            final List<Map> list2 = dMethod(net.tec.kyfw.eMap.aEnum.USERS);
            if (list2 != null) {
                for (int i = 0; i < list2.size(); ++i) {
                    if (s.equals(list2.get(i).get("USERNAME"))) {
                        list2.get(i).put("PASSENGERS", pUtil.aMethod(list));
                        break;
                    }
                }
            }
        }
        catch (Exception ex) {
            aMethod(net.tec.kyfw.eMap.aEnum.USERS, (Object)null);
            ex.printStackTrace();
        }
    }
    
    public static String aMethod(final Cookie cookie) {
        final StringBuffer sb = new StringBuffer();
        sb.append(pUtil.bMethod(cookie.getName())).append(",");
        sb.append(pUtil.bMethod(cookie.getValue())).append(",");
        sb.append(cookie.getVersion()).append(",");
        sb.append(pUtil.bMethod(cookie.getDomain())).append(",");
        sb.append(pUtil.bMethod(cookie.getPath())).append(",");
        sb.append((cookie.getExpiryDate() != null) ? cookie.getExpiryDate().getTime() : 0L);
        return sb.toString();
    }
    
    public static BasicClientCookie cMethod(final String s) {
        BasicClientCookie basicClientCookie = null;
        try {
            final Calendar instance = Calendar.getInstance();
            final String[] split = s.split(",");
            if (split.length == 6) {
                final long long1 = Long.parseLong(split[5]);
                if (long1 == 0L || long1 > instance.getTime().getTime()) {
                    basicClientCookie = new BasicClientCookie(split[0], split[1]);
                    basicClientCookie.setVersion(Integer.parseInt(split[2]));
                    basicClientCookie.setDomain(split[3]);
                    basicClientCookie.setPath(split[4]);
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return basicClientCookie;
    }
    
    static {
        net.tec.kyfw.eMap.a = Boolean.FALSE;
        cMap = new HashMap<String, ObservableList<dProperty>>();
        net.tec.kyfw.eMap.d = null;
        net.tec.kyfw.eMap.eMap = null;
    }
    
    public enum aEnum
    {
        PROXY_HOST, 
        PROXY_PORT, 
        FROM_STATION, 
        TO_STATION, 
        TRAINDATE, 
        STARTTIME, 
        TRAINCLASS, 
        PRIORTRAINS, 
        PRIORSEATS, 
        PRIORDATES, 
        PRIOROPTION, 
        AUTOSUBMIT, 
        AUTOVERIFYCODE, 
        SHOWCANBUY, 
        SUBMITOPTION, 
        PLAYMUSIC, 
        CDN_OPTION, 
        QUERY_INTERVAL, 
        MUSIC, 
        MSGAPI, 
        DM_ACCOUNT, 
        USERS, 
        COOKIES, 
        HOSTS, 
        HOSTS_UPDATE_DATE, 
        TRANSFORMOPTION, 
        GT_CHOOSE_SEAT;
    }
}
