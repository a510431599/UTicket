// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging;

import java.io.OutputStream;
import java.io.FileOutputStream;
import java.net.URLConnection;
import java.net.URL;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Enumeration;
import java.io.InputStream;
import java.util.Properties;
import java.io.UnsupportedEncodingException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.io.PrintStream;

public abstract class LogFactory
{
    public static final String PRIORITY_KEY = "priority";
    public static final String TCCL_KEY = "use_tccl";
    public static final String FACTORY_PROPERTY = "org.apache.commons.logging.LogFactory";
    public static final String FACTORY_DEFAULT = "org.apache.commons.logging.impl.LogFactoryImpl";
    public static final String FACTORY_PROPERTIES = "commons-logging.properties";
    protected static final String SERVICE_ID = "META-INF/services/org.apache.commons.logging.LogFactory";
    public static final String DIAGNOSTICS_DEST_PROPERTY = "org.apache.commons.logging.diagnostics.dest";
    private static PrintStream diagnosticsStream;
    private static final String diagnosticPrefix;
    public static final String HASHTABLE_IMPLEMENTATION_PROPERTY = "org.apache.commons.logging.LogFactory.HashtableImpl";
    private static final String WEAK_HASHTABLE_CLASSNAME = "org.apache.commons.logging.impl.WeakHashtable";
    private static final ClassLoader thisClassLoader;
    protected static Hashtable factories;
    protected static volatile LogFactory nullClassLoaderFactory;
    static Class class$org$apache$commons$logging$LogFactory;
    
    public abstract Object getAttribute(final String p0);
    
    public abstract String[] getAttributeNames();
    
    public abstract Log getInstance(final Class p0);
    
    public abstract Log getInstance(final String p0);
    
    public abstract void release();
    
    public abstract void removeAttribute(final String p0);
    
    public abstract void setAttribute(final String p0, final Object p1);
    
    private static final Hashtable createFactoryStore() {
        Hashtable<?, ?> hashtable = null;
        String systemProperty;
        try {
            systemProperty = getSystemProperty("org.apache.commons.logging.LogFactory.HashtableImpl", null);
        }
        catch (SecurityException ex) {
            systemProperty = null;
        }
        if (systemProperty == null) {
            systemProperty = "org.apache.commons.logging.impl.WeakHashtable";
        }
        try {
            hashtable = (Hashtable<?, ?>)Class.forName(systemProperty).newInstance();
        }
        catch (Throwable t) {
            handleThrowable(t);
            if (!"org.apache.commons.logging.impl.WeakHashtable".equals(systemProperty)) {
                if (isDiagnosticsEnabled()) {
                    logDiagnostic("[ERROR] LogFactory: Load of custom hashtable failed");
                }
                else {
                    System.err.println("[ERROR] LogFactory: Load of custom hashtable failed");
                }
            }
        }
        if (hashtable == null) {
            hashtable = new Hashtable<Object, Object>();
        }
        return hashtable;
    }
    
    private static String trim(final String s) {
        if (s == null) {
            return null;
        }
        return s.trim();
    }
    
    protected static void handleThrowable(final Throwable t) {
        if (t instanceof ThreadDeath) {
            throw (ThreadDeath)t;
        }
        if (t instanceof VirtualMachineError) {
            throw (VirtualMachineError)t;
        }
    }
    
    public static LogFactory getFactory() {
        final ClassLoader contextClassLoaderInternal = getContextClassLoaderInternal();
        if (contextClassLoaderInternal == null && isDiagnosticsEnabled()) {
            logDiagnostic("Context classloader is null.");
        }
        LogFactory logFactory = getCachedFactory(contextClassLoaderInternal);
        if (logFactory != null) {
            return logFactory;
        }
        if (isDiagnosticsEnabled()) {
            logDiagnostic(new StringBuffer().append("[LOOKUP] LogFactory implementation requested for the first time for context classloader ").append(objectId(contextClassLoaderInternal)).toString());
            logHierarchy("[LOOKUP] ", contextClassLoaderInternal);
        }
        final Properties configurationFile = getConfigurationFile(contextClassLoaderInternal, "commons-logging.properties");
        ClassLoader thisClassLoader = contextClassLoaderInternal;
        if (configurationFile != null) {
            final String property = configurationFile.getProperty("use_tccl");
            if (property != null && !Boolean.valueOf(property)) {
                thisClassLoader = LogFactory.thisClassLoader;
            }
        }
        if (isDiagnosticsEnabled()) {
            logDiagnostic("[LOOKUP] Looking for system property [org.apache.commons.logging.LogFactory] to define the LogFactory subclass to use...");
        }
        try {
            final String systemProperty = getSystemProperty("org.apache.commons.logging.LogFactory", null);
            if (systemProperty != null) {
                if (isDiagnosticsEnabled()) {
                    logDiagnostic(new StringBuffer().append("[LOOKUP] Creating an instance of LogFactory class '").append(systemProperty).append("' as specified by system property ").append("org.apache.commons.logging.LogFactory").toString());
                }
                logFactory = newFactory(systemProperty, thisClassLoader, contextClassLoaderInternal);
            }
            else if (isDiagnosticsEnabled()) {
                logDiagnostic("[LOOKUP] No system property [org.apache.commons.logging.LogFactory] defined.");
            }
        }
        catch (SecurityException ex) {
            if (isDiagnosticsEnabled()) {
                logDiagnostic(new StringBuffer().append("[LOOKUP] A security exception occurred while trying to create an instance of the custom factory class: [").append(trim(ex.getMessage())).append("]. Trying alternative implementations...").toString());
            }
        }
        catch (RuntimeException ex2) {
            if (isDiagnosticsEnabled()) {
                logDiagnostic(new StringBuffer().append("[LOOKUP] An exception occurred while trying to create an instance of the custom factory class: [").append(trim(ex2.getMessage())).append("] as specified by a system property.").toString());
            }
            throw ex2;
        }
        if (logFactory == null) {
            if (isDiagnosticsEnabled()) {
                logDiagnostic("[LOOKUP] Looking for a resource file of name [META-INF/services/org.apache.commons.logging.LogFactory] to define the LogFactory subclass to use...");
            }
            try {
                final InputStream resourceAsStream = getResourceAsStream(contextClassLoaderInternal, "META-INF/services/org.apache.commons.logging.LogFactory");
                if (resourceAsStream != null) {
                    BufferedReader bufferedReader;
                    try {
                        bufferedReader = new BufferedReader(new InputStreamReader(resourceAsStream, "UTF-8"));
                    }
                    catch (UnsupportedEncodingException ex4) {
                        bufferedReader = new BufferedReader(new InputStreamReader(resourceAsStream));
                    }
                    final String line = bufferedReader.readLine();
                    bufferedReader.close();
                    if (line != null && !"".equals(line)) {
                        if (isDiagnosticsEnabled()) {
                            logDiagnostic(new StringBuffer().append("[LOOKUP]  Creating an instance of LogFactory class ").append(line).append(" as specified by file '").append("META-INF/services/org.apache.commons.logging.LogFactory").append("' which was present in the path of the context classloader.").toString());
                        }
                        logFactory = newFactory(line, thisClassLoader, contextClassLoaderInternal);
                    }
                }
                else if (isDiagnosticsEnabled()) {
                    logDiagnostic("[LOOKUP] No resource file with name 'META-INF/services/org.apache.commons.logging.LogFactory' found.");
                }
            }
            catch (Exception ex3) {
                if (isDiagnosticsEnabled()) {
                    logDiagnostic(new StringBuffer().append("[LOOKUP] A security exception occurred while trying to create an instance of the custom factory class: [").append(trim(ex3.getMessage())).append("]. Trying alternative implementations...").toString());
                }
            }
        }
        if (logFactory == null) {
            if (configurationFile != null) {
                if (isDiagnosticsEnabled()) {
                    logDiagnostic("[LOOKUP] Looking in properties file for entry with key 'org.apache.commons.logging.LogFactory' to define the LogFactory subclass to use...");
                }
                final String property2 = configurationFile.getProperty("org.apache.commons.logging.LogFactory");
                if (property2 != null) {
                    if (isDiagnosticsEnabled()) {
                        logDiagnostic(new StringBuffer().append("[LOOKUP] Properties file specifies LogFactory subclass '").append(property2).append("'").toString());
                    }
                    logFactory = newFactory(property2, thisClassLoader, contextClassLoaderInternal);
                }
                else if (isDiagnosticsEnabled()) {
                    logDiagnostic("[LOOKUP] Properties file has no entry specifying LogFactory subclass.");
                }
            }
            else if (isDiagnosticsEnabled()) {
                logDiagnostic("[LOOKUP] No properties file available to determine LogFactory subclass from..");
            }
        }
        if (logFactory == null) {
            if (isDiagnosticsEnabled()) {
                logDiagnostic("[LOOKUP] Loading the default LogFactory implementation 'org.apache.commons.logging.impl.LogFactoryImpl' via the same classloader that loaded this LogFactory class (ie not looking in the context classloader).");
            }
            logFactory = newFactory("org.apache.commons.logging.impl.LogFactoryImpl", LogFactory.thisClassLoader, contextClassLoaderInternal);
        }
        if (logFactory != null) {
            cacheFactory(contextClassLoaderInternal, logFactory);
            if (configurationFile != null) {
                final Enumeration<?> propertyNames = configurationFile.propertyNames();
                while (propertyNames.hasMoreElements()) {
                    final String s = (String)propertyNames.nextElement();
                    logFactory.setAttribute(s, configurationFile.getProperty(s));
                }
            }
        }
        return logFactory;
    }
    
    public static Log getLog(final Class clazz) {
        return getFactory().getInstance(clazz);
    }
    
    public static Log getLog(final String s) {
        return getFactory().getInstance(s);
    }
    
    public static void release(final ClassLoader classLoader) {
        if (isDiagnosticsEnabled()) {
            logDiagnostic(new StringBuffer().append("Releasing factory for classloader ").append(objectId(classLoader)).toString());
        }
        final Hashtable factories = LogFactory.factories;
        synchronized (factories) {
            if (classLoader == null) {
                if (LogFactory.nullClassLoaderFactory != null) {
                    LogFactory.nullClassLoaderFactory.release();
                    LogFactory.nullClassLoaderFactory = null;
                }
            }
            else {
                final LogFactory logFactory = factories.get(classLoader);
                if (logFactory != null) {
                    logFactory.release();
                    factories.remove(classLoader);
                }
            }
        }
    }
    
    public static void releaseAll() {
        if (isDiagnosticsEnabled()) {
            logDiagnostic("Releasing factory for all classloaders.");
        }
        final Hashtable factories = LogFactory.factories;
        synchronized (factories) {
            final Enumeration<LogFactory> elements = factories.elements();
            while (elements.hasMoreElements()) {
                elements.nextElement().release();
            }
            factories.clear();
            if (LogFactory.nullClassLoaderFactory != null) {
                LogFactory.nullClassLoaderFactory.release();
                LogFactory.nullClassLoaderFactory = null;
            }
        }
    }
    
    protected static ClassLoader getClassLoader(final Class clazz) {
        try {
            return clazz.getClassLoader();
        }
        catch (SecurityException ex) {
            if (isDiagnosticsEnabled()) {
                logDiagnostic(new StringBuffer().append("Unable to get classloader for class '").append(clazz).append("' due to security restrictions - ").append(ex.getMessage()).toString());
            }
            throw ex;
        }
    }
    
    protected static ClassLoader getContextClassLoader() {
        return directGetContextClassLoader();
    }
    
    private static ClassLoader getContextClassLoaderInternal() {
        return AccessController.doPrivileged((PrivilegedAction<ClassLoader>)new PrivilegedAction() {
            @Override
            public Object run() {
                return LogFactory.directGetContextClassLoader();
            }
        });
    }
    
    protected static ClassLoader directGetContextClassLoader() {
        ClassLoader contextClassLoader = null;
        try {
            contextClassLoader = Thread.currentThread().getContextClassLoader();
        }
        catch (SecurityException ex) {}
        return contextClassLoader;
    }
    
    private static LogFactory getCachedFactory(final ClassLoader classLoader) {
        if (classLoader == null) {
            return LogFactory.nullClassLoaderFactory;
        }
        return LogFactory.factories.get(classLoader);
    }
    
    private static void cacheFactory(final ClassLoader classLoader, final LogFactory nullClassLoaderFactory) {
        if (nullClassLoaderFactory != null) {
            if (classLoader == null) {
                LogFactory.nullClassLoaderFactory = nullClassLoaderFactory;
            }
            else {
                LogFactory.factories.put(classLoader, nullClassLoaderFactory);
            }
        }
    }
    
    protected static LogFactory newFactory(final String s, final ClassLoader classLoader, final ClassLoader classLoader2) {
        final LogConfigurationException doPrivileged = AccessController.doPrivileged((PrivilegedAction<LogConfigurationException>)new PrivilegedAction(s, classLoader) {
            private final String val$factoryClass = val$factoryClass;
            private final ClassLoader val$classLoader = val$classLoader;
            
            @Override
            public Object run() {
                return LogFactory.createFactory(this.val$factoryClass, this.val$classLoader);
            }
        });
        if (doPrivileged instanceof LogConfigurationException) {
            final LogConfigurationException ex = doPrivileged;
            if (isDiagnosticsEnabled()) {
                logDiagnostic(new StringBuffer().append("An error occurred while loading the factory class:").append(ex.getMessage()).toString());
            }
            throw ex;
        }
        if (isDiagnosticsEnabled()) {
            logDiagnostic(new StringBuffer().append("Created object ").append(objectId(doPrivileged)).append(" to manage classloader ").append(objectId(classLoader2)).toString());
        }
        return (LogFactory)doPrivileged;
    }
    
    protected static LogFactory newFactory(final String s, final ClassLoader classLoader) {
        return newFactory(s, classLoader, null);
    }
    
    protected static Object createFactory(final String s, final ClassLoader classLoader) {
        Class<?> clazz = null;
        try {
            if (classLoader != null) {
                try {
                    clazz = classLoader.loadClass(s);
                    if (((LogFactory.class$org$apache$commons$logging$LogFactory == null) ? (LogFactory.class$org$apache$commons$logging$LogFactory = class$("org.apache.commons.logging.LogFactory")) : LogFactory.class$org$apache$commons$logging$LogFactory).isAssignableFrom(clazz)) {
                        if (isDiagnosticsEnabled()) {
                            logDiagnostic(new StringBuffer().append("Loaded class ").append(clazz.getName()).append(" from classloader ").append(objectId(classLoader)).toString());
                        }
                    }
                    else if (isDiagnosticsEnabled()) {
                        logDiagnostic(new StringBuffer().append("Factory class ").append(clazz.getName()).append(" loaded from classloader ").append(objectId(clazz.getClassLoader())).append(" does not extend '").append(((LogFactory.class$org$apache$commons$logging$LogFactory == null) ? (LogFactory.class$org$apache$commons$logging$LogFactory = class$("org.apache.commons.logging.LogFactory")) : LogFactory.class$org$apache$commons$logging$LogFactory).getName()).append("' as loaded by this classloader.").toString());
                        logHierarchy("[BAD CL TREE] ", classLoader);
                    }
                    return (LogFactory)clazz.newInstance();
                }
                catch (ClassNotFoundException ex) {
                    if (classLoader == LogFactory.thisClassLoader) {
                        if (isDiagnosticsEnabled()) {
                            logDiagnostic(new StringBuffer().append("Unable to locate any class called '").append(s).append("' via classloader ").append(objectId(classLoader)).toString());
                        }
                        throw ex;
                    }
                }
                catch (NoClassDefFoundError noClassDefFoundError) {
                    if (classLoader == LogFactory.thisClassLoader) {
                        if (isDiagnosticsEnabled()) {
                            logDiagnostic(new StringBuffer().append("Class '").append(s).append("' cannot be loaded").append(" via classloader ").append(objectId(classLoader)).append(" - it depends on some other class that cannot be found.").toString());
                        }
                        throw noClassDefFoundError;
                    }
                }
                catch (ClassCastException ex3) {
                    if (classLoader == LogFactory.thisClassLoader) {
                        final boolean implementsLogFactory = implementsLogFactory(clazz);
                        final StringBuffer sb = new StringBuffer();
                        sb.append("The application has specified that a custom LogFactory implementation ");
                        sb.append("should be used but Class '");
                        sb.append(s);
                        sb.append("' cannot be converted to '");
                        sb.append(((LogFactory.class$org$apache$commons$logging$LogFactory == null) ? (LogFactory.class$org$apache$commons$logging$LogFactory = class$("org.apache.commons.logging.LogFactory")) : LogFactory.class$org$apache$commons$logging$LogFactory).getName());
                        sb.append("'. ");
                        if (implementsLogFactory) {
                            sb.append("The conflict is caused by the presence of multiple LogFactory classes ");
                            sb.append("in incompatible classloaders. ");
                            sb.append("Background can be found in http://commons.apache.org/logging/tech.html. ");
                            sb.append("If you have not explicitly specified a custom LogFactory then it is likely ");
                            sb.append("that the container has set one without your knowledge. ");
                            sb.append("In this case, consider using the commons-logging-adapters.jar file or ");
                            sb.append("specifying the standard LogFactory from the command line. ");
                        }
                        else {
                            sb.append("Please check the custom implementation. ");
                        }
                        sb.append("Help can be found @http://commons.apache.org/logging/troubleshooting.html.");
                        if (isDiagnosticsEnabled()) {
                            logDiagnostic(sb.toString());
                        }
                        throw new ClassCastException(sb.toString());
                    }
                }
            }
            if (isDiagnosticsEnabled()) {
                logDiagnostic(new StringBuffer().append("Unable to load factory class via classloader ").append(objectId(classLoader)).append(" - trying the classloader associated with this LogFactory.").toString());
            }
            clazz = Class.forName(s);
            return (LogFactory)clazz.newInstance();
        }
        catch (Exception ex2) {
            if (isDiagnosticsEnabled()) {
                logDiagnostic("Unable to create LogFactory instance.");
            }
            if (clazz != null && !((LogFactory.class$org$apache$commons$logging$LogFactory == null) ? (LogFactory.class$org$apache$commons$logging$LogFactory = class$("org.apache.commons.logging.LogFactory")) : LogFactory.class$org$apache$commons$logging$LogFactory).isAssignableFrom(clazz)) {
                return new LogConfigurationException("The chosen LogFactory implementation does not extend LogFactory. Please check your configuration.", ex2);
            }
            return new LogConfigurationException(ex2);
        }
    }
    
    private static boolean implementsLogFactory(final Class clazz) {
        boolean assignable = false;
        if (clazz != null) {
            try {
                final ClassLoader classLoader = clazz.getClassLoader();
                if (classLoader == null) {
                    logDiagnostic("[CUSTOM LOG FACTORY] was loaded by the boot classloader");
                }
                else {
                    logHierarchy("[CUSTOM LOG FACTORY] ", classLoader);
                    assignable = Class.forName("org.apache.commons.logging.LogFactory", false, classLoader).isAssignableFrom(clazz);
                    if (assignable) {
                        logDiagnostic(new StringBuffer().append("[CUSTOM LOG FACTORY] ").append(clazz.getName()).append(" implements LogFactory but was loaded by an incompatible classloader.").toString());
                    }
                    else {
                        logDiagnostic(new StringBuffer().append("[CUSTOM LOG FACTORY] ").append(clazz.getName()).append(" does not implement LogFactory.").toString());
                    }
                }
            }
            catch (SecurityException ex) {
                logDiagnostic(new StringBuffer().append("[CUSTOM LOG FACTORY] SecurityException thrown whilst trying to determine whether the compatibility was caused by a classloader conflict: ").append(ex.getMessage()).toString());
            }
            catch (LinkageError linkageError) {
                logDiagnostic(new StringBuffer().append("[CUSTOM LOG FACTORY] LinkageError thrown whilst trying to determine whether the compatibility was caused by a classloader conflict: ").append(linkageError.getMessage()).toString());
            }
            catch (ClassNotFoundException ex2) {
                logDiagnostic("[CUSTOM LOG FACTORY] LogFactory class cannot be loaded by classloader which loaded the custom LogFactory implementation. Is the custom factory in the right classloader?");
            }
        }
        return assignable;
    }
    
    private static InputStream getResourceAsStream(final ClassLoader classLoader, final String s) {
        return AccessController.doPrivileged((PrivilegedAction<InputStream>)new PrivilegedAction(classLoader, s) {
            private final ClassLoader val$loader = val$loader;
            private final String val$name = val$name;
            
            @Override
            public Object run() {
                if (this.val$loader != null) {
                    return this.val$loader.getResourceAsStream(this.val$name);
                }
                return ClassLoader.getSystemResourceAsStream(this.val$name);
            }
        });
    }
    
    private static Enumeration getResources(final ClassLoader classLoader, final String s) {
        return AccessController.doPrivileged((PrivilegedAction<Enumeration>)new PrivilegedAction(classLoader, s) {
            private final ClassLoader val$loader = val$loader;
            private final String val$name = val$name;
            
            @Override
            public Object run() {
                try {
                    if (this.val$loader != null) {
                        return this.val$loader.getResources(this.val$name);
                    }
                    return ClassLoader.getSystemResources(this.val$name);
                }
                catch (IOException ex) {
                    if (LogFactory.isDiagnosticsEnabled()) {
                        LogFactory.access$000(new StringBuffer().append("Exception while trying to find configuration file ").append(this.val$name).append(":").append(ex.getMessage()).toString());
                    }
                    return null;
                }
                catch (NoSuchMethodError noSuchMethodError) {
                    return null;
                }
            }
        });
    }
    
    private static Properties getProperties(final URL url) {
        return AccessController.doPrivileged((PrivilegedAction<Properties>)new PrivilegedAction(url) {
            private final URL val$url = val$url;
            
            @Override
            public Object run() {
                InputStream inputStream = null;
                try {
                    final URLConnection openConnection = this.val$url.openConnection();
                    openConnection.setUseCaches(false);
                    inputStream = openConnection.getInputStream();
                    if (inputStream != null) {
                        final Properties properties = new Properties();
                        properties.load(inputStream);
                        inputStream.close();
                        inputStream = null;
                        return properties;
                    }
                }
                catch (IOException ex) {
                    if (LogFactory.isDiagnosticsEnabled()) {
                        LogFactory.access$000(new StringBuffer().append("Unable to read URL ").append(this.val$url).toString());
                    }
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        }
                        catch (IOException ex2) {
                            if (LogFactory.isDiagnosticsEnabled()) {
                                LogFactory.access$000(new StringBuffer().append("Unable to close stream for URL ").append(this.val$url).toString());
                            }
                        }
                    }
                }
                finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        }
                        catch (IOException ex3) {
                            if (LogFactory.isDiagnosticsEnabled()) {
                                LogFactory.access$000(new StringBuffer().append("Unable to close stream for URL ").append(this.val$url).toString());
                            }
                        }
                    }
                }
                return null;
            }
        });
    }
    
    private static final Properties getConfigurationFile(final ClassLoader classLoader, final String s) {
        Properties properties = null;
        double double1 = 0.0;
        Object o = null;
        try {
            final Enumeration resources = getResources(classLoader, s);
            if (resources == null) {
                return null;
            }
            while (resources.hasMoreElements()) {
                final URL url = resources.nextElement();
                final Properties properties2 = getProperties(url);
                if (properties2 != null) {
                    if (properties == null) {
                        o = url;
                        properties = properties2;
                        final String property = properties.getProperty("priority");
                        double1 = 0.0;
                        if (property != null) {
                            double1 = Double.parseDouble(property);
                        }
                        if (!isDiagnosticsEnabled()) {
                            continue;
                        }
                        logDiagnostic(new StringBuffer().append("[LOOKUP] Properties file found at '").append(url).append("'").append(" with priority ").append(double1).toString());
                    }
                    else {
                        final String property2 = properties2.getProperty("priority");
                        double double2 = 0.0;
                        if (property2 != null) {
                            double2 = Double.parseDouble(property2);
                        }
                        if (double2 > double1) {
                            if (isDiagnosticsEnabled()) {
                                logDiagnostic(new StringBuffer().append("[LOOKUP] Properties file at '").append(url).append("'").append(" with priority ").append(double2).append(" overrides file at '").append(o).append("'").append(" with priority ").append(double1).toString());
                            }
                            o = url;
                            properties = properties2;
                            double1 = double2;
                        }
                        else {
                            if (!isDiagnosticsEnabled()) {
                                continue;
                            }
                            logDiagnostic(new StringBuffer().append("[LOOKUP] Properties file at '").append(url).append("'").append(" with priority ").append(double2).append(" does not override file at '").append(o).append("'").append(" with priority ").append(double1).toString());
                        }
                    }
                }
            }
        }
        catch (SecurityException ex) {
            if (isDiagnosticsEnabled()) {
                logDiagnostic("SecurityException thrown while trying to find/read config files.");
            }
        }
        if (isDiagnosticsEnabled()) {
            if (properties == null) {
                logDiagnostic(new StringBuffer().append("[LOOKUP] No properties file of name '").append(s).append("' found.").toString());
            }
            else {
                logDiagnostic(new StringBuffer().append("[LOOKUP] Properties file of name '").append(s).append("' found at '").append(o).append('\"').toString());
            }
        }
        return properties;
    }
    
    private static String getSystemProperty(final String s, final String s2) {
        return AccessController.doPrivileged((PrivilegedAction<String>)new PrivilegedAction(s, s2) {
            private final String val$key = val$key;
            private final String val$def = val$def;
            
            @Override
            public Object run() {
                return System.getProperty(this.val$key, this.val$def);
            }
        });
    }
    
    private static PrintStream initDiagnostics() {
        String systemProperty;
        try {
            systemProperty = getSystemProperty("org.apache.commons.logging.diagnostics.dest", null);
            if (systemProperty == null) {
                return null;
            }
        }
        catch (SecurityException ex) {
            return null;
        }
        if (systemProperty.equals("STDOUT")) {
            return System.out;
        }
        if (systemProperty.equals("STDERR")) {
            return System.err;
        }
        try {
            return new PrintStream(new FileOutputStream(systemProperty, true));
        }
        catch (IOException ex2) {
            return null;
        }
    }
    
    protected static boolean isDiagnosticsEnabled() {
        return LogFactory.diagnosticsStream != null;
    }
    
    private static final void logDiagnostic(final String s) {
        if (LogFactory.diagnosticsStream != null) {
            LogFactory.diagnosticsStream.print(LogFactory.diagnosticPrefix);
            LogFactory.diagnosticsStream.println(s);
            LogFactory.diagnosticsStream.flush();
        }
    }
    
    protected static final void logRawDiagnostic(final String s) {
        if (LogFactory.diagnosticsStream != null) {
            LogFactory.diagnosticsStream.println(s);
            LogFactory.diagnosticsStream.flush();
        }
    }
    
    private static void logClassLoaderEnvironment(final Class clazz) {
        if (!isDiagnosticsEnabled()) {
            return;
        }
        try {
            logDiagnostic(new StringBuffer().append("[ENV] Extension directories (java.ext.dir): ").append(System.getProperty("java.ext.dir")).toString());
            logDiagnostic(new StringBuffer().append("[ENV] Application classpath (java.class.path): ").append(System.getProperty("java.class.path")).toString());
        }
        catch (SecurityException ex) {
            logDiagnostic("[ENV] Security setting prevent interrogation of system classpaths.");
        }
        final String name = clazz.getName();
        ClassLoader classLoader;
        try {
            classLoader = getClassLoader(clazz);
        }
        catch (SecurityException ex2) {
            logDiagnostic(new StringBuffer().append("[ENV] Security forbids determining the classloader for ").append(name).toString());
            return;
        }
        logDiagnostic(new StringBuffer().append("[ENV] Class ").append(name).append(" was loaded via classloader ").append(objectId(classLoader)).toString());
        logHierarchy(new StringBuffer().append("[ENV] Ancestry of classloader which loaded ").append(name).append(" is ").toString(), classLoader);
    }
    
    private static void logHierarchy(final String s, ClassLoader parent) {
        if (!isDiagnosticsEnabled()) {
            return;
        }
        if (parent != null) {
            logDiagnostic(new StringBuffer().append(s).append(objectId(parent)).append(" == '").append(parent.toString()).append("'").toString());
        }
        ClassLoader systemClassLoader;
        try {
            systemClassLoader = ClassLoader.getSystemClassLoader();
        }
        catch (SecurityException ex) {
            logDiagnostic(new StringBuffer().append(s).append("Security forbids determining the system classloader.").toString());
            return;
        }
        if (parent != null) {
            final StringBuffer sb = new StringBuffer(new StringBuffer().append(s).append("ClassLoader tree:").toString());
        Label_0178:
            while (true) {
                do {
                    sb.append(objectId(parent));
                    if (parent == systemClassLoader) {
                        sb.append(" (SYSTEM) ");
                    }
                    try {
                        parent = parent.getParent();
                    }
                    catch (SecurityException ex2) {
                        sb.append(" --> SECRET");
                        break Label_0178;
                    }
                    sb.append(" --> ");
                    continue;
                    logDiagnostic(sb.toString());
                    return;
                } while (parent != null);
                sb.append("BOOT");
                continue Label_0178;
            }
        }
    }
    
    public static String objectId(final Object o) {
        if (o == null) {
            return "null";
        }
        return new StringBuffer().append(o.getClass().getName()).append("@").append(System.identityHashCode(o)).toString();
    }
    
    static Class class$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException ex) {
            throw new NoClassDefFoundError(ex.getMessage());
        }
    }
    
    static void access$000(final String s) {
        logDiagnostic(s);
    }
    
    static {
        LogFactory.diagnosticsStream = null;
        LogFactory.factories = null;
        LogFactory.nullClassLoaderFactory = null;
        thisClassLoader = getClassLoader((LogFactory.class$org$apache$commons$logging$LogFactory == null) ? (LogFactory.class$org$apache$commons$logging$LogFactory = class$("org.apache.commons.logging.LogFactory")) : LogFactory.class$org$apache$commons$logging$LogFactory);
        String objectId;
        try {
            final ClassLoader thisClassLoader2 = LogFactory.thisClassLoader;
            if (LogFactory.thisClassLoader == null) {
                objectId = "BOOTLOADER";
            }
            else {
                objectId = objectId(thisClassLoader2);
            }
        }
        catch (SecurityException ex) {
            objectId = "UNKNOWN";
        }
        diagnosticPrefix = new StringBuffer().append("[LogFactory from ").append(objectId).append("] ").toString();
        LogFactory.diagnosticsStream = initDiagnostics();
        logClassLoaderEnvironment((LogFactory.class$org$apache$commons$logging$LogFactory == null) ? (LogFactory.class$org$apache$commons$logging$LogFactory = class$("org.apache.commons.logging.LogFactory")) : LogFactory.class$org$apache$commons$logging$LogFactory);
        LogFactory.factories = createFactoryStore();
        if (isDiagnosticsEnabled()) {
            logDiagnostic("BOOTSTRAP COMPLETED");
        }
    }
}
