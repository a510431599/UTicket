// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging.impl;

import org.apache.log4j.Level;
import org.apache.log4j.Priority;
import org.apache.log4j.Logger;
import org.apache.commons.logging.Log;
import java.io.Serializable;

public class Log4JLogger implements Serializable, Log
{
    private static final long serialVersionUID = 5160705895411730424L;
    private static final String FQCN;
    private transient volatile Logger logger;
    private final String name;
    private static final Priority traceLevel;
    static Class class$org$apache$commons$logging$impl$Log4JLogger;
    static Class class$org$apache$log4j$Level;
    static Class class$org$apache$log4j$Priority;
    
    public Log4JLogger() {
        this.logger = null;
        this.name = null;
    }
    
    public Log4JLogger(final String name) {
        this.logger = null;
        this.name = name;
        this.logger = this.getLogger();
    }
    
    public Log4JLogger(final Logger logger) {
        this.logger = null;
        if (logger == null) {
            throw new IllegalArgumentException("Warning - null logger in constructor; possible log4j misconfiguration.");
        }
        this.name = logger.getName();
        this.logger = logger;
    }
    
    @Override
    public void trace(final Object o) {
        this.getLogger().log(Log4JLogger.FQCN, Log4JLogger.traceLevel, o, null);
    }
    
    @Override
    public void trace(final Object o, final Throwable t) {
        this.getLogger().log(Log4JLogger.FQCN, Log4JLogger.traceLevel, o, t);
    }
    
    @Override
    public void debug(final Object o) {
        this.getLogger().log(Log4JLogger.FQCN, Level.DEBUG, o, null);
    }
    
    @Override
    public void debug(final Object o, final Throwable t) {
        this.getLogger().log(Log4JLogger.FQCN, Level.DEBUG, o, t);
    }
    
    @Override
    public void info(final Object o) {
        this.getLogger().log(Log4JLogger.FQCN, Level.INFO, o, null);
    }
    
    @Override
    public void info(final Object o, final Throwable t) {
        this.getLogger().log(Log4JLogger.FQCN, Level.INFO, o, t);
    }
    
    @Override
    public void warn(final Object o) {
        this.getLogger().log(Log4JLogger.FQCN, Level.WARN, o, null);
    }
    
    @Override
    public void warn(final Object o, final Throwable t) {
        this.getLogger().log(Log4JLogger.FQCN, Level.WARN, o, t);
    }
    
    @Override
    public void error(final Object o) {
        this.getLogger().log(Log4JLogger.FQCN, Level.ERROR, o, null);
    }
    
    @Override
    public void error(final Object o, final Throwable t) {
        this.getLogger().log(Log4JLogger.FQCN, Level.ERROR, o, t);
    }
    
    @Override
    public void fatal(final Object o) {
        this.getLogger().log(Log4JLogger.FQCN, Level.FATAL, o, null);
    }
    
    @Override
    public void fatal(final Object o, final Throwable t) {
        this.getLogger().log(Log4JLogger.FQCN, Level.FATAL, o, t);
    }
    
    public Logger getLogger() {
        Logger logger = this.logger;
        if (logger == null) {
            synchronized (this) {
                logger = this.logger;
                if (logger == null) {
                    logger = (this.logger = Logger.getLogger(this.name));
                }
            }
        }
        return logger;
    }
    
    @Override
    public boolean isDebugEnabled() {
        return this.getLogger().isDebugEnabled();
    }
    
    @Override
    public boolean isErrorEnabled() {
        return this.getLogger().isEnabledFor(Level.ERROR);
    }
    
    @Override
    public boolean isFatalEnabled() {
        return this.getLogger().isEnabledFor(Level.FATAL);
    }
    
    @Override
    public boolean isInfoEnabled() {
        return this.getLogger().isInfoEnabled();
    }
    
    @Override
    public boolean isTraceEnabled() {
        return this.getLogger().isEnabledFor(Log4JLogger.traceLevel);
    }
    
    @Override
    public boolean isWarnEnabled() {
        return this.getLogger().isEnabledFor(Level.WARN);
    }
    
    static Class class$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException ex) {
            throw new NoClassDefFoundError(ex.getMessage());
        }
    }
    
    static {
        FQCN = ((Log4JLogger.class$org$apache$commons$logging$impl$Log4JLogger == null) ? (Log4JLogger.class$org$apache$commons$logging$impl$Log4JLogger = class$("org.apache.commons.logging.impl.Log4JLogger")) : Log4JLogger.class$org$apache$commons$logging$impl$Log4JLogger).getName();
        if (!((Log4JLogger.class$org$apache$log4j$Priority == null) ? (Log4JLogger.class$org$apache$log4j$Priority = class$("org.apache.log4j.Priority")) : Log4JLogger.class$org$apache$log4j$Priority).isAssignableFrom((Log4JLogger.class$org$apache$log4j$Level == null) ? (Log4JLogger.class$org$apache$log4j$Level = class$("org.apache.log4j.Level")) : Log4JLogger.class$org$apache$log4j$Level)) {
            throw new InstantiationError("Log4J 1.2 not available");
        }
        Priority debug;
        try {
            debug = (Priority)((Log4JLogger.class$org$apache$log4j$Level == null) ? (Log4JLogger.class$org$apache$log4j$Level = class$("org.apache.log4j.Level")) : Log4JLogger.class$org$apache$log4j$Level).getDeclaredField("TRACE").get(null);
        }
        catch (Exception ex) {
            debug = Level.DEBUG;
        }
        traceLevel = debug;
    }
}
