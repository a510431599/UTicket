// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging.impl;

import org.apache.commons.logging.Log;
import java.io.Serializable;

public class NoOpLog implements Serializable, Log
{
    private static final long serialVersionUID = 561423906191706148L;
    
    public NoOpLog() {
    }
    
    public NoOpLog(final String s) {
    }
    
    @Override
    public void trace(final Object o) {
    }
    
    @Override
    public void trace(final Object o, final Throwable t) {
    }
    
    @Override
    public void debug(final Object o) {
    }
    
    @Override
    public void debug(final Object o, final Throwable t) {
    }
    
    @Override
    public void info(final Object o) {
    }
    
    @Override
    public void info(final Object o, final Throwable t) {
    }
    
    @Override
    public void warn(final Object o) {
    }
    
    @Override
    public void warn(final Object o, final Throwable t) {
    }
    
    @Override
    public void error(final Object o) {
    }
    
    @Override
    public void error(final Object o, final Throwable t) {
    }
    
    @Override
    public void fatal(final Object o) {
    }
    
    @Override
    public void fatal(final Object o, final Throwable t) {
    }
    
    @Override
    public final boolean isDebugEnabled() {
        return false;
    }
    
    @Override
    public final boolean isErrorEnabled() {
        return false;
    }
    
    @Override
    public final boolean isFatalEnabled() {
        return false;
    }
    
    @Override
    public final boolean isInfoEnabled() {
        return false;
    }
    
    @Override
    public final boolean isTraceEnabled() {
        return false;
    }
    
    @Override
    public final boolean isWarnEnabled() {
        return false;
    }
}
