// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging.impl;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.logging.LogConfigurationException;
import org.apache.commons.logging.Log;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;
import java.util.Hashtable;
import org.apache.commons.logging.LogFactory;

public class LogFactoryImpl extends LogFactory
{
    private static final String LOGGING_IMPL_LOG4J_LOGGER = "org.apache.commons.logging.impl.Log4JLogger";
    private static final String LOGGING_IMPL_JDK14_LOGGER = "org.apache.commons.logging.impl.Jdk14Logger";
    private static final String LOGGING_IMPL_LUMBERJACK_LOGGER = "org.apache.commons.logging.impl.Jdk13LumberjackLogger";
    private static final String LOGGING_IMPL_SIMPLE_LOGGER = "org.apache.commons.logging.impl.SimpleLog";
    private static final String PKG_IMPL = "org.apache.commons.logging.impl.";
    private static final int PKG_LEN;
    public static final String LOG_PROPERTY = "org.apache.commons.logging.Log";
    protected static final String LOG_PROPERTY_OLD = "org.apache.commons.logging.log";
    public static final String ALLOW_FLAWED_CONTEXT_PROPERTY = "org.apache.commons.logging.Log.allowFlawedContext";
    public static final String ALLOW_FLAWED_DISCOVERY_PROPERTY = "org.apache.commons.logging.Log.allowFlawedDiscovery";
    public static final String ALLOW_FLAWED_HIERARCHY_PROPERTY = "org.apache.commons.logging.Log.allowFlawedHierarchy";
    private static final String[] classesToDiscover;
    private boolean useTCCL;
    private String diagnosticPrefix;
    protected Hashtable attributes;
    protected Hashtable instances;
    private String logClassName;
    protected Constructor logConstructor;
    protected Class[] logConstructorSignature;
    protected Method logMethod;
    protected Class[] logMethodSignature;
    private boolean allowFlawedContext;
    private boolean allowFlawedDiscovery;
    private boolean allowFlawedHierarchy;
    static Class class$java$lang$String;
    static Class class$org$apache$commons$logging$LogFactory;
    static Class class$org$apache$commons$logging$impl$LogFactoryImpl;
    static Class class$org$apache$commons$logging$Log;
    
    public LogFactoryImpl() {
        this.useTCCL = true;
        this.attributes = new Hashtable();
        this.instances = new Hashtable();
        this.logConstructor = null;
        this.logConstructorSignature = new Class[] { (LogFactoryImpl.class$java$lang$String == null) ? (LogFactoryImpl.class$java$lang$String = class$("java.lang.String")) : LogFactoryImpl.class$java$lang$String };
        this.logMethod = null;
        this.logMethodSignature = new Class[] { (LogFactoryImpl.class$org$apache$commons$logging$LogFactory == null) ? (LogFactoryImpl.class$org$apache$commons$logging$LogFactory = class$("org.apache.commons.logging.LogFactory")) : LogFactoryImpl.class$org$apache$commons$logging$LogFactory };
        this.initDiagnostics();
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic("Instance created.");
        }
    }
    
    @Override
    public Object getAttribute(final String s) {
        return this.attributes.get(s);
    }
    
    @Override
    public String[] getAttributeNames() {
        return (String[])this.attributes.keySet().toArray(new String[this.attributes.size()]);
    }
    
    @Override
    public Log getInstance(final Class clazz) {
        return this.getInstance(clazz.getName());
    }
    
    @Override
    public Log getInstance(final String s) {
        Log instance = this.instances.get(s);
        if (instance == null) {
            instance = this.newInstance(s);
            this.instances.put(s, instance);
        }
        return instance;
    }
    
    @Override
    public void release() {
        this.logDiagnostic("Releasing all known loggers");
        this.instances.clear();
    }
    
    @Override
    public void removeAttribute(final String s) {
        this.attributes.remove(s);
    }
    
    @Override
    public void setAttribute(final String s, final Object o) {
        if (this.logConstructor != null) {
            this.logDiagnostic("setAttribute: call too late; configuration already performed.");
        }
        if (o == null) {
            this.attributes.remove(s);
        }
        else {
            this.attributes.put(s, o);
        }
        if (s.equals("use_tccl")) {
            this.useTCCL = (o != null && Boolean.valueOf(o.toString()));
        }
    }
    
    protected static ClassLoader getContextClassLoader() {
        return LogFactory.getContextClassLoader();
    }
    
    protected static boolean isDiagnosticsEnabled() {
        return LogFactory.isDiagnosticsEnabled();
    }
    
    protected static ClassLoader getClassLoader(final Class clazz) {
        return LogFactory.getClassLoader(clazz);
    }
    
    private void initDiagnostics() {
        final ClassLoader classLoader = getClassLoader(this.getClass());
        String objectId;
        try {
            if (classLoader == null) {
                objectId = "BOOTLOADER";
            }
            else {
                objectId = LogFactory.objectId(classLoader);
            }
        }
        catch (SecurityException ex) {
            objectId = "UNKNOWN";
        }
        this.diagnosticPrefix = new StringBuffer().append("[LogFactoryImpl@").append(System.identityHashCode(this)).append(" from ").append(objectId).append("] ").toString();
    }
    
    protected void logDiagnostic(final String s) {
        if (isDiagnosticsEnabled()) {
            LogFactory.logRawDiagnostic(new StringBuffer().append(this.diagnosticPrefix).append(s).toString());
        }
    }
    
    protected String getLogClassName() {
        if (this.logClassName == null) {
            this.discoverLogImplementation(this.getClass().getName());
        }
        return this.logClassName;
    }
    
    protected Constructor getLogConstructor() {
        if (this.logConstructor == null) {
            this.discoverLogImplementation(this.getClass().getName());
        }
        return this.logConstructor;
    }
    
    protected boolean isJdk13LumberjackAvailable() {
        return this.isLogLibraryAvailable("Jdk13Lumberjack", "org.apache.commons.logging.impl.Jdk13LumberjackLogger");
    }
    
    protected boolean isJdk14Available() {
        return this.isLogLibraryAvailable("Jdk14", "org.apache.commons.logging.impl.Jdk14Logger");
    }
    
    protected boolean isLog4JAvailable() {
        return this.isLogLibraryAvailable("Log4J", "org.apache.commons.logging.impl.Log4JLogger");
    }
    
    protected Log newInstance(final String s) {
        try {
            Log discoverLogImplementation;
            if (this.logConstructor == null) {
                discoverLogImplementation = this.discoverLogImplementation(s);
            }
            else {
                discoverLogImplementation = this.logConstructor.newInstance(s);
            }
            if (this.logMethod != null) {
                this.logMethod.invoke(discoverLogImplementation, this);
            }
            return discoverLogImplementation;
        }
        catch (LogConfigurationException ex) {
            throw ex;
        }
        catch (InvocationTargetException ex2) {
            final Throwable targetException = ex2.getTargetException();
            throw new LogConfigurationException((targetException == null) ? ex2 : targetException);
        }
        catch (Throwable t) {
            LogFactory.handleThrowable(t);
            throw new LogConfigurationException(t);
        }
    }
    
    private static ClassLoader getContextClassLoaderInternal() {
        return AccessController.doPrivileged((PrivilegedAction<ClassLoader>)new PrivilegedAction() {
            @Override
            public Object run() {
                return LogFactoryImpl.access$000();
            }
        });
    }
    
    private static String getSystemProperty(final String s, final String s2) {
        return AccessController.doPrivileged((PrivilegedAction<String>)new PrivilegedAction(s, s2) {
            private final String val$key = val$key;
            private final String val$def = val$def;
            
            @Override
            public Object run() {
                return System.getProperty(this.val$key, this.val$def);
            }
        });
    }
    
    private ClassLoader getParentClassLoader(final ClassLoader classLoader) {
        try {
            return AccessController.doPrivileged((PrivilegedAction<ClassLoader>)new PrivilegedAction(classLoader) {
                private final ClassLoader val$cl = val$cl;
                private final LogFactoryImpl this$0 = this$0;
                
                @Override
                public Object run() {
                    return this.val$cl.getParent();
                }
            });
        }
        catch (SecurityException ex) {
            this.logDiagnostic("[SECURITY] Unable to obtain parent classloader");
            return null;
        }
    }
    
    private boolean isLogLibraryAvailable(final String s, final String s2) {
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic(new StringBuffer().append("Checking for '").append(s).append("'.").toString());
        }
        try {
            if (this.createLogFromClass(s2, this.getClass().getName(), false) == null) {
                if (isDiagnosticsEnabled()) {
                    this.logDiagnostic(new StringBuffer().append("Did not find '").append(s).append("'.").toString());
                }
                return false;
            }
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic(new StringBuffer().append("Found '").append(s).append("'.").toString());
            }
            return true;
        }
        catch (LogConfigurationException ex) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic(new StringBuffer().append("Logging system '").append(s).append("' is available but not useable.").toString());
            }
            return false;
        }
    }
    
    private String getConfigurationValue(final String s) {
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic(new StringBuffer().append("[ENV] Trying to get configuration for item ").append(s).toString());
        }
        final Object attribute = this.getAttribute(s);
        if (attribute != null) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic(new StringBuffer().append("[ENV] Found LogFactory attribute [").append(attribute).append("] for ").append(s).toString());
            }
            return attribute.toString();
        }
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic(new StringBuffer().append("[ENV] No LogFactory attribute found for ").append(s).toString());
        }
        try {
            final String systemProperty = getSystemProperty(s, null);
            if (systemProperty != null) {
                if (isDiagnosticsEnabled()) {
                    this.logDiagnostic(new StringBuffer().append("[ENV] Found system property [").append(systemProperty).append("] for ").append(s).toString());
                }
                return systemProperty;
            }
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic(new StringBuffer().append("[ENV] No system property found for property ").append(s).toString());
            }
        }
        catch (SecurityException ex) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic(new StringBuffer().append("[ENV] Security prevented reading system property ").append(s).toString());
            }
        }
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic(new StringBuffer().append("[ENV] No configuration defined for item ").append(s).toString());
        }
        return null;
    }
    
    private boolean getBooleanConfiguration(final String s, final boolean b) {
        final String configurationValue = this.getConfigurationValue(s);
        if (configurationValue == null) {
            return b;
        }
        return Boolean.valueOf(configurationValue);
    }
    
    private void initConfiguration() {
        this.allowFlawedContext = this.getBooleanConfiguration("org.apache.commons.logging.Log.allowFlawedContext", true);
        this.allowFlawedDiscovery = this.getBooleanConfiguration("org.apache.commons.logging.Log.allowFlawedDiscovery", true);
        this.allowFlawedHierarchy = this.getBooleanConfiguration("org.apache.commons.logging.Log.allowFlawedHierarchy", true);
    }
    
    private Log discoverLogImplementation(final String s) {
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic("Discovering a Log implementation...");
        }
        this.initConfiguration();
        Log logFromClass = null;
        final String userSpecifiedLogClassName = this.findUserSpecifiedLogClassName();
        if (userSpecifiedLogClassName != null) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic(new StringBuffer().append("Attempting to load user-specified log class '").append(userSpecifiedLogClassName).append("'...").toString());
            }
            final Log logFromClass2 = this.createLogFromClass(userSpecifiedLogClassName, s, true);
            if (logFromClass2 == null) {
                final StringBuffer sb = new StringBuffer("User-specified log class '");
                sb.append(userSpecifiedLogClassName);
                sb.append("' cannot be found or is not useable.");
                this.informUponSimilarName(sb, userSpecifiedLogClassName, "org.apache.commons.logging.impl.Log4JLogger");
                this.informUponSimilarName(sb, userSpecifiedLogClassName, "org.apache.commons.logging.impl.Jdk14Logger");
                this.informUponSimilarName(sb, userSpecifiedLogClassName, "org.apache.commons.logging.impl.Jdk13LumberjackLogger");
                this.informUponSimilarName(sb, userSpecifiedLogClassName, "org.apache.commons.logging.impl.SimpleLog");
                throw new LogConfigurationException(sb.toString());
            }
            return logFromClass2;
        }
        else {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic("No user-specified Log implementation; performing discovery using the standard supported logging implementations...");
            }
            for (int n = 0; n < LogFactoryImpl.classesToDiscover.length && logFromClass == null; logFromClass = this.createLogFromClass(LogFactoryImpl.classesToDiscover[n], s, true), ++n) {}
            if (logFromClass == null) {
                throw new LogConfigurationException("No suitable Log implementation");
            }
            return logFromClass;
        }
    }
    
    private void informUponSimilarName(final StringBuffer sb, final String s, final String s2) {
        if (s.equals(s2)) {
            return;
        }
        if (s.regionMatches(true, 0, s2, 0, LogFactoryImpl.PKG_LEN + 5)) {
            sb.append(" Did you mean '");
            sb.append(s2);
            sb.append("'?");
        }
    }
    
    private String findUserSpecifiedLogClassName() {
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic("Trying to get log class from attribute 'org.apache.commons.logging.Log'");
        }
        String s = (String)this.getAttribute("org.apache.commons.logging.Log");
        if (s == null) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic("Trying to get log class from attribute 'org.apache.commons.logging.log'");
            }
            s = (String)this.getAttribute("org.apache.commons.logging.log");
        }
        if (s == null) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic("Trying to get log class from system property 'org.apache.commons.logging.Log'");
            }
            try {
                s = getSystemProperty("org.apache.commons.logging.Log", null);
            }
            catch (SecurityException ex) {
                if (isDiagnosticsEnabled()) {
                    this.logDiagnostic(new StringBuffer().append("No access allowed to system property 'org.apache.commons.logging.Log' - ").append(ex.getMessage()).toString());
                }
            }
        }
        if (s == null) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic("Trying to get log class from system property 'org.apache.commons.logging.log'");
            }
            try {
                s = getSystemProperty("org.apache.commons.logging.log", null);
            }
            catch (SecurityException ex2) {
                if (isDiagnosticsEnabled()) {
                    this.logDiagnostic(new StringBuffer().append("No access allowed to system property 'org.apache.commons.logging.log' - ").append(ex2.getMessage()).toString());
                }
            }
        }
        if (s != null) {
            s = s.trim();
        }
        return s;
    }
    
    private Log createLogFromClass(final String logClassName, final String s, final boolean b) {
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic(new StringBuffer().append("Attempting to instantiate '").append(logClassName).append("'").toString());
        }
        final Object[] array = { s };
        Log log = null;
        Constructor<?> constructor = null;
        Class<?> clazz = null;
        ClassLoader classLoader = this.getBaseClassLoader();
        while (true) {
            this.logDiagnostic(new StringBuffer().append("Trying to load '").append(logClassName).append("' from classloader ").append(LogFactory.objectId(classLoader)).toString());
            try {
                if (isDiagnosticsEnabled()) {
                    final String string = new StringBuffer().append(logClassName.replace('.', '/')).append(".class").toString();
                    URL url;
                    if (classLoader != null) {
                        url = classLoader.getResource(string);
                    }
                    else {
                        url = ClassLoader.getSystemResource(new StringBuffer().append(string).append(".class").toString());
                    }
                    if (url == null) {
                        this.logDiagnostic(new StringBuffer().append("Class '").append(logClassName).append("' [").append(string).append("] cannot be found.").toString());
                    }
                    else {
                        this.logDiagnostic(new StringBuffer().append("Class '").append(logClassName).append("' was found at '").append(url).append("'").toString());
                    }
                }
                Class<?> clazz2 = null;
                try {
                    clazz2 = Class.forName(logClassName, true, classLoader);
                }
                catch (ClassNotFoundException ex) {
                    this.logDiagnostic(new StringBuffer().append("The log adapter '").append(logClassName).append("' is not available via classloader ").append(LogFactory.objectId(classLoader)).append(": ").append(ex.getMessage().trim()).toString());
                    try {
                        clazz2 = Class.forName(logClassName);
                    }
                    catch (ClassNotFoundException ex2) {
                        this.logDiagnostic(new StringBuffer().append("The log adapter '").append(logClassName).append("' is not available via the LogFactoryImpl class classloader: ").append(ex2.getMessage().trim()).toString());
                    }
                }
                constructor = clazz2.getConstructor((Class<?>[])this.logConstructorSignature);
                final Object instance = constructor.newInstance(array);
                if (instance instanceof Log) {
                    clazz = clazz2;
                    log = (Log)instance;
                    break;
                }
                this.handleFlawedHierarchy(classLoader, clazz2);
            }
            catch (NoClassDefFoundError noClassDefFoundError) {
                this.logDiagnostic(new StringBuffer().append("The log adapter '").append(logClassName).append("' is missing dependencies when loaded via classloader ").append(LogFactory.objectId(classLoader)).append(": ").append(noClassDefFoundError.getMessage().trim()).toString());
                break;
            }
            catch (ExceptionInInitializerError exceptionInInitializerError) {
                this.logDiagnostic(new StringBuffer().append("The log adapter '").append(logClassName).append("' is unable to initialize itself when loaded via classloader ").append(LogFactory.objectId(classLoader)).append(": ").append(exceptionInInitializerError.getMessage().trim()).toString());
                break;
            }
            catch (LogConfigurationException ex3) {
                throw ex3;
            }
            catch (Throwable t) {
                LogFactory.handleThrowable(t);
                this.handleFlawedDiscovery(logClassName, classLoader, t);
            }
            if (classLoader == null) {
                break;
            }
            classLoader = this.getParentClassLoader(classLoader);
        }
        if (clazz != null && b) {
            this.logClassName = logClassName;
            this.logConstructor = constructor;
            try {
                this.logMethod = clazz.getMethod("setLogFactory", (Class<?>[])this.logMethodSignature);
                this.logDiagnostic(new StringBuffer().append("Found method setLogFactory(LogFactory) in '").append(logClassName).append("'").toString());
            }
            catch (Throwable t2) {
                LogFactory.handleThrowable(t2);
                this.logMethod = null;
                this.logDiagnostic(new StringBuffer().append("[INFO] '").append(logClassName).append("' from classloader ").append(LogFactory.objectId(classLoader)).append(" does not declare optional method ").append("setLogFactory(LogFactory)").toString());
            }
            this.logDiagnostic(new StringBuffer().append("Log adapter '").append(logClassName).append("' from classloader ").append(LogFactory.objectId(clazz.getClassLoader())).append(" has been selected for use.").toString());
        }
        return log;
    }
    
    private ClassLoader getBaseClassLoader() {
        final ClassLoader classLoader = getClassLoader((LogFactoryImpl.class$org$apache$commons$logging$impl$LogFactoryImpl == null) ? (LogFactoryImpl.class$org$apache$commons$logging$impl$LogFactoryImpl = class$("org.apache.commons.logging.impl.LogFactoryImpl")) : LogFactoryImpl.class$org$apache$commons$logging$impl$LogFactoryImpl);
        if (!this.useTCCL) {
            return classLoader;
        }
        final ClassLoader contextClassLoaderInternal = getContextClassLoaderInternal();
        final ClassLoader lowestClassLoader = this.getLowestClassLoader(contextClassLoaderInternal, classLoader);
        if (lowestClassLoader != null) {
            if (lowestClassLoader != contextClassLoaderInternal) {
                if (!this.allowFlawedContext) {
                    throw new LogConfigurationException("Bad classloader hierarchy; LogFactoryImpl was loaded via a classloader that is not related to the current context classloader.");
                }
                if (isDiagnosticsEnabled()) {
                    this.logDiagnostic("Warning: the context classloader is an ancestor of the classloader that loaded LogFactoryImpl; it should be the same or a descendant. The application using commons-logging should ensure the context classloader is used correctly.");
                }
            }
            return lowestClassLoader;
        }
        if (this.allowFlawedContext) {
            if (isDiagnosticsEnabled()) {
                this.logDiagnostic("[WARNING] the context classloader is not part of a parent-child relationship with the classloader that loaded LogFactoryImpl.");
            }
            return contextClassLoaderInternal;
        }
        throw new LogConfigurationException("Bad classloader hierarchy; LogFactoryImpl was loaded via a classloader that is not related to the current context classloader.");
    }
    
    private ClassLoader getLowestClassLoader(final ClassLoader classLoader, final ClassLoader classLoader2) {
        if (classLoader == null) {
            return classLoader2;
        }
        if (classLoader2 == null) {
            return classLoader;
        }
        for (ClassLoader parentClassLoader = classLoader; parentClassLoader != null; parentClassLoader = this.getParentClassLoader(parentClassLoader)) {
            if (parentClassLoader == classLoader2) {
                return classLoader;
            }
        }
        for (ClassLoader parentClassLoader2 = classLoader2; parentClassLoader2 != null; parentClassLoader2 = this.getParentClassLoader(parentClassLoader2)) {
            if (parentClassLoader2 == classLoader) {
                return classLoader2;
            }
        }
        return null;
    }
    
    private void handleFlawedDiscovery(final String s, final ClassLoader classLoader, final Throwable t) {
        if (isDiagnosticsEnabled()) {
            this.logDiagnostic(new StringBuffer().append("Could not instantiate Log '").append(s).append("' -- ").append(t.getClass().getName()).append(": ").append(t.getLocalizedMessage()).toString());
            if (t instanceof InvocationTargetException) {
                final Throwable targetException = ((InvocationTargetException)t).getTargetException();
                if (targetException != null) {
                    this.logDiagnostic(new StringBuffer().append("... InvocationTargetException: ").append(((ExceptionInInitializerError)targetException).getClass().getName()).append(": ").append(targetException.getLocalizedMessage()).toString());
                    if (targetException instanceof ExceptionInInitializerError) {
                        final Throwable exception = ((ExceptionInInitializerError)targetException).getException();
                        if (exception != null) {
                            final StringWriter stringWriter = new StringWriter();
                            exception.printStackTrace(new PrintWriter(stringWriter, true));
                            this.logDiagnostic(new StringBuffer().append("... ExceptionInInitializerError: ").append(stringWriter.toString()).toString());
                        }
                    }
                }
            }
        }
        if (!this.allowFlawedDiscovery) {
            throw new LogConfigurationException(t);
        }
    }
    
    private void handleFlawedHierarchy(final ClassLoader classLoader, final Class clazz) {
        boolean b = false;
        final String name = ((LogFactoryImpl.class$org$apache$commons$logging$Log == null) ? (LogFactoryImpl.class$org$apache$commons$logging$Log = class$("org.apache.commons.logging.Log")) : LogFactoryImpl.class$org$apache$commons$logging$Log).getName();
        final Class[] interfaces = clazz.getInterfaces();
        for (int i = 0; i < interfaces.length; ++i) {
            if (name.equals(interfaces[i].getName())) {
                b = true;
                break;
            }
        }
        if (b) {
            if (isDiagnosticsEnabled()) {
                try {
                    this.logDiagnostic(new StringBuffer().append("Class '").append(clazz.getName()).append("' was found in classloader ").append(LogFactory.objectId(classLoader)).append(". It is bound to a Log interface which is not").append(" the one loaded from classloader ").append(LogFactory.objectId(getClassLoader((LogFactoryImpl.class$org$apache$commons$logging$Log == null) ? (LogFactoryImpl.class$org$apache$commons$logging$Log = class$("org.apache.commons.logging.Log")) : LogFactoryImpl.class$org$apache$commons$logging$Log))).toString());
                }
                catch (Throwable t) {
                    LogFactory.handleThrowable(t);
                    this.logDiagnostic(new StringBuffer().append("Error while trying to output diagnostics about bad class '").append(clazz).append("'").toString());
                }
            }
            if (!this.allowFlawedHierarchy) {
                final StringBuffer sb = new StringBuffer();
                sb.append("Terminating logging for this context ");
                sb.append("due to bad log hierarchy. ");
                sb.append("You have more than one version of '");
                sb.append(((LogFactoryImpl.class$org$apache$commons$logging$Log == null) ? (LogFactoryImpl.class$org$apache$commons$logging$Log = class$("org.apache.commons.logging.Log")) : LogFactoryImpl.class$org$apache$commons$logging$Log).getName());
                sb.append("' visible.");
                if (isDiagnosticsEnabled()) {
                    this.logDiagnostic(sb.toString());
                }
                throw new LogConfigurationException(sb.toString());
            }
            if (isDiagnosticsEnabled()) {
                final StringBuffer sb2 = new StringBuffer();
                sb2.append("Warning: bad log hierarchy. ");
                sb2.append("You have more than one version of '");
                sb2.append(((LogFactoryImpl.class$org$apache$commons$logging$Log == null) ? (LogFactoryImpl.class$org$apache$commons$logging$Log = class$("org.apache.commons.logging.Log")) : LogFactoryImpl.class$org$apache$commons$logging$Log).getName());
                sb2.append("' visible.");
                this.logDiagnostic(sb2.toString());
            }
        }
        else {
            if (!this.allowFlawedDiscovery) {
                final StringBuffer sb3 = new StringBuffer();
                sb3.append("Terminating logging for this context. ");
                sb3.append("Log class '");
                sb3.append(clazz.getName());
                sb3.append("' does not implement the Log interface.");
                if (isDiagnosticsEnabled()) {
                    this.logDiagnostic(sb3.toString());
                }
                throw new LogConfigurationException(sb3.toString());
            }
            if (isDiagnosticsEnabled()) {
                final StringBuffer sb4 = new StringBuffer();
                sb4.append("[WARNING] Log class '");
                sb4.append(clazz.getName());
                sb4.append("' does not implement the Log interface.");
                this.logDiagnostic(sb4.toString());
            }
        }
    }
    
    static Class class$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException ex) {
            throw new NoClassDefFoundError(ex.getMessage());
        }
    }
    
    static ClassLoader access$000() {
        return LogFactory.directGetContextClassLoader();
    }
    
    static {
        PKG_LEN = "org.apache.commons.logging.impl.".length();
        classesToDiscover = new String[] { "org.apache.commons.logging.impl.Log4JLogger", "org.apache.commons.logging.impl.Jdk14Logger", "org.apache.commons.logging.impl.Jdk13LumberjackLogger", "org.apache.commons.logging.impl.SimpleLog" };
    }
}
