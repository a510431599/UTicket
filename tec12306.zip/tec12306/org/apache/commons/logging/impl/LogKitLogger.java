// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging.impl;

import org.apache.log.Hierarchy;
import org.apache.log.Logger;
import org.apache.commons.logging.Log;
import java.io.Serializable;

public class LogKitLogger implements Serializable, Log
{
    private static final long serialVersionUID = 3768538055836059519L;
    protected transient volatile Logger logger;
    protected String name;
    
    public LogKitLogger(final String name) {
        this.logger = null;
        this.name = null;
        this.name = name;
        this.logger = this.getLogger();
    }
    
    public Logger getLogger() {
        Logger logger = this.logger;
        if (logger == null) {
            synchronized (this) {
                logger = this.logger;
                if (logger == null) {
                    logger = (this.logger = Hierarchy.getDefaultHierarchy().getLoggerFor(this.name));
                }
            }
        }
        return logger;
    }
    
    @Override
    public void trace(final Object o) {
        this.debug(o);
    }
    
    @Override
    public void trace(final Object o, final Throwable t) {
        this.debug(o, t);
    }
    
    @Override
    public void debug(final Object o) {
        if (o != null) {
            this.getLogger().debug(String.valueOf(o));
        }
    }
    
    @Override
    public void debug(final Object o, final Throwable t) {
        if (o != null) {
            this.getLogger().debug(String.valueOf(o), t);
        }
    }
    
    @Override
    public void info(final Object o) {
        if (o != null) {
            this.getLogger().info(String.valueOf(o));
        }
    }
    
    @Override
    public void info(final Object o, final Throwable t) {
        if (o != null) {
            this.getLogger().info(String.valueOf(o), t);
        }
    }
    
    @Override
    public void warn(final Object o) {
        if (o != null) {
            this.getLogger().warn(String.valueOf(o));
        }
    }
    
    @Override
    public void warn(final Object o, final Throwable t) {
        if (o != null) {
            this.getLogger().warn(String.valueOf(o), t);
        }
    }
    
    @Override
    public void error(final Object o) {
        if (o != null) {
            this.getLogger().error(String.valueOf(o));
        }
    }
    
    @Override
    public void error(final Object o, final Throwable t) {
        if (o != null) {
            this.getLogger().error(String.valueOf(o), t);
        }
    }
    
    @Override
    public void fatal(final Object o) {
        if (o != null) {
            this.getLogger().fatalError(String.valueOf(o));
        }
    }
    
    @Override
    public void fatal(final Object o, final Throwable t) {
        if (o != null) {
            this.getLogger().fatalError(String.valueOf(o), t);
        }
    }
    
    @Override
    public boolean isDebugEnabled() {
        return this.getLogger().isDebugEnabled();
    }
    
    @Override
    public boolean isErrorEnabled() {
        return this.getLogger().isErrorEnabled();
    }
    
    @Override
    public boolean isFatalEnabled() {
        return this.getLogger().isFatalErrorEnabled();
    }
    
    @Override
    public boolean isInfoEnabled() {
        return this.getLogger().isInfoEnabled();
    }
    
    @Override
    public boolean isTraceEnabled() {
        return this.getLogger().isDebugEnabled();
    }
    
    @Override
    public boolean isWarnEnabled() {
        return this.getLogger().isWarnEnabled();
    }
}
