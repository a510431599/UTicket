// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging.impl;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.Enumeration;
import java.lang.ref.ReferenceQueue;
import java.util.Hashtable;

public final class WeakHashtable extends Hashtable
{
    private static final long serialVersionUID = -1546036869799732453L;
    private static final int MAX_CHANGES_BEFORE_PURGE = 100;
    private static final int PARTIAL_PURGE_COUNT = 10;
    private final ReferenceQueue queue;
    private int changeCount;
    
    public WeakHashtable() {
        this.queue = new ReferenceQueue();
        this.changeCount = 0;
    }
    
    @Override
    public boolean containsKey(final Object o) {
        return super.containsKey(new Referenced(o, (WeakHashtable$1)null));
    }
    
    @Override
    public Enumeration elements() {
        this.purge();
        return super.elements();
    }
    
    @Override
    public Set entrySet() {
        this.purge();
        final Set<Map.Entry<Referenced, V>> entrySet = super.entrySet();
        final HashSet<Entry> set = new HashSet<Entry>();
        for (final Map.Entry<Referenced, V> entry : entrySet) {
            final Object access$100 = Referenced.access$100(entry.getKey());
            final V value = entry.getValue();
            if (access$100 != null) {
                set.add(new Entry(access$100, value, null));
            }
        }
        return set;
    }
    
    @Override
    public Object get(final Object o) {
        return super.get(new Referenced(o, (WeakHashtable$1)null));
    }
    
    @Override
    public Enumeration keys() {
        this.purge();
        return new Enumeration((Enumeration)super.keys()) {
            private final Enumeration val$enumer = val$enumer;
            private final WeakHashtable this$0 = this$0;
            
            @Override
            public boolean hasMoreElements() {
                return this.val$enumer.hasMoreElements();
            }
            
            @Override
            public Object nextElement() {
                return Referenced.access$100(this.val$enumer.nextElement());
            }
        };
    }
    
    @Override
    public Set keySet() {
        this.purge();
        final Set<Referenced> keySet = super.keySet();
        final HashSet<Object> set = new HashSet<Object>();
        final Iterator<Referenced> iterator = keySet.iterator();
        while (iterator.hasNext()) {
            final Object access$100 = Referenced.access$100(iterator.next());
            if (access$100 != null) {
                set.add(access$100);
            }
        }
        return set;
    }
    
    @Override
    public synchronized Object put(final Object o, final Object o2) {
        if (o == null) {
            throw new NullPointerException("Null keys are not allowed");
        }
        if (o2 == null) {
            throw new NullPointerException("Null values are not allowed");
        }
        if (this.changeCount++ > 100) {
            this.purge();
            this.changeCount = 0;
        }
        else if (this.changeCount % 10 == 0) {
            this.purgeOne();
        }
        return super.put(new Referenced(o, this.queue, null), o2);
    }
    
    @Override
    public void putAll(final Map map) {
        if (map != null) {
            for (final Map.Entry<Object, V> entry : map.entrySet()) {
                this.put(entry.getKey(), entry.getValue());
            }
        }
    }
    
    @Override
    public Collection values() {
        this.purge();
        return super.values();
    }
    
    @Override
    public synchronized Object remove(final Object o) {
        if (this.changeCount++ > 100) {
            this.purge();
            this.changeCount = 0;
        }
        else if (this.changeCount % 10 == 0) {
            this.purgeOne();
        }
        return super.remove(new Referenced(o, (WeakHashtable$1)null));
    }
    
    @Override
    public boolean isEmpty() {
        this.purge();
        return super.isEmpty();
    }
    
    @Override
    public int size() {
        this.purge();
        return super.size();
    }
    
    @Override
    public String toString() {
        this.purge();
        return super.toString();
    }
    
    @Override
    protected void rehash() {
        this.purge();
        super.rehash();
    }
    
    private void purge() {
        final ArrayList<Referenced> list = new ArrayList<Referenced>();
        synchronized (this.queue) {
            WeakKey weakKey;
            while ((weakKey = (WeakKey)this.queue.poll()) != null) {
                list.add(WeakKey.access$400(weakKey));
            }
        }
        for (int size = list.size(), i = 0; i < size; ++i) {
            super.remove(list.get(i));
        }
    }
    
    private void purgeOne() {
        synchronized (this.queue) {
            final WeakKey weakKey = (WeakKey)this.queue.poll();
            if (weakKey != null) {
                super.remove(WeakKey.access$400(weakKey));
            }
        }
    }
    
    private static final class WeakKey extends WeakReference
    {
        private final Referenced referenced;
        
        private WeakKey(final Object o, final ReferenceQueue referenceQueue, final Referenced referenced) {
            super(o, referenceQueue);
            this.referenced = referenced;
        }
        
        private Referenced getReferenced() {
            return this.referenced;
        }
        
        static Referenced access$400(final WeakKey weakKey) {
            return weakKey.getReferenced();
        }
        
        WeakKey(final Object o, final ReferenceQueue referenceQueue, final Referenced referenced, final WeakHashtable$1 enumeration) {
            this(o, referenceQueue, referenced);
        }
    }
    
    private static final class Referenced
    {
        private final WeakReference reference;
        private final int hashCode;
        
        private Referenced(final Object o) {
            this.reference = new WeakReference((T)o);
            this.hashCode = o.hashCode();
        }
        
        private Referenced(final Object o, final ReferenceQueue referenceQueue) {
            this.reference = new WeakKey(o, referenceQueue, this, null);
            this.hashCode = o.hashCode();
        }
        
        @Override
        public int hashCode() {
            return this.hashCode;
        }
        
        private Object getValue() {
            return this.reference.get();
        }
        
        @Override
        public boolean equals(final Object o) {
            boolean equals = false;
            if (o instanceof Referenced) {
                final Referenced referenced = (Referenced)o;
                final Object value = this.getValue();
                final Object value2 = referenced.getValue();
                if (value == null) {
                    equals = (value2 == null && this.hashCode() == referenced.hashCode());
                }
                else {
                    equals = value.equals(value2);
                }
            }
            return equals;
        }
        
        Referenced(final Object o, final WeakHashtable$1 enumeration) {
            this(o);
        }
        
        static Object access$100(final Referenced referenced) {
            return referenced.getValue();
        }
        
        Referenced(final Object o, final ReferenceQueue referenceQueue, final WeakHashtable$1 enumeration) {
            this(o, referenceQueue);
        }
    }
    
    private static final class Entry implements Map.Entry
    {
        private final Object key;
        private final Object value;
        
        private Entry(final Object key, final Object value) {
            this.key = key;
            this.value = value;
        }
        
        @Override
        public boolean equals(final Object o) {
            boolean b = false;
            if (o != null && o instanceof Map.Entry) {
                final Map.Entry entry = (Map.Entry)o;
                boolean b2 = false;
                Label_0093: {
                    Label_0092: {
                        if (this.getKey() == null) {
                            if (entry.getKey() != null) {
                                break Label_0092;
                            }
                        }
                        else if (!this.getKey().equals(entry.getKey())) {
                            break Label_0092;
                        }
                        if ((this.getValue() != null) ? this.getValue().equals(entry.getValue()) : (entry.getValue() == null)) {
                            b2 = true;
                            break Label_0093;
                        }
                    }
                    b2 = false;
                }
                b = b2;
            }
            return b;
        }
        
        @Override
        public int hashCode() {
            return ((this.getKey() == null) ? 0 : this.getKey().hashCode()) ^ ((this.getValue() == null) ? 0 : this.getValue().hashCode());
        }
        
        @Override
        public Object setValue(final Object o) {
            throw new UnsupportedOperationException("Entry.setValue is not supported.");
        }
        
        @Override
        public Object getValue() {
            return this.value;
        }
        
        @Override
        public Object getKey() {
            return this.key;
        }
        
        Entry(final Object o, final Object o2, final WeakHashtable$1 enumeration) {
            this(o, o2);
        }
    }
}
