// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging.impl;

import org.apache.commons.logging.LogFactory;
import java.lang.reflect.InvocationTargetException;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ServletContextCleaner implements ServletContextListener
{
    private static final Class[] RELEASE_SIGNATURE;
    static Class class$java$lang$ClassLoader;
    
    public void contextDestroyed(final ServletContextEvent servletContextEvent) {
        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        final Object[] array = { contextClassLoader };
        ClassLoader parent = contextClassLoader;
        while (parent != null) {
            try {
                final Class<?> loadClass = parent.loadClass("org.apache.commons.logging.LogFactory");
                loadClass.getMethod("release", (Class<?>[])ServletContextCleaner.RELEASE_SIGNATURE).invoke(null, array);
                parent = loadClass.getClassLoader().getParent();
            }
            catch (ClassNotFoundException ex) {
                parent = null;
            }
            catch (NoSuchMethodException ex2) {
                System.err.println("LogFactory instance found which does not support release method!");
                parent = null;
            }
            catch (IllegalAccessException ex3) {
                System.err.println("LogFactory instance found which is not accessable!");
                parent = null;
            }
            catch (InvocationTargetException ex4) {
                System.err.println("LogFactory instance release method failed!");
                parent = null;
            }
        }
        LogFactory.release(contextClassLoader);
    }
    
    public void contextInitialized(final ServletContextEvent servletContextEvent) {
    }
    
    static Class class$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException ex) {
            throw new NoClassDefFoundError(ex.getMessage());
        }
    }
    
    static {
        RELEASE_SIGNATURE = new Class[] { (ServletContextCleaner.class$java$lang$ClassLoader == null) ? (ServletContextCleaner.class$java$lang$ClassLoader = class$("java.lang.ClassLoader")) : ServletContextCleaner.class$java$lang$ClassLoader };
    }
}
