// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.logging;

import org.apache.commons.logging.impl.NoOpLog;
import java.lang.reflect.Constructor;
import java.util.Hashtable;

public class LogSource
{
    protected static Hashtable logs;
    protected static boolean log4jIsAvailable;
    protected static boolean jdk14IsAvailable;
    protected static Constructor logImplctor;
    
    public static void setLogImplementation(final String s) {
        try {
            LogSource.logImplctor = Class.forName(s).getConstructor("".getClass());
        }
        catch (Throwable t) {
            LogSource.logImplctor = null;
        }
    }
    
    public static void setLogImplementation(final Class clazz) {
        LogSource.logImplctor = clazz.getConstructor("".getClass());
    }
    
    public static Log getInstance(final String s) {
        Log newLogInstance = LogSource.logs.get(s);
        if (null == newLogInstance) {
            newLogInstance = makeNewLogInstance(s);
            LogSource.logs.put(s, newLogInstance);
        }
        return newLogInstance;
    }
    
    public static Log getInstance(final Class clazz) {
        return getInstance(clazz.getName());
    }
    
    public static Log makeNewLogInstance(final String s) {
        Log log;
        try {
            log = LogSource.logImplctor.newInstance(s);
        }
        catch (Throwable t) {
            log = null;
        }
        if (null == log) {
            log = new NoOpLog(s);
        }
        return log;
    }
    
    public static String[] getLogNames() {
        return (String[])LogSource.logs.keySet().toArray(new String[LogSource.logs.size()]);
    }
    
    static {
        LogSource.logs = new Hashtable();
        LogSource.log4jIsAvailable = false;
        LogSource.jdk14IsAvailable = false;
        LogSource.logImplctor = null;
        try {
            LogSource.log4jIsAvailable = (null != Class.forName("org.apache.log4j.Logger"));
        }
        catch (Throwable t) {
            LogSource.log4jIsAvailable = false;
        }
        try {
            LogSource.jdk14IsAvailable = (null != Class.forName("java.util.logging.Logger") && null != Class.forName("org.apache.commons.logging.impl.Jdk14Logger"));
        }
        catch (Throwable t2) {
            LogSource.jdk14IsAvailable = false;
        }
        String logImplementation = null;
        try {
            logImplementation = System.getProperty("org.apache.commons.logging.log");
            if (logImplementation == null) {
                logImplementation = System.getProperty("org.apache.commons.logging.Log");
            }
        }
        catch (Throwable t3) {}
        if (logImplementation != null) {
            try {
                setLogImplementation(logImplementation);
            }
            catch (Throwable t4) {
                try {
                    setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
                }
                catch (Throwable t5) {}
            }
        }
        else {
            try {
                if (LogSource.log4jIsAvailable) {
                    setLogImplementation("org.apache.commons.logging.impl.Log4JLogger");
                }
                else if (LogSource.jdk14IsAvailable) {
                    setLogImplementation("org.apache.commons.logging.impl.Jdk14Logger");
                }
                else {
                    setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
                }
            }
            catch (Throwable t6) {
                try {
                    setLogImplementation("org.apache.commons.logging.impl.NoOpLog");
                }
                catch (Throwable t7) {}
            }
        }
    }
}
