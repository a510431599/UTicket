// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.codec;

public interface Encoder
{
    Object encode(final Object p0);
}
