// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.codec;

public interface BinaryDecoder extends Decoder
{
    byte[] decode(final byte[] p0);
}
