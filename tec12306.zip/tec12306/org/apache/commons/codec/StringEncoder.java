// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.codec;

public interface StringEncoder extends Encoder
{
    String encode(final String p0);
}
