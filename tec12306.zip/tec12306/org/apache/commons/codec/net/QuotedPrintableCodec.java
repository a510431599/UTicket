// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.codec.net;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.codec.DecoderException;
import java.io.ByteArrayOutputStream;
import org.apache.commons.codec.Charsets;
import java.util.BitSet;
import java.nio.charset.Charset;
import org.apache.commons.codec.StringEncoder;
import org.apache.commons.codec.StringDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.BinaryDecoder;

public class QuotedPrintableCodec implements BinaryDecoder, BinaryEncoder, StringDecoder, StringEncoder
{
    private final Charset charset;
    private static final BitSet PRINTABLE_CHARS;
    private static final byte ESCAPE_CHAR = 61;
    private static final byte TAB = 9;
    private static final byte SPACE = 32;
    
    public QuotedPrintableCodec() {
        this(Charsets.UTF_8);
    }
    
    public QuotedPrintableCodec(final Charset charset) {
        this.charset = charset;
    }
    
    public QuotedPrintableCodec(final String s) {
        this(Charset.forName(s));
    }
    
    private static final void encodeQuotedPrintable(final int n, final ByteArrayOutputStream byteArrayOutputStream) {
        byteArrayOutputStream.write(61);
        final char upperCase = Character.toUpperCase(Character.forDigit(n >> 4 & 0xF, 16));
        final char upperCase2 = Character.toUpperCase(Character.forDigit(n & 0xF, 16));
        byteArrayOutputStream.write(upperCase);
        byteArrayOutputStream.write(upperCase2);
    }
    
    public static final byte[] encodeQuotedPrintable(BitSet printable_CHARS, final byte[] array) {
        if (array == null) {
            return null;
        }
        if (printable_CHARS == null) {
            printable_CHARS = QuotedPrintableCodec.PRINTABLE_CHARS;
        }
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        for (int n : array) {
            if (n < 0) {
                n += 256;
            }
            if (printable_CHARS.get(n)) {
                byteArrayOutputStream.write(n);
            }
            else {
                encodeQuotedPrintable(n, byteArrayOutputStream);
            }
        }
        return byteArrayOutputStream.toByteArray();
    }
    
    public static final byte[] decodeQuotedPrintable(final byte[] array) {
        if (array == null) {
            return null;
        }
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        for (int i = 0; i < array.length; ++i) {
            final byte b = array[i];
            if (b == 61) {
                try {
                    byteArrayOutputStream.write((char)((Utils.digit16(array[++i]) << 4) + Utils.digit16(array[++i])));
                    continue;
                }
                catch (ArrayIndexOutOfBoundsException ex) {
                    throw new DecoderException("Invalid quoted-printable encoding", ex);
                }
            }
            byteArrayOutputStream.write(b);
        }
        return byteArrayOutputStream.toByteArray();
    }
    
    @Override
    public byte[] encode(final byte[] array) {
        return encodeQuotedPrintable(QuotedPrintableCodec.PRINTABLE_CHARS, array);
    }
    
    @Override
    public byte[] decode(final byte[] array) {
        return decodeQuotedPrintable(array);
    }
    
    @Override
    public String encode(final String s) {
        return this.encode(s, this.getCharset());
    }
    
    public String decode(final String s, final Charset charset) {
        if (s == null) {
            return null;
        }
        return new String(this.decode(StringUtils.getBytesUsAscii(s)), charset);
    }
    
    public String decode(final String s, final String s2) {
        if (s == null) {
            return null;
        }
        return new String(this.decode(StringUtils.getBytesUsAscii(s)), s2);
    }
    
    @Override
    public String decode(final String s) {
        return this.decode(s, this.getCharset());
    }
    
    @Override
    public Object encode(final Object o) {
        if (o == null) {
            return null;
        }
        if (o instanceof byte[]) {
            return this.encode((byte[])o);
        }
        if (o instanceof String) {
            return this.encode((String)o);
        }
        throw new EncoderException("Objects of type " + o.getClass().getName() + " cannot be quoted-printable encoded");
    }
    
    @Override
    public Object decode(final Object o) {
        if (o == null) {
            return null;
        }
        if (o instanceof byte[]) {
            return this.decode((byte[])o);
        }
        if (o instanceof String) {
            return this.decode((String)o);
        }
        throw new DecoderException("Objects of type " + o.getClass().getName() + " cannot be quoted-printable decoded");
    }
    
    public Charset getCharset() {
        return this.charset;
    }
    
    public String getDefaultCharset() {
        return this.charset.name();
    }
    
    public String encode(final String s, final Charset charset) {
        if (s == null) {
            return null;
        }
        return StringUtils.newStringUsAscii(this.encode(s.getBytes(charset)));
    }
    
    public String encode(final String s, final String s2) {
        if (s == null) {
            return null;
        }
        return StringUtils.newStringUsAscii(this.encode(s.getBytes(s2)));
    }
    
    static {
        PRINTABLE_CHARS = new BitSet(256);
        for (int i = 33; i <= 60; ++i) {
            QuotedPrintableCodec.PRINTABLE_CHARS.set(i);
        }
        for (int j = 62; j <= 126; ++j) {
            QuotedPrintableCodec.PRINTABLE_CHARS.set(j);
        }
        QuotedPrintableCodec.PRINTABLE_CHARS.set(9);
        QuotedPrintableCodec.PRINTABLE_CHARS.set(32);
    }
}
