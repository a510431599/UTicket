// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.commons.codec.language;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.StringEncoder;

public abstract class AbstractCaverphone implements StringEncoder
{
    @Override
    public Object encode(final Object o) {
        if (!(o instanceof String)) {
            throw new EncoderException("Parameter supplied to Caverphone encode is not of type java.lang.String");
        }
        return this.encode((String)o);
    }
    
    public boolean isEncodeEqual(final String s, final String s2) {
        return this.encode(s).equals(this.encode(s2));
    }
}
