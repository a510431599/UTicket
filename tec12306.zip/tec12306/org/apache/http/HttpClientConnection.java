// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.http;

public interface HttpClientConnection extends HttpConnection
{
    boolean isResponseAvailable(final int p0);
    
    void sendRequestHeader(final HttpRequest p0);
    
    void sendRequestEntity(final HttpEntityEnclosingRequest p0);
    
    HttpResponse receiveResponseHeader();
    
    void receiveResponseEntity(final HttpResponse p0);
    
    void flush();
}
