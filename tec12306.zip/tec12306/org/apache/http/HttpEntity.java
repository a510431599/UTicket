// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.http;

import java.io.OutputStream;
import java.io.InputStream;

public interface HttpEntity
{
    boolean isRepeatable();
    
    boolean isChunked();
    
    long getContentLength();
    
    Header getContentType();
    
    Header getContentEncoding();
    
    InputStream getContent();
    
    void writeTo(final OutputStream p0);
    
    boolean isStreaming();
    
    @Deprecated
    void consumeContent();
}
