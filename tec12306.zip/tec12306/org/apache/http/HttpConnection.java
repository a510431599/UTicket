// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.http;

import java.io.Closeable;

public interface HttpConnection extends Closeable
{
    void close();
    
    boolean isOpen();
    
    boolean isStale();
    
    void setSocketTimeout(final int p0);
    
    int getSocketTimeout();
    
    void shutdown();
    
    HttpConnectionMetrics getMetrics();
}
