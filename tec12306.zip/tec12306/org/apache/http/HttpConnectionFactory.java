// 
// Decompiled by Procyon v0.5.30
// 

package org.apache.http;

import java.net.Socket;

public interface HttpConnectionFactory<T extends HttpConnection>
{
    T createConnection(final Socket p0);
}
