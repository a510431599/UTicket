// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.perspectives;

import java.util.Iterator;
import java.util.Collection;
import com.rits.cloning.Cloner;

public class Perspectives
{
    private final Cloner cloner;
    
    public Perspectives(final Cloner cloner) {
        this.cloner = cloner;
    }
    
    public <T, E extends T> E viewAs(final Class<E> clazz, final T t) {
        if (t == null) {
            return null;
        }
        if (t instanceof Collection) {
            throw new IllegalArgumentException("for collections please use viewCollectionAs() method. Invalid object " + t);
        }
        final T fastCloneOrNewInstance = this.cloner.fastCloneOrNewInstance(clazz);
        this.cloner.copyPropertiesOfInheritedClass(t, fastCloneOrNewInstance);
        return (E)fastCloneOrNewInstance;
    }
    
    public <I, NI extends I, T extends Collection<I>, E extends Collection<NI>> E viewCollectionAs(final E e, final Class<NI> clazz, final T t) {
        if (t == null) {
            return null;
        }
        final Iterator<I> iterator = t.iterator();
        while (iterator.hasNext()) {
            e.add(this.viewAs(clazz, iterator.next()));
        }
        return e;
    }
}
