// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Map;

public interface IDeepCloner
{
     <T> T deepClone(final T p0, final Map<Object, Object> p1);
}
