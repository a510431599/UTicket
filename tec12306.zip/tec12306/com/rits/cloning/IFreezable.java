// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

public interface IFreezable
{
    boolean isFrozen();
}
