// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class FastClonerConcurrentHashMap implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final ConcurrentHashMap concurrentHashMap = (ConcurrentHashMap)o;
        final ConcurrentHashMap<Object, Object> concurrentHashMap2 = new ConcurrentHashMap<Object, Object>();
        for (final Map.Entry<T, V> entry : concurrentHashMap.entrySet()) {
            concurrentHashMap2.put(deepCloner.deepClone((Object)entry.getKey(), map), deepCloner.deepClone(entry.getValue(), map));
        }
        return concurrentHashMap2;
    }
}
