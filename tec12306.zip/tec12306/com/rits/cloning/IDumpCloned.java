// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.lang.reflect.Field;

public interface IDumpCloned
{
    void startCloning(final Class<?> p0);
    
    void cloning(final Field p0, final Class<?> p1);
}
