// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Map;

public interface IFastCloner
{
    Object clone(final Object p0, final IDeepCloner p1, final Map<Object, Object> p2);
}
