// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.Map;

public abstract class FastClonerCustomMap<T extends Map> implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final Map map2 = (Map)o;
        final Map<Object, Object> instance = this.getInstance((Map<Object, Object>)o);
        for (final Map.Entry<T, V> entry : map2.entrySet()) {
            instance.put(deepCloner.deepClone((Object)entry.getKey(), map), deepCloner.deepClone(entry.getValue(), map));
        }
        return instance;
    }
    
    protected abstract T getInstance(final T p0);
}
