// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

public interface IInstantiationStrategy
{
     <T> T newInstance(final Class<T> p0);
}
