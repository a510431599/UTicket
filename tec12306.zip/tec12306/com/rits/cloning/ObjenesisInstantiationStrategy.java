// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import org.objenesis.ObjenesisStd;
import org.objenesis.Objenesis;

public class ObjenesisInstantiationStrategy implements IInstantiationStrategy
{
    private final Objenesis objenesis;
    private static ObjenesisInstantiationStrategy instance;
    
    public ObjenesisInstantiationStrategy() {
        this.objenesis = new ObjenesisStd();
    }
    
    @Override
    public <T> T newInstance(final Class<T> clazz) {
        return this.objenesis.newInstance(clazz);
    }
    
    public static ObjenesisInstantiationStrategy getInstance() {
        return ObjenesisInstantiationStrategy.instance;
    }
    
    static {
        ObjenesisInstantiationStrategy.instance = new ObjenesisInstantiationStrategy();
    }
}
