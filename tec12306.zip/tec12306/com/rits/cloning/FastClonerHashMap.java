// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;

public class FastClonerHashMap implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final HashMap hashMap = (HashMap)o;
        final HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
        for (final Map.Entry<T, V> entry : hashMap.entrySet()) {
            hashMap2.put(deepCloner.deepClone((Object)entry.getKey(), map), deepCloner.deepClone(entry.getValue(), map));
        }
        return hashMap2;
    }
}
