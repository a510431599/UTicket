// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.lang.reflect.Array;
import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.Iterator;
import java.lang.reflect.Modifier;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.UUID;
import java.net.URL;
import java.net.URI;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.IdentityHashMap;
import java.util.HashMap;
import java.util.HashSet;
import java.lang.reflect.Field;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.Set;

public class Cloner
{
    private final IInstantiationStrategy instantiationStrategy;
    private final Set<Class<?>> ignored;
    private final Set<Class<?>> ignoredInstanceOf;
    private final Set<Class<?>> nullInstead;
    private final Map<Class<?>, IFastCloner> fastCloners;
    private final Map<Object, Boolean> ignoredInstances;
    private final ConcurrentHashMap<Class<?>, List<Field>> fieldsCache;
    private IDumpCloned dumpCloned;
    private boolean cloningEnabled;
    private boolean nullTransient;
    private boolean cloneSynthetics;
    private IDeepCloner deepCloner;
    private final ConcurrentHashMap<Class<?>, Boolean> immutables;
    private boolean cloneAnonymousParent;
    
    public IDumpCloned getDumpCloned() {
        return this.dumpCloned;
    }
    
    public void setDumpCloned(final IDumpCloned dumpCloned) {
        this.dumpCloned = dumpCloned;
    }
    
    public Cloner() {
        this.ignored = new HashSet<Class<?>>();
        this.ignoredInstanceOf = new HashSet<Class<?>>();
        this.nullInstead = new HashSet<Class<?>>();
        this.fastCloners = new HashMap<Class<?>, IFastCloner>();
        this.ignoredInstances = new IdentityHashMap<Object, Boolean>();
        this.fieldsCache = new ConcurrentHashMap<Class<?>, List<Field>>();
        this.dumpCloned = null;
        this.cloningEnabled = true;
        this.nullTransient = false;
        this.cloneSynthetics = true;
        this.deepCloner = new IDeepCloner() {
            @Override
            public <T> T deepClone(final T t, final Map<Object, Object> map) {
                try {
                    return Cloner.this.cloneInternal(t, map);
                }
                catch (IllegalAccessException ex) {
                    throw new IllegalStateException(ex);
                }
            }
        };
        this.immutables = new ConcurrentHashMap<Class<?>, Boolean>();
        this.cloneAnonymousParent = true;
        this.instantiationStrategy = ObjenesisInstantiationStrategy.getInstance();
        this.init();
    }
    
    public Cloner(final IInstantiationStrategy instantiationStrategy) {
        this.ignored = new HashSet<Class<?>>();
        this.ignoredInstanceOf = new HashSet<Class<?>>();
        this.nullInstead = new HashSet<Class<?>>();
        this.fastCloners = new HashMap<Class<?>, IFastCloner>();
        this.ignoredInstances = new IdentityHashMap<Object, Boolean>();
        this.fieldsCache = new ConcurrentHashMap<Class<?>, List<Field>>();
        this.dumpCloned = null;
        this.cloningEnabled = true;
        this.nullTransient = false;
        this.cloneSynthetics = true;
        this.deepCloner = new IDeepCloner() {
            @Override
            public <T> T deepClone(final T t, final Map<Object, Object> map) {
                try {
                    return Cloner.this.cloneInternal(t, map);
                }
                catch (IllegalAccessException ex) {
                    throw new IllegalStateException(ex);
                }
            }
        };
        this.immutables = new ConcurrentHashMap<Class<?>, Boolean>();
        this.cloneAnonymousParent = true;
        this.instantiationStrategy = instantiationStrategy;
        this.init();
    }
    
    public boolean isNullTransient() {
        return this.nullTransient;
    }
    
    public void setNullTransient(final boolean nullTransient) {
        this.nullTransient = nullTransient;
    }
    
    public void setCloneSynthetics(final boolean cloneSynthetics) {
        this.cloneSynthetics = cloneSynthetics;
    }
    
    private void init() {
        this.registerKnownJdkImmutableClasses();
        this.registerKnownConstants();
        this.registerFastCloners();
    }
    
    protected void registerFastCloners() {
        this.fastCloners.put(GregorianCalendar.class, new FastClonerCalendar());
        this.fastCloners.put(ArrayList.class, new FastClonerArrayList());
        this.fastCloners.put(LinkedList.class, new FastClonerLinkedList());
        this.fastCloners.put(HashSet.class, new FastClonerHashSet());
        this.fastCloners.put(HashMap.class, new FastClonerHashMap());
        this.fastCloners.put(TreeMap.class, new FastClonerTreeMap());
        this.fastCloners.put(LinkedHashMap.class, new FastClonerLinkedHashMap());
        this.fastCloners.put(ConcurrentHashMap.class, new FastClonerConcurrentHashMap());
    }
    
    protected Object fastClone(final Object o, final Map<Object, Object> map) {
        final IFastCloner fastCloner = this.fastCloners.get(o.getClass());
        if (fastCloner != null) {
            return fastCloner.clone(o, this.deepCloner, map);
        }
        return null;
    }
    
    public void registerConstant(final Object o) {
        this.ignoredInstances.put(o, true);
    }
    
    public void registerConstant(final Class<?> clazz, final String s) {
        try {
            final Field declaredField = clazz.getDeclaredField(s);
            declaredField.setAccessible(true);
            this.ignoredInstances.put(declaredField.get(null), true);
        }
        catch (SecurityException ex) {
            throw new RuntimeException(ex);
        }
        catch (NoSuchFieldException ex2) {
            throw new RuntimeException(ex2);
        }
        catch (IllegalArgumentException ex3) {
            throw new RuntimeException(ex3);
        }
        catch (IllegalAccessException ex4) {
            throw new RuntimeException(ex4);
        }
    }
    
    protected void registerKnownJdkImmutableClasses() {
        this.registerImmutable(String.class);
        this.registerImmutable(Integer.class);
        this.registerImmutable(Long.class);
        this.registerImmutable(Boolean.class);
        this.registerImmutable(Class.class);
        this.registerImmutable(Float.class);
        this.registerImmutable(Double.class);
        this.registerImmutable(Character.class);
        this.registerImmutable(Byte.class);
        this.registerImmutable(Short.class);
        this.registerImmutable(Void.class);
        this.registerImmutable(BigDecimal.class);
        this.registerImmutable(BigInteger.class);
        this.registerImmutable(URI.class);
        this.registerImmutable(URL.class);
        this.registerImmutable(UUID.class);
        this.registerImmutable(Pattern.class);
    }
    
    protected void registerKnownConstants() {
        this.registerStaticFields(TreeSet.class, HashSet.class, HashMap.class, TreeMap.class);
    }
    
    public void registerStaticFields(final Class<?>... array) {
        for (final Class<?> clazz : array) {
            for (final Field field : this.allFields(clazz)) {
                if (Modifier.isStatic(field.getModifiers()) && !field.getType().isPrimitive()) {
                    this.registerConstant(clazz, field.getName());
                }
            }
        }
    }
    
    public void setExtraStaticFields(final Set<Class<?>> set) {
        this.registerStaticFields((Class<?>[])set.toArray());
    }
    
    public void dontClone(final Class<?>... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.ignored.add(array[i]);
        }
    }
    
    public void dontCloneInstanceOf(final Class<?>... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.ignoredInstanceOf.add(array[i]);
        }
    }
    
    public void setDontCloneInstanceOf(final Class<?>... array) {
        this.dontCloneInstanceOf(array);
    }
    
    public void nullInsteadOfClone(final Class<?>... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.nullInstead.add(array[i]);
        }
    }
    
    public void setExtraNullInsteadOfClone(final Set<Class<?>> set) {
        this.nullInstead.addAll(set);
    }
    
    public void registerImmutable(final Class<?>... array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            this.ignored.add(array[i]);
        }
    }
    
    public void setExtraImmutables(final Set<Class<?>> set) {
        this.ignored.addAll(set);
    }
    
    public void registerFastCloner(final Class<?> clazz, final IFastCloner fastCloner) {
        if (this.fastCloners.containsKey(clazz)) {
            throw new IllegalArgumentException(clazz + " already fast-cloned!");
        }
        this.fastCloners.put(clazz, fastCloner);
    }
    
    public void unregisterFastCloner(final Class<?> clazz) {
        this.fastCloners.remove(clazz);
    }
    
    protected <T> T newInstance(final Class<T> clazz) {
        return this.instantiationStrategy.newInstance(clazz);
    }
    
    public <T> T fastCloneOrNewInstance(final Class<T> clazz) {
        try {
            final Object fastClone = this.fastClone(clazz, null);
            if (fastClone != null) {
                return (T)fastClone;
            }
        }
        catch (IllegalAccessException ex) {
            throw new RuntimeException(ex);
        }
        return (T)this.newInstance((Class<Object>)clazz);
    }
    
    public <T> T deepClone(final T t) {
        if (t == null) {
            return null;
        }
        if (!this.cloningEnabled) {
            return t;
        }
        if (this.dumpCloned != null) {
            this.dumpCloned.startCloning(t.getClass());
        }
        final IdentityHashMap<Object, Object> identityHashMap = new IdentityHashMap<Object, Object>(16);
        try {
            return this.cloneInternal(t, identityHashMap);
        }
        catch (IllegalAccessException ex) {
            throw new CloningException("error during cloning of " + t, ex);
        }
    }
    
    public <T> T deepCloneDontCloneInstances(final T t, final Object... array) {
        if (t == null) {
            return null;
        }
        if (!this.cloningEnabled) {
            return t;
        }
        if (this.dumpCloned != null) {
            this.dumpCloned.startCloning(t.getClass());
        }
        final IdentityHashMap<Object, Object> identityHashMap = new IdentityHashMap<Object, Object>(16);
        for (final Object o : array) {
            identityHashMap.put(o, o);
        }
        try {
            return this.cloneInternal(t, identityHashMap);
        }
        catch (IllegalAccessException ex) {
            throw new CloningException("error during cloning of " + t, ex);
        }
    }
    
    public <T> T shallowClone(final T t) {
        if (t == null) {
            return null;
        }
        if (!this.cloningEnabled) {
            return t;
        }
        try {
            return this.cloneInternal(t, null);
        }
        catch (IllegalAccessException ex) {
            throw new CloningException("error during cloning of " + t, ex);
        }
    }
    
    protected boolean considerImmutable(final Class<?> clazz) {
        return false;
    }
    
    protected Class<?> getImmutableAnnotation() {
        return Immutable.class;
    }
    
    private boolean isImmutable(final Class<?> clazz) {
        final Boolean b = this.immutables.get(clazz);
        if (b != null) {
            return b;
        }
        if (this.considerImmutable(clazz)) {
            return true;
        }
        final Class<?> immutableAnnotation = this.getImmutableAnnotation();
        final Annotation[] declaredAnnotations = clazz.getDeclaredAnnotations();
        for (int length = declaredAnnotations.length, i = 0; i < length; ++i) {
            if (declaredAnnotations[i].annotationType() == immutableAnnotation) {
                this.immutables.put(clazz, Boolean.TRUE);
                return true;
            }
        }
        for (Class<?> clazz2 = clazz.getSuperclass(); clazz2 != null && clazz2 != Object.class; clazz2 = clazz2.getSuperclass()) {
            for (final Annotation annotation : clazz2.getDeclaredAnnotations()) {
                if (annotation.annotationType() == Immutable.class && ((Immutable)annotation).subClass()) {
                    this.immutables.put(clazz, Boolean.TRUE);
                    return true;
                }
            }
        }
        this.immutables.put(clazz, Boolean.FALSE);
        return false;
    }
    
    protected <T> T cloneInternal(final T t, final Map<Object, Object> map) {
        if (t == null) {
            return null;
        }
        if (t == this) {
            return null;
        }
        if (this.ignoredInstances.containsKey(t)) {
            return t;
        }
        if (t instanceof Enum) {
            return t;
        }
        final Class<?> class1 = t.getClass();
        if (this.nullInstead.contains(class1)) {
            return null;
        }
        if (this.ignored.contains(class1)) {
            return t;
        }
        final Iterator<Class<?>> iterator = this.ignoredInstanceOf.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().isAssignableFrom(class1)) {
                return t;
            }
        }
        if (this.isImmutable(class1)) {
            return t;
        }
        if (t instanceof IFreezable && ((IFreezable)t).isFrozen()) {
            return t;
        }
        final T t2 = (map != null) ? map.get(t) : null;
        if (t2 != null) {
            return t2;
        }
        final Object fastClone = this.fastClone(t, map);
        if (fastClone != null) {
            if (map != null) {
                map.put(t, fastClone);
            }
            return (T)fastClone;
        }
        if (this.dumpCloned != null) {
            this.dumpCloned.startCloning(t.getClass());
        }
        if (class1.isArray()) {
            return (T)this.cloneArray((Object)t, map);
        }
        return this.cloneObject(t, map, class1);
    }
    
    private <T> T cloneObject(final T t, final Map<Object, Object> map, final Class<T> clazz) {
        final T instance = this.newInstance(clazz);
        if (map != null) {
            map.put(t, instance);
        }
        for (final Field field : this.allFields(clazz)) {
            final int modifiers = field.getModifiers();
            if (!Modifier.isStatic(modifiers) && (!this.nullTransient || !Modifier.isTransient(modifiers))) {
                final Object value = field.get(t);
                final boolean b = (this.cloneSynthetics || !field.isSynthetic()) && (this.cloneAnonymousParent || !this.isAnonymousParent(field));
                final Object o = (map != null) ? (b ? this.cloneInternal(value, map) : value) : value;
                field.set(instance, o);
                if (this.dumpCloned == null || o == value) {
                    continue;
                }
                this.dumpCloned.cloning(field, t.getClass());
            }
        }
        return instance;
    }
    
    private <T> T cloneArray(final T t, final Map<Object, Object> map) {
        final Class<?> class1 = t.getClass();
        final int length = Array.getLength(t);
        final Object instance = Array.newInstance(class1.getComponentType(), length);
        if (map != null) {
            map.put(t, instance);
        }
        if (class1.getComponentType().isPrimitive() || this.isImmutable(class1.getComponentType())) {
            System.arraycopy(t, 0, instance, 0, length);
        }
        else {
            for (int i = 0; i < length; ++i) {
                final Object value = Array.get(t, i);
                Array.set(instance, i, (map != null) ? this.cloneInternal(value, map) : value);
            }
        }
        return (T)instance;
    }
    
    private boolean isAnonymousParent(final Field field) {
        return "this$0".equals(field.getName());
    }
    
    public <T, E extends T> void copyPropertiesOfInheritedClass(final T t, final E e) {
        if (t == null) {
            throw new IllegalArgumentException("src can't be null");
        }
        if (e == null) {
            throw new IllegalArgumentException("dest can't be null");
        }
        final Class<?> class1 = t.getClass();
        final Class<?> class2 = e.getClass();
        if (!class1.isArray()) {
            final List<Field> allFields = this.allFields(class1);
            final List<Field> allFields2 = this.allFields(e.getClass());
            for (final Field field : allFields) {
                if (!Modifier.isStatic(field.getModifiers())) {
                    try {
                        final Object value = field.get(t);
                        field.setAccessible(true);
                        if (!allFields2.contains(field)) {
                            continue;
                        }
                        field.set(e, value);
                    }
                    catch (IllegalArgumentException ex) {
                        throw new RuntimeException(ex);
                    }
                    catch (IllegalAccessException ex2) {
                        throw new RuntimeException(ex2);
                    }
                }
            }
            return;
        }
        if (!class2.isArray()) {
            throw new IllegalArgumentException("can't copy from array to non-array class " + class2);
        }
        for (int length = Array.getLength(t), i = 0; i < length; ++i) {
            Array.set(e, i, Array.get(t, i));
        }
    }
    
    private void addAll(final List<Field> list, final Field[] array) {
        for (final Field field : array) {
            if (!field.isAccessible()) {
                field.setAccessible(true);
            }
            list.add(field);
        }
    }
    
    protected List<Field> allFields(final Class<?> clazz) {
        List<Field> list = this.fieldsCache.get(clazz);
        if (list == null) {
            list = new LinkedList<Field>();
            this.addAll(list, clazz.getDeclaredFields());
            Class<?> superclass = clazz;
            while ((superclass = superclass.getSuperclass()) != Object.class && superclass != null) {
                this.addAll(list, superclass.getDeclaredFields());
            }
            this.fieldsCache.putIfAbsent(clazz, list);
        }
        return list;
    }
    
    public boolean isDumpClonedClasses() {
        return this.dumpCloned != null;
    }
    
    public void setDumpClonedClasses(final boolean b) {
        if (b) {
            this.dumpCloned = new IDumpCloned() {
                @Override
                public void startCloning(final Class<?> clazz) {
                    System.out.println("clone>" + clazz);
                }
                
                @Override
                public void cloning(final Field field, final Class<?> clazz) {
                    System.out.println("cloned field>" + field + "  -- of class " + clazz);
                }
            };
        }
        else {
            this.dumpCloned = null;
        }
    }
    
    public boolean isCloningEnabled() {
        return this.cloningEnabled;
    }
    
    public void setCloningEnabled(final boolean cloningEnabled) {
        this.cloningEnabled = cloningEnabled;
    }
    
    public void setCloneAnonymousParent(final boolean cloneAnonymousParent) {
        this.cloneAnonymousParent = cloneAnonymousParent;
    }
    
    public boolean isCloneAnonymousParent() {
        return this.cloneAnonymousParent;
    }
    
    public static Cloner standard() {
        return new Cloner();
    }
    
    public static Cloner shared() {
        return new Cloner(new ObjenesisInstantiationStrategy());
    }
}
