// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.HashSet;
import java.util.Map;

public class FastClonerHashSet implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final HashSet set = (HashSet)o;
        final HashSet<Object> set2 = new HashSet<Object>();
        final Iterator<T> iterator = set.iterator();
        while (iterator.hasNext()) {
            set2.add(deepCloner.deepClone((Object)iterator.next(), map));
        }
        return set2;
    }
}
