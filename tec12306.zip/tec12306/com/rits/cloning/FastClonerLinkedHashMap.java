// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class FastClonerLinkedHashMap implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final LinkedHashMap linkedHashMap = (LinkedHashMap)o;
        final LinkedHashMap<Object, Object> linkedHashMap2 = new LinkedHashMap<Object, Object>();
        for (final Map.Entry<T, V> entry : linkedHashMap.entrySet()) {
            linkedHashMap2.put(deepCloner.deepClone((Object)entry.getKey(), map), deepCloner.deepClone(entry.getValue(), map));
        }
        return linkedHashMap2;
    }
}
