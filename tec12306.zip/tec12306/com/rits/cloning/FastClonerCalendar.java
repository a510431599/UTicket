// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.TimeZone;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Map;

public class FastClonerCalendar implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final GregorianCalendar gregorianCalendar = new GregorianCalendar();
        final Calendar calendar = (Calendar)o;
        gregorianCalendar.setTimeInMillis(calendar.getTimeInMillis());
        gregorianCalendar.setTimeZone((TimeZone)calendar.getTimeZone().clone());
        return gregorianCalendar;
    }
}
