// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.Map;

public class FastClonerArrayList implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final ArrayList list = (ArrayList)o;
        final ArrayList list2 = new ArrayList<Object>(list.size());
        final Iterator<T> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(deepCloner.deepClone((Object)iterator.next(), map));
        }
        return list2;
    }
}
