// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.Map;
import java.util.Collection;

public abstract class FastClonerCustomCollection<T extends Collection> implements IFastCloner
{
    public abstract T getInstance(final T p0);
    
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final Collection<Object> instance = this.getInstance((Collection<Object>)o);
        final Iterator<T> iterator = ((Collection)o).iterator();
        while (iterator.hasNext()) {
            instance.add(deepCloner.deepClone((Object)iterator.next(), map));
        }
        return instance;
    }
}
