// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

public class FastClonerLinkedList implements IFastCloner
{
    @Override
    public Object clone(final Object o, final IDeepCloner deepCloner, final Map<Object, Object> map) {
        final LinkedList list = (LinkedList)o;
        final LinkedList<Object> list2 = new LinkedList<Object>();
        final Iterator<T> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(deepCloner.deepClone((Object)iterator.next(), map));
        }
        return list2;
    }
}
