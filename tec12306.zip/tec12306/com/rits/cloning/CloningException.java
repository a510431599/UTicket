// 
// Decompiled by Procyon v0.5.30
// 

package com.rits.cloning;

public class CloningException extends RuntimeException
{
    private static final long serialVersionUID = 3815175312001146867L;
    
    public CloningException(final String s, final Throwable t) {
        super(s, t);
    }
}
