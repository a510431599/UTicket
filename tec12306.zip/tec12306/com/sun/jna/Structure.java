// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.jna;

import java.util.AbstractCollection;
import java.util.LinkedHashMap;
import java.util.Arrays;
import java.util.WeakHashMap;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Array;
import java.util.HashSet;
import java.io.Serializable;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.nio.Buffer;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;

public abstract class Structure
{
    public static final int ALIGN_DEFAULT = 0;
    public static final int ALIGN_NONE = 1;
    public static final int ALIGN_GNUC = 2;
    public static final int ALIGN_MSVC = 3;
    protected static final int CALCULATE_SIZE = -1;
    static final Map layoutInfo;
    static final Map fieldOrder;
    private Pointer memory;
    private int size;
    private int alignType;
    private String encoding;
    private int actualAlignType;
    private int structAlignment;
    private Map structFields;
    private final Map nativeStrings;
    private TypeMapper typeMapper;
    private long typeInfo;
    private boolean autoRead;
    private boolean autoWrite;
    private Structure[] array;
    private boolean readCalled;
    private static final ThreadLocal reads;
    private static final ThreadLocal busy;
    private static final Pointer PLACEHOLDER_MEMORY;
    
    protected Structure() {
        this(0);
    }
    
    protected Structure(final TypeMapper typeMapper) {
        this(null, 0, typeMapper);
    }
    
    protected Structure(final int n) {
        this(null, n);
    }
    
    protected Structure(final int n, final TypeMapper typeMapper) {
        this(null, n, typeMapper);
    }
    
    protected Structure(final Pointer pointer) {
        this(pointer, 0);
    }
    
    protected Structure(final Pointer pointer, final int n) {
        this(pointer, n, null);
    }
    
    protected Structure(final Pointer pointer, final int alignType, final TypeMapper typeMapper) {
        this.size = -1;
        this.nativeStrings = new HashMap();
        this.autoRead = true;
        this.autoWrite = true;
        this.setAlignType(alignType);
        this.setStringEncoding(Native.getStringEncoding(this.getClass()));
        this.initializeTypeMapper(typeMapper);
        this.validateFields();
        if (pointer != null) {
            this.useMemory(pointer, 0, true);
        }
        else {
            this.allocateMemory(-1);
        }
        this.initializeFields();
    }
    
    Map fields() {
        return this.structFields;
    }
    
    TypeMapper getTypeMapper() {
        return this.typeMapper;
    }
    
    private void initializeTypeMapper(TypeMapper typeMapper) {
        if (typeMapper == null) {
            typeMapper = Native.getTypeMapper(this.getClass());
        }
        this.typeMapper = typeMapper;
        this.layoutChanged();
    }
    
    private void layoutChanged() {
        if (this.size != -1) {
            this.size = -1;
            if (this.memory instanceof AutoAllocated) {
                this.memory = null;
            }
            this.ensureAllocated();
        }
    }
    
    protected void setStringEncoding(final String encoding) {
        this.encoding = encoding;
    }
    
    protected String getStringEncoding() {
        return this.encoding;
    }
    
    protected void setAlignType(int structureAlignment) {
        this.alignType = structureAlignment;
        if (structureAlignment == 0) {
            structureAlignment = Native.getStructureAlignment(this.getClass());
            if (structureAlignment == 0) {
                if (Platform.isWindows()) {
                    structureAlignment = 3;
                }
                else {
                    structureAlignment = 2;
                }
            }
        }
        this.actualAlignType = structureAlignment;
        this.layoutChanged();
    }
    
    protected Memory autoAllocate(final int n) {
        return new AutoAllocated(n);
    }
    
    protected void useMemory(final Pointer pointer) {
        this.useMemory(pointer, 0);
    }
    
    protected void useMemory(final Pointer pointer, final int n) {
        this.useMemory(pointer, n, false);
    }
    
    void useMemory(final Pointer pointer, final int n, final boolean b) {
        try {
            this.nativeStrings.clear();
            if (this instanceof ByValue && !b) {
                final byte[] array = new byte[this.size()];
                pointer.read(0L, array, 0, array.length);
                this.memory.write(0L, array, 0, array.length);
            }
            else {
                this.memory = pointer.share(n);
                if (this.size == -1) {
                    this.size = this.calculateSize(false);
                }
                if (this.size != -1) {
                    this.memory = pointer.share(n, this.size);
                }
            }
            this.array = null;
            this.readCalled = false;
        }
        catch (IndexOutOfBoundsException ex) {
            throw new IllegalArgumentException("Structure exceeds provided memory bounds", ex);
        }
    }
    
    protected void ensureAllocated() {
        this.ensureAllocated(false);
    }
    
    private void ensureAllocated(final boolean b) {
        if (this.memory == null) {
            this.allocateMemory(b);
        }
        else if (this.size == -1) {
            this.size = this.calculateSize(true, b);
            if (!(this.memory instanceof AutoAllocated)) {
                try {
                    this.memory = this.memory.share(0L, this.size);
                }
                catch (IndexOutOfBoundsException ex) {
                    throw new IllegalArgumentException("Structure exceeds provided memory bounds", ex);
                }
            }
        }
    }
    
    protected void allocateMemory() {
        this.allocateMemory(false);
    }
    
    private void allocateMemory(final boolean b) {
        this.allocateMemory(this.calculateSize(true, b));
    }
    
    protected void allocateMemory(int calculateSize) {
        if (calculateSize == -1) {
            calculateSize = this.calculateSize(false);
        }
        else if (calculateSize <= 0) {
            throw new IllegalArgumentException("Structure size must be greater than zero: " + calculateSize);
        }
        if (calculateSize != -1) {
            if (this.memory == null || this.memory instanceof AutoAllocated) {
                this.memory = this.autoAllocate(calculateSize);
            }
            this.size = calculateSize;
        }
    }
    
    public int size() {
        this.ensureAllocated();
        return this.size;
    }
    
    public void clear() {
        this.ensureAllocated();
        this.memory.clear(this.size());
    }
    
    public Pointer getPointer() {
        this.ensureAllocated();
        return this.memory;
    }
    
    static Set busy() {
        return Structure.busy.get();
    }
    
    static Map reading() {
        return Structure.reads.get();
    }
    
    void conditionalAutoRead() {
        if (!this.readCalled) {
            this.autoRead();
        }
    }
    
    public void read() {
        if (this.memory == Structure.PLACEHOLDER_MEMORY) {
            return;
        }
        this.readCalled = true;
        this.ensureAllocated();
        if (busy().contains(this)) {
            return;
        }
        busy().add(this);
        if (this instanceof ByReference) {
            reading().put(this.getPointer(), this);
        }
        try {
            final Iterator<StructField> iterator = this.fields().values().iterator();
            while (iterator.hasNext()) {
                this.readField(iterator.next());
            }
        }
        finally {
            busy().remove(this);
            if (reading().get(this.getPointer()) == this) {
                reading().remove(this.getPointer());
            }
        }
    }
    
    protected int fieldOffset(final String s) {
        this.ensureAllocated();
        final StructField structField = this.fields().get(s);
        if (structField == null) {
            throw new IllegalArgumentException("No such field: " + s);
        }
        return structField.offset;
    }
    
    public Object readField(final String s) {
        this.ensureAllocated();
        final StructField structField = this.fields().get(s);
        if (structField == null) {
            throw new IllegalArgumentException("No such field: " + s);
        }
        return this.readField(structField);
    }
    
    Object getFieldValue(final Field field) {
        try {
            return field.get(this);
        }
        catch (Exception ex) {
            throw new Error("Exception reading field '" + field.getName() + "' in " + this.getClass(), ex);
        }
    }
    
    void setFieldValue(final Field field, final Object o) {
        this.setFieldValue(field, o, false);
    }
    
    private void setFieldValue(final Field field, final Object o, final boolean b) {
        try {
            field.set(this, o);
        }
        catch (IllegalAccessException ex) {
            if (!Modifier.isFinal(field.getModifiers())) {
                throw new Error("Unexpectedly unable to write to field '" + field.getName() + "' within " + this.getClass(), ex);
            }
            if (b) {
                throw new UnsupportedOperationException("This VM does not support Structures with final fields (field '" + field.getName() + "' within " + this.getClass() + ")", ex);
            }
            throw new UnsupportedOperationException("Attempt to write to read-only field '" + field.getName() + "' within " + this.getClass(), ex);
        }
    }
    
    static Structure updateStructureByReference(final Class clazz, Structure instance, final Pointer pointer) {
        if (pointer == null) {
            instance = null;
        }
        else if (instance == null || !pointer.equals(instance.getPointer())) {
            final Structure structure = reading().get(pointer);
            if (structure != null && clazz.equals(structure.getClass())) {
                instance = structure;
                instance.autoRead();
            }
            else {
                instance = newInstance(clazz, pointer);
                instance.conditionalAutoRead();
            }
        }
        else {
            instance.autoRead();
        }
        return instance;
    }
    
    protected Object readField(final StructField structField) {
        final int offset = structField.offset;
        Class clazz = structField.type;
        final FromNativeConverter readConverter = structField.readConverter;
        if (readConverter != null) {
            clazz = readConverter.nativeType();
        }
        final Object o = (Structure.class.isAssignableFrom(clazz) || Callback.class.isAssignableFrom(clazz) || (Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(clazz)) || Pointer.class.isAssignableFrom(clazz) || NativeMapped.class.isAssignableFrom(clazz) || clazz.isArray()) ? this.getFieldValue(structField.field) : null;
        Object o2;
        if (clazz == String.class) {
            final Pointer pointer = this.memory.getPointer(offset);
            o2 = ((pointer == null) ? null : pointer.getString(0L, this.encoding));
        }
        else {
            o2 = this.memory.getValue(offset, clazz, o);
        }
        if (readConverter != null) {
            o2 = readConverter.fromNative(o2, structField.context);
            if (o != null && o.equals(o2)) {
                o2 = o;
            }
        }
        if (clazz.equals(String.class) || clazz.equals(WString.class)) {
            this.nativeStrings.put(structField.name + ".ptr", this.memory.getPointer(offset));
            this.nativeStrings.put(structField.name + ".val", o2);
        }
        this.setFieldValue(structField.field, o2, true);
        return o2;
    }
    
    public void write() {
        if (this.memory == Structure.PLACEHOLDER_MEMORY) {
            return;
        }
        this.ensureAllocated();
        if (this instanceof ByValue) {
            this.getTypeInfo();
        }
        if (busy().contains(this)) {
            return;
        }
        busy().add(this);
        try {
            for (final StructField structField : this.fields().values()) {
                if (!structField.isVolatile) {
                    this.writeField(structField);
                }
            }
        }
        finally {
            busy().remove(this);
        }
    }
    
    public void writeField(final String s) {
        this.ensureAllocated();
        final StructField structField = this.fields().get(s);
        if (structField == null) {
            throw new IllegalArgumentException("No such field: " + s);
        }
        this.writeField(structField);
    }
    
    public void writeField(final String s, final Object o) {
        this.ensureAllocated();
        final StructField structField = this.fields().get(s);
        if (structField == null) {
            throw new IllegalArgumentException("No such field: " + s);
        }
        this.setFieldValue(structField.field, o);
        this.writeField(structField);
    }
    
    protected void writeField(final StructField structField) {
        if (structField.isReadOnly) {
            return;
        }
        final int offset = structField.offset;
        Object o = this.getFieldValue(structField.field);
        Class clazz = structField.type;
        final ToNativeConverter writeConverter = structField.writeConverter;
        if (writeConverter != null) {
            o = writeConverter.toNative(o, new StructureWriteContext(this, structField.field));
            clazz = writeConverter.nativeType();
        }
        if (String.class == clazz || WString.class == clazz) {
            final boolean b = clazz == WString.class;
            if (o != null) {
                if (this.nativeStrings.containsKey(structField.name + ".ptr") && o.equals(this.nativeStrings.get(structField.name + ".val"))) {
                    return;
                }
                final NativeString nativeString = b ? new NativeString(o.toString(), true) : new NativeString(o.toString(), this.encoding);
                this.nativeStrings.put(structField.name, nativeString);
                o = nativeString.getPointer();
            }
            else {
                this.nativeStrings.remove(structField.name);
            }
            this.nativeStrings.remove(structField.name + ".ptr");
            this.nativeStrings.remove(structField.name + ".val");
        }
        try {
            this.memory.setValue(offset, o, clazz);
        }
        catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Structure field \"" + structField.name + "\" was declared as " + structField.type + ((structField.type == clazz) ? "" : (" (native type " + clazz + ")")) + ", which is not supported within a Structure", ex);
        }
    }
    
    protected abstract List getFieldOrder();
    
    protected final void setFieldOrder(final String[] array) {
        throw new Error("This method is obsolete, use getFieldOrder() instead");
    }
    
    protected void sortFields(final List list, final List list2) {
        for (int i = 0; i < list2.size(); ++i) {
            final String s = list2.get(i);
            for (int j = 0; j < list.size(); ++j) {
                if (s.equals(list.get(j).getName())) {
                    Collections.swap(list, i, j);
                    break;
                }
            }
        }
    }
    
    protected List getFieldList() {
        final ArrayList list = new ArrayList();
        for (Serializable s = this.getClass(); !s.equals(Structure.class); s = ((Class<? extends Structure>)s).getSuperclass()) {
            final ArrayList<Field> list2 = new ArrayList<Field>();
            final Field[] declaredFields = ((Class)s).getDeclaredFields();
            for (int i = 0; i < declaredFields.length; ++i) {
                final int modifiers = declaredFields[i].getModifiers();
                if (!Modifier.isStatic(modifiers)) {
                    if (Modifier.isPublic(modifiers)) {
                        list2.add(declaredFields[i]);
                    }
                }
            }
            list.addAll(0, list2);
        }
        return list;
    }
    
    private List fieldOrder() {
        synchronized (Structure.fieldOrder) {
            List fieldOrder = Structure.fieldOrder.get(this.getClass());
            if (fieldOrder == null) {
                fieldOrder = this.getFieldOrder();
                Structure.fieldOrder.put(this.getClass(), fieldOrder);
            }
            return fieldOrder;
        }
    }
    
    private List sort(final Collection collection) {
        final ArrayList<Comparable> list = new ArrayList<Comparable>(collection);
        Collections.sort(list);
        return list;
    }
    
    protected List getFields(final boolean b) {
        final List fieldList = this.getFieldList();
        final HashSet<String> set = new HashSet<String>();
        final Iterator<Field> iterator = fieldList.iterator();
        while (iterator.hasNext()) {
            set.add(iterator.next().getName());
        }
        final List fieldOrder = this.fieldOrder();
        if (fieldOrder.size() != fieldList.size() && fieldList.size() > 1) {
            if (b) {
                throw new Error("Structure.getFieldOrder() on " + this.getClass() + " does not provide enough names [" + fieldOrder.size() + "] (" + this.sort(fieldOrder) + ") to match declared fields [" + fieldList.size() + "] (" + this.sort(set) + ")");
            }
            return null;
        }
        else {
            if (!new HashSet(fieldOrder).equals(set)) {
                throw new Error("Structure.getFieldOrder() on " + this.getClass() + " returns names (" + this.sort(fieldOrder) + ") which do not match declared field names (" + this.sort(set) + ")");
            }
            this.sortFields(fieldList, fieldOrder);
            return fieldList;
        }
    }
    
    protected int calculateSize(final boolean b) {
        return this.calculateSize(b, false);
    }
    
    static int size(final Class clazz) {
        return size(clazz, null);
    }
    
    static int size(final Class clazz, Structure instance) {
        final LayoutInfo layoutInfo;
        synchronized (Structure.layoutInfo) {
            layoutInfo = Structure.layoutInfo.get(clazz);
        }
        int size = (layoutInfo != null && !layoutInfo.variable) ? layoutInfo.size : -1;
        if (size == -1) {
            if (instance == null) {
                instance = newInstance(clazz, Structure.PLACEHOLDER_MEMORY);
            }
            size = instance.size();
        }
        return size;
    }
    
    int calculateSize(final boolean b, final boolean b2) {
        int access$100 = -1;
        LayoutInfo deriveLayout;
        synchronized (Structure.layoutInfo) {
            deriveLayout = Structure.layoutInfo.get(this.getClass());
        }
        if (deriveLayout == null || this.alignType != deriveLayout.alignType || this.typeMapper != deriveLayout.typeMapper) {
            deriveLayout = this.deriveLayout(b, b2);
        }
        if (deriveLayout != null) {
            this.structAlignment = deriveLayout.alignment;
            this.structFields = deriveLayout.fields;
            if (!deriveLayout.variable) {
                synchronized (Structure.layoutInfo) {
                    if (!Structure.layoutInfo.containsKey(this.getClass()) || this.alignType != 0 || this.typeMapper != null) {
                        Structure.layoutInfo.put(this.getClass(), deriveLayout);
                    }
                }
            }
            access$100 = deriveLayout.size;
        }
        return access$100;
    }
    
    private void validateField(final String s, final Class clazz) {
        if (this.typeMapper != null) {
            final ToNativeConverter toNativeConverter = this.typeMapper.getToNativeConverter(clazz);
            if (toNativeConverter != null) {
                this.validateField(s, toNativeConverter.nativeType());
                return;
            }
        }
        if (clazz.isArray()) {
            this.validateField(s, clazz.getComponentType());
        }
        else {
            try {
                this.getNativeSize(clazz);
            }
            catch (IllegalArgumentException ex) {
                throw new IllegalArgumentException("Invalid Structure field in " + this.getClass() + ", field name '" + s + "' (" + clazz + "): " + ex.getMessage(), ex);
            }
        }
    }
    
    private void validateFields() {
        for (final Field field : this.getFieldList()) {
            this.validateField(field.getName(), field.getType());
        }
    }
    
    private LayoutInfo deriveLayout(final boolean b, final boolean b2) {
        int max = 0;
        final List fields = this.getFields(b);
        if (fields == null) {
            return null;
        }
        final LayoutInfo layoutInfo = new LayoutInfo();
        layoutInfo.alignType = this.alignType;
        layoutInfo.typeMapper = this.typeMapper;
        boolean b3 = true;
        for (final Field field : fields) {
            final int modifiers = field.getModifiers();
            final Class<?> type = field.getType();
            if (type.isArray()) {
                layoutInfo.variable = true;
            }
            final StructField structField = new StructField();
            structField.isVolatile = Modifier.isVolatile(modifiers);
            structField.isReadOnly = Modifier.isFinal(modifiers);
            if (structField.isReadOnly) {
                if (!Platform.RO_FIELDS) {
                    throw new IllegalArgumentException("This VM does not support read-only fields (field '" + field.getName() + "' within " + this.getClass() + ")");
                }
                field.setAccessible(true);
            }
            structField.field = field;
            structField.name = field.getName();
            structField.type = type;
            if (Callback.class.isAssignableFrom(type) && !type.isInterface()) {
                throw new IllegalArgumentException("Structure Callback field '" + field.getName() + "' must be an interface");
            }
            if (type.isArray() && Structure.class.equals(type.getComponentType())) {
                throw new IllegalArgumentException("Nested Structure arrays must use a derived Structure type so that the size of the elements can be determined");
            }
            if (Modifier.isPublic(field.getModifiers())) {
                Object o = this.getFieldValue(structField.field);
                if (o == null && type.isArray()) {
                    if (b) {
                        throw new IllegalStateException("Array fields must be initialized");
                    }
                    return null;
                }
                else {
                    Class<?> nativeType = type;
                    if (NativeMapped.class.isAssignableFrom(type)) {
                        final NativeMappedConverter instance = NativeMappedConverter.getInstance(type);
                        nativeType = (Class<?>)instance.nativeType();
                        structField.writeConverter = instance;
                        structField.readConverter = instance;
                        structField.context = new StructureReadContext(this, field);
                    }
                    else if (this.typeMapper != null) {
                        final ToNativeConverter toNativeConverter = this.typeMapper.getToNativeConverter(type);
                        final FromNativeConverter fromNativeConverter = this.typeMapper.getFromNativeConverter(type);
                        if (toNativeConverter != null && fromNativeConverter != null) {
                            o = toNativeConverter.toNative(o, new StructureWriteContext(this, structField.field));
                            nativeType = ((o != null) ? o.getClass() : Pointer.class);
                            structField.writeConverter = toNativeConverter;
                            structField.readConverter = fromNativeConverter;
                            structField.context = new StructureReadContext(this, field);
                        }
                        else if (toNativeConverter != null || fromNativeConverter != null) {
                            throw new IllegalArgumentException("Structures require bidirectional type conversion for " + type);
                        }
                    }
                    if (o == null) {
                        o = this.initializeField(structField.field, type);
                    }
                    int nativeAlignment;
                    try {
                        structField.size = this.getNativeSize(nativeType, o);
                        nativeAlignment = this.getNativeAlignment(nativeType, o, b3);
                    }
                    catch (IllegalArgumentException ex) {
                        if (!b && this.typeMapper == null) {
                            return null;
                        }
                        throw new IllegalArgumentException("Invalid Structure field in " + this.getClass() + ", field name '" + structField.name + "' (" + structField.type + "): " + ex.getMessage(), ex);
                    }
                    if (nativeAlignment == 0) {
                        throw new Error("Field alignment is zero for field '" + structField.name + "' within " + this.getClass());
                    }
                    layoutInfo.alignment = Math.max(layoutInfo.alignment, nativeAlignment);
                    if (max % nativeAlignment != 0) {
                        max += nativeAlignment - max % nativeAlignment;
                    }
                    if (this instanceof Union) {
                        structField.offset = 0;
                        max = Math.max(max, structField.size);
                    }
                    else {
                        structField.offset = max;
                        max += structField.size;
                    }
                    layoutInfo.fields.put(structField.name, structField);
                    if (layoutInfo.typeInfoField == null || layoutInfo.typeInfoField.size < structField.size || (layoutInfo.typeInfoField.size == structField.size && Structure.class.isAssignableFrom(structField.type))) {
                        layoutInfo.typeInfoField = structField;
                    }
                }
            }
            b3 = false;
        }
        if (max > 0) {
            final int addPadding = this.addPadding(max, layoutInfo.alignment);
            if (this instanceof ByValue && !b2) {
                this.getTypeInfo();
            }
            layoutInfo.size = addPadding;
            return layoutInfo;
        }
        throw new IllegalArgumentException("Structure " + this.getClass() + " has unknown or zero size (ensure " + "all fields are public)");
    }
    
    private void initializeFields() {
        for (final Field field : this.getFieldList()) {
            try {
                if (field.get(this) != null) {
                    continue;
                }
                this.initializeField(field, field.getType());
            }
            catch (Exception ex) {
                throw new Error("Exception reading field '" + field.getName() + "' in " + this.getClass(), ex);
            }
        }
    }
    
    private Object initializeField(final Field field, final Class clazz) {
        Object o = null;
        if (Structure.class.isAssignableFrom(clazz) && !ByReference.class.isAssignableFrom(clazz)) {
            try {
                o = newInstance(clazz, Structure.PLACEHOLDER_MEMORY);
                this.setFieldValue(field, o);
                return o;
            }
            catch (IllegalArgumentException ex) {
                throw new IllegalArgumentException("Can't determine size of nested structure", ex);
            }
        }
        if (NativeMapped.class.isAssignableFrom(clazz)) {
            o = NativeMappedConverter.getInstance(clazz).defaultValue();
            this.setFieldValue(field, o);
        }
        return o;
    }
    
    private int addPadding(final int n) {
        return this.addPadding(n, this.structAlignment);
    }
    
    private int addPadding(int n, final int n2) {
        if (this.actualAlignType != 1 && n % n2 != 0) {
            n += n2 - n % n2;
        }
        return n;
    }
    
    protected int getStructAlignment() {
        if (this.size == -1) {
            this.calculateSize(true);
        }
        return this.structAlignment;
    }
    
    protected int getNativeAlignment(Class nativeType, Object o, final boolean b) {
        if (NativeMapped.class.isAssignableFrom(nativeType)) {
            final NativeMappedConverter instance = NativeMappedConverter.getInstance(nativeType);
            nativeType = instance.nativeType();
            o = instance.toNative(o, new ToNativeContext());
        }
        final int nativeSize = Native.getNativeSize(nativeType, o);
        int n;
        if (nativeType.isPrimitive() || Long.class == nativeType || Integer.class == nativeType || Short.class == nativeType || Character.class == nativeType || Byte.class == nativeType || Boolean.class == nativeType || Float.class == nativeType || Double.class == nativeType) {
            n = nativeSize;
        }
        else if ((Pointer.class.isAssignableFrom(nativeType) && !Function.class.isAssignableFrom(nativeType)) || (Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(nativeType)) || Callback.class.isAssignableFrom(nativeType) || WString.class == nativeType || String.class == nativeType) {
            n = Pointer.SIZE;
        }
        else if (Structure.class.isAssignableFrom(nativeType)) {
            if (ByReference.class.isAssignableFrom(nativeType)) {
                n = Pointer.SIZE;
            }
            else {
                if (o == null) {
                    o = newInstance(nativeType, Structure.PLACEHOLDER_MEMORY);
                }
                n = ((Structure)o).getStructAlignment();
            }
        }
        else {
            if (!nativeType.isArray()) {
                throw new IllegalArgumentException("Type " + nativeType + " has unknown " + "native alignment");
            }
            n = this.getNativeAlignment(nativeType.getComponentType(), null, b);
        }
        if (this.actualAlignType == 1) {
            n = 1;
        }
        else if (this.actualAlignType == 3) {
            n = Math.min(8, n);
        }
        else if (this.actualAlignType == 2) {
            if (!b || !Platform.isMac() || !Platform.isPPC()) {
                n = Math.min(Native.MAX_ALIGNMENT, n);
            }
            if (!b && Platform.isAIX() && (nativeType == Double.TYPE || nativeType == Double.class)) {
                n = 4;
            }
        }
        return n;
    }
    
    @Override
    public String toString() {
        return this.toString(Boolean.getBoolean("jna.dump_memory"));
    }
    
    public String toString(final boolean b) {
        return this.toString(0, true, b);
    }
    
    private String format(final Class clazz) {
        final String name = clazz.getName();
        return name.substring(name.lastIndexOf(".") + 1);
    }
    
    private String toString(final int n, final boolean b, final boolean b2) {
        this.ensureAllocated();
        final String property = System.getProperty("line.separator");
        String s = this.format(this.getClass()) + "(" + this.getPointer() + ")";
        if (!(this.getPointer() instanceof Memory)) {
            s = s + " (" + this.size() + " bytes)";
        }
        String string = "";
        for (int i = 0; i < n; ++i) {
            string += "  ";
        }
        String s2 = property;
        if (!b) {
            s2 = "...}";
        }
        else {
            final Iterator<StructField> iterator = this.fields().values().iterator();
            while (iterator.hasNext()) {
                final StructField structField = iterator.next();
                Object o = this.getFieldValue(structField.field);
                String s3 = this.format(structField.type);
                String string2 = "";
                final String string3 = s2 + string;
                if (structField.type.isArray() && o != null) {
                    s3 = this.format(structField.type.getComponentType());
                    string2 = "[" + Array.getLength(o) + "]";
                }
                final String string4 = string3 + "  " + s3 + " " + structField.name + string2 + "@" + Integer.toHexString(structField.offset);
                if (o instanceof Structure) {
                    o = ((Structure)o).toString(n + 1, !(o instanceof ByReference), b2);
                }
                final String string5 = string4 + "=";
                String s4;
                if (o instanceof Long) {
                    s4 = string5 + Long.toHexString((long)o);
                }
                else if (o instanceof Integer) {
                    s4 = string5 + Integer.toHexString((int)o);
                }
                else if (o instanceof Short) {
                    s4 = string5 + Integer.toHexString((short)o);
                }
                else if (o instanceof Byte) {
                    s4 = string5 + Integer.toHexString((byte)o);
                }
                else {
                    s4 = string5 + String.valueOf(o).trim();
                }
                s2 = s4 + property;
                if (!iterator.hasNext()) {
                    s2 = s2 + string + "}";
                }
            }
        }
        if (n == 0 && b2) {
            String s5 = s2 + property + "memory dump" + property;
            final byte[] byteArray = this.getPointer().getByteArray(0L, this.size());
            for (int j = 0; j < byteArray.length; ++j) {
                if (j % 4 == 0) {
                    s5 += "[";
                }
                if (byteArray[j] >= 0 && byteArray[j] < 16) {
                    s5 += "0";
                }
                s5 += Integer.toHexString(byteArray[j] & 0xFF);
                if (j % 4 == 3 && j < byteArray.length - 1) {
                    s5 = s5 + "]" + property;
                }
            }
            s2 = s5 + "]";
        }
        return s + " {" + s2;
    }
    
    public Structure[] toArray(final Structure[] array) {
        this.ensureAllocated();
        if (this.memory instanceof AutoAllocated) {
            final Memory memory = (Memory)this.memory;
            final int n = array.length * this.size();
            if (memory.size() < n) {
                this.useMemory(this.autoAllocate(n));
            }
        }
        array[0] = this;
        final int size = this.size();
        for (int i = 1; i < array.length; ++i) {
            (array[i] = newInstance(this.getClass(), this.memory.share(i * size, size))).conditionalAutoRead();
        }
        if (!(this instanceof ByValue)) {
            this.array = array;
        }
        return array;
    }
    
    public Structure[] toArray(final int n) {
        return this.toArray((Structure[])Array.newInstance(this.getClass(), n));
    }
    
    private Class baseClass() {
        if ((this instanceof ByReference || this instanceof ByValue) && Structure.class.isAssignableFrom(this.getClass().getSuperclass())) {
            return this.getClass().getSuperclass();
        }
        return this.getClass();
    }
    
    public boolean dataEquals(final Structure structure) {
        return this.dataEquals(structure, false);
    }
    
    public boolean dataEquals(final Structure structure, final boolean b) {
        if (b) {
            structure.getPointer().clear(structure.size());
            structure.write();
            this.getPointer().clear(this.size());
            this.write();
        }
        final byte[] byteArray = structure.getPointer().getByteArray(0L, structure.size());
        final byte[] byteArray2 = this.getPointer().getByteArray(0L, this.size());
        if (byteArray.length == byteArray2.length) {
            for (int i = 0; i < byteArray.length; ++i) {
                if (byteArray[i] != byteArray2[i]) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof Structure && o.getClass() == this.getClass() && ((Structure)o).getPointer().equals(this.getPointer());
    }
    
    @Override
    public int hashCode() {
        if (this.getPointer() != null) {
            return this.getPointer().hashCode();
        }
        return this.getClass().hashCode();
    }
    
    protected void cacheTypeInfo(final Pointer pointer) {
        this.typeInfo = pointer.peer;
    }
    
    Pointer getFieldTypeInfo(final StructField structField) {
        Class clazz = structField.type;
        Object o = this.getFieldValue(structField.field);
        if (this.typeMapper != null) {
            final ToNativeConverter toNativeConverter = this.typeMapper.getToNativeConverter(clazz);
            if (toNativeConverter != null) {
                clazz = toNativeConverter.nativeType();
                o = toNativeConverter.toNative(o, new ToNativeContext());
            }
        }
        return get(o, clazz);
    }
    
    Pointer getTypeInfo() {
        final Pointer typeInfo = getTypeInfo(this);
        this.cacheTypeInfo(typeInfo);
        return typeInfo;
    }
    
    public void setAutoSynch(final boolean b) {
        this.setAutoRead(b);
        this.setAutoWrite(b);
    }
    
    public void setAutoRead(final boolean autoRead) {
        this.autoRead = autoRead;
    }
    
    public boolean getAutoRead() {
        return this.autoRead;
    }
    
    public void setAutoWrite(final boolean autoWrite) {
        this.autoWrite = autoWrite;
    }
    
    public boolean getAutoWrite() {
        return this.autoWrite;
    }
    
    static Pointer getTypeInfo(final Object o) {
        return FFIType.get(o);
    }
    
    private static Structure newInstance(final Class clazz, final long n) {
        try {
            final Structure instance = newInstance(clazz, (n == 0L) ? Structure.PLACEHOLDER_MEMORY : new Pointer(n));
            if (n != 0L) {
                instance.conditionalAutoRead();
            }
            return instance;
        }
        catch (Throwable t) {
            System.err.println("JNA: Error creating structure: " + t);
            return null;
        }
    }
    
    public static Structure newInstance(final Class clazz, final Pointer pointer) {
        try {
            return clazz.getConstructor(Pointer.class).newInstance(pointer);
        }
        catch (NoSuchMethodException ex4) {}
        catch (SecurityException ex5) {}
        catch (InstantiationException ex) {
            throw new IllegalArgumentException("Can't instantiate " + clazz, ex);
        }
        catch (IllegalAccessException ex2) {
            throw new IllegalArgumentException("Instantiation of " + clazz + " (Pointer) not allowed, is it public?", ex2);
        }
        catch (InvocationTargetException ex3) {
            final String string = "Exception thrown while instantiating an instance of " + clazz;
            ex3.printStackTrace();
            throw new IllegalArgumentException(string, ex3);
        }
        final Structure instance = newInstance(clazz);
        if (pointer != Structure.PLACEHOLDER_MEMORY) {
            instance.useMemory(pointer);
        }
        return instance;
    }
    
    public static Structure newInstance(final Class clazz) {
        try {
            final Structure structure = clazz.newInstance();
            if (structure instanceof ByValue) {
                structure.allocateMemory();
            }
            return structure;
        }
        catch (InstantiationException ex) {
            throw new IllegalArgumentException("Can't instantiate " + clazz, ex);
        }
        catch (IllegalAccessException ex2) {
            throw new IllegalArgumentException("Instantiation of " + clazz + " not allowed, is it public?", ex2);
        }
    }
    
    StructField typeInfoField() {
        final LayoutInfo layoutInfo;
        synchronized (Structure.layoutInfo) {
            layoutInfo = Structure.layoutInfo.get(this.getClass());
        }
        if (layoutInfo != null) {
            return layoutInfo.typeInfoField;
        }
        return null;
    }
    
    private static void structureArrayCheck(final Structure[] array) {
        if (ByReference[].class.isAssignableFrom(array.getClass())) {
            return;
        }
        final Pointer pointer = array[0].getPointer();
        final int size = array[0].size();
        for (int i = 1; i < array.length; ++i) {
            if (array[i].getPointer().peer != pointer.peer + size * i) {
                throw new IllegalArgumentException("Structure array elements must use contiguous memory (bad backing address at Structure array index " + i + ")");
            }
        }
    }
    
    public static void autoRead(final Structure[] array) {
        structureArrayCheck(array);
        if (array[0].array == array) {
            array[0].autoRead();
        }
        else {
            for (int i = 0; i < array.length; ++i) {
                if (array[i] != null) {
                    array[i].autoRead();
                }
            }
        }
    }
    
    public void autoRead() {
        if (this.getAutoRead()) {
            this.read();
            if (this.array != null) {
                for (int i = 1; i < this.array.length; ++i) {
                    this.array[i].autoRead();
                }
            }
        }
    }
    
    public static void autoWrite(final Structure[] array) {
        structureArrayCheck(array);
        if (array[0].array == array) {
            array[0].autoWrite();
        }
        else {
            for (int i = 0; i < array.length; ++i) {
                if (array[i] != null) {
                    array[i].autoWrite();
                }
            }
        }
    }
    
    public void autoWrite() {
        if (this.getAutoWrite()) {
            this.write();
            if (this.array != null) {
                for (int i = 1; i < this.array.length; ++i) {
                    this.array[i].autoWrite();
                }
            }
        }
    }
    
    protected int getNativeSize(final Class clazz) {
        return this.getNativeSize(clazz, null);
    }
    
    protected int getNativeSize(final Class clazz, final Object o) {
        return Native.getNativeSize(clazz, o);
    }
    
    static void validate(final Class clazz) {
        newInstance(clazz, Structure.PLACEHOLDER_MEMORY);
    }
    
    static {
        layoutInfo = new WeakHashMap();
        fieldOrder = new WeakHashMap();
        reads = new ThreadLocal() {
            @Override
            protected synchronized Object initialValue() {
                return new HashMap();
            }
        };
        busy = new ThreadLocal() {
            @Override
            protected synchronized Object initialValue() {
                return new StructureSet();
            }
        };
        PLACEHOLDER_MEMORY = new Pointer(0L) {
            @Override
            public Pointer share(final long n, final long n2) {
                return this;
            }
        };
    }
    
    private static class AutoAllocated extends Memory
    {
        public AutoAllocated(final int n) {
            super(n);
            super.clear();
        }
        
        @Override
        public String toString() {
            return "auto-" + super.toString();
        }
    }
    
    static class FFIType extends Structure
    {
        private static Map typeInfoMap;
        private static final int FFI_TYPE_STRUCT = 13;
        public size_t size;
        public short alignment;
        public short type;
        public Pointer elements;
        
        private FFIType(final Structure structure) {
            this.type = 13;
            structure.ensureAllocated(true);
            Pointer[] array;
            if (structure instanceof Union) {
                final StructField typeInfoField = ((Union)structure).typeInfoField();
                array = new Pointer[] { get(structure.getFieldValue(typeInfoField.field), typeInfoField.type), null };
            }
            else {
                array = new Pointer[structure.fields().size() + 1];
                int n = 0;
                final Iterator<StructField> iterator = structure.fields().values().iterator();
                while (iterator.hasNext()) {
                    array[n++] = structure.getFieldTypeInfo(iterator.next());
                }
            }
            this.init(array);
        }
        
        private FFIType(final Object o, final Class clazz) {
            this.type = 13;
            final int length = Array.getLength(o);
            final Pointer[] array = new Pointer[length + 1];
            final Pointer value = get(null, clazz.getComponentType());
            for (int i = 0; i < length; ++i) {
                array[i] = value;
            }
            this.init(array);
        }
        
        @Override
        protected List getFieldOrder() {
            return Arrays.asList("size", "alignment", "type", "elements");
        }
        
        private void init(final Pointer[] array) {
            (this.elements = new Memory(Pointer.SIZE * array.length)).write(0L, array, 0, array.length);
            this.write();
        }
        
        static Pointer get(final Object o) {
            if (o == null) {
                return FFITypes.ffi_type_pointer;
            }
            if (o instanceof Class) {
                return get(null, (Class)o);
            }
            return get(o, o.getClass());
        }
        
        private static Pointer get(Object instance, Class nativeType) {
            final TypeMapper typeMapper = Native.getTypeMapper(nativeType);
            if (typeMapper != null) {
                final ToNativeConverter toNativeConverter = typeMapper.getToNativeConverter(nativeType);
                if (toNativeConverter != null) {
                    nativeType = toNativeConverter.nativeType();
                }
            }
            synchronized (FFIType.typeInfoMap) {
                final Object value = FFIType.typeInfoMap.get(nativeType);
                if (value instanceof Pointer) {
                    return (Pointer)value;
                }
                if (value instanceof FFIType) {
                    return ((FFIType)value).getPointer();
                }
                if ((Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(nativeType)) || Callback.class.isAssignableFrom(nativeType)) {
                    FFIType.typeInfoMap.put(nativeType, FFITypes.ffi_type_pointer);
                    return FFITypes.ffi_type_pointer;
                }
                if (Structure.class.isAssignableFrom(nativeType)) {
                    if (instance == null) {
                        instance = Structure.newInstance(nativeType, Structure.PLACEHOLDER_MEMORY);
                    }
                    if (ByReference.class.isAssignableFrom(nativeType)) {
                        FFIType.typeInfoMap.put(nativeType, FFITypes.ffi_type_pointer);
                        return FFITypes.ffi_type_pointer;
                    }
                    final FFIType ffiType = new FFIType((Structure)instance);
                    FFIType.typeInfoMap.put(nativeType, ffiType);
                    return ffiType.getPointer();
                }
                else {
                    if (NativeMapped.class.isAssignableFrom(nativeType)) {
                        final NativeMappedConverter instance2 = NativeMappedConverter.getInstance(nativeType);
                        return get(instance2.toNative(instance, new ToNativeContext()), instance2.nativeType());
                    }
                    if (nativeType.isArray()) {
                        final FFIType ffiType2 = new FFIType(instance, nativeType);
                        FFIType.typeInfoMap.put(instance, ffiType2);
                        return ffiType2.getPointer();
                    }
                    throw new IllegalArgumentException("Unsupported type " + nativeType);
                }
            }
        }
        
        static {
            FFIType.typeInfoMap = new WeakHashMap();
            if (Native.POINTER_SIZE == 0) {
                throw new Error("Native library not initialized");
            }
            if (FFITypes.ffi_type_void == null) {
                throw new Error("FFI types not initialized");
            }
            FFIType.typeInfoMap.put(Void.TYPE, FFITypes.ffi_type_void);
            FFIType.typeInfoMap.put(Void.class, FFITypes.ffi_type_void);
            FFIType.typeInfoMap.put(Float.TYPE, FFITypes.ffi_type_float);
            FFIType.typeInfoMap.put(Float.class, FFITypes.ffi_type_float);
            FFIType.typeInfoMap.put(Double.TYPE, FFITypes.ffi_type_double);
            FFIType.typeInfoMap.put(Double.class, FFITypes.ffi_type_double);
            FFIType.typeInfoMap.put(Long.TYPE, FFITypes.ffi_type_sint64);
            FFIType.typeInfoMap.put(Long.class, FFITypes.ffi_type_sint64);
            FFIType.typeInfoMap.put(Integer.TYPE, FFITypes.ffi_type_sint32);
            FFIType.typeInfoMap.put(Integer.class, FFITypes.ffi_type_sint32);
            FFIType.typeInfoMap.put(Short.TYPE, FFITypes.ffi_type_sint16);
            FFIType.typeInfoMap.put(Short.class, FFITypes.ffi_type_sint16);
            final Pointer pointer = (Native.WCHAR_SIZE == 2) ? FFITypes.ffi_type_uint16 : FFITypes.ffi_type_uint32;
            FFIType.typeInfoMap.put(Character.TYPE, pointer);
            FFIType.typeInfoMap.put(Character.class, pointer);
            FFIType.typeInfoMap.put(Byte.TYPE, FFITypes.ffi_type_sint8);
            FFIType.typeInfoMap.put(Byte.class, FFITypes.ffi_type_sint8);
            FFIType.typeInfoMap.put(Pointer.class, FFITypes.ffi_type_pointer);
            FFIType.typeInfoMap.put(String.class, FFITypes.ffi_type_pointer);
            FFIType.typeInfoMap.put(WString.class, FFITypes.ffi_type_pointer);
            FFIType.typeInfoMap.put(Boolean.TYPE, FFITypes.ffi_type_uint32);
            FFIType.typeInfoMap.put(Boolean.class, FFITypes.ffi_type_uint32);
        }
        
        private static class FFITypes
        {
            private static Pointer ffi_type_void;
            private static Pointer ffi_type_float;
            private static Pointer ffi_type_double;
            private static Pointer ffi_type_longdouble;
            private static Pointer ffi_type_uint8;
            private static Pointer ffi_type_sint8;
            private static Pointer ffi_type_uint16;
            private static Pointer ffi_type_sint16;
            private static Pointer ffi_type_uint32;
            private static Pointer ffi_type_sint32;
            private static Pointer ffi_type_uint64;
            private static Pointer ffi_type_sint64;
            private static Pointer ffi_type_pointer;
        }
        
        public static class size_t extends IntegerType
        {
            public size_t() {
                this(0L);
            }
            
            public size_t(final long n) {
                super(Native.SIZE_T_SIZE, n);
            }
        }
    }
    
    protected static class StructField
    {
        public String name;
        public Class type;
        public Field field;
        public int size;
        public int offset;
        public boolean isVolatile;
        public boolean isReadOnly;
        public FromNativeConverter readConverter;
        public ToNativeConverter writeConverter;
        public FromNativeContext context;
        
        protected StructField() {
            this.size = -1;
            this.offset = -1;
        }
        
        @Override
        public String toString() {
            return this.name + "@" + this.offset + "[" + this.size + "] (" + this.type + ")";
        }
    }
    
    public interface ByReference
    {
    }
    
    private static class LayoutInfo
    {
        private int size;
        private int alignment;
        private final Map fields;
        private int alignType;
        private TypeMapper typeMapper;
        private boolean variable;
        private StructField typeInfoField;
        
        private LayoutInfo() {
            this.size = -1;
            this.alignment = 1;
            this.fields = Collections.synchronizedMap(new LinkedHashMap<Object, Object>());
            this.alignType = 0;
        }
    }
    
    static class StructureSet extends AbstractCollection implements Set
    {
        Structure[] elements;
        private int count;
        
        private void ensureCapacity(final int n) {
            if (this.elements == null) {
                this.elements = new Structure[n * 3 / 2];
            }
            else if (this.elements.length < n) {
                final Structure[] elements = new Structure[n * 3 / 2];
                System.arraycopy(this.elements, 0, elements, 0, this.elements.length);
                this.elements = elements;
            }
        }
        
        public Structure[] getElements() {
            return this.elements;
        }
        
        @Override
        public int size() {
            return this.count;
        }
        
        @Override
        public boolean contains(final Object o) {
            return this.indexOf(o) != -1;
        }
        
        @Override
        public boolean add(final Object o) {
            if (!this.contains(o)) {
                this.ensureCapacity(this.count + 1);
                this.elements[this.count++] = (Structure)o;
            }
            return true;
        }
        
        private int indexOf(final Object o) {
            final Structure structure = (Structure)o;
            for (int i = 0; i < this.count; ++i) {
                final Structure structure2 = this.elements[i];
                if (structure == structure2 || (structure.getClass() == structure2.getClass() && structure.size() == structure2.size() && structure.getPointer().equals(structure2.getPointer()))) {
                    return i;
                }
            }
            return -1;
        }
        
        @Override
        public boolean remove(final Object o) {
            final int index = this.indexOf(o);
            if (index != -1) {
                if (--this.count >= 0) {
                    this.elements[index] = this.elements[this.count];
                    this.elements[this.count] = null;
                }
                return true;
            }
            return false;
        }
        
        @Override
        public Iterator iterator() {
            final Structure[] array = new Structure[this.count];
            if (this.count > 0) {
                System.arraycopy(this.elements, 0, array, 0, this.count);
            }
            return Arrays.asList(array).iterator();
        }
    }
    
    public interface ByValue
    {
    }
}
