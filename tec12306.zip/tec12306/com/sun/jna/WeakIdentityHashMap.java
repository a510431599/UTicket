// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.jna;

import java.lang.ref.WeakReference;
import java.lang.ref.Reference;
import java.util.Collection;
import java.util.Iterator;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.lang.ref.ReferenceQueue;
import java.util.Map;

public class WeakIdentityHashMap implements Map
{
    private final ReferenceQueue queue;
    private Map backingStore;
    
    public WeakIdentityHashMap() {
        this.queue = new ReferenceQueue();
        this.backingStore = new HashMap();
    }
    
    @Override
    public void clear() {
        this.backingStore.clear();
        this.reap();
    }
    
    @Override
    public boolean containsKey(final Object o) {
        this.reap();
        return this.backingStore.containsKey(new IdentityWeakReference(o));
    }
    
    @Override
    public boolean containsValue(final Object o) {
        this.reap();
        return this.backingStore.containsValue(o);
    }
    
    @Override
    public Set entrySet() {
        this.reap();
        final HashSet<WeakIdentityHashMap$1> set = new HashSet<WeakIdentityHashMap$1>();
        for (final Entry<IdentityWeakReference, V> entry : this.backingStore.entrySet()) {
            set.add(new Entry() {
                final /* synthetic */ Object val$key = entry.getKey().get();
                final /* synthetic */ Object val$value = entry.getValue();
                
                @Override
                public Object getKey() {
                    return this.val$key;
                }
                
                @Override
                public Object getValue() {
                    return this.val$value;
                }
                
                @Override
                public Object setValue(final Object o) {
                    throw new UnsupportedOperationException();
                }
            });
        }
        return Collections.unmodifiableSet((Set<?>)set);
    }
    
    @Override
    public Set keySet() {
        this.reap();
        final HashSet<Object> set = new HashSet<Object>();
        final Iterator<IdentityWeakReference> iterator = this.backingStore.keySet().iterator();
        while (iterator.hasNext()) {
            set.add(iterator.next().get());
        }
        return Collections.unmodifiableSet((Set<?>)set);
    }
    
    @Override
    public boolean equals(final Object o) {
        return this.backingStore.equals(((WeakIdentityHashMap)o).backingStore);
    }
    
    @Override
    public Object get(final Object o) {
        this.reap();
        return this.backingStore.get(new IdentityWeakReference(o));
    }
    
    @Override
    public Object put(final Object o, final Object o2) {
        this.reap();
        return this.backingStore.put(new IdentityWeakReference(o), o2);
    }
    
    @Override
    public int hashCode() {
        this.reap();
        return this.backingStore.hashCode();
    }
    
    @Override
    public boolean isEmpty() {
        this.reap();
        return this.backingStore.isEmpty();
    }
    
    @Override
    public void putAll(final Map map) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public Object remove(final Object o) {
        this.reap();
        return this.backingStore.remove(new IdentityWeakReference(o));
    }
    
    @Override
    public int size() {
        this.reap();
        return this.backingStore.size();
    }
    
    @Override
    public Collection values() {
        this.reap();
        return this.backingStore.values();
    }
    
    private synchronized void reap() {
        for (Reference reference = this.queue.poll(); reference != null; reference = this.queue.poll()) {
            this.backingStore.remove(reference);
        }
    }
    
    class IdentityWeakReference extends WeakReference
    {
        int hash;
        
        IdentityWeakReference(final Object o) {
            super(o, WeakIdentityHashMap.this.queue);
            this.hash = System.identityHashCode(o);
        }
        
        @Override
        public int hashCode() {
            return this.hash;
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || this.get() == ((IdentityWeakReference)o).get();
        }
    }
}
