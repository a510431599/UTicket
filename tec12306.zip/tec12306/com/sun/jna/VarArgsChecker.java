// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.jna;

import java.lang.reflect.Method;

abstract class VarArgsChecker
{
    static VarArgsChecker create() {
        try {
            if (Method.class.getMethod("isVarArgs", (Class<?>[])new Class[0]) != null) {
                return new RealVarArgsChecker();
            }
            return new NoVarArgsChecker();
        }
        catch (NoSuchMethodException ex) {
            return new NoVarArgsChecker();
        }
        catch (SecurityException ex2) {
            return new NoVarArgsChecker();
        }
    }
    
    abstract boolean isVarArgs(final Method p0);
    
    private static final class NoVarArgsChecker extends VarArgsChecker
    {
        private NoVarArgsChecker() {
            super(null);
        }
        
        @Override
        boolean isVarArgs(final Method method) {
            return false;
        }
    }
    
    private static final class RealVarArgsChecker extends VarArgsChecker
    {
        private RealVarArgsChecker() {
            super(null);
        }
        
        @Override
        boolean isVarArgs(final Method method) {
            return method.isVarArgs();
        }
    }
}
