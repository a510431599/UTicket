// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.jna;

import java.util.List;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.WeakHashMap;
import java.util.Iterator;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import com.sun.jna.win32.DLLCallback;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.lang.ref.Reference;
import java.lang.reflect.Method;
import java.util.Map;
import java.lang.ref.WeakReference;

class CallbackReference extends WeakReference
{
    static final Map callbackMap;
    static final Map directCallbackMap;
    static final Map pointerCallbackMap;
    static final Map allocations;
    private static final Map allocatedMemory;
    private static final Method PROXY_CALLBACK_METHOD;
    private static final Map initializers;
    Pointer cbstruct;
    Pointer trampoline;
    CallbackProxy proxy;
    Method method;
    
    static void setCallbackThreadInitializer(final Callback callback, final CallbackThreadInitializer callbackThreadInitializer) {
        synchronized (CallbackReference.callbackMap) {
            if (callbackThreadInitializer != null) {
                CallbackReference.initializers.put(callback, callbackThreadInitializer);
            }
            else {
                CallbackReference.initializers.remove(callback);
            }
        }
    }
    
    private static ThreadGroup initializeThread(Callback callback, final AttachOptions attachOptions) {
        CallbackThreadInitializer callbackThreadInitializer = null;
        if (callback instanceof DefaultCallbackProxy) {
            callback = ((DefaultCallbackProxy)callback).getCallback();
        }
        synchronized (CallbackReference.callbackMap) {
            callbackThreadInitializer = CallbackReference.initializers.get(callback);
        }
        ThreadGroup threadGroup = null;
        if (callbackThreadInitializer != null) {
            threadGroup = callbackThreadInitializer.getThreadGroup(callback);
            attachOptions.name = callbackThreadInitializer.getName(callback);
            attachOptions.daemon = callbackThreadInitializer.isDaemon(callback);
            attachOptions.detach = callbackThreadInitializer.detach(callback);
            attachOptions.write();
        }
        return threadGroup;
    }
    
    public static Callback getCallback(final Class clazz, final Pointer pointer) {
        return getCallback(clazz, pointer, false);
    }
    
    private static Callback getCallback(final Class clazz, final Pointer pointer, final boolean b) {
        if (pointer == null) {
            return null;
        }
        if (!clazz.isInterface()) {
            throw new IllegalArgumentException("Callback type must be an interface");
        }
        final Map map = b ? CallbackReference.directCallbackMap : CallbackReference.callbackMap;
        synchronized (CallbackReference.callbackMap) {
            final Reference<Callback> reference = CallbackReference.pointerCallbackMap.get(pointer);
            if (reference == null) {
                final int n = AltCallingConvention.class.isAssignableFrom(clazz) ? 63 : 0;
                final HashMap<String, Method> hashMap = new HashMap<String, Method>(Native.getLibraryOptions(clazz));
                hashMap.put("invoking-method", getCallbackMethod(clazz));
                final Callback callback = (Callback)Proxy.newProxyInstance(clazz.getClassLoader(), new Class[] { clazz }, new NativeFunctionHandler(pointer, n, hashMap));
                map.put(callback, null);
                CallbackReference.pointerCallbackMap.put(pointer, new WeakReference<Callback>(callback));
                return callback;
            }
            final Callback callback2 = reference.get();
            if (callback2 != null && !clazz.isAssignableFrom(callback2.getClass())) {
                throw new IllegalStateException("Pointer " + pointer + " already mapped to " + callback2 + ".\nNative code may be re-using a default function pointer" + ", in which case you may need to use a common Callback class" + " wherever the function pointer is reused.");
            }
            return callback2;
        }
    }
    
    private CallbackReference(final Callback callback, final int n, boolean b) {
        super(callback);
        final TypeMapper typeMapper = Native.getTypeMapper(callback.getClass());
        final boolean ppc = Platform.isPPC();
        if (b) {
            final Method callbackMethod = getCallbackMethod(callback);
            final Class<?>[] parameterTypes = callbackMethod.getParameterTypes();
            for (int i = 0; i < parameterTypes.length; ++i) {
                if (ppc && (parameterTypes[i] == Float.TYPE || parameterTypes[i] == Double.TYPE)) {
                    b = false;
                    break;
                }
                if (typeMapper != null && typeMapper.getFromNativeConverter(parameterTypes[i]) != null) {
                    b = false;
                    break;
                }
            }
            if (typeMapper != null && typeMapper.getToNativeConverter(callbackMethod.getReturnType()) != null) {
                b = false;
            }
        }
        final String stringEncoding = Native.getStringEncoding(callback.getClass());
        if (b) {
            this.method = getCallbackMethod(callback);
            final Class<?>[] parameterTypes2 = this.method.getParameterTypes();
            final Class<?> returnType = this.method.getReturnType();
            int n2 = 1;
            if (callback instanceof DLLCallback) {
                n2 |= 0x2;
            }
            final long nativeCallback = Native.createNativeCallback(callback, this.method, parameterTypes2, returnType, n, n2, stringEncoding);
            this.cbstruct = ((nativeCallback != 0L) ? new Pointer(nativeCallback) : null);
            CallbackReference.allocatedMemory.put(this, new WeakReference<CallbackReference>(this));
        }
        else {
            if (callback instanceof CallbackProxy) {
                this.proxy = (CallbackProxy)callback;
            }
            else {
                this.proxy = new DefaultCallbackProxy(getCallbackMethod(callback), typeMapper, stringEncoding);
            }
            final Class[] parameterTypes3 = this.proxy.getParameterTypes();
            Class clazz = this.proxy.getReturnType();
            if (typeMapper != null) {
                for (int j = 0; j < parameterTypes3.length; ++j) {
                    final FromNativeConverter fromNativeConverter = typeMapper.getFromNativeConverter(parameterTypes3[j]);
                    if (fromNativeConverter != null) {
                        parameterTypes3[j] = fromNativeConverter.nativeType();
                    }
                }
                final ToNativeConverter toNativeConverter = typeMapper.getToNativeConverter(clazz);
                if (toNativeConverter != null) {
                    clazz = toNativeConverter.nativeType();
                }
            }
            for (int k = 0; k < parameterTypes3.length; ++k) {
                parameterTypes3[k] = this.getNativeType(parameterTypes3[k]);
                if (!isAllowableNativeType(parameterTypes3[k])) {
                    throw new IllegalArgumentException("Callback argument " + parameterTypes3[k] + " requires custom type conversion");
                }
            }
            final Class nativeType = this.getNativeType(clazz);
            if (!isAllowableNativeType(nativeType)) {
                throw new IllegalArgumentException("Callback return type " + nativeType + " requires custom type conversion");
            }
            final long nativeCallback2 = Native.createNativeCallback(this.proxy, CallbackReference.PROXY_CALLBACK_METHOD, parameterTypes3, nativeType, n, (callback instanceof DLLCallback) ? 2 : 0, stringEncoding);
            this.cbstruct = ((nativeCallback2 != 0L) ? new Pointer(nativeCallback2) : null);
        }
    }
    
    private Class getNativeType(final Class clazz) {
        if (Structure.class.isAssignableFrom(clazz)) {
            Structure.validate(clazz);
            if (!Structure.ByValue.class.isAssignableFrom(clazz)) {
                return Pointer.class;
            }
        }
        else {
            if (NativeMapped.class.isAssignableFrom(clazz)) {
                return NativeMappedConverter.getInstance(clazz).nativeType();
            }
            if (clazz == String.class || clazz == WString.class || clazz == String[].class || clazz == WString[].class || Callback.class.isAssignableFrom(clazz)) {
                return Pointer.class;
            }
        }
        return clazz;
    }
    
    private static Method checkMethod(final Method method) {
        if (method.getParameterTypes().length > 256) {
            throw new UnsupportedOperationException("Method signature exceeds the maximum parameter count: " + method);
        }
        return method;
    }
    
    static Class findCallbackClass(final Class clazz) {
        if (!Callback.class.isAssignableFrom(clazz)) {
            throw new IllegalArgumentException(clazz.getName() + " is not derived from com.sun.jna.Callback");
        }
        if (clazz.isInterface()) {
            return clazz;
        }
        final Class<?>[] interfaces = clazz.getInterfaces();
        for (int i = 0; i < interfaces.length; ++i) {
            if (Callback.class.isAssignableFrom(interfaces[i])) {
                try {
                    getCallbackMethod(interfaces[i]);
                    return interfaces[i];
                }
                catch (IllegalArgumentException ex) {
                    break;
                }
            }
        }
        if (Callback.class.isAssignableFrom(clazz.getSuperclass())) {
            return findCallbackClass(clazz.getSuperclass());
        }
        return clazz;
    }
    
    private static Method getCallbackMethod(final Callback callback) {
        return getCallbackMethod(findCallbackClass(callback.getClass()));
    }
    
    private static Method getCallbackMethod(final Class clazz) {
        final Method[] declaredMethods = clazz.getDeclaredMethods();
        final Method[] methods = clazz.getMethods();
        final HashSet set = new HashSet<Object>(Arrays.asList(declaredMethods));
        set.retainAll(Arrays.asList(methods));
        final Iterator<Method> iterator = (Iterator<Method>)set.iterator();
        while (iterator.hasNext()) {
            if (Callback.FORBIDDEN_NAMES.contains(iterator.next().getName())) {
                iterator.remove();
            }
        }
        final Method[] array = set.toArray(new Method[set.size()]);
        if (array.length == 1) {
            return checkMethod(array[0]);
        }
        for (int i = 0; i < array.length; ++i) {
            final Method method = array[i];
            if ("callback".equals(method.getName())) {
                return checkMethod(method);
            }
        }
        throw new IllegalArgumentException("Callback must implement a single public method, or one public method named 'callback'");
    }
    
    private void setCallbackOptions(final int n) {
        this.cbstruct.setInt(Pointer.SIZE, n);
    }
    
    public Pointer getTrampoline() {
        if (this.trampoline == null) {
            this.trampoline = this.cbstruct.getPointer(0L);
        }
        return this.trampoline;
    }
    
    @Override
    protected void finalize() {
        this.dispose();
    }
    
    protected synchronized void dispose() {
        if (this.cbstruct != null) {
            Native.freeNativeCallback(this.cbstruct.peer);
            this.cbstruct.peer = 0L;
            this.cbstruct = null;
            CallbackReference.allocatedMemory.remove(this);
        }
    }
    
    static void disposeAll() {
        final Iterator<Memory> iterator = CallbackReference.allocatedMemory.keySet().iterator();
        while (iterator.hasNext()) {
            iterator.next().dispose();
        }
    }
    
    private Callback getCallback() {
        return this.get();
    }
    
    private static Pointer getNativeFunctionPointer(final Callback callback) {
        if (Proxy.isProxyClass(callback.getClass())) {
            final InvocationHandler invocationHandler = Proxy.getInvocationHandler(callback);
            if (invocationHandler instanceof NativeFunctionHandler) {
                return ((NativeFunctionHandler)invocationHandler).getPointer();
            }
        }
        return null;
    }
    
    public static Pointer getFunctionPointer(final Callback callback) {
        return getFunctionPointer(callback, false);
    }
    
    private static Pointer getFunctionPointer(final Callback callback, final boolean b) {
        if (callback == null) {
            return null;
        }
        final Pointer nativeFunctionPointer;
        if ((nativeFunctionPointer = getNativeFunctionPointer(callback)) != null) {
            return nativeFunctionPointer;
        }
        final int n = (callback instanceof AltCallingConvention) ? 63 : 0;
        final Map map = b ? CallbackReference.directCallbackMap : CallbackReference.callbackMap;
        synchronized (CallbackReference.callbackMap) {
            CallbackReference callbackReference = map.get(callback);
            if (callbackReference == null) {
                callbackReference = new CallbackReference(callback, n, b);
                map.put(callback, callbackReference);
                CallbackReference.pointerCallbackMap.put(callbackReference.getTrampoline(), new WeakReference<Callback>(callback));
                if (CallbackReference.initializers.containsKey(callback)) {
                    callbackReference.setCallbackOptions(1);
                }
            }
            return callbackReference.getTrampoline();
        }
    }
    
    private static boolean isAllowableNativeType(final Class clazz) {
        return clazz == Void.TYPE || clazz == Void.class || clazz == Boolean.TYPE || clazz == Boolean.class || clazz == Byte.TYPE || clazz == Byte.class || clazz == Short.TYPE || clazz == Short.class || clazz == Character.TYPE || clazz == Character.class || clazz == Integer.TYPE || clazz == Integer.class || clazz == Long.TYPE || clazz == Long.class || clazz == Float.TYPE || clazz == Float.class || clazz == Double.TYPE || clazz == Double.class || (Structure.ByValue.class.isAssignableFrom(clazz) && Structure.class.isAssignableFrom(clazz)) || Pointer.class.isAssignableFrom(clazz);
    }
    
    private static Pointer getNativeString(final Object o, final boolean b) {
        if (o != null) {
            final NativeString nativeString = new NativeString(o.toString(), b);
            CallbackReference.allocations.put(o, nativeString);
            return nativeString.getPointer();
        }
        return null;
    }
    
    static {
        callbackMap = new WeakHashMap();
        directCallbackMap = new WeakHashMap();
        pointerCallbackMap = new WeakHashMap();
        allocations = new WeakHashMap();
        allocatedMemory = Collections.synchronizedMap(new WeakHashMap<Object, Object>());
        try {
            PROXY_CALLBACK_METHOD = CallbackProxy.class.getMethod("callback", Object[].class);
        }
        catch (Exception ex) {
            throw new Error("Error looking up CallbackProxy.callback() method");
        }
        initializers = new WeakHashMap();
    }
    
    private static class NativeFunctionHandler implements InvocationHandler
    {
        private final Function function;
        private final Map options;
        
        public NativeFunctionHandler(final Pointer pointer, final int n, final Map options) {
            this.function = new Function(pointer, n, options.get("string-encoding"));
            this.options = options;
        }
        
        @Override
        public Object invoke(final Object o, final Method method, Object[] concatenateVarArgs) {
            if (Library.Handler.OBJECT_TOSTRING.equals(method)) {
                return "Proxy interface to " + this.function + " (" + CallbackReference.findCallbackClass(this.options.get("invoking-method").getDeclaringClass()).getName() + ")";
            }
            if (Library.Handler.OBJECT_HASHCODE.equals(method)) {
                return new Integer(this.hashCode());
            }
            if (!Library.Handler.OBJECT_EQUALS.equals(method)) {
                if (Function.isVarArgs(method)) {
                    concatenateVarArgs = Function.concatenateVarArgs(concatenateVarArgs);
                }
                return this.function.invoke(method.getReturnType(), concatenateVarArgs, this.options);
            }
            final Object o2 = concatenateVarArgs[0];
            if (o2 != null && Proxy.isProxyClass(o2.getClass())) {
                return Function.valueOf(Proxy.getInvocationHandler(o2) == this);
            }
            return Boolean.FALSE;
        }
        
        public Pointer getPointer() {
            return this.function;
        }
    }
    
    private class DefaultCallbackProxy implements CallbackProxy
    {
        private final Method callbackMethod;
        private ToNativeConverter toNative;
        private final FromNativeConverter[] fromNative;
        private final String encoding;
        
        public DefaultCallbackProxy(final Method callbackMethod, final TypeMapper typeMapper, final String encoding) {
            this.callbackMethod = callbackMethod;
            this.encoding = encoding;
            final Class<?>[] parameterTypes = callbackMethod.getParameterTypes();
            final Class<?> returnType = callbackMethod.getReturnType();
            this.fromNative = new FromNativeConverter[parameterTypes.length];
            if (NativeMapped.class.isAssignableFrom(returnType)) {
                this.toNative = NativeMappedConverter.getInstance(returnType);
            }
            else if (typeMapper != null) {
                this.toNative = typeMapper.getToNativeConverter(returnType);
            }
            for (int i = 0; i < this.fromNative.length; ++i) {
                if (NativeMapped.class.isAssignableFrom(parameterTypes[i])) {
                    this.fromNative[i] = new NativeMappedConverter(parameterTypes[i]);
                }
                else if (typeMapper != null) {
                    this.fromNative[i] = typeMapper.getFromNativeConverter(parameterTypes[i]);
                }
            }
            if (!callbackMethod.isAccessible()) {
                try {
                    callbackMethod.setAccessible(true);
                }
                catch (SecurityException ex) {
                    throw new IllegalArgumentException("Callback method is inaccessible, make sure the interface is public: " + callbackMethod);
                }
            }
        }
        
        public Callback getCallback() {
            return CallbackReference.this.getCallback();
        }
        
        private Object invokeCallback(final Object[] array) {
            final Class<?>[] parameterTypes = this.callbackMethod.getParameterTypes();
            final Object[] array2 = new Object[array.length];
            for (int i = 0; i < array.length; ++i) {
                final Class<?> clazz = parameterTypes[i];
                final Object o = array[i];
                if (this.fromNative[i] != null) {
                    array2[i] = this.fromNative[i].fromNative(o, new CallbackParameterContext(clazz, this.callbackMethod, array, i));
                }
                else {
                    array2[i] = this.convertArgument(o, clazz);
                }
            }
            Object convertResult = null;
            final Callback callback = this.getCallback();
            if (callback != null) {
                try {
                    convertResult = this.convertResult(this.callbackMethod.invoke(callback, array2));
                }
                catch (IllegalArgumentException ex) {
                    Native.getCallbackExceptionHandler().uncaughtException(callback, ex);
                }
                catch (IllegalAccessException ex2) {
                    Native.getCallbackExceptionHandler().uncaughtException(callback, ex2);
                }
                catch (InvocationTargetException ex3) {
                    Native.getCallbackExceptionHandler().uncaughtException(callback, ex3.getTargetException());
                }
            }
            for (int j = 0; j < array2.length; ++j) {
                if (array2[j] instanceof Structure && !(array2[j] instanceof Structure.ByValue)) {
                    ((Structure)array2[j]).autoWrite();
                }
            }
            return convertResult;
        }
        
        @Override
        public Object callback(final Object[] array) {
            try {
                return this.invokeCallback(array);
            }
            catch (Throwable t) {
                Native.getCallbackExceptionHandler().uncaughtException(this.getCallback(), t);
                return null;
            }
        }
        
        private Object convertArgument(Object o, final Class clazz) {
            if (o instanceof Pointer) {
                if (clazz == String.class) {
                    o = ((Pointer)o).getString(0L, this.encoding);
                }
                else if (clazz == WString.class) {
                    o = new WString(((Pointer)o).getWideString(0L));
                }
                else if (clazz == String[].class) {
                    o = ((Pointer)o).getStringArray(0L, this.encoding);
                }
                else if (clazz == WString[].class) {
                    o = ((Pointer)o).getWideStringArray(0L);
                }
                else if (Callback.class.isAssignableFrom(clazz)) {
                    final CallbackReference this$0 = CallbackReference.this;
                    o = CallbackReference.getCallback(clazz, (Pointer)o);
                }
                else if (Structure.class.isAssignableFrom(clazz)) {
                    if (Structure.ByValue.class.isAssignableFrom(clazz)) {
                        final Structure instance = Structure.newInstance(clazz);
                        final byte[] array = new byte[instance.size()];
                        ((Pointer)o).read(0L, array, 0, array.length);
                        instance.getPointer().write(0L, array, 0, array.length);
                        instance.read();
                        o = instance;
                    }
                    else {
                        final Structure instance2 = Structure.newInstance(clazz, (Pointer)o);
                        instance2.conditionalAutoRead();
                        o = instance2;
                    }
                }
            }
            else if ((Boolean.TYPE == clazz || Boolean.class == clazz) && o instanceof Number) {
                o = Function.valueOf(((Number)o).intValue() != 0);
            }
            return o;
        }
        
        private Object convertResult(Object native1) {
            if (this.toNative != null) {
                native1 = this.toNative.toNative(native1, new CallbackResultContext(this.callbackMethod));
            }
            if (native1 == null) {
                return null;
            }
            final Class<?> class1 = native1.getClass();
            if (Structure.class.isAssignableFrom(class1)) {
                if (Structure.ByValue.class.isAssignableFrom(class1)) {
                    return native1;
                }
                return ((Structure)native1).getPointer();
            }
            else {
                if (class1 == Boolean.TYPE || class1 == Boolean.class) {
                    return Boolean.TRUE.equals(native1) ? Function.INTEGER_TRUE : Function.INTEGER_FALSE;
                }
                if (class1 == String.class || class1 == WString.class) {
                    return getNativeString(native1, class1 == WString.class);
                }
                if (class1 == String[].class || class1 == WString.class) {
                    final StringArray stringArray = (class1 == String[].class) ? new StringArray((String[])native1, this.encoding) : new StringArray((WString[])native1);
                    CallbackReference.allocations.put(native1, stringArray);
                    return stringArray;
                }
                if (Callback.class.isAssignableFrom(class1)) {
                    return CallbackReference.getFunctionPointer((Callback)native1);
                }
                return native1;
            }
        }
        
        @Override
        public Class[] getParameterTypes() {
            return this.callbackMethod.getParameterTypes();
        }
        
        @Override
        public Class getReturnType() {
            return this.callbackMethod.getReturnType();
        }
    }
    
    static class AttachOptions extends Structure
    {
        public boolean daemon;
        public boolean detach;
        public String name;
        
        AttachOptions() {
            this.setStringEncoding("utf8");
        }
        
        @Override
        protected List getFieldOrder() {
            return Arrays.asList("daemon", "detach", "name");
        }
    }
}
