// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.jna;

import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.WeakHashMap;
import java.util.Map;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationHandler;

public interface Library
{
    public static final String OPTION_TYPE_MAPPER = "type-mapper";
    public static final String OPTION_FUNCTION_MAPPER = "function-mapper";
    public static final String OPTION_INVOCATION_MAPPER = "invocation-mapper";
    public static final String OPTION_STRUCTURE_ALIGNMENT = "structure-alignment";
    public static final String OPTION_STRING_ENCODING = "string-encoding";
    public static final String OPTION_ALLOW_OBJECTS = "allow-objects";
    public static final String OPTION_CALLING_CONVENTION = "calling-convention";
    public static final String OPTION_OPEN_FLAGS = "open-flags";
    public static final String OPTION_CLASSLOADER = "classloader";
    
    public static class Handler implements InvocationHandler
    {
        static final Method OBJECT_TOSTRING;
        static final Method OBJECT_HASHCODE;
        static final Method OBJECT_EQUALS;
        private final NativeLibrary nativeLibrary;
        private final Class interfaceClass;
        private final Map options;
        private final InvocationMapper invocationMapper;
        private final Map functions;
        
        public Handler(final String s, final Class interfaceClass, final Map map) {
            this.functions = new WeakHashMap();
            if (s != null && "".equals(s.trim())) {
                throw new IllegalArgumentException("Invalid library name \"" + s + "\"");
            }
            this.interfaceClass = interfaceClass;
            final HashMap<String, InvocationMapper> options = new HashMap<String, InvocationMapper>(map);
            final int n = AltCallingConvention.class.isAssignableFrom(interfaceClass) ? 63 : 0;
            if (options.get("calling-convention") == null) {
                options.put("calling-convention", (InvocationMapper)new Integer(n));
            }
            if (options.get("classloader") == null) {
                options.put("classloader", (InvocationMapper)interfaceClass.getClassLoader());
            }
            this.options = options;
            this.nativeLibrary = NativeLibrary.getInstance(s, options);
            this.invocationMapper = (InvocationMapper)options.get("invocation-mapper");
        }
        
        public NativeLibrary getNativeLibrary() {
            return this.nativeLibrary;
        }
        
        public String getLibraryName() {
            return this.nativeLibrary.getName();
        }
        
        public Class getInterfaceClass() {
            return this.interfaceClass;
        }
        
        @Override
        public Object invoke(final Object o, final Method method, Object[] concatenateVarArgs) {
            if (Handler.OBJECT_TOSTRING.equals(method)) {
                return "Proxy interface to " + this.nativeLibrary;
            }
            if (Handler.OBJECT_HASHCODE.equals(method)) {
                return new Integer(this.hashCode());
            }
            if (Handler.OBJECT_EQUALS.equals(method)) {
                final Object o2 = concatenateVarArgs[0];
                if (o2 != null && Proxy.isProxyClass(o2.getClass())) {
                    return Function.valueOf(Proxy.getInvocationHandler(o2) == this);
                }
                return Boolean.FALSE;
            }
            else {
                FunctionInfo functionInfo = this.functions.get(method);
                if (functionInfo == null) {
                    synchronized (this.functions) {
                        functionInfo = this.functions.get(method);
                        if (functionInfo == null) {
                            final boolean varArgs = Function.isVarArgs(method);
                            InvocationHandler invocationHandler = null;
                            if (this.invocationMapper != null) {
                                invocationHandler = this.invocationMapper.getInvocationHandler(this.nativeLibrary, method);
                            }
                            Function function = null;
                            Class<?>[] parameterTypes = null;
                            Map<String, Method> map = null;
                            if (invocationHandler == null) {
                                function = this.nativeLibrary.getFunction(method.getName(), method);
                                parameterTypes = method.getParameterTypes();
                                map = new HashMap<String, Method>(this.options);
                                map.put("invoking-method", method);
                            }
                            functionInfo = new FunctionInfo(invocationHandler, function, parameterTypes, varArgs, map);
                            this.functions.put(method, functionInfo);
                        }
                    }
                }
                if (functionInfo.isVarArgs) {
                    concatenateVarArgs = Function.concatenateVarArgs(concatenateVarArgs);
                }
                if (functionInfo.handler != null) {
                    return functionInfo.handler.invoke(o, method, concatenateVarArgs);
                }
                return functionInfo.function.invoke(method, functionInfo.parameterTypes, method.getReturnType(), concatenateVarArgs, functionInfo.options);
            }
        }
        
        static {
            try {
                OBJECT_TOSTRING = Object.class.getMethod("toString", (Class<?>[])new Class[0]);
                OBJECT_HASHCODE = Object.class.getMethod("hashCode", (Class<?>[])new Class[0]);
                OBJECT_EQUALS = Object.class.getMethod("equals", Object.class);
            }
            catch (Exception ex) {
                throw new Error("Error retrieving Object.toString() method");
            }
        }
        
        private static final class FunctionInfo
        {
            final InvocationHandler handler;
            final Function function;
            final boolean isVarArgs;
            final Map options;
            final Class[] parameterTypes;
            
            FunctionInfo(final InvocationHandler handler, final Function function, final Class[] parameterTypes, final boolean isVarArgs, final Map options) {
                this.handler = handler;
                this.function = function;
                this.isVarArgs = isVarArgs;
                this.options = options;
                this.parameterTypes = parameterTypes;
            }
        }
    }
}
