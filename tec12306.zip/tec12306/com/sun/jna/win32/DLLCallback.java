// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.jna.win32;

import com.sun.jna.Callback;

public interface DLLCallback extends Callback
{
    public static final int DLL_FPTRS = 16;
}
