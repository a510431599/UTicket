// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.jna;

public interface TypeConverter extends FromNativeConverter, ToNativeConverter
{
}
