// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.activation.registries;

public class MailcapParseException extends Exception
{
    public MailcapParseException() {
    }
    
    public MailcapParseException(final String s) {
        super(s);
    }
}
