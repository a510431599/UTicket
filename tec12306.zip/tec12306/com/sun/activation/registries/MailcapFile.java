// 
// Decompiled by Procyon v0.5.30
// 

package com.sun.activation.registries;

import java.util.LinkedHashMap;
import java.io.StringReader;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Collection;
import java.util.HashSet;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class MailcapFile
{
    private Map type_hash;
    private Map fallback_hash;
    private Map native_commands;
    private static boolean addReverse;
    
    public MailcapFile(final String s) {
        this.type_hash = new HashMap();
        this.fallback_hash = new HashMap();
        this.native_commands = new HashMap();
        if (LogSupport.isLoggable()) {
            LogSupport.log(new StringBuffer().append("new MailcapFile: file ").append(s).toString());
        }
        Reader reader = null;
        try {
            reader = new FileReader(s);
            this.parse(new BufferedReader(reader));
        }
        finally {
            if (reader != null) {
                try {
                    ((InputStreamReader)reader).close();
                }
                catch (IOException ex) {}
            }
        }
    }
    
    public MailcapFile(final InputStream inputStream) {
        this.type_hash = new HashMap();
        this.fallback_hash = new HashMap();
        this.native_commands = new HashMap();
        if (LogSupport.isLoggable()) {
            LogSupport.log("new MailcapFile: InputStream");
        }
        this.parse(new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1")));
    }
    
    public MailcapFile() {
        this.type_hash = new HashMap();
        this.fallback_hash = new HashMap();
        this.native_commands = new HashMap();
        if (LogSupport.isLoggable()) {
            LogSupport.log("new MailcapFile: default");
        }
    }
    
    public Map getMailcapList(final String s) {
        Map mergeResults = this.type_hash.get(s);
        final int index = s.indexOf(47);
        if (!s.substring(index + 1).equals("*")) {
            final Map map = this.type_hash.get(new StringBuffer().append(s.substring(0, index + 1)).append("*").toString());
            if (map != null) {
                if (mergeResults != null) {
                    mergeResults = this.mergeResults(mergeResults, map);
                }
                else {
                    mergeResults = map;
                }
            }
        }
        return mergeResults;
    }
    
    public Map getMailcapFallbackList(final String s) {
        Map mergeResults = this.fallback_hash.get(s);
        final int index = s.indexOf(47);
        if (!s.substring(index + 1).equals("*")) {
            final Map map = this.fallback_hash.get(new StringBuffer().append(s.substring(0, index + 1)).append("*").toString());
            if (map != null) {
                if (mergeResults != null) {
                    mergeResults = this.mergeResults(mergeResults, map);
                }
                else {
                    mergeResults = map;
                }
            }
        }
        return mergeResults;
    }
    
    public String[] getMimeTypes() {
        final HashSet set = new HashSet(this.type_hash.keySet());
        set.addAll(this.fallback_hash.keySet());
        set.addAll(this.native_commands.keySet());
        return (String[])set.toArray(new String[set.size()]);
    }
    
    public String[] getNativeCommands(final String s) {
        String[] array = null;
        final List list = this.native_commands.get(s.toLowerCase());
        if (list != null) {
            array = (String[])list.toArray(new String[list.size()]);
        }
        return array;
    }
    
    private Map mergeResults(final Map map, final Map map2) {
        final Iterator<String> iterator = map2.keySet().iterator();
        final HashMap<String, ArrayList<? extends E>> hashMap = new HashMap<String, ArrayList<? extends E>>(map);
        while (iterator.hasNext()) {
            final String s = iterator.next();
            final List<? extends E> list = hashMap.get(s);
            if (list == null) {
                hashMap.put(s, (ArrayList<? extends E>)map2.get(s));
            }
            else {
                final List list2 = (List)map2.get(s);
                final ArrayList list3 = new ArrayList<Object>(list);
                list3.addAll((Collection<?>)list2);
                hashMap.put(s, (ArrayList<? extends E>)list3);
            }
        }
        return hashMap;
    }
    
    public void appendToMailcap(final String s) {
        if (LogSupport.isLoggable()) {
            LogSupport.log(new StringBuffer().append("appendToMailcap: ").append(s).toString());
        }
        try {
            this.parse(new StringReader(s));
        }
        catch (IOException ex) {}
    }
    
    private void parse(final Reader reader) {
        final BufferedReader bufferedReader = new BufferedReader(reader);
        String s = null;
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            final String trim = line.trim();
            try {
                if (trim.charAt(0) == '#') {
                    continue;
                }
                if (trim.charAt(trim.length() - 1) == '\\') {
                    if (s != null) {
                        s = new StringBuffer().append(s).append(trim.substring(0, trim.length() - 1)).toString();
                    }
                    else {
                        s = trim.substring(0, trim.length() - 1);
                    }
                }
                else if (s != null) {
                    s = new StringBuffer().append(s).append(trim).toString();
                    try {
                        this.parseLine(s);
                    }
                    catch (MailcapParseException ex) {}
                    s = null;
                }
                else {
                    try {
                        this.parseLine(trim);
                    }
                    catch (MailcapParseException ex2) {}
                }
            }
            catch (StringIndexOutOfBoundsException ex3) {}
        }
    }
    
    protected void parseLine(final String s) {
        final MailcapTokenizer mailcapTokenizer = new MailcapTokenizer(s);
        mailcapTokenizer.setIsAutoquoting(false);
        if (LogSupport.isLoggable()) {
            LogSupport.log(new StringBuffer().append("parse: ").append(s).toString());
        }
        final int nextToken = mailcapTokenizer.nextToken();
        if (nextToken != 2) {
            reportParseError(2, nextToken, mailcapTokenizer.getCurrentTokenValue());
        }
        final String lowerCase = mailcapTokenizer.getCurrentTokenValue().toLowerCase();
        String lowerCase2 = "*";
        int n = mailcapTokenizer.nextToken();
        if (n != 47 && n != 59) {
            reportParseError(47, 59, n, mailcapTokenizer.getCurrentTokenValue());
        }
        if (n == 47) {
            final int nextToken2 = mailcapTokenizer.nextToken();
            if (nextToken2 != 2) {
                reportParseError(2, nextToken2, mailcapTokenizer.getCurrentTokenValue());
            }
            lowerCase2 = mailcapTokenizer.getCurrentTokenValue().toLowerCase();
            n = mailcapTokenizer.nextToken();
        }
        final String string = new StringBuffer().append(lowerCase).append("/").append(lowerCase2).toString();
        if (LogSupport.isLoggable()) {
            LogSupport.log(new StringBuffer().append("  Type: ").append(string).toString());
        }
        final LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<String, Object>();
        if (n != 59) {
            reportParseError(59, n, mailcapTokenizer.getCurrentTokenValue());
        }
        mailcapTokenizer.setIsAutoquoting(true);
        int n2 = mailcapTokenizer.nextToken();
        mailcapTokenizer.setIsAutoquoting(false);
        if (n2 != 2 && n2 != 59) {
            reportParseError(2, 59, n2, mailcapTokenizer.getCurrentTokenValue());
        }
        if (n2 == 2) {
            final List<String> list = this.native_commands.get(string);
            if (list == null) {
                final ArrayList<String> list2 = new ArrayList<String>();
                list2.add(s);
                this.native_commands.put(string, list2);
            }
            else {
                list.add(s);
            }
        }
        if (n2 != 59) {
            n2 = mailcapTokenizer.nextToken();
        }
        if (n2 == 59) {
            boolean b = false;
            int i;
            do {
                final int nextToken3 = mailcapTokenizer.nextToken();
                if (nextToken3 != 2) {
                    reportParseError(2, nextToken3, mailcapTokenizer.getCurrentTokenValue());
                }
                final String lowerCase3 = mailcapTokenizer.getCurrentTokenValue().toLowerCase();
                i = mailcapTokenizer.nextToken();
                if (i != 61 && i != 59 && i != 5) {
                    reportParseError(61, 59, 5, i, mailcapTokenizer.getCurrentTokenValue());
                }
                if (i == 61) {
                    mailcapTokenizer.setIsAutoquoting(true);
                    final int nextToken4 = mailcapTokenizer.nextToken();
                    mailcapTokenizer.setIsAutoquoting(false);
                    if (nextToken4 != 2) {
                        reportParseError(2, nextToken4, mailcapTokenizer.getCurrentTokenValue());
                    }
                    final String currentTokenValue = mailcapTokenizer.getCurrentTokenValue();
                    if (lowerCase3.startsWith("x-java-")) {
                        final String substring = lowerCase3.substring(7);
                        if (substring.equals("fallback-entry") && currentTokenValue.equalsIgnoreCase("true")) {
                            b = true;
                        }
                        else {
                            if (LogSupport.isLoggable()) {
                                LogSupport.log(new StringBuffer().append("    Command: ").append(substring).append(", Class: ").append(currentTokenValue).toString());
                            }
                            List<?> list3 = linkedHashMap.get(substring);
                            if (list3 == null) {
                                list3 = new ArrayList<Object>();
                                linkedHashMap.put(substring, list3);
                            }
                            if (MailcapFile.addReverse) {
                                list3.add(0, currentTokenValue);
                            }
                            else {
                                list3.add(currentTokenValue);
                            }
                        }
                    }
                    i = mailcapTokenizer.nextToken();
                }
            } while (i == 59);
            final Map map = b ? this.fallback_hash : this.type_hash;
            final LinkedHashMap<String, Object> linkedHashMap2 = map.get(string);
            if (linkedHashMap2 == null) {
                map.put(string, linkedHashMap);
            }
            else {
                if (LogSupport.isLoggable()) {
                    LogSupport.log(new StringBuffer().append("Merging commands for type ").append(string).toString());
                }
                for (final String s2 : linkedHashMap2.keySet()) {
                    final List<String> list4 = linkedHashMap2.get(s2);
                    final List<?> list5 = linkedHashMap.get(s2);
                    if (list5 == null) {
                        continue;
                    }
                    for (final String s3 : list5) {
                        if (!list4.contains(s3)) {
                            if (MailcapFile.addReverse) {
                                list4.add(0, s3);
                            }
                            else {
                                list4.add(s3);
                            }
                        }
                    }
                }
                for (final String s4 : linkedHashMap.keySet()) {
                    if (linkedHashMap2.containsKey(s4)) {
                        continue;
                    }
                    linkedHashMap2.put(s4, linkedHashMap.get(s4));
                }
            }
        }
        else if (n2 != 5) {
            reportParseError(5, 59, n2, mailcapTokenizer.getCurrentTokenValue());
        }
    }
    
    protected static void reportParseError(final int n, final int n2, final String s) {
        throw new MailcapParseException(new StringBuffer().append("Encountered a ").append(MailcapTokenizer.nameForToken(n2)).append(" token (").append(s).append(") while expecting a ").append(MailcapTokenizer.nameForToken(n)).append(" token.").toString());
    }
    
    protected static void reportParseError(final int n, final int n2, final int n3, final String s) {
        throw new MailcapParseException(new StringBuffer().append("Encountered a ").append(MailcapTokenizer.nameForToken(n3)).append(" token (").append(s).append(") while expecting a ").append(MailcapTokenizer.nameForToken(n)).append(" or a ").append(MailcapTokenizer.nameForToken(n2)).append(" token.").toString());
    }
    
    protected static void reportParseError(final int n, final int n2, final int n3, final int n4, final String s) {
        if (LogSupport.isLoggable()) {
            LogSupport.log(new StringBuffer().append("PARSE ERROR: Encountered a ").append(MailcapTokenizer.nameForToken(n4)).append(" token (").append(s).append(") while expecting a ").append(MailcapTokenizer.nameForToken(n)).append(", a ").append(MailcapTokenizer.nameForToken(n2)).append(", or a ").append(MailcapTokenizer.nameForToken(n3)).append(" token.").toString());
        }
        throw new MailcapParseException(new StringBuffer().append("Encountered a ").append(MailcapTokenizer.nameForToken(n4)).append(" token (").append(s).append(") while expecting a ").append(MailcapTokenizer.nameForToken(n)).append(", a ").append(MailcapTokenizer.nameForToken(n2)).append(", or a ").append(MailcapTokenizer.nameForToken(n3)).append(" token.").toString());
    }
    
    static {
        MailcapFile.addReverse = false;
        try {
            MailcapFile.addReverse = Boolean.getBoolean("javax.activation.addreverse");
        }
        catch (Throwable t) {}
    }
}
